<?php

namespace App\Controllers;

use App\Models\User;
use TypeRocket\Controllers\WPUserController;
use \TypeRocket\Controllers\Controller;
use \TypeRocket\Http\Response;
use \TypeRocket\Http\Request;
use \App\Models\Student;

class StudentController extends Controller
{

    function frontEndUserUpdate() {

    	$request = new Request();

    	$response = new Response;
    	
    	if ( ! is_user_logged_in() ) {
	    	$response->setError( 'faild', esc_html__( 'Unauthorized Access, Please Register or Signin', 'wow-lms' ) );
			return $response->exitJson(200);
		}

		$options = [
		    //'user_email' 			=> 'required|email',
		    'user_first_name'  		=> 'required|min:3',
		    'user_last_name'		=> 'required|min:3',
		    'display_name'			=> 'required|min:3',
		    'avatar'  				=> 'required',
		    'about'			 		=> 'required',

		];

		$validator = tr_validator($options, $request->getFields());

		$this->validate( $validator, $response );

		$save = ( new Student )->updateUser( $this->passes );

		if ( $save ) {
			$response->setMessage( esc_html__( 'Profile updated successfully', 'wow-lms' ) );

			return $response->exitJson(200);
		}

		$response->setError( esc_html__( 'There is an issue saving profile, please try again after reloading the page', 'wow-lms' ) );

		return $response->exitJson(200);
    }

    /**
	 * [validate description]
	 *
	 * @param  [type] $validator [description]
	 * @param  [type] $response  [description]
	 * @return [type]            [description]
	 */
	function validate( $validator, $response ) {

		$this->errors = $validator->getErrors();
		$this->passes = $validator->getPasses();

		if($validator->getErrors() ) {
			
			$response->setErrors( $this->errors );
		    $validator->flashErrors( $response );
		    return $response->exitJson(200);
		}

	}
}