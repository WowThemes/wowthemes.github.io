<?php

namespace App\Models;

use TypeRocket\Models\WPUser;

class Student extends WPUser
{

	protected $custom_fields = [
		
		'display_name'	=> 'display_name',
		'user_email'	=> 'user_email',
	];

	protected $custom_meta_fields = [
		'avatar'		=> 'avatar',
		'first_name'	=> 'user_first_name',
		'last_name'		=> 'user_last_name',
		'description'	=> 'about'
	];

	function updateUser( $data = array() ) {

		$dn = new \Studentwp_DotNotation( $data );

		$user_fields = [
			'ID'			=> wp_get_current_user()->ID,
			'first_name'	=> $dn->get('user_first_name'),
			'last_name'		=> $dn->get('user_last_name'),
			'display_name'	=> $dn->get('display_name'),
			'description'	=> $dn->get('about')
		];

		$user_id = wp_update_user( $user_fields );

		if ( ! is_wp_error( $user_id ) ) {
			$meta_fields = [
				'avatar'		=> $dn->get('avatar'),
			];

			foreach( $meta_fields as $meta_key => $m_field ) {
				update_user_meta( $user_id, $meta_key, $m_field );
			}
		}

		return true;
	}

	function getFieldValue( $object ) {

		$name = $object->getName();
		$fields = array_flip( $this->custom_fields );
		$field = isset( $fields[$name] ) ? $fields[$name] : '';

		if ( $field ) {
			
			return wp_get_current_user()->data->{$field};
		}


		$fields = array_flip( $this->custom_meta_fields );
		$field = isset( $fields[$name] ) ? $fields[$name] : '';

		return get_user_meta( wp_get_current_user()->ID, $field, true );
	}
}