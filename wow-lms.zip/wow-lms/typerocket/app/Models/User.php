<?php

namespace App\Models;

use TypeRocket\Models\WPUser;

class User extends WPUser
{
}