<?php
/*
|--------------------------------------------------------------------------
| TypeRocket Routes
|--------------------------------------------------------------------------
|
| Manage your web routes here.
|
*/

$protocol = is_ssl() ? 'https://' : 'http://';
$base = str_replace( $protocol.$_SERVER['SERVER_NAME'], '', home_url( '/' ) );

tr_route()->post( $base . 'studentwp/user_profile/update_user_profile', 'frontEndUserUpdate@Student');