<?php
/**
 * Class WP course
 *
 * @package WordPress
 * @subpackage Wow LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

if ( ! class_exists( 'WOWLMS_WP_Course' ) ) {

	/**
	* 
	*/
	class WOWLMS_WP_Course extends Wowlms_Courses
	{
		
		private $course;

		function __construct( int $post_id ) {
			
			$post = get_post( $post_id );

			if ( ! $post ) {
				return;
			}

			

		}
	}
}