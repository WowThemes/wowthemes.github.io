<?php
/**
 * Courses
 *
 * @package WordPress
 * @subpackage WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}


if ( ! class_exists( 'Wowlms_Ajax' ) ) {
	/**
	 * The class to register post types.
	 */
	class Wowlms_Ajax
	{

		/**
		 * [$instance description]
		 *
		 * @var [type]
		 */
		public static $instance;

		static function instance() {
			if ( is_null( self::$instance ) ) {
		      self::$instance = new self();
		    }
		    return self::$instance;
		}


		function init() {

			$method = esc_attr( wowlms_set( $_REQUEST, 'subaction' ) );

			if ( method_exists( $this, $method ) ) {
				$this->$method( $_REQUEST );
			}

			exit();
		}

		function post_form( $data ) {

			$post_data = array();
			$current_user = wp_get_current_user();

			check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

			if ( wp_verify_nonce( wowlms_set( $data, 'cs-framework-metabox-nonce' ), 'cs-framework-metabox' ) ) {

				$post_ID = wowlms_set( $data, 'post_ID' );

				if ( $value = wowlms_set( $data, 'post_title' ) ) {
					$post_data['post_title'] = $value;
				}

				if ( $value = wowlms_set( $data, 'post_content' ) ) {
					$post_data['post_content'] = $value;
				}

				if ( $post_ID ) {
					$post_data['ID'] = $post_ID;
				}

				$post_data['post_type'] = wowlms_set( $data, 'post_type' );
				$post_data['post_status'] = in_array( 'administrator', $current_user->roles ) ? 'publish' : 'pending';

				// Attach the terms data with the array
				$post_data = wowlms_frontend_post_form_taxonomies_set( $post_data, $data );

				if ( $post_ID && is_numeric( $post_ID ) ) {
					$post_id = wp_update_post( $post_data, true );
				} else {
					$post_id = wp_insert_post( $post_data, true );
				}

				if ( ! is_wp_error(  $post_id ) ) {

					$wp_post = get_post( $post_id );

					// Allow plugins to update the post meta.
					do_action( 'save_post', $post_id, $wp_post );

					// Check if post type support thumbnail, then set the post thumbnail.
					if ( post_type_supports( $wp_post->post_type, 'thumbnail' ) ) {
						if ( $thumbnail = wowlms_set( $data, 'thumbnail' ) ) {
							set_post_thumbnail( $post_id, $thumbnail );
						}
					}
				}

			}
		}

		function edit_post_form( $data ) {


			check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );
			
			$post_id = wowlms_set( $data, 'post_id' );

			if ( ! $post_id ) {
				wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'Invalide params', 'wow-lms' ) ) );
			}

			$post_id = str_replace( 'wowlmsgetpostid_', '', base64_decode( $post_id ) );

			if ( ! is_numeric( $post_id ) ) {
				wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'Invalide params for post id', 'wow-lms' ) ) );
			}

			$query = new WP_Query( array( 'post__in' => array( $post_id ), 'posts_per_page' => 1, 'post_type' => 'any' ) );

			if ( ! $query->have_posts() ) {
				wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'No post found for the given ID', 'wow-lms' ) ) );
			}

			if ( ! class_exists( 'Wowlms_Frontend' ) ) {
				require_once WOWLMS_PATH . '/includes/classes/class-frontend.php';
			}

			$object = Wowlms_Frontend::instance();
			$options = apply_filters( 'cs_metabox_options', array() );
			$screen = wowlms_set( $data, 'screen' );
			$current_tab = wowlms_set( $object->get_tabs(), $screen );

			while( $query->have_posts() ) : $query->the_post();

				$post_type = get_post_type();

				wowlms_template_part( 'my-account/post-form.php', compact( 'post_type', 'current_tab', 'object', 'options' ) );
			endwhile;

			wp_reset_postdata();
		}


		function add_post_form( $data ) {


			if ( ! class_exists( 'Wowlms_Frontend' ) ) {
				require_once WOWLMS_PATH . '/includes/classes/class-frontend.php';
			}

			$object = Wowlms_Frontend::instance();
			$options = apply_filters( 'cs_metabox_options', array() );
			$screen = wowlms_set( $data, 'screen' );
			$current_tab = wowlms_set( $object->get_tabs(), $screen );

			//while( $query->have_posts() ) : $query->the_post();

				$post_type = $screen;

				wowlms_template_part( 'my-account/post-form.php', compact( 'post_type', 'current_tab', 'object', 'options' ) );
			//endwhile;

			//wp_reset_postdata();
		}

		function submit_assignment() {

			if ( isset( $_POST['comment'] ) ) {

				if ( isset( $_FILES['assignment_file'] ) ) {

					$res = WOWLMS()->assignments->assignment_comment();

					exit( $res );

				}
			}
		}

		function profile_form() {

			check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

			if ( ! is_user_logged_in() ) {
				exit( '<div class="alert alert-danger">' . esc_html__( 'Restricted Access. Please contact the administrator', 'wow-lms' ) . '</div>' );
			}

			wowlms_template_part( 'my-account/profile-edit.php' );
		}

		function update_profile() {

			check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

			if ( ! is_user_logged_in() ) {
				exit( '<div class="alert alert-danger">' . esc_html__( 'Restricted Access. Please contact the administrator', 'wow-lms' ) . '</div>' );
			}

			$fields = wowlms_profile_fields();

			$validation = WOWLMS()->validation;

			$core = $meta = array();

			$date 	= wowlms_set( $_POST, 'dob_date' );
			$month 	= wowlms_set( $_POST, 'dob_month' );
			$year 	= wowlms_set( $_POST, 'dob_year' );

			if ( $date && $month && $year ) {
				$_POST['dob'] = $year . '-' . $month . '-' . $date;
			}

			foreach ( $fields as $key => $value) {
				
				$validation->set_rules( $key, $key, $value['validation'] );

				if ( 'core' === $value['type'] ) {
					$core[ $key ] = wowlms_set( $_POST, $key );
				} else if ( 'meta' === $value['type'] ) {
					$meta[ $key ] = wowlms_set( $_POST, $key );
				}
			}

			if ( $validation->run() !== FALSE && empty( $t->validation->_error_array ) ) {

				$current_user = wp_get_current_user();
				$core['ID'] = $current_user->ID;

				wp_update_user( $core );

				foreach ( $meta as $key => $value) {
					update_user_meta( $current_user->ID, $key, $value );
				}

			} else {
				if ( is_array( $validation->_error_array ) ) {

					 foreach ( $validation->_error_array as $msg ) {
						 $messages .= '<div class="alert alert-error">'.__('Error! ', 'aplus').$msg.'</div>';
					 }
				}
				exit($messages);
			}
			exit('success');
		}
	}

}
