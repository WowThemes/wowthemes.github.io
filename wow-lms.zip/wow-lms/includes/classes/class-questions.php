<?php
/**
 * Questions
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Wowlms_Questions
{

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	/**
	 * [__construct description]
	 */
	function __construct() {

		self::$instance = $this;

		$this->init();

		add_action( 'init', array( $this, 'post_type' ) );

		// Save Fields.
		add_action( 'publish_course', array( $this, 'woo_process_fields' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_course_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );


	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}


	function init() {

	}
	/**
	 * Prints the output of the custom field in general tab
	 *
	 * @return  void [<description>]
	 */
	
	function enqueue() {
		
	}


	/**
	 * Process the custom fields.
	 *
	 * @param  integer $post_id [description].
	 * @return void          [description]
	 */
	function woo_process_fields( $post_id ) {


		
	}


	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'question' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_question' );

		$permalink        = 'question';

		register_post_type( 'question',
			apply_filters( 'wowlms_register_post_type_question_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Questions', 'wow-lms' ),
							'singular_name'         => __( 'Question', 'wow-lms' ),
							'menu_name'             => _x( 'Questions', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Question', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Question', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Question', 'wow-lms' ),
							'new_item'              => __( 'New Question', 'wow-lms' ),
							'view'                  => __( 'View Question', 'wow-lms' ),
							'view_item'             => __( 'View Question', 'wow-lms' ),
							'search_items'          => __( 'Search Questions', 'wow-lms' ),
							'not_found'             => __( 'No Questions found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Questions found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Question', 'wow-lms' ),
							'featured_image'        => __( 'Question Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Question image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Question image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Question image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Question', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Question', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Questions', 'wow-lms' ),
							'items_list_navigation' => __( 'Questions navigation', 'wow-lms' ),
							'items_list'            => __( 'Questions list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Lessons to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor' ),
					'has_archive'         => true,
					'show_in_nav_menus'   => true,
					'menu_icon'			  => 'dashicons-welcome-learn-more',
					'show_in_menu'		  => 'edit.php?post_type=course',
				)
			)
		);

	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'question' ) ) {
			$default = locate_template( 'single-question.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-question.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_course_fields( $options ) {


		$options[]    = array(
			'id'        => '_wowlms_question_options',
			'title'     => esc_html__( 'Question Options', 'wow-lms' ),
			'post_type' => array( 'question' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

		    	// Begin: a section.
				array(
					'name'  => 'course_info',
					//'title' => esc_html__( 'Course Info', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      			=> 'questions',
							'type'    			=> 'group',
							'title'   			=> esc_html__( 'Question Options', 'wow-lms' ),
							'help'				=> esc_html__( 'Add the question options for multiple choices', 'wow-lms' ),
							'button_title'    	=> esc_html__( 'Add New Option', 'wow-lms' ),
							'accordion_title' 	=> esc_html__( 'Add New Option', 'wow-lms' ),

							'fields' => array(
								array(
									'id'      	=> 'option',
									'type'    	=> 'text',
									'title'   	=> esc_html__( 'Option', 'wow-lms' ),
									'desc' 		=> esc_html__( 'Add the options', 'wow-lms'),
								),
								array(
									'id'      	=> 'desc',
									'type'    	=> 'text',
									'title'   	=> esc_html__( 'Description', 'wow-lms' ),
									'desc' 		=> esc_html__( 'Enter the option description', 'wow-lms'),
								),
							),
						),
					),
				),
		    	// End: a section.

			),
		);

		return $options;
	}

	
	

}

new Wowlms_Questions;
