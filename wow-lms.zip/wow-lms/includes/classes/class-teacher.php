<?php
/**
 * Creating post type array
 *
 * @package Real Estate
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

/**
 * Wow LMS Teachers class.
 */
class Wowlms_Teacher
{

	/**
	 * [__construct description]
	 */
	function __construct() {

		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'post_type' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_teacher_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );
	}

	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'teacher' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_teacher' );

		$permalink        = 'teacher';

		register_post_type( 'teacher',
			apply_filters( 'wowlms_register_post_type_teacher_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Teachers', 'wow-lms' ),
							'singular_name'         => __( 'Teacher', 'wow-lms' ),
							'menu_name'             => _x( 'Teachers', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Teacher', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Teacher', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Teacher', 'wow-lms' ),
							'new_item'              => __( 'New Teacher', 'wow-lms' ),
							'view'                  => __( 'View Teacher', 'wow-lms' ),
							'view_item'             => __( 'View Teacher', 'wow-lms' ),
							'search_items'          => __( 'Search Teachers', 'wow-lms' ),
							'not_found'             => __( 'No Teachers found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Teachers found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Teacher', 'wow-lms' ),
							'featured_image'        => __( 'Teacher Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Teacher image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Teacher image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Teacher image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Teacher', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Teacher', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Teachers', 'wow-lms' ),
							'items_list_navigation' => __( 'Teachers navigation', 'wow-lms' ),
							'items_list'            => __( 'Teachers list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Teachers to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => 'edit.php?post_type=course',
				)
			)
		);
	}


	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_teacher_fields( $options ) {

		$options[]    = array(
			'id'        => '_wowlms_teacher_options',
			'title'     => esc_html__( 'Course Options', 'wow-lms' ),
			'post_type' => array( 'teacher' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'General', 'wow-lms' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'designation',
							'type'  => 'text',
							'title' => esc_html__( 'Designation', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the teacher designation', 'wow-lms' )
						),
		        		// end: a field

						array(
							'id'    => 'expertise',
							'type'  => 'text',
							'title' => esc_html__( 'Expertise', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the teacher expertise', 'wow-lms' ),
						),
						array(
							'id'    => 'block',
							'title'    => esc_html__( 'Before Footer Static Block', 'studentwp' ),
							'type'  => 'select',
							'options' => 'posts',
							'query_args'		=> array(
								'post_type'		=> 'static_block',
							),
							'class'		=> 'chosen',
							'attributes' => array(
								'style' => 'width: 80%;',
							),
							'default_option' => esc_html__( 'No Block', 'studentwp' ),
							'description'		=> sprintf( __( 'Manage <a href="%s" target="_blank">static blocks</a> to show before footer on blog detail page', 'studentwp' ), esc_url( admin_url('edit.php?post_type=static_block' ) ) ),
						),

		      		), // end: fields
		    	), // end: a section


		    	// begin: a section
				array(
					'name'  => 'section_2',
					'title' => esc_html__( 'Information', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'info',
							'type'    => 'group',
							'title'   => esc_html__( 'Information', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the label of information', 'wow-lms' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the value of the information', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_3',
					'title' => esc_html__( 'Skills', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'skills',
							'type'    => 'group',
							'title'   => esc_html__( 'Skills', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the label of Skill', 'wow-lms' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the value of the skill, must be integer. eg: 70', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_4',
					'title' => esc_html__( 'Social Info', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'social',
							'type'    => 'group',
							'title'   => esc_html__( 'Social Profiles', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Social Title', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the name of social website', 'wow-lms' ),
								),
								array(
									'id'    => 'icon',
									'type'  => 'icon',
									'title' => esc_html__( 'Icon', 'wow-lms' ),
									'description'	=> esc_html__( 'Choose social icon', 'wow-lms' ),
								),
								array(
									'id'    => 'link',
									'type'  => 'text',
									'title' => esc_html__( 'URL', 'wow-lms' ),
									'description'	=> esc_html__( 'URL to your social profile', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	
		    	

			),
		);

		return $options;
	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'teacher' ) ) {
			$default = locate_template( 'single-teacher.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-teacher.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}
}

new Wowlms_Teacher;
