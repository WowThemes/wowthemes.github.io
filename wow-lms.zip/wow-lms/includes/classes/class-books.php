<?php
/**
 * WowLMS Books handler file
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

/**
 * The main class books class
 */
class Wowlms_Books
{

	/**
	 * [__construct description]
	 */
	function __construct() {

		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'post_type' ) );
	}

	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'book' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_books_action' );

		$permalink        = 'book';

		register_post_type( 'book',
			apply_filters( 'wowlms_register_post_type_books',
				array(
					'labels'              => array(
							'name'                  => __( 'Books', 'wow-lms' ),
							'singular_name'         => __( 'Book', 'wow-lms' ),
							'menu_name'             => _x( 'Books', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Book', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Book', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Book', 'wow-lms' ),
							'new_item'              => __( 'New Book', 'wow-lms' ),
							'view'                  => __( 'View Book', 'wow-lms' ),
							'view_item'             => __( 'View Book', 'wow-lms' ),
							'search_items'          => __( 'Search Books', 'wow-lms' ),
							'not_found'             => __( 'No Books found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Books found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Book', 'wow-lms' ),
							'featured_image'        => __( 'Book Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Book image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Book image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Book image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Book', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Book', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Books', 'wow-lms' ),
							'items_list_navigation' => __( 'Books navigation', 'wow-lms' ),
							'items_list'            => __( 'Books list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Books to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments', 'custom-fields', 'page-attributes', 'publicize', 'wpcom-markdown' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => true,
					'menu_icon'			  => 'dashicons-book',
				)
			)
		);

		// Add new taxonomy, hierarchical (like category).
		$labels = array(
			'name'                       => _x( 'Writers', 'taxonomy general name', 'textdomain' ),
			'singular_name'              => _x( 'Writer', 'taxonomy singular name', 'textdomain' ),
			'search_items'               => __( 'Search Writers', 'textdomain' ),
			'popular_items'              => __( 'Popular Writers', 'textdomain' ),
			'all_items'                  => __( 'All Writers', 'textdomain' ),
			'parent_item'                => null,
			'parent_item_colon'          => null,
			'edit_item'                  => __( 'Edit Writer', 'textdomain' ),
			'update_item'                => __( 'Update Writer', 'textdomain' ),
			'add_new_item'               => __( 'Add New Writer', 'textdomain' ),
			'new_item_name'              => __( 'New Writer Name', 'textdomain' ),
			'separate_items_with_commas' => __( 'Separate writers with commas', 'textdomain' ),
			'add_or_remove_items'        => __( 'Add or remove writers', 'textdomain' ),
			'choose_from_most_used'      => __( 'Choose from the most used writers', 'textdomain' ),
			'not_found'                  => __( 'No writers found.', 'textdomain' ),
			'menu_name'                  => __( 'Writers', 'textdomain' ),
		);

		$args = array(
			'hierarchical'          => true,
			'labels'                => $labels,
			'show_ui'               => true,
			'show_admin_column'     => true,
			'query_var'             => true,
			'rewrite'               => array( 'slug' => 'writer' ),
		);

		register_taxonomy( 'writer', 'book', $args );
	}
}

new Wowlms_Books;
