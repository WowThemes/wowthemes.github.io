<?php
/**
 * Register Post Types
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}


/**
 * The class to register post types.
 */
class Wowlms_Lessons
{

	protected $meta_key = '_wowlms_lesson_options';

	protected $meta 	= '';

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	/**
	 * [__construct description]
	 */
	function __construct() {

		global $post;

		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'post_type' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_course_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		if ( is_object( $post ) && isset( $post->ID ) ) {
			$this->meta = get_post_meta( get_the_id(), $this->meta_key, true );
		}
	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}

	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'lesson' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_lesson' );

		$permalink        = 'lesson';

		register_post_type( 'lesson',
			apply_filters( 'wowlms_register_post_type_lesson_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Lessons', 'wow-lms' ),
							'singular_name'         => __( 'Lesson', 'wow-lms' ),
							'menu_name'             => _x( 'Lessons', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Lesson', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Lesson', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Lesson', 'wow-lms' ),
							'new_item'              => __( 'New Lesson', 'wow-lms' ),
							'view'                  => __( 'View Lesson', 'wow-lms' ),
							'view_item'             => __( 'View Lesson', 'wow-lms' ),
							'search_items'          => __( 'Search Lessons', 'wow-lms' ),
							'not_found'             => __( 'No Lessons found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Lessons found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Lesson', 'wow-lms' ),
							'featured_image'        => __( 'Lesson Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Lesson image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Lesson image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Lesson image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Lesson', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Lesson', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Lessons', 'wow-lms' ),
							'items_list_navigation' => __( 'Lessons navigation', 'wow-lms' ),
							'items_list'            => __( 'Lessons list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Lessons to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => 'edit.php?post_type=course',
				)
			)
		);
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_course_fields( $options ) {

		$options[]    = array(
			'id'        => $this->meta_key,
			'title'     => esc_html__( 'Lesson Options', 'wow-lms' ),
			'post_type' => array( 'lesson' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'Lesson Settings', 'wow-lms' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'length',
							'type'  => 'text',
							'title' => esc_html__( 'Lesson Length', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the lesson length in minute:seconds', 'wow-lms' )
						),
		        		// end: a field

		      		), // End: fields.
		    	), // End: a section.


		    	// Begin: a section.
				array(
					'name'  => 'lesson_info',
					'title' => esc_html__( 'Video and Audios', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(
						// begin: a field
						array(
							'id'    => 'videos',
							'type'  => 'group',
							'title' => esc_html__( 'Videos and Audios', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the Embed code of videos and audios', 'wow-lms' ),
							'button_title'	=> esc_html__( 'Add Video or Audio', 'wow-lms' ),
							'fields' => array(
								// begin: a field
								array(
									'id'    => 'embed',
									'type'  => 'textarea',
									'title' => esc_html__( 'Embed Code', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter embed codeo of video or audio', 'wow-lms' )
								),
				        		// end: a field
							)
						),
		        		// end: a field
		        		
		        		array(
							'id'    		=> 'assignment',
							'type'  		=> 'select',
							'title' 		=> esc_html__( 'Assignment', 'wow-lms' ),
							'options'		=> 'posts',
							'query_args'	=> array(
									'post_type'			=> 'assignment',
									'posts_per_page'	=> -1,
									'author'			=> get_current_user_id(),
							),
							'class'			=> 'chosen',
						),
						array(
							'id'    		=> 'quiz',
							'type'  		=> 'select',
							'title' 		=> esc_html__( 'Quiz', 'wow-lms' ),
							'options'		=> 'posts',
							'query_args'	=> array(
									'post_type'			=> 'quiz',
									'posts_per_page'	=> -1,
									'author'			=> get_current_user_id(),
							),
							'class'			=> 'chosen',
						),
						array(
							'id'    		=> 'marks',
							'type'  		=> 'group',
							'title' 		=> esc_html__( 'Marks', 'wow-lms' ),
							'button_title'	=> esc_html( 'Marks', 'wow-lms' ),
							'fields'		=> array(

								array(
									'id'    		=> 'label',
									'type'  		=> 'text',
									'title' 		=> esc_html__( 'Label', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter label for mark', 'wow-lms' )
								),
								array(
									'id'    		=> 'total',
									'type'  		=> 'number',
									'title' 		=> esc_html__( 'Total Number', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter Total number for this label', 'wow-lms' )
								),
							)

						),
					),
				),
		    	// End: a section.
			),
		);

		return $options;
	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'lesson' ) ) {
			$default = locate_template( 'single-lesson.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-lesson.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}

	/**
	 * [get_assignments description]
	 *
	 * @return [type] [description]
	 */
	function get_assignments() {

		$meta = $this->meta;

		$data = '';

		if ( $meta ) {

			$data = wowlms_set( $meta, 'assignment' );

		}

		return $data;
	}

	function get_marks() {

		$marks = wowlms_set( $this->meta, 'marks' );

		$return = array();

		if ( $marks && is_array( $marks ) ) {

			$return = $marks;
		}

		$assignment_marks = WOWLMS()->assignments->get_marks( wowlms_set( $this->meta, 'assignment' ) );

		if ( $assignment_marks ) {
			$return[] = array( 'label' => esc_html__( 'Assignment', 'wow-lms' ), 'total' => $assignment_marks );
		}

		if ( $return && is_array( $return ) ) {

			$totals = wp_list_pluck( $return, 'total' );

			$return[] = array( 'label' => esc_html__( 'Total Marks', 'wow-lms' ), 'total' => array_sum( $totals ), 'type' => 'total' );	
		}
		return $return;
	}
}

new Wowlms_Lessons;
