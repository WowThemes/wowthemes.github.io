<?php
/**
 * Quizes
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Wowlms_Quizes
{

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	/**
	 * [__construct description]
	 */
	function __construct() {

		self::$instance = $this;

		$this->init();

		add_action( 'init', array( $this, 'post_type' ) );

		// Save Fields.
		add_action( 'publish_course', array( $this, 'woo_process_fields' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_course_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );


	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}


	function init() {

	}
	/**
	 * Prints the output of the custom field in general tab
	 *
	 * @return  void [<description>]
	 */
	
	function enqueue() {
		
	}


	/**
	 * Process the custom fields.
	 *
	 * @param  integer $post_id [description].
	 * @return void          [description]
	 */
	function woo_process_fields( $post_id ) {


		
	}


	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'quiz' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_quiz' );

		$permalink        = 'quiz';

		register_post_type( 'quiz',
			apply_filters( 'wowlms_register_post_type_quiz_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Quizes', 'wow-lms' ),
							'singular_name'         => __( 'Quiz', 'wow-lms' ),
							'menu_name'             => _x( 'Quizes', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Quiz', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Quiz', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Quiz', 'wow-lms' ),
							'new_item'              => __( 'New Quiz', 'wow-lms' ),
							'view'                  => __( 'View Quiz', 'wow-lms' ),
							'view_item'             => __( 'View Quiz', 'wow-lms' ),
							'search_items'          => __( 'Search Quizes', 'wow-lms' ),
							'not_found'             => __( 'No Quizes found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Quizes found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Quiz', 'wow-lms' ),
							'featured_image'        => __( 'Quiz Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Quiz image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Quiz image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Quiz image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Quiz', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Quiz', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Quizes', 'wow-lms' ),
							'items_list_navigation' => __( 'Quizes navigation', 'wow-lms' ),
							'items_list'            => __( 'Quizes list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Lessons to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor' ),
					'has_archive'         => true,
					'show_in_nav_menus'   => true,
					'menu_icon'			  => 'dashicons-welcome-learn-more',
					'show_in_menu'		  => 'edit.php?post_type=course',
				)
			)
		);

	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'quiz' ) ) {
			$default = locate_template( 'single-quiz.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-quiz.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_course_fields( $options ) {

		$options[]    = array(
			'id'        => '_wowlms_quiz_options',
			'title'     => esc_html__( 'Quiz Settings', 'wow-lms' ),
			'post_type' => array( 'quiz' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'General', 'wow-lms' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'attempts',
							'type'  => 'text',
							'title' => esc_html__( 'Allowed Attempts', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enter number of allowed attempts, leave blank for unlimited attempts', 'wow-lms' )
						),
		        		// end: a field

						array(
							'id'    => 'course_start_date',
							'type'  => 'datepicker',
							'title' => esc_html__( 'Course Start Date', 'wow-lms' ),
							'desc'	=> esc_html__( 'Choose the course start date', 'wow-lms' ),
							'dependency'	=> array( 'duration', '==', 'true' ),
							'attributes'	=> array( 'data-date-format' => 'yy-mm-dd' ),
						),

						array(
							'id'    => 'passing_percentage',
							'type'  => 'number',
							'title' => esc_html__( 'Passing Percentage', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enter the percentage for passing', 'wow-lms' ),
						),
						array(
							'id'    => 'time_limit',
							'type'  => 'number',
							'title' => esc_html__( 'Time Limit', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enter the time limit in seconds', 'wow-lms' ),
						),
						array(
							'id'    		=> 'randomize',
							'type'  		=> 'switcher',
							'title' 		=> esc_html__( 'Randomize Questions', 'wow-lms' ),
							'label' 		=> esc_html__( 'Whether to randomize questions.', 'wow-lms' ),
						),
						array(
							'id'    		=> 'result',
							'type'  		=> 'switcher',
							'title' 		=> esc_html__( 'Show results', 'wow-lms' ),
							'label' 		=> esc_html__( 'Show results on completion of quiz.', 'wow-lms' ),
						),

		      		), // End: fields.
		    	), // End: a section.

				
		    	// Begin: a section.
				array(
					'name'  => 'questions',
					'title' => esc_html__( 'Quiz Questions', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'quiz_questions',
							'type'    => 'group',
							'title'   => esc_html__( 'Quiz Question', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New Question', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Question', 'wow-lms' ),

							'fields' => array(
								array(
									'id'      		=> 'question',
									'type'    		=> 'select',
									'title'   		=> esc_html__( 'Choose Question', 'wow-lms' ),
									'options'		=> 'posts',
									'query_args'	=> array(

											'post_type'			=> 'question',
											'posts_per_page'	=> -1,
											'author'			=> get_current_user_id(),
									),
									'class'			=> 'chosen',
								),
								array(
									'id'      => 'point',
									'type'    => 'number',
									'title'   => esc_html__( 'Point', 'wow-lms' ),
									'default' => 1,
								),
							),
						),
					),
				),
		    	// End: a section.
			),
		);

		return $options;
	}

	
	

}

new Wowlms_Quizes;
