<?php
/**
 * Courses
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Wowlms_Courses
{

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	protected $meta;

	/**
	 * [__construct description]
	 */
	function __construct() {

		global $post;

		self::$instance = $this;

		$this->init();

		// Display Fields.
		//add_action( 'woocommerce_product_options_general_product_data',  array( $this, 'woo_custom_field' ) );

		add_action( 'init', array( $this, 'post_type' ) );

		//add_action( 'woocommerce_product_options_pricing', array( $this, 'woo_custom_field' ) );

		// Save Fields.
		add_action( 'publish_course', array( $this, 'woo_process_fields' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_course_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		//add_shortcode( 'add_new_course', array( $this, 'new_course' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ) );

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue' ) );

		add_filter( 'query_vars', array( $this, 'custom_query_vars_filter' ) );

		add_filter( 'woocommerce_data_stores', array( $this, 'studentwp_woocommerce_data_stores' ) );
		//
		//add_filter( 'wspsc_add_cart_submit_button_value', array( $this, 'wspsc_add_cart_submit_button_value' ) );

		add_filter( 'woocommerce_product_get_price', array( $this, 'woocommerce_get_price' ), 20, 2 );

		if ( ! is_admin() && isset( $post->ID ) ) {
			$this->meta = get_post_meta( $post->ID, '_wowlms_course_options', true );
		}

		add_role( 
			'instructor', 
			esc_html__( 'Instructor', 'wow-lms' ), 
			array(
				'read'         => true,  // true allows this capability
		        'edit_posts'   => true,
		        'delete_posts' => false, // Use false to explicitly deny
			) 
		);
	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}


	function init() {

		$symbol = get_option( 'cart_currency_symbol' );
		$this->symbol = ( $symbol ) ? $symbol : '$';
	}	
	/**
	 * Prints the output of the custom field in general tab
	 *
	 * @return  void [<description>]
	 */
	
	function enqueue() {
		$file = WOWLMS_URL . '/assets/css/wowlms.css';

		if ( file_exists( get_stylesheet_directory().'/css/wowlms.css' ) ) {
			$file = get_stylesheet_directory_uri().'/css/wowlms.css';
		} else if ( file_exists( get_template_directory().'/css/wowlms.css' ) ) {
			$file = get_template_directory_uri().'/css/wowlms.css';
		}

		wp_enqueue_style( 'wowlms_main', $file );
	}


	function admin_enqueue() {
		wp_enqueue_style( 'jquery-ui-core', WOWLMS_URL . '/assets/css/jquery-ui.css' );
		wp_enqueue_style( 'jquery-ui-themes', WOWLMS_URL . '/assets/css/jquery-ui.theme.css' );
	}

	/**
	 * Process the custom fields.
	 *
	 * @param  integer $post_id [description].
	 * @return void          [description]
	 */
	function woo_process_fields( $post_id ) {


		if (
		    false
		) {

			return false;

		} else {

			$_course_price_term = isset( $_POST['_course_price_term'] ) ? $_POST['_course_price_term'] : '';
			if ( $_course_price_term ) {
				update_post_meta( $post_id, '_course_price_term', $_course_price_term );
			}

			$meta = wowlms_set( $_POST, '_wowlms_course_options' );
			$course_start_date = wowlms_set( $meta, 'course_start_date' );
			$course_end_date = wowlms_set( $meta, 'course_end_date' );

			/** @var extras Save the extra values to meta */
			$extras = array( 'price', 'sale_price', 'sale_price_start_date', 'sale_price_end_date', 'price_period' );

			foreach ( $extras as $extra ) {
				
				$posted_value = wowlms_set( $meta, $extra );
				$posted_value = ( strstr( $extra, 'date' ) && $posted_value ) ? date('Y-m-d h:i:s', strtotime( $posted_value ) ) : $posted_value;
				update_post_meta( $post_id, 'wowlms_' . $extra, wowlms_set( $meta, $extra ) );
			}

			//$diff = date('U', strtotime( $course_end_date ) ) - date( 'U', strtotime( $course_start_date ) );
			$diff = human_time_diff( strtotime($course_start_date), strtotime($course_end_date) );

			if ( $diff ) {
				update_post_meta( $post_id, 'course_duration', $diff );
			}

			$level = wowlms_set( $meta, 'course_level' );

			if ( $level ) {
				update_post_meta( $post_id, 'course_level', $level );
			}
		}
	}


	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'course' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_course' );

		$permalink        = 'course';

		register_post_type( 'course',
			apply_filters( 'wowlms_register_post_type_course_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Courses', 'wow-lms' ),
							'singular_name'         => __( 'Course', 'wow-lms' ),
							'menu_name'             => _x( 'Courses', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Course', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Course', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Course', 'wow-lms' ),
							'new_item'              => __( 'New Course', 'wow-lms' ),
							'view'                  => __( 'View Course', 'wow-lms' ),
							'view_item'             => __( 'View Course', 'wow-lms' ),
							'search_items'          => __( 'Search Courses', 'wow-lms' ),
							'not_found'             => __( 'No Courses found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Courses found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Course', 'wow-lms' ),
							'featured_image'        => __( 'Course Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Course image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Course image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Course image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Course', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Course', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Courses', 'wow-lms' ),
							'items_list_navigation' => __( 'Courses navigation', 'wow-lms' ),
							'items_list'            => __( 'Courses list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Lessons to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail', 'comments', 'custom-fields' ),
					'has_archive'         => true,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => true,
					'menu_icon'			  => 'dashicons-welcome-learn-more',
				)
			)
		);


		register_taxonomy( 'course_cat', 'course',
			apply_filters( 'wowlms_register_taxonomy_course_filter',
				array(
					'labels' => array(
							'name'                       => _x( 'Categories', 'taxonomy general name', 'textdomain' ),
							'singular_name'              => _x( 'Category', 'taxonomy singular name', 'textdomain' ),
							'search_items'               => __( 'Search Categories', 'textdomain' ),
							'popular_items'              => __( 'Popular Categories', 'textdomain' ),
							'all_items'                  => __( 'All Categories', 'textdomain' ),
							'parent_item'                => null,
							'parent_item_colon'          => null,
							'edit_item'                  => __( 'Edit Category', 'textdomain' ),
							'update_item'                => __( 'Update Category', 'textdomain' ),
							'add_new_item'               => __( 'Add New Category', 'textdomain' ),
							'new_item_name'              => __( 'New Category Name', 'textdomain' ),
							'separate_items_with_commas' => __( 'Separate Categories with commas', 'textdomain' ),
							'add_or_remove_items'        => __( 'Add or remove Categories', 'textdomain' ),
							'choose_from_most_used'      => __( 'Choose from the most used Categories', 'textdomain' ),
							'not_found'                  => __( 'No Categories found.', 'textdomain' ),
							'menu_name'                  => __( 'Categories', 'textdomain' ),
						),
					'hierarchical'          => true,
					//'labels'                => $labels,
					'show_ui'               => true,
					'show_admin_column'     => true,
					//'update_count_callback' => '_update_post_term_count',
					'query_var'             => true,
					'rewrite'               => array( 'slug' => apply_filters( 'wowlms_courses_cat_slug', 'course_cat' ) ),
				)
			)
		);



	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'course' ) ) {
			$default = locate_template( 'single-course.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-course.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_course_fields( $options ) {

		$options[]    = array(
			'id'        => '_wowlms_course_options',
			'title'     => esc_html__( 'Course Options', 'wow-lms' ),
			'post_type' => array( 'course' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'Course Settings', 'wow-lms' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'course_detail_link',
							'type'  => 'text',
							'title' => esc_html__( 'Course Detail Link', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enter the custom course detail page link ( optional ), leave blank if you want to user to go proper course detial page', 'wow-lms' )
						),
		        		// begin: a field
						array(
							'id'    => 'duration',
							'type'  => 'switcher',
							'title' => esc_html__( 'Enable Course Duration', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enable to Choose the course duration between two dates', 'wow-lms' )
						),
		        		// end: a field

						array(
							'id'    => 'course_start_date',
							'type'  => 'datepicker',
							'title' => esc_html__( 'Course Start Date', 'wow-lms' ),
							'desc'	=> esc_html__( 'Choose the course start date', 'wow-lms' ),
							'dependency'	=> array( 'duration', '==', 'true' ),
							'attributes'	=> array( 'data-date-format' => 'yy-mm-dd' ),
						),

						array(
							'id'    => 'course_end_date',
							'type'  => 'datepicker',
							'title' => esc_html__( 'Course End Date', 'wow-lms' ),
							'desc'	=> esc_html__( 'Choose the course end date', 'wow-lms' ),
							'dependency'	=> array( 'duration', '==', 'true' ),
							'attributes'	=> array( 'data-date-format' => 'yy-mm-dd' ),
						),
						array(
							'id'    => 'course_level',
							'type'  => 'text',
							'title' => esc_html__( 'Course Level', 'wow-lms' ),
							'desc'	=> esc_html__( 'Enter course leve eg: leve 1, level2 etc', 'wow-lms' ),
						),
						array(
							'id'    		=> 'teacher',
							'type'  		=> 'select',
							'title' 		=> esc_html__( 'Teacher', 'wow-lms' ),
							'label' 		=> esc_html__( 'Yes, Please do it.', 'wow-lms' ),
							'options'		=> 'posts',
							'query_args'	=> array(
									'post_type'			=> 'teacher',
									'posts_per_page'	=> -1,
							),
							'class'			=> 'chosen',
							'roles'			=> array( 'administrator' )
						),

		      		), // End: fields.
		    	), // End: a section.

				// Begin: a section.
				array(
					'name'  => 'course_pricing',
					'title' => esc_html__( 'Pricing Info', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'			=> 'price',
							'type'			=> 'number',
							'title'			=> esc_html__( 'Price', 'studentwp' ),
							'after'			=> __( '<p><small class="cs-text-desc">Enter the price of the course, 0 (zero ) for free course.</small></p>', 'studentwp' ),
						),
						array(
							'id'			=> 'sale_price_status',
							'type'			=> 'switcher',
							'title'			=> esc_html__( 'Enable Sale Price', 'studentwp' ),
							'after'			=> __( '<p><small class="cs-text-desc">Enable sale price</small></p>', 'studentwp' ),
						),
						array(
							'id'			=> 'sale_price',
							'type'			=> 'number',
							'title'			=> esc_html__( 'Sale Price', 'studentwp' ),
							'help'			=> esc_html__( 'Enter the sale price.', 'studentwp' ),
							'dependency'	=> array( 'sale_price_status', '==', 'true' )
						),
						array(
							'id'			=> 'sale_price_start_date',
							'type'			=> 'datepicker',
							'title'			=> esc_html__( 'Sale Price Start Date', 'studentwp' ),
							'dependency'	=> array( 'sale_price_status', '==', 'true' ),
						),
						array(
							'id'			=> 'sale_price_end_date',
							'type'			=> 'datepicker',
							'title'			=> esc_html__( 'Sale Price End date', 'studentwp' ),
							'help'			=> esc_html__( 'Choose the sale price end date.', 'studentwp' ),
							'dependency'	=> array( 'sale_price_status', '==', 'true' ),
						),
					
						array(
							'id'			=> 'price_period',
							'type'			=> 'select',
							'title'			=> esc_html__( 'Price Period', 'studentwp' ),
							'help'			=> esc_html__( 'Choose the price period.', 'studentwp' ),
							'class'			=> 'chosen',
							'options'		=> apply_filters( 'wowlms_course_terms_options', array(
													'month'            	=> __( 'Per Month', 'wow-lms' ),
													'3month' 			=> __( 'Per 3 Month', 'wow-lms' ),
													'6month'	   	    => __( 'Per 6 Month', 'wow-lms' ),
													'year'	   	    	=> __( 'Per Year', 'wow-lms' ),
												) ),
						),
							
					),
				),
		    	// Begin: a section.
				array(
					'name'  => 'course_info',
					'title' => esc_html__( 'Course Info', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'			=> 'featured_video',
							'type'			=> 'text',
							'title'			=> esc_html__( 'Featured Video', 'studentwp' ),
							'after'			=> __( '<p><small class="cs-text-desc">Paste the url for a Wistia, Vimeo or Youtube video or a hosted video file. For a full list of supported providers see <a href="https://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F" target="_blank">WordPress oEmbeds</a></small></p>', 'studentwp' ),
						),
						array(
							'id'			=> 'featured_audio',
							'type'			=> 'text',
							'title'			=> esc_html__( 'Featured Audio', 'studentwp' ),
							'after'			=> __( '<p><small class="cs-text-desc">Paste the url for a SoundCloud or Spotify song or a hosted audio file. For a full list of supported providers see <a href="https://codex.wordpress.org/Embeds#Okay.2C_So_What_Sites_Can_I_Embed_From.3F" target="_blank">WordPress oEmbeds</a></small></p>', 'studentwp' ),
						),
						array(
							'id'			=> 'course_capacity_status',
							'type'			=> 'switcher',
							'title'			=> esc_html__( 'Enable Course Capacity', 'studentwp' ),
							'help'			=> esc_html__( 'Limit the number of users that can enroll in this course.', 'studentwp' ),
						),
						array(
							'id'			=> 'course_capacity',
							'type'			=> 'text',
							'title'			=> esc_html__( 'Course Capatcity', 'studentwp' ),
							'dependency'	=> array( 'course_capacity_status', '==', 'true' ),
						),
						array(
							'id'			=> 'course_capacity_msg',
							'type'			=> 'text',
							'title'			=> esc_html__( 'Course Capatcity Reach Message', 'studentwp' ),
							'help'			=> esc_html__( 'This message will be displayed to non-enrolled visitors once the Course Capacity has been reached.', 'studentwp' ),
							'dependency'	=> array( 'course_capacity_status', '==', 'true' ),
						),
						array(
							'id'      => 'course_info',
							'type'    => 'group',
							'title'   => esc_html__( 'Course Information', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),

							'fields' => array(
								array(
									'id'      => 'label',
									'type'    => 'text',
									'title'   => esc_html__( 'Label', 'wow-lms' ),
									'default' => esc_html__( 'Lectures', 'wow-lms'),
								),
								array(
									'id'      => 'value',
									'type'    => 'textarea',
									'title'   => esc_html__( 'Value', 'wow-lms' ),
									'default' => esc_html__( '65', 'wow-lms'),
								),
							),
						),
					),
				),
		    	// End: a section.

				// Begin: a section.
				array(
					'name'  => 'lesson_settings',
					'title' => esc_html__( 'Lessons Settings', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      		=> 'lessons',
							'type'    		=> 'select',
							'title'   		=> esc_html__( 'Lessons', 'wow-lms' ),
							'options'		=> 'posts',
							'query_args'	=> array(

									'post_type'			=> 'lesson',
									'posts_per_page'	=> -1,
									'author'			=> get_current_user_id(),
							),
							'class'			=> 'chosen',
							'attributes'	=> array( 'multiple' => 'multiple' ),
						),
					),
				),
		    	// End: a section.
			),
		);

		return $options;
	}

	
	/**
	 * Sync product rating count. Can be called statically.
	 * @param  int $post_id
	 */
	public static function sync_rating_count( $post_id ) {
		global $wpdb;

		$counts     = array();
		$raw_counts = $wpdb->get_results( $wpdb->prepare( "
			SELECT meta_value, COUNT( * ) as meta_value_count FROM $wpdb->commentmeta
			LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
			WHERE meta_key = 'rating'
			AND comment_post_ID = %d
			AND comment_approved = '1'
			AND meta_value > 0
			GROUP BY meta_value
		", $post_id ) );

		foreach ( $raw_counts as $count ) {
			$counts[ $count->meta_value ] = $count->meta_value_count;
		}

		update_post_meta( $post_id, '_wc_rating_count', $counts );
	}

	/**
	 * Sync product rating. Can be called statically.
	 * @param  int $post_id
	 */
	public static function sync_average_rating( $post_id ) {
		if ( ! metadata_exists( 'post', $post_id, '_wc_rating_count' ) ) {
			self::sync_rating_count( $post_id );
		}

		$count = array_sum( (array) get_post_meta( $post_id, '_wc_rating_count', true ) );

		if ( $count ) {
			global $wpdb;

			$ratings = $wpdb->get_var( $wpdb->prepare("
				SELECT SUM(meta_value) FROM $wpdb->commentmeta
				LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
				WHERE meta_key = 'rating'
				AND comment_post_ID = %d
				AND comment_approved = '1'
				AND meta_value > 0
			", $post_id ) );
			$average = number_format( $ratings / $count, 2, '.', '' );
		} else {
			$average = 0;
		}
		update_post_meta( $post_id, '_wc_average_rating', $average );
	}

	/**
	 * Get the total amount (COUNT) of ratings.
	 * @param  int $value Optional. Rating value to get the count for. By default returns the count of all rating values.
	 * @return int
	 */
	public function get_rating_count( $value = null ) {
		// No meta data? Do the calculation
		if ( ! metadata_exists( 'post', get_the_id(), '_wc_rating_count' ) ) {
			$this->sync_rating_count( get_the_id() );
		}

		$counts = array_filter( (array) get_post_meta( get_the_id(), '_wc_rating_count', true ) );

		if ( is_null( $value ) ) {
			return array_sum( $counts );
		} else {
			return isset( $counts[ $value ] ) ? $counts[ $value ] : 0;
		}
	}

	/**
	 * Get the average rating of product. This is calculated once and stored in postmeta.
	 * @return string
	 */
	public function get_average_rating() {
		// No meta data? Do the calculation
		if ( ! metadata_exists( 'post', get_the_id(), '_wc_average_rating' ) ) {
			$this->sync_average_rating( get_the_id() );
		}

		return (string) floatval( get_post_meta( get_the_id(), '_wc_average_rating', true ) );
	}

	/**
	 * Returns the product rating in html format.
	 *
	 * @param string $rating (default: '')
	 *
	 * @return string
	 */
	public function get_rating_html( $rating = null ) {
		$rating_html = '';

		if ( ! is_numeric( $rating ) ) {
			$rating = $this->get_average_rating();
		}

		if ( $rating > 0 ) {

			$rating_html  = '<div class="star-rating" title="' . sprintf( __( 'Rated %s out of 5', 'wow-lms' ), $rating ) . '">';

			$rating_html .= '<span style="width:' . ( ( $rating / 5 ) * 100 ) . '%"><strong class="rating">' . $rating . '</strong> ' . __( 'out of 5', 'wow-lms' ) . '</span>';

			$rating_html .= '</div>';
		}

		return apply_filters( 'woocommerce_product_get_rating_html', $rating_html, $rating );
	}

	/**
	 * Get the total amount (COUNT) of reviews.
	 *
	 * @since 2.3.2
	 * @return int The total numver of product reviews
	 */
	public function get_review_count() {
		global $wpdb;

		// No meta date? Do the calculation
		if ( ! metadata_exists( 'post', get_the_id(), '_wc_review_count' ) ) {
			$count = $wpdb->get_var( $wpdb->prepare("
				SELECT COUNT(*) FROM $wpdb->comments
				WHERE comment_parent = 0
				AND comment_post_ID = %d
				AND comment_approved = '1'
			", $this->id ) );

			update_post_meta( get_the_id(), '_wc_review_count', $count );
		} else {
			$count = get_post_meta( get_the_id(), '_wc_review_count', true );
		}

		return apply_filters( 'woocommerce_product_review_count', $count, $this );
	}


	/**
	 * [get_formatted_price description]
	 * 
	 * @param  [type] $id [description]
	 * @return [type]     [description]
	 */
	function get_formatted_price( $id = null ) {

		$id = ( $id ) ? $id : get_the_id();

		$price = get_post_meta( $id, 'wowlms_price', true );

		if ( ! $price ) {
			return;
		}

		return $this->price_html( $id, (int) $price );
	}

	function get_price( $id ) {

		$meta = ( $this->meta ) ? $$this->meta : get_post_meta( $id, '_wowlms_course_options', true );

		$price = get_post_meta( $id, 'wowlms_price', true );

		if ( $sale_price = $this->sale_price( $id ) ) {
			return $sale_price;
		}

		return $price;

	}

	function sale_price( $id ) {
		$meta = ( $this->meta ) ? $this->meta : get_post_meta( $id, '_wowlms_course_options', true );

		$status = wowlms_set( $meta, 'sale_price_status' );
		$sale_price = wowlms_set( $meta, 'sale_price' );
		$start = strtotime( wowlms_set( $meta, 'sale_price_start_date' ) );
		$end = strtotime( wowlms_set( $meta, 'sale_price_end_date' ) );

		if ( ! $status ) {
			return;
		}

		if ( $start < time() && time() < $end ) {
			return $sale_price;
		}

		return false;
	}

	/**
	 * [sale_price description]
	 *
	 * @param  int    $id    [description]
	 * @param  int    $price [description]
	 * @return [type]        [description]
	 */
	function price_html( $id, $price ) {

		$meta = ( $this->meta ) ? $this->meta : get_post_meta( $id, '_wowlms_course_options', true );

		$status = wowlms_set( $meta, 'sale_price_status' );
		$sale_price = wowlms_set( $meta, 'sale_price' );
		$start = strtotime( wowlms_set( $meta, 'sale_price_start_date' ) );
		$end = strtotime( wowlms_set( $meta, 'sale_price_end_date' ) );
		$period = wowlms_set( $meta, 'price_period' );
		$period = ( $period ) ? ' / ' . ucwords( $period ) : '';

		$return = '<span class="regular-price">' . $this->format( $price ) . '</span>';

		if ( ! $status ) {
			return $return;
		}

		if ( $start < time() && time() < $end ) {

			return '<span class="price-on-sale">'. $return . '<span class="sale-price">' . $this->format( $sale_price ) . '</span>' . $period . '</span>';
		}

		return $return . $period;
	}

	/**
	 * [format description]
	 *
	 * @param  int    $integer [description]
	 * @return [type]          [description]
	 */
	function format( $integer ) {

		return $this->symbol . number_format( $integer, 0 );
	}


	function add_to_cart() {

		wowlms_template_part( 'single-course/add-to-cart.php' );
	}

	/**
	 * [wspsc_add_cart_submit_button_value description] Deprecated
	 * @param  [type] $value [description]
	 * @return [type]        [description]
	 */
	function wspsc_add_cart_submit_button_value( $value ) {

		global $post_type;

		if ( 'course' === $post_type ) {
			return esc_html__( 'Take Course', 'wow-lms' );
		}

		return $value;
	}
	/**
	 * [custom_query_vars_filter description]
	 *
	 * @param  [type] $vars [description]
	 * @return [type]       [description]
	 */
	function custom_query_vars_filter( $vars ) {
		$vars[] = 'course_duration';
		$vars[] .= 'course_level';
		$vars[] .= 'fee_range';
		return $vars;
	}

	/**
	 * [studentwp_woocommerce_data_stores description]
	 *
	 * @param  [type] $stores [description]
	 * @return [type]         [description]
	 */
	function studentwp_woocommerce_data_stores( $stores ) {

		require_once WOWLMS_PATH . '/includes/classes/class-course-data-store-cpt.php';
		$stores['product'] = 'StudentWP_Product_Data_Store_CPT';

		return $stores;
	}

	/**
	 * [woocommerce_get_price description]
	 *
	 * @param  [type] $price [description].
	 * @param  [type] $post  [description].
	 * @return [type]        [description]
	 */
	function woocommerce_get_price( $price, $post ) {

		if ( get_post_type( $post->get_id() ) === 'course') {
			$price = $this->get_price( $post->get_id() );
		}

		return $price;
	}

}

new Wowlms_Courses;
