<?php
/**
 * Courses
 *
 * @package WordPress
 * @subpackage WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Wowlms_Assignments
{

	protected $meta_key = '_sh_assignment_settings';

	protected $meta 	= '';

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	/**
	 * [__construct description]
	 */
	function __construct() {

		global $post;

		if ( ! function_exists( 'WC' ) ) {
			return;
		}

		add_action( 'init', array( $this, 'post_type' ) );

		// Save Fields.
		add_action( 'publish_assignment', array( $this, 'process_fields' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_assignment_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		//add_shortcode( 'add_new_course', array( $this, 'new_course' ) );
		
		if ( is_object( $post ) && isset( $post->ID ) ) {
			$this->meta = get_post_meta( get_the_id(), $this->meta_key, true );
		}
	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}

	/**
	 * Prints the output of the custom field in general tab
	 *
	 * @return  void [<description>]
	 */
	function woo_custom_field() {

		include WOWLMS_PATH . 'includes/views/fields.php';
	}

	/**
	 * Process the custom fields.
	 *
	 * @param  integer $post_id [description].
	 * @return void          [description]
	 */
	function woo_process_fields( $post_id ) {


		if (
		    ! isset( $_POST['wowlms_nonce_field'] )
		    || ! wp_verify_nonce( wp_unslash( $_POST['wowlms_nonce_field'] ), 'wowlms_nonce_field_action' )
		) {

			return false;

		} else {

			$_course_price_term = isset( $_POST['_course_price_term'] ) ? $_POST['_course_price_term'] : '';
			if ( $_course_price_term ) {
				update_post_meta( $post_id, '_course_price_term', $_course_price_term );
			}
		}
	}


	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'assignment' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_assignment' );

		$permalink        = 'assignment';

		register_post_type( 'assignment',
			apply_filters( 'wowlms_register_post_type_assignment_filter',
				array(
					'labels'              => array(
							'name'                  => __( 'Assignments', 'wow-lms' ),
							'singular_name'         => __( 'Assignment', 'wow-lms' ),
							'menu_name'             => _x( 'Assignments', 'Admin menu name', 'wow-lms' ),
							'add_new'               => __( 'Add Assignment', 'wow-lms' ),
							'add_new_item'          => __( 'Add New Assignment', 'wow-lms' ),
							'edit'                  => __( 'Edit', 'wow-lms' ),
							'edit_item'             => __( 'Edit Assignment', 'wow-lms' ),
							'new_item'              => __( 'New Assignment', 'wow-lms' ),
							'view'                  => __( 'View Assignment', 'wow-lms' ),
							'view_item'             => __( 'View Assignment', 'wow-lms' ),
							'search_items'          => __( 'Search Assignments', 'wow-lms' ),
							'not_found'             => __( 'No Assignments found', 'wow-lms' ),
							'not_found_in_trash'    => __( 'No Assignments found in trash', 'wow-lms' ),
							'parent'                => __( 'Parent Assignment', 'wow-lms' ),
							'featured_image'        => __( 'Assignment Image', 'wow-lms' ),
							'set_featured_image'    => __( 'Set Assignment image', 'wow-lms' ),
							'remove_featured_image' => __( 'Remove Assignment image', 'wow-lms' ),
							'use_featured_image'    => __( 'Use as Assignment image', 'wow-lms' ),
							'insert_into_item'      => __( 'Insert into Assignment', 'wow-lms' ),
							'uploaded_to_this_item' => __( 'Uploaded to this Assignment', 'wow-lms' ),
							'filter_items_list'     => __( 'Filter Assignments', 'wow-lms' ),
							'items_list_navigation' => __( 'Assignments navigation', 'wow-lms' ),
							'items_list'            => __( 'Assignments list', 'wow-lms' ),
						),
					'description'         => __( 'This is where you can add new Lessons to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'thumbnail', 'comments' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => 'edit.php?post_type=course',
					'menu_icon'			  => 'dashicons-welcome-learn-more',
				)
			)
		);


	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'assignment' ) ) {
			$default = locate_template( 'single-assignment.php' );

			if ( ! file_exists( $default ) ) {
				$file = wowlms_template_part( 'single-assignment.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_assignment_fields( $options ) {

		$options[]    = array(
			'id'        => $this->meta_key,
			'title'     => esc_html__('Assignment Settings', 'studentwp'),
			'post_type' => array( 'assignment' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

					array(
						'name'   => '_sh_assignment_settings',
						'fields' => array(

							array(
								'id' 			=> 'files',
								'type' 			=> 'group',
								'title' 		=> esc_html__( 'Files', 'wow-lms' ),
								'button_title'	=> esc_html__( 'Add Files', 'wow-lms' ),
								'fields'		=> array(

									array(
										'id'      	=> 'file',
										'type'  	=> 'upload',
										'title'   	=> esc_html__( 'Choose File', 'wow-lms' ),
										'desc'    	=> esc_html__( 'Choose file for the assignment.', 'wow-lms' ),
									)
								)
							),

							array(
								'id'      	=> 'mark',
								'type'  	=> 'number',
								'title'   	=> esc_html__( 'Total Marks', 'wow-lms' ),
								'desc'    	=> esc_html__( 'Enter the total marks of the assignment.', 'wow-lms' ),
							)
							
						),
					),

			),
		);
		

		return $options;
	}

	function get_marks( $post_id = 0 ) {

		$meta = $this->meta;

		if ( $post_id ) {
			$meta = get_post_meta( $post_id, $this->meta_key, true );
		}

		$marks = wowlms_set( $meta, 'mark' );

		if ( $marks ) {
			return $marks;
		}

		return false;
	}

	function is_accessible( $post_id = '' ) {

		$lesson_id = wowlms_set( $_GET, 'lesson_id', 0 );

		if ( ! is_user_logged_in() ) {
			return false;
		}

		if ( ! $lesson_id ) {
			return false;
		}

		if ( 'lesson' !== get_post_type( $lesson_id ) ) {
			return false;
		}

		/*if ( ! wowlms_wc_customer_baught_product( $course_id ) ) {
			return false;
		}*/

		$meta = get_post_meta( $lesson_id, '_wowlms_lesson_options', true );
		$assignment = studentwp_set( $meta, 'assignment' );

		if ( get_the_id() != $assignment ) {
			return false;
		}

		return true;

	}


	function assignment_comment() {

		if ( ! function_exists( 'wp_handle_upload' ) ) {
		    require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}

		$uploadedfile = $_FILES['assignment_file'];

		$upload_overrides = array( 'test_form' => false );

		$movefile = wp_handle_upload( $uploadedfile, $upload_overrides );

		if ( $movefile && ! isset( $movefile['error'] ) ) {
		    /*echo "File is valid, and was successfully uploaded.\n";
		    var_dump( $movefile );*/
		    $comment = wp_handle_comment_submission( $_POST );
		    //printr($comment);
		    if ( ! is_wp_error( $comment ) ) {
		    	update_comment_meta( $comment->comment_ID, 'assignment_file_type', wowlms_set( $movefile, 'type' ) );
		    	update_comment_meta( $comment->comment_ID, 'assignment_file_url', wowlms_set( $movefile, 'url' ) );
		    	update_comment_meta( $comment->comment_ID, 'assignment_file_path', wowlms_set( $movefile, 'file' ) );

		    	return '<div class="alert alert-success">'.esc_html__( 'Feedback posted successfully', 'wow-lms' ) . '</div>';
		    } else {
		    	return '<div class="alert alert-danger">'. $comment->get_error_message() . '</div>';
		    }
		} else {
		    /**
		     * Error generated by _wp_handle_upload()
		     * @see _wp_handle_upload() in wp-admin/includes/file.php
		     */
		    return '<div class="alert alert-danger">'.$movefile['error'].'</div>';
		}

		


	}
}

new Wowlms_Assignments;
