<?php
/**
 * Pre defined helper functions.
 *
 * @package WordPress
 * @subpackage WowLMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

add_action( 'wp_ajax__wowlms_ajax_callback', array( Wowlms_Ajax::instance(), 'init' ) );


function WOWLMS() {

	if ( ! class_exists( 'Wowlms' ) ) {
		require_once WOWLMS_PATH . 'includes/classes/class-wowlms.php';
	}

	return $GLOBALS['WOWLMS'];
}

if ( ! function_exists( 'wowlms_set' ) ) {

	/**
	 * [studentwp_set description]
	 *
	 * @param  [type] $var [description].
	 * @param  [type] $key [description].
	 * @param  string $def [description].
	 * @return [type]      [description]
	 */
	function wowlms_set( $var, $key, $def = '' ) {

		if ( is_object( $var ) && isset( $var->$key ) ) {
			return $var->$key;
		} elseif ( is_array( $var ) && isset( $var[ $key ] ) ) {
			return $var[ $key ];
		} elseif ( $def ) {
			return $def;
		} else {
			return false;
		}
	}
}

if ( ! function_exists( 'wowlms_template_part' ) ) {

	/**
	 * [wowlms_template_part description]
	 *
	 * @param  [type]  $template [description].
	 * @param  array   $vars     [description].
	 * @param  boolean $load     [description].
	 * @return string              [description]
	 */
	function wowlms_template_part( $template, $vars = array(), $load = true ) {

		$locate = locate_template( 'wowlms/' . $template );

		$return = '';

		extract( $vars );

		if ( $locate ) {
			$return = $locate;

		} elseif ( file_exists( WOWLMS_PATH . 'templates/' . $template ) ) {
			$return = WOWLMS_PATH . 'templates/' . $template;
		}

		if ( $load && $return ) {
			include $return;
		} else {
			return $return;
		}
	}
}

function wowlms_check_lesson_access() {

	$course_id = wowlms_set( $_GET, 'course_id', 0 );

	if ( ! is_user_logged_in() ) {
		return false;
	}

	if ( ! $course_id ) {
		return false;
	}

	if ( 'course' !== get_post_type( $course_id ) ) {
		return false;
	}

	if ( ! wowlms_wc_customer_baught_product( $course_id ) ) {
		return false;
	}

	$meta = get_post_meta( $course_id, '_wowlms_course_options', true );
	$lessons = studentwp_set( $meta, 'lessons' );

	if ( ! in_array( get_the_id(), $lessons ) ) {
		return;
	}

	return true;
}

/**
 * [wowlms_wc_customer_baught_product description]
 *
 * @param  integer $id [description].
 * @return [type]      [description]
 */
function wowlms_wc_customer_baught_product( $id = 0 ) {

	if ( ! $id ) {
		$id = get_the_id();
	}

	if ( function_exists( 'wc_customer_bought_product' ) ) {
		return wc_customer_bought_product( wp_get_current_user()->user_email, get_current_user_id(), $id );
	}

	// Get All order of current user.
	$orders = get_posts( array(
	    'numberposts' => 10,
	    'meta_key'    => '_customer_user',
	    'meta_value'  => get_current_user_id(),
	    'post_type'   => wc_get_order_types( 'view-orders' ),
	    'post_status' => array_keys( wc_get_order_statuses() ),
	) );

	if ( ! $orders ) {
		return false; // Return if no order found.
	}

	$all_ordered_product = array(); // Store all products ordered by ID in an array.

	foreach ( $orders as $order => $data ) { // Loop through each order
	    $order_data = new WC_Order( $data->ID ); // create new object for each order
	    foreach ( $order_data->get_items() as $key => $item ) {  // loop through each order item
	        // Store in array with product ID as key and order date a value.
	        $all_ordered_product[ $item['product_id'] ] = $data->post_date;
	    }
	}
	// Check if defined ID is found in array.
	if ( isset( $all_ordered_product[ $id ] ) ) {
		return true;
	} else {
		return false;
	}
}

/**
 * Get the total amount (COUNT) of reviews.
 *
 * @since 2.3.2
 * @return int The total numver of product reviews
 */
function wowlms_get_review_count() {
	global $wpdb, $post;
	
	// No meta date? Do the calculation
	if ( ! metadata_exists( 'post', get_the_id(), '_wlms_review_count' ) ) {
		$count = $wpdb->get_var( $wpdb->prepare("
			SELECT COUNT(*) FROM $wpdb->comments
			WHERE comment_parent = 0
			AND comment_post_ID = %d
			AND comment_approved = '1'
		", get_the_id() ) );

		update_post_meta( get_the_id(), '_wlms_review_count', $count );
	} else {
		$count = get_post_meta( get_the_id(), '_wlms_review_count', true );
	}

	return apply_filters( 'wowlms_course_review_count', $count, $post );
}

/**
 * [get_course_subjects description]
 *
 * @param  [type]  $course_id [description].
 * @param  boolean $user      [description].
 * @return [type]             [description]
 */
function get_course_lessons_link( $course_id, $user = false ) {

	$meta = get_post_meta( $course_id, '_wowlms_course_options', true );

	$lessons = isset( $meta['lessons'] ) ? $meta['lessons'] : '';

	$link = '';

	if ( $lessons ) {
		if ( isset( $lessons[0] ) ) {
			$get_post = get_post( $lessons[0] );

			$course_permalink = add_query_arg( array( 'course_id' => $course_id ), get_permalink( $get_post->ID ) );
			if ( $get_post ) {
				$link = '<a class="btn btn-primary" href="'.esc_url( $course_permalink ).'" title="'.esc_attr( $get_post->post_title ).'">'
					.esc_html__( 'Take Lessons', 'wow-lms' ).
				'</a>';
			}
		}
	}

	if ( $link ) {
		return $link;
	} else {
		return __( '<h3>No lessons found for this course', 'wow-lms' );
	}
}



/**
 * [course_total_students_enrolled description]
 *
 * @param  [type] $course_id [description].
 * @return [type]            [description]
 */
function course_total_students_enrolled( $course_id ) {

	$number = $units_sold = get_post_meta( $course_id, 'total_sales', true );

	return number_format( $number );
}


/**
 * [qvrenti_wow_themes_star_rating description]
 *
 * @param  boolean $dis [description].
 * @return void       [description]
 */
function wowlms_star_rating( $post_id ) {

	
	$count = array_sum( (array) get_post_meta( $post_id, '_wowlms_rating_count', true ) );

	if ( $count ) {
		global $wpdb;

		$ratings = $wpdb->get_var( $wpdb->prepare("
			SELECT SUM(meta_value) FROM $wpdb->commentmeta
			LEFT JOIN $wpdb->comments ON $wpdb->commentmeta.comment_id = $wpdb->comments.comment_ID
			WHERE meta_key = 'rating'
			AND comment_post_ID = %d
			AND comment_approved = '1'
			AND meta_value > 0
		", $post_id ) );
		$average = number_format( $ratings / $count, 2, '.', '' );
	} else {
		$average = 0;
	}
	update_post_meta( $post_id, '_wc_average_rating', $average );
}


add_action( 'comment_post','wowlms_review_comments', 99, 2 );

/**
 * [wowlms_review_comments description]
 *
 * @return [type] [description]
 */
function wowlms_review_comments( $comment_id ) {

	if ( isset( $_POST['rating'] ) && 'course' === get_post_type( $_POST['comment_post_ID'] ) ) {
		if ( ! $_POST['rating'] || $_POST['rating'] > 5 || $_POST['rating'] < 0 ) {
			return;
		}
		update_comment_meta( $comment_id, 'rating', (int) esc_attr( $_POST['rating'] ), true );
	}

	wowlms_verified_review( $comment_id );
}

/**
 * [wowlms_verified_review description]
 *
 * @return [type] [description]
 */
function wowlms_verified_review( $comment_id ) {

	$comment  = get_comment( $comment_id );
	$verified = false;
	if ( 'course' === get_post_type( $comment->comment_post_ID ) ) {
		$verified = wowlms_wc_customer_baught_product( $comment->comment_author_email, $comment->user_id, $comment->comment_post_ID );
		update_comment_meta( $comment_id, 'verified', (int) $verified, true );
	}
	return $verified;

}



/**
 * [render_meta_box_content description]
 *
 * @param  [type] $post     [description].
 * @param  [type] $callback [description].
 * @return [type]           [description]
 */
function wowlms_render_meta_box_content( $post, $callback ) {

	global $post, $cs_errors, $typenow;

	wp_nonce_field( 'cs-framework-metabox', 'cs-framework-metabox-nonce' );

	$unique     = $callback['args']['id'];
	$sections   = $callback['args']['sections'];
	$meta_value = get_post_meta( $post->ID, $unique, true );
	$transient  = get_transient( 'cs-metabox-transient' );
	$cs_errors  = $transient['errors'];
	$has_nav    = ( count( $sections ) >= 2 && $callback['args']['context'] != 'side' ) ? true : false;
	$show_all   = ( ! $has_nav ) ? ' cs-show-all' : '';
	$section_id = ( ! empty( $transient['ids'][$unique] ) ) ? $transient['ids'][$unique] : '';
	$section_id = cs_get_var( 'cs-section', $section_id );

	echo '<div class="cs-framework cs-metabox-framework">';

	  echo '<input type="hidden" name="cs_section_id['. $unique .']" class="cs-reset" value="'. $section_id .'">';

	  echo '<div class="cs-body'. $show_all .'">';

	    if( $has_nav ) {

	      echo '<div class="cs-nav">';

	        echo '<ul>';
	        $num = 0;
	        foreach( $sections as $value ) {

	          if( ! empty( $value['typenow'] ) && $value['typenow'] !== $typenow ) { continue; }

	          $tab_icon = ( ! empty( $value['icon'] ) ) ? '<i class="cs-icon '. $value['icon'] .'"></i>' : '';

	          if( isset( $value['fields'] ) ) {
	            $active_section = ( ( empty( $section_id ) && $num === 0 ) || $section_id == $value['name'] ) ? ' class="cs-section-active"' : '';
	            echo '<li><a href="#"'. $active_section .' data-section="'. $value['name'] .'">'. $tab_icon . $value['title'] .'</a></li>';
	          } else {
	            echo '<li><div class="cs-seperator">'. $tab_icon . $value['title'] .'</div></li>';
	          }

	          $num++;
	        }
	        echo '</ul>';

	      echo '</div>';

	    }

	    echo '<div class="cs-content">';

	      echo '<div class="cs-sections">';
	      $num = 0;
	      foreach( $sections as $v ) {

	        if( ! empty( $v['typenow'] ) && $v['typenow'] !== $typenow ) { continue; }

	        if( isset( $v['fields'] ) ) {

	          $active_content = ( ( empty( $section_id ) && $num === 0 ) || $section_id == $v['name'] ) ? ' style="display: block;"' : '';

	          echo '<div id="cs-tab-'. $v['name'] .'" class="cs-section"'. $active_content .'>';
	          echo ( isset( $v['title'] ) ) ? '<div class="cs-section-title"><h3>'. $v['title'] .'</h3></div>' : '';

	          foreach ( $v['fields'] as $field_key => $field ) {

	          	if ( wowlms_set( $field, 'hide_on_frontend' )) {
	          		continue;
	          	}

	            $default    = ( isset( $field['default'] ) ) ? $field['default'] : '';
	            $elem_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';
	            $elem_value = ( is_array( $meta_value ) && isset( $meta_value[$elem_id] ) ) ? $meta_value[$elem_id] : $default;
	            echo cs_add_element( $field, $elem_value, $unique );

	          }
	          echo '</div>';

	        }

	        $num++;
	      }
	      echo '</div>';

	      echo '<div class="clear"></div>';

	    echo '</div>';

	    echo ( $has_nav ) ? '<div class="cs-nav-background"></div>' : '';

	    echo '<div class="clear"></div>';

	  echo '</div>';

	echo '</div>';

}

function wowlms_frontend_terms( $tax ) {

	$user = get_current_user_id();
	$terms = get_terms( array( 'taxonomy' => $tax, 'number' => -1, 'author' => $user, 'hide_empty' => false ) );

	$return = array( '' => esc_html__( '--Select--', 'wow-lms' ) );

	if ( ! is_wp_error( $terms ) ) {

		foreach ( $terms as $key => $value ) {
			
			$return[ $value->term_id ] = $value->name;
		}
	}

	return $return;
}

function wowlms_frontend_post_form_taxonomies_set( $post_data, $ajax_data ) {

	$post_type = wowlms_set( $post_data, 'post_type' );

	if ( ! $post_type ) {
		return $post_data;
	}

	$taxonomies = get_object_taxonomies( $post_type );

	$tax_terms = array();

	foreach ( $taxonomies as $tax ) {
		# code...
		$posted_data = wowlms_set( $ajax_data, $tax );

		if ( $posted_data ) {
			$tax_terms[ $tax ][] = $posted_data;
		}
	}

	if ( $tax_terms ) {
		$post_data['tax_input'] = $tax_terms;
	}

	return $post_data;
}


function wowlms_get_author_posts( $post_type ) {

	$current_user = wp_get_current_user();

	if ( ! $current_user ) {
		return false;
	}

	$args = array( 'post_type' => $post_type, 'post_status' => array( 'publish', 'pending', 'draft' ), 'orderby' => 'date', 'order' => 'DESC' );

	if ( ! in_array( 'administrator', $current_user->roles ) ) {
		$args['author'] = $current_user->ID;
	}

	$query = new WP_Query( $args );

	return $query;
}

function wowlms_edit_post_link( $object ) {

	if ( ! is_user_logged_in() ) {
		return false;
	}

	$post_id = base64_encode( 'wowlmsgetpostid_'. get_the_id() ); ?>

	<a href="javascript:void(0);" data-screen="<?php echo esc_attr( $object->get_screen() ); ?>" data-id="<?php echo esc_attr( $post_id ); ?>" onclick="WOWLMSOBJECT.edit_post( this );">
		<?php the_title(); ?>
	</a>

	<?php
}

function wowlms_profile_fields() {

	$data = array(
		'user_email'	=> array(
			'type'			=> 'core',
			'validation'	=> 'valid_email',
		),
		'confirm_email'	=> array(
			'type'			=> 'core',
			'validation'	=> 'valid_email',
		),
		'description'	=> array(
			'type'			=> 'core',
			'validation'	=> '',
		),
		'first_name'	=> array(
			'type'			=> 'core',
			'validation'	=> 'alpha',
		),
		'last_name'	=> array(
			'type'			=> 'core',
			'validation'	=> 'alpha',
		),
		'country'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'numeric',
		),
		'phone'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'is_natural',
		),
		'dob'	=> array(
			'type'			=> 'meta',
			'validation'	=> '',
		),
		'avatar'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'alpha',
		),

	);

	return apply_filters( 'wowlms_profile_fields', $data );
}


/**
 * [wowlms_is_student description]
 *
 * @return [type] [description]
 */
function wowlms_is_student() {

	$role = _WSH()->option( 'student_role' );

	if ( ! $role ) {
		$role = 'subscriber';
	}

	if ( in_array( $role, wp_get_current_user()->roles ) ) {
		return true;
	}

	if ( in_array( 'administrator', wp_get_current_user()->roles ) ) {
		return true;
	}

	return false;
}

/**
 * [wowlms_is_teacher description]
 *
 * @return [type] [description]
 */
function wowlms_is_teacher() {

	$role = _WSH()->option( 'teacher_role' );

	if ( ! $role ) {
		$role = 'instructor';
	}

	if ( in_array( $role, wp_get_current_user()->roles ) ) {
		return true;
	}

	if ( in_array( 'administrator', wp_get_current_user()->roles ) ) {
		return true;
	}

	return false;
}
