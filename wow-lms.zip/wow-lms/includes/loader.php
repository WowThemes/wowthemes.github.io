<?php
/**
 * Creating post type array
 *
 * @package WordPress
 * @subpackage WowLMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

if ( ! class_exists( 'CMB2_Bootstrap_224_Trunk' ) ) {
	//require_once WOWLMS_PATH . '/includes/thirdparty/CMB2/init.php';
}

if ( ! function_exists( 'always_show_cart_handler' ) ) {
	//require_once WOWLMS_PATH . '/includes/thirdparty/wordpress-simple-paypal-shopping-cart/wp_shopping_cart.php';
}

require_once WOWLMS_PATH . '/includes/classes/class-ajax.php';
require_once WOWLMS_PATH . '/includes/classes/class-dotnotation.php';

require_once WOWLMS_PATH . '/includes/library/functions.php';

require_once WOWLMS_PATH . '/includes/classes/class-courses.php';
//require_once WOWLMS_PATH . '/includes/classes/class-woocommerce.php';
require_once WOWLMS_PATH . '/includes/classes/class-lessons.php';
require_once WOWLMS_PATH . '/includes/classes/class-assignments.php';
require_once WOWLMS_PATH . '/includes/classes/class-quizes.php';
require_once WOWLMS_PATH . '/includes/classes/class-questions.php';
require_once WOWLMS_PATH . '/includes/classes/class-teacher.php';

if ( ! is_admin() ) {
	require_once WOWLMS_PATH . '/includes/classes/class-frontend.php';
	require_once WOWLMS_PATH . '/includes/classes/class-student-frontend.php';
}

