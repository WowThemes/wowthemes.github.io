<?php
/**
 * Output the custom woocmmerce fields.
 *
 * @package WooUpSells
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

global $post, $woocommerce; ?>


<p class="form-field product_field_type">

<?php wp_nonce_field( 'wowlms_nonce_field_action', 'wowlms_nonce_field' );

// Price Type
woocommerce_wp_select( array( 'id' => '_course_price_term', 'label' => __( 'Price Term', 'wow-lms' ), 'description' => sprintf( __( 'Choose the course price term.', 'wow-lms' ), 'http://schema.org/' ), 'options' => apply_filters( 'wowlms_course_terms_options', array(
	'month'            	=> __( 'Per Month', 'wow-lms' ),
	'3month' 			=> __( 'Per 3 Month', 'wow-lms' ),
	'6month'	   	    => __( 'Per 6 Month', 'wow-lms' ),
	'year'	   	    	=> __( 'Per Year', 'wow-lms' ),
) ) ) );
?>

</p>
