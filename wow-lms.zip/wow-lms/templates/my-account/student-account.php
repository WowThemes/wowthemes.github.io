<?php
/**
 * Student account shortcode
 *
 * @package WordPress
 * @subpackage WOw LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! function_exists( 'add_action' ) ) {
	exit( 'Restricted' );
}


if ( ! is_user_logged_in() ) {
	esc_html_e( 'Please signin to view this page', 'wow-lms' );
	return;
}

if ( ! wowlms_is_student() ) {
	esc_html_e( 'You are not authorized to view this page', 'wow-lms' );
	return;
}

wp_enqueue_style( array( 'sweetalert2' ) );
wp_enqueue_script( array( 'sweetalert2' ) );

$user = wp_get_current_user();
$dn = new Studentwp_DotNotation( get_user_meta( $user->ID ) );

$tabs = tr_tabs();
$form = tr_form('student');
$form->useAjax();
$form->useRoute('post', 'studentwp.user_profile.update_user_profile' );
echo $form->open();

$profile = function() use ($form, $user, $dn) {
    echo $form->image('Avatar')->setSetting('button', esc_html__( 'Set Avatar', 'wow-lms' ) );
    echo $form->text('First Name')->setName('user_first_name')->setAttributes(['class' => 'form-control', 'value' => $dn->get('first_name.0') ]);
    echo $form->text('Last Name')->setName('user_last_name')->setAttributes(['class' => 'form-control', 'value' => $dn->get('last_name.0')] );
    echo $form->text('Display Name')->setName('display_name')->setAttributes(['class' => 'form-control', 'value' => $user->data->display_name ] );
    echo $form->text('Email')->setName('user_email')->setAttributes(['class' => 'form-control', 'readonly' => 'readonly', 'value' => $user->data->user_email ] );
    echo $form->textarea('About')->setAttributes([ 'class' => 'form-control', 'value' => $dn->get('description.0') ]);

};

$sidebar = "<p><input type=\"submit\" value=\"Update\" class=\"btn btn-primary\" /></p>";

$tabs->setSidebar( $sidebar );

$tabContentTwo = "<p>Main content 2.</p>";

$tabs->addTab( esc_html__( 'Your Profile', 'wow-lms' ), $profile, 'user');

if ( function_exists('WC') ) {

	ob_start();
	wc_get_template( 'myaccount/my-orders.php', array('order_count'=>null) );
	$tabContentTwo = ob_get_clean();
	$tabs->addTab( esc_html__( 'My Orders', 'wow-lms' ), $tabContentTwo, 'cart');
}

$tabs->render('box');

echo $form->close();

