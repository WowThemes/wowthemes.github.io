<?php
/**
 * Plugin Name: WowThemes LMS
 * Plugin URI: http://themeforest.net/user/wptech
 * Description: This plugin is compatible with all wow_themes wordpress themes.
 * Author: Shahbaz Ahmed
 * Author URI: https://wptech.co
 * Version: 1.0.5
 * Text Domain: wow-themes
 * GitLab Plugin URI: https://gitlab.com/wowthemes/wow-lms
 * @package WowThemes LMS
 */

/**
 * Wowthemes Plugins for LMS
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}

if ( ! defined( 'WOWLMS_PATH' ) ) {
	define( 'WOWLMS_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'WOWLMS_URL' ) ) {
	define( 'WOWLMS_URL', plugin_dir_url( __FILE__ ) );
}

add_action( 'plugins_loaded', 'wowlms_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function wowlms_load_textdomain() {

	load_plugin_textdomain( 'wow-lms', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
}


require_once WOWLMS_PATH . '/typerocket/init.php';
require_once WOWLMS_PATH . '/includes/loader.php';
