<?php

use StudentCore\Register\PostType;
use StudentCore\Register\Taxonomy;
use StudentCore\Util\Arr;

if ( ! function_exists( 'printr' ) ) {
	function printr($var) {
		echo '<pre>';
		print_r($var);
		exit;
	}
}

if ( ! function_exists( 'student_core_mailchimp_list') ) {
	/**
	 * Mailchimp list.
	 * 
	 * @return array
	 */
	function student_core_mailchimp_list($assos = true) {
		if ( ! function_exists( 'mc4wp' ) ) {
			return array();
		}

		if ( ! class_exists( 'MC4WP_Mailchimp' ) ) {
			require_once MC4WP_PLUGIN_DIR . '/includes/class-mailchimp.php';
		}
		$mc4   = new MC4WP_Mailchimp();
		$lists = array();
		if ( method_exists( $mc4, 'get_lists' ) ) {
			$lists = $mc4->get_lists();
			if ( $assos ) {
				$return = array();
				foreach ( $lists as $list ) {
					$return[ $list->id ] = $list->name;
				}
				return $return;
			}
		}
		return $lists;
	}
}

if( ! function_exists( 'student_get' ) ) {
	function student_get($var, $key, $def = '') {
		if(is_array($var)) {
			return Arr::get($var, $key, $def);
		} elseif( is_object( $var ) ) {
			return isset( $var->{$key} ) ? $var->{$key} : $def;
		}

		return $def;
	}
}

if( ! function_exists( 'student_post_type' ) ) {
	/**
	 * Register post type.
	 *
	 * @param  [type] $singular [description]
	 * @param  string $plural   [description]
	 * @param  array  $settings [description]
	 * @return [type]           [description]
	 */
	function student_post_type($singular, $plural = '', $settings = []) {

		$obj = new PostType($singular, $plural, $settings);
		$obj->addToRegistry();

		return $obj;
	}
}

if( ! function_exists( 'student_taxonomy' ) ) {
	/**
	 * Register post type.
	 *
	 * @param  [type] $singular [description]
	 * @param  string $plural   [description]
	 * @param  array  $settings [description]
	 * @return [type]           [description]
	 */
	function student_taxonomy($singular, $plural = '', $settings = []) {

		$obj = new Taxonomy($singular, $plural, $settings);
		$obj->addToRegistry();

		return $obj;
	}
}

/**
 * Used to overcome core bug when taxonomy is in more then one post type
 *
 * @see   https://core.trac.wordpress.org/ticket/27918
 * @global array $wp_taxonomies The registered taxonomies.
 * @since 0.0.1
 *
 * @param array  $args
 * @param string $output
 * @param string $operator
 *
 * @return array
 */
function student_get_taxonomies( $args = [], $output = 'names', $operator = 'and' ) {
	global $wp_taxonomies;

	$field = ( 'names' === $output ) ? 'name' : false;

	// Handle 'object_type' separately.
	if ( isset( $args['object_type'] ) ) {
		$object_type = (array) $args['object_type'];
		unset( $args['object_type'] );
	}

	$taxonomies = wp_filter_object_list( $wp_taxonomies, $args, $operator );

	if ( isset( $object_type ) ) {
		foreach ( $taxonomies as $tax => $tax_data ) {
			if ( ! array_intersect( $object_type, $tax_data->object_type ) ) {
				unset( $taxonomies[ $tax ] );
			}
		}
	}

	if ( $field ) {
		$taxonomies = wp_list_pluck( $taxonomies, $field );
	}

	return $taxonomies;
}


if( ! function_exists( 'student_get_sidebars' ) ) {
	/**
	 * Get sidebars
	 * 
	 * @param  boolean $multi [description]
	 * @return [type]         [description]
	 */
	function student_get_sidebars($multi = false) {
		global $wp_registered_sidebars;
		$sidebars = ! ( $wp_registered_sidebars ) ? get_option( 'wp_registered_sidebars' ) : $wp_registered_sidebars;
		if ( $multi ) {
			$data[] = array( 'value' => '', 'label' => '' );
		}
		foreach ( (array) $sidebars as $sidebar ) {
			if ( $multi ) {
				$data[] = array( 'value' => student_get( $sidebar, 'id' ), 'label' => student_get( $sidebar, 'name' ) );
			} else {
				$data[ student_get( $sidebar, 'id' ) ] = student_get( $sidebar, 'name' );
			}
		}

		return $data;
	}
}

if(! function_exists('studentwp_sorting_order')) {
	function studentwp_sorting_order($value) {
		$orderby = $value;
		$order = 'desc';
		$meta_key = '';
		switch ($value) {
			case 'most_selling':
				$meta_key = '_lp_students';
				$orderby = 'meta_value';
				$order = 'DESC';
				break;
			case 'top_rated':
				$meta_key = '_lp_students';
				$orderby = 'meta_value';
				$order = 'DESC';
				break;
			case 'low_price':
				$meta_key = '_lp_price';
				$orderby = 'meta_value';
				$order = 'ASC';
				break;
			case 'high_price':
				$meta_key = '_lp_price';
				$orderby = 'meta_value';
				$order = 'DESC';
				break;
			case 'tite_asc':
				$return = 'title';
				$order = 'ASC';
				break;
			case 'tite_desc':
				$return = 'title';
				$order = 'DESC';
				break;
			
			default:
				# code...
				break;
		}

		return compact('orderby', 'order', 'meta_key');
	}
}

if(! function_exists('student_get_terms')) {
	/**
	 * Get associactive array of terms.
	 * 
	 * @param  [type] $taxonomy [description]
	 * @param  array  $args     [description]
	 * @return [type]           [description]
	 */
	function student_get_terms($taxonomy, $args = []) {
		$args['taxonomy'] = $taxonomy;
		$terms = get_terms($args);
		$return = [];
		if(! is_wp_error( $terms )) {
			foreach($terms as $term) {
				$return[ $term->slug ] = $term->name;
			}
		}

		return $return;
	}
}

if(! function_exists('student_get_posts')) {
	/**
	 * Get associactive array of terms.
	 * 
	 * @param  [type] $taxonomy [description]
	 * @param  array  $args     [description]
	 * @return [type]           [description]
	 */
	function student_get_posts($post_type, $args = []) {
		$args['post_type'] = $post_type;
		$query = new WP_Query($args);
		$return = [];
		if($query->have_posts()) {
			while($query->have_posts()) {
				$query->the_post();
				$return[get_the_id()] = get_the_title();
			}
		}
		wp_reset_postdata();
		return $return;
	}
}

if ( ! function_exists('studentwp_file_path') ) {
	/**
	 * Studentwp file path.
	 *
	 * @param  [type] $tpl [description]
	 * @return [type]      [description]
	 */
	function studentwp_file_path($tpl) {
		if ( file_exists( get_theme_file_path( $tpl ) ) ) {
			return get_theme_file_path( $tpl );
		}

		return STUDENT_CORE_PATH . $tpl;
	}
}


/*add_action('rwmb_meta_boxes','category_meta_boxes');
function category_meta_boxes($meta_boxes){
   $meta_boxes[] = array(
   	'title'=>'Standard Fields',
   	'taxonomies'=>'category',
   	'fields'=>array(
   		array(
   			'name'=>esc_html__('Featured?','studentp-core'),
   			'id'=>'featured',
   			'type'=>'checkbox',
   		),
   		array(
   			'name'=>esc_html__('Featured Content','studentwp-core'),
   			'id'=>'featured_content',
   			'type'=>'wysiwyg',
   		),
   		array(
   			'name'=>esc_html__('Featured Image','studentwp-core'),
   			'id'=>'image_advanced',
   			'type'=>'image_advanced',
   		),
   		array(
   			'name'=>esc_html__('Color','studentwp-core'),
   			'id'=>'color',
   			'type'=>'color',
   		),

   	),

   );
   return $meta_boxes;
}*/


