<?php

namespace StudentCore\Classes;

use StudentCore\Register\Registry;
use StudentCore\Widgets\RecentPosts;
use StudentCore\Widgets\UpcomingEvents;
use StudentCore\Widgets\FooterCourses;



class Plugin
{
	public static function init() {

		(new Hooks)->init();

		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action('init', [__CLASS__, 'register']);

		/*
		add_action('after_setup_theme', function() {
		/*add_action('after_setup_theme', function() {
		}, 200);*/

		require_once STUDENT_CORE_PATH . 'config/options.php';
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'mailchimp_list' ) );

		self::elementor();
		add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'elementor_widgets' ) );

		add_action( 'wp_ajax_student_core_ajax', array( Ajax::class, 'init' ) );
		add_action( 'wp_ajax_nopriv_student_core_ajax', array( Ajax::class, 'init' ) );
				add_action( 'vc_before_init', array( __CLASS__, 'vc_init' ) );

		add_action( 'widgets_init', array( __CLASS__, 'widgets_init' ) );
	}

	/**
	 * Register Post Types.
	 *
	 * @return [type] [description]
	 */
	public static function register() {

		require_once STUDENT_CORE_PATH . 'config/post_types.php';
		require_once STUDENT_CORE_PATH . 'config/taxonomies.php';

		foreach ( Registry::$collection as $coll ) {
			$coll->register();
		}

	}

	/**
	 * Load the elementor modules.
	 *
	 * @return [type] [description]
	 */
	private static function elementor() {
		$modules = include STUDENT_CORE_PATH . 'config/elementor.php';

		foreach ( $modules['modules'] as $module ) {
			if ( class_exists( $module ) ) {
				call_user_func( array( $module, 'boot' ) );
			}
		}
	}

	public static function elementor_widgets( $elementor ) {
		$modules = include STUDENT_CORE_PATH . 'config/elementor.php';
		$modules = array_filter($modules);

		foreach ( $modules['widgets'] as $module ) {
			if ( class_exists( $module ) ) {
				$elementor->register_widget_type( new $module() );
			}
		}
	}

	public static function vc_init() {

	}

	/**
	 * Mailchimp list.
	 *
	 * @return [type] [description]
	 */
	public static function mailchimp_list() {
		$list = get_transient( 'studentwp_mailchimp_list' );

		if ( $list ) {
			return;
		}
		return;

		if ( function_exists( 'studentwp' ) ) {

			$api = studentwp()->options->get( 'mailchimp_api_key' );

			if ( $api ) {

				if ( $list === false ) {
					try {
						$MailChimp = new \StudentPlugin\Libraries\MailChimp( $api );
						$lists     = $MailChimp->get( 'lists' );
						if ( $MailChimp->success() ) {
							foreach ( $lists['lists'] as $value ) {
								$list[ student_get( $value, 'id' ) ] = student_get( $value, 'name' );
							}

							set_transient( 'studentwp_mailchimp_list', $list, 3600 * 24 * 5 );
						}
					} catch ( \Exception $e ) {

					}
				}
			}
		}
	}

	/**
	 * REgister Custom widgets.
	 *
	 * @return [type] [description]
	 */
	public static function widgets_init() {

		/* Script For Widget */
		add_image_size( 'studentwp-90-90', 90, 90, true ); /* Upcoming Widget */
		add_image_size( 'studentwp-59-59', 59, 59, true ); /* Recent Post Widget */

		register_widget( RecentPosts::class );
		register_widget( UpcomingEvents::class );
		register_widget( FooterCourses::class );
	}
}
