<?php

namespace StudentCore\Classes;

class Hooks {

    public function init() {
        add_filter('studentwp_get_sidebar', array($this, 'get_sidebar'));
    }

    /**
     * Get sidebar hook.
     */
    public function get_sidebar( $sidebar ) {
        global $wp_query;

        if ( is_search() ) {
            return $sidebar;
        }

        if ( $wp_query->is_posts_page || is_singular() ) {
            if ( $field = get_field('sidebar') ) {
                return $field;
            } else {
                return studentwp_options('blog_single_sidebar', 'default-sidebar');
            }
        }
        if ( function_exists('WC') && is_archive('product') ) {
            $shop_page_id = wc_get_page_id('shop');
            if ( $shop_page_id ) {
                if ( $field = get_field('sidebar') ) {
                    return $field;
                } else {
                    return studentwp_options('woocommerce_shop_sidebar', 'shop');
                }
            } else {
                return studentwp_options('woocommerce_shop_sidebar', 'shop');
            }
        }
        if ( is_archive() || is_home() ) {
            return studentwp_options('archive_page_sidebar', 'default-sidebar');
        }

        return $sidebar;
    }
}