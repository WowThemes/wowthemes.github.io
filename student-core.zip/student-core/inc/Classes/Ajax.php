<?php

namespace StudentCore\Classes;

use StudentCore\Util\Arr;

class Ajax
{
	public static function init() {

		$subaction = sanitize_text_field( Arr::get($_REQUEST, 'subaction') );

		if($subaction && method_exists(new static, $subaction)) {
			call_user_func([new static, $subaction]);
		}
		wp_send_json_error( ['message' => esc_html__('No sub action found', 'student-core')], 400 );
	}


	private function ajaxselect2() {
		$query = sanitize_text_field( $_REQUEST['s'] );
		$type = sanitize_text_field( $_REQUEST['data'] );

		switch ($type) {
			case 'post':
				$this->getPosts($query);
				break;
			case 'term':
				$this->getTerms($query);
				break;
			
			default:
				# code...
				break;
		}
	}


	private function getPosts($search) {

		$type = sanitize_text_field( $_REQUEST['type'] );
		$query = new \WP_Query(['post_type' => $type, 'post_per_page' => 100, 's' => $search]);

		$results = [];

		while ($query->have_posts()) {
			$query->the_post();

			$results[] = ['id' => get_the_id(), 'text' => get_the_title()];
		}

		wp_reset_postdata();

		wp_send_json(compact('results'));
	}

	private function getTerms($search) {

		$type = sanitize_text_field( $_REQUEST['type'] );
		$terms = get_terms(['taxonomy' => $type, 'number' => 100, 'search' => $search]);

		$results = [];

		if($terms) {
			foreach ( $terms as $term ) {
				$results[] = ['id' => $term->slug, 'text' => $term->name];
			}
		}

		wp_send_json(compact('results'));
	}

	/**
	 * Login
	 */
	private function login() {
		$nonce = sanitize_text_field( Arr::get($_POST, 'nonce') );

		if( ! wp_verify_nonce($nonce, 'STUDENTWP_ACTION') ) {
			wp_send_json_error(['message' => esc_html__('Security check failed')], 403);
		}
		$username = sanitize_text_field( Arr::get($_POST, 'form.username'));
		$pwd = sanitize_text_field( Arr::get($_POST, 'form.password'));
		$remember = sanitize_text_field( Arr::get($_POST, 'form.rememberme'));
		$login = wp_signon(['user_login' => $username, 'user_password' => $pwd, 'rememberme' => $remember]);

		if( ! is_wp_error( $login ) ) {
			wp_send_json_success(['message' => esc_html__('Login successful', 'studentwp-core')]);
		}
		wp_send_json_error(['message' => $login->get_error_message()], 403);
	}

	/**
	 * Register
	 */
	private function register() {
		$nonce = sanitize_text_field( Arr::get($_POST, 'nonce') );

		if( ! wp_verify_nonce($nonce, 'STUDENTWP_ACTION') ) {
			wp_send_json_error(['message' => esc_html__('Security check failed')], 403);
		}
		if( ! get_option('users_can_register') ) {
			wp_send_json_error(['message' => esc_html__('Registration is not allowed')], 403);
		}
		$username = sanitize_text_field( Arr::get($_POST, 'form.username'));
		$pwd = sanitize_text_field( Arr::get($_POST, 'form.password'));
		$confirm = sanitize_text_field( Arr::get($_POST, 'form.confirm_password'));
		if ( $pwd !== $confirm ) {
			wp_send_json_error(['message' => esc_html__('Password and confirm password doesn\'t match')], 403);
		}
		if ( strlen($pwd) < 10 ) {
			wp_send_json_error(['message' => esc_html__('Minimum password sould be 10')], 403);
		}
		$email = sanitize_text_field( Arr::get($_POST, 'form.email'));
		if(! is_email($email)) {
			wp_send_json_error(['message' => esc_html__('Invalid email provided')], 403);
		}
		$user_id = register_new_user($username, $email);

		if( ! is_wp_error( $user_id ) ) {
			wp_send_json_success(['message' => esc_html__('Registeration successful, please check your email', 'studentwp-core')]);
		}
		wp_send_json_error(['message' => $user_id->get_error_message()], 403);
	}

	/**
	 * Subscribe for Mailchimp.
	 * 
	 * @return void
	 */
	public function subscribe() {
		$nonce = sanitize_text_field( Arr::get($_POST, 'nonce') );

		if ( ! wp_verify_nonce($nonce, 'STUDENTWP_ACTION') ) {
			wp_send_json_error(['message' => esc_html__('Security check failed')], 403);
		}
		$list = sanitize_text_field( Arr::get($_POST, 'form.list') );
		$email = sanitize_text_field( Arr::get($_POST, 'form.email') );
		if ( ! $list ) {
			wp_send_json_error(['message' => esc_html__('No subscription list provided')], 400);
		}
		if ( ! is_email( $email ) ) {
			wp_send_json_error(['message' => esc_html__('Invalid email provided')], 400);
		}
		try {
			if ( ! class_exists( 'MC4WP_Mailchimp' ) ) {
				require_once MC4WP_PLUGIN_DIR . '/includes/class-mailchimp.php';
			}
			$mc4   = new \MC4WP_Mailchimp();
			$response = $mc4->list_subscribe($list, $email);
			if(! $response && $mc4->error_code) {
				
				wp_send_json_error(['message' => $mc4->error_message->detail ? $mc4->error_message->detail : $mc4->error_message], 400);
			}
			wp_send_json_success(['message' => esc_html__('Successfully subsribed, please check your email box', 'studentwp-core')]);
		} catch (\Exception $e) {
			wp_send_json_error(['message' => $e->getMessage()]);
		}

	}
}