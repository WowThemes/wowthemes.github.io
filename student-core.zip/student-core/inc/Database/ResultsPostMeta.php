<?php


namespace StudentCore\Database;


class ResultsPostMeta extends ResultsMeta
{

    protected $cache_key = 'post_meta';
    protected $cache_column = 'post_id';

}