<?php
namespace StudentCore\Widgets;

use LP_Course;
use StudentCore\Util\Arr;

/**
 * Class FooterCourses
 */
class FooterCourses extends \WP_Widget {
 
    /**
     * Constructs the new widget.
     *
     * @see WP_Widget::__construct()
     */
    function __construct() {
        // Instantiate the parent object.
        $widget_ops = array( 'classname' => 'widget_footer_student_courses', 'description' => esc_html__( "Display the courses.", "student-core" ) );
        parent::__construct('widget_student_courses', __('Student :: Courses', "student-core"), $widget_ops);
    }
 
    /**
     * The widget's HTML output.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args     Display arguments including before_title, after_title,
     *                        before_widget, and after_widget.
     * @param array $instance The settings for the particular instance of the widget.
     */
    function widget($args, $instance ) {

        if ( ! isset( $args['widget_id'] ) ) {
            $args['widget_id'] = $this->id;
        }

        /** This filter is documented in wp-includes/default-widgets.php */
        $title = apply_filters( 'widget_title', Arr::get($instance, 'title'), $instance, $this->id_base );


        $qry_args = array (
            'post_type'              => 'lp_course',
            'posts_per_page'         => Arr::get($instance, 'number', 3),
            'ignore_sticky_posts'    => true,
            'order'                  => Arr::get($instance, 'order', 'DESC'),
            'orderby'                => Arr::get($instance, 'sorting_order', 'title'),
        );


        $qry = new \WP_Query( $qry_args );

        echo $args['before_widget'];

        if ( $title ) {
            echo $args['before_title'] . $title . $args['after_title'];
        }
        $style = Arr::get($instance, 'style', '2');
        ?>
        <div class="course-widget style-<?php echo esc_attr( $style ) ?>">
            <?php
            while ( $qry->have_posts() ) : $qry->the_post();
                $course = new \LP_Course(get_the_id());
                $students = $course->count_students();
                $start = $course->get_data('start_time');

                ?>
                <div class="course-widget-item d-flex align-items-center">
                    <?php the_post_thumbnail([90, 90], ['class' => ( '1' === $style ) ? 'rounded-circle' : '']); ?>
                    <div class="ps-3">
                        <h5 class="mb-3">
                            <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute()?>">
                                <?php the_title(); ?>
                            </a>
                        </h5>
                        <?php if ( '2' === $style ) : ?>
                            <span class="text-primary"><?php printf( esc_html__('%d Students are attending', 'studentwp-core'), $students ) ?></span>
                        <?php else : ?>
                            <span class="d-block pb-1"><?php printf(esc_html__('Started on %s', 'studentwp-core'), $start) ?></span>
                            <span class="d-block"><?php comments_number() ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <?php
            endwhile;
            ?>
        </div>
        <?php
        echo $args['after_widget'];

        // Reset the global $the_post as this query will have stomped on it
        wp_reset_postdata();

    }
 
    /**
     * The widget update handler.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance The new instance of the widget.
     * @param array $old_instance The old instance of the widget.
     * @return array The updated instance of the widget.
     */
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['style'] = $new_instance['style'];
		$instance['sorting_order'] = $new_instance['sorting_order'];
		$instance['order'] = $new_instance['order'];
		$instance['course_category'] = Arr::get($new_instance, 'course_category', array());
		$instance['number'] = (int) $new_instance['number'];
		$instance['course_tag'] = Arr::get($new_instance, 'course_tag', array());

		return $instance;
    }
 
    /**
     * Output the admin widget options form HTML.
     *
     * @param array $instance The current widget settings.
     * @return string The HTML markup for the form.
     */
    public function form( $instance ) {

        $sorting_order      = isset( $instance['sorting_order'] ) ? esc_attr( $instance['sorting_order'] ) : 'title';
        $order              = isset( $instance['order'] ) ? esc_attr( $instance['order'] ) : 'DESC';
        $style              = isset( $instance['style'] ) ? esc_attr( $instance['style'] ) : '2';
        $title              = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
        $course_category    = isset( $instance['course_category'] ) ? (array) $instance['course_category'] : '';
        $course_tag         = isset( $instance['course_tag'] ) ? $instance['course_tag'] : '';
        $number             = isset( $instance['number'] ) ? absint( $instance['number'] ) : 3;

        ?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title:', "student-core" ); ?></label>
            <input class="widefat" type="text" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr($title); ?>" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'style' ); ?>"><?php esc_html_e( 'Style', "student-core" ); ?></label>
            
            <select class="widefat" id="<?php echo $this->get_field_id( 'style' ); ?>" name="<?php echo $this->get_field_name( 'style' ); ?>">
                <option value="1" <?php selected('1', $style) ?>><?php esc_html_e('One', 'studentwp-core') ?></option>
                <option value="2" <?php selected('2', $style) ?>><?php esc_html_e('Two', 'studentwp-core') ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'sorting_order' ); ?>"><?php esc_html_e( 'Order By', "student-core" ); ?></label>
            <select class="widefat" id="<?php echo $this->get_field_id( 'sorting_order' ); ?>" name="<?php echo $this->get_field_name( 'sorting_order' ); ?>">
                <option value="date" <?php selected('date', $sorting_order) ?>><?php esc_html_e('Date', 'studentwp-core') ?></option>
                <option value="author" <?php selected('author', $sorting_order) ?>><?php esc_html_e('Author', 'studentwp-core') ?></option>
                <option value="comment_count" <?php selected('comments_count', $sorting_order) ?>><?php esc_html_e('Comment Count', 'studentwp-core') ?></option>
                <option value="title" <?php selected('title', $sorting_order) ?>><?php esc_html_e('Title', 'studentwp-core') ?></option>
                <option value="rand" <?php selected('rand', $sorting_order) ?>><?php esc_html_e('Random', 'studentwp-core') ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'order' ); ?>"><?php esc_html_e( 'Order', "student-core" ); ?></label>
            
            <select class="widefat" id="<?php echo $this->get_field_id( 'order' ); ?>" name="<?php echo $this->get_field_name( 'order' ); ?>">
                <option value="ASC" <?php selected('ASC', $order) ?>><?php esc_html_e('Ascending', 'studentwp-core') ?></option>
                <option value="DESC" <?php selected('DESC', $order) ?>><?php esc_html_e('Dscending', 'studentwp-core') ?></option>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'course_category' ); ?>"><?php esc_html_e( 'Courses Categories', "student-core" ); ?></label>
            <select multiple class="widefat" id="<?php echo $this->get_field_id( 'course_category' ); ?>" name="<?php echo $this->get_field_name( 'course_category' ); ?>[]">
                <?php if( $course_categories = student_get_terms('course_category', ['hide_empty' => false]) ) : ?>
                    <?php foreach( $course_categories as $cat_id => $cat_name ) : ?>
                        <?php $selected = in_array($cat_id, $course_category) ? ' selected="selected"' : ''; ?>
                        <option value="<?php echo esc_attr( $cat_id ) ?>" <?php echo $selected ?>><?php echo esc_attr( $cat_name ) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'course_tag' ); ?>"><?php esc_html_e( 'Courses Tags', "student-core" ); ?></label>
            <select multiple class="widefat" id="<?php echo $this->get_field_id( 'course_tag' ); ?>" name="<?php echo $this->get_field_name( 'course_tag' ); ?>[]">
                <?php if( $course_tags = student_get_terms('course_tag', ['hide_empty' => false]) ) : ?>
                    <?php foreach( $course_tags as $tag_id => $tag_name ) : ?>
                        <?php $selected = in_array($tag_id, $course_tag) ? ' selected="selected"' : ''; ?>
                        <option value="<?php echo esc_attr( $tag_id ) ?>" <?php echo $selected ?>><?php echo esc_attr( $tag_name ) ?></option>
                    <?php endforeach; ?>
                <?php endif; ?>
            </select>
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'number' ); ?>"><?php esc_html_e( 'Number of posts to show:', "student-core" ); ?></label>
            <input type="number" id="<?php echo $this->get_field_id( 'number' ); ?>" name="<?php echo $this->get_field_name( 'number' ); ?>" value="<?php echo esc_attr($number); ?>" size="3" />
        </p>
        <?php
    }
}
