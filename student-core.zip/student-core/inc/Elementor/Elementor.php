<?php

use StudentCore\Elementor\Classes\CSSModule;
use StudentCore\Elementor\Classes\Enqueue;
use StudentCore\Elementor\Classes\StudentElementor;
use StudentCore\Elementor\Classes\StudentModules;

add_action( 'plugins_loaded', function() {

	if( class_exists('\Elementor\Plugin')) {
		new CSSModule;
		new StudentElementor;
		new Enqueue;
		new StudentModules;
	}

}, 50 );