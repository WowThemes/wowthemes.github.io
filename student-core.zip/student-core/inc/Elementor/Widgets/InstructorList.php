<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class InstructorList extends Widget_Base {

	public function get_name() {
		return 'StudentwpInstructorList';
	}

	public function get_title() {
		return esc_html__( 'InstructorList', 'studentwp-core' );
	}
	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'InstructorList', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_instructor_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'Instructor to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 500,
					'default'   => 3,
				]
			);

		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor_name',
			]
		);
		$this->add_control(
			'instructor_text_color',
			[
				'label' => esc_html__( 'Instructor Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor_name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'instructor_hover_color',
			[
				'label' => esc_html__( 'Instructor hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor_name:hover, {{WRAPPER}} .instructor_name:focus' => 'color: {{VALUE}};'
				],
			]
		);	
		$this->end_controls_section();
		$this->start_controls_section(
			'designation',
			[
				'label' => esc_html__( 'Designation', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor_designation',
			]
		);
		$this->add_control(
			'designation_color',
			[
				'label' => esc_html__( 'Designation Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor_designation' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'designation_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor_designation:hover, {{WRAPPER}} .instructor_designation:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if(file_exists(get_theme_file_path( 'templates/elementor/instructorlist.php' ))) {
			include get_theme_file_path( 'templates/elementor/instructorlist.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/instructorlist.php';
	}
}