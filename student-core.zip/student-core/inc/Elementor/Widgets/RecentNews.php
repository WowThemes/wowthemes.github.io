<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class RecentNews extends Widget_Base {

	public function get_name() {
		return 'StudentwpRecentNews';
	}

	public function get_title() {
		return esc_html__( 'RecentNews', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return array( 'RecentNews', 'icon' );
	}
	public function get_categories() {
		return array( 'we-widget' );
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @since  0.0.1
	 * @access public
	 * @return array Element script dependencies.
	 */
	public function get_script_depends() {
		return array( 'owl-carousel', 'studentwp-scripts' );
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_blog_query_setting',
			array(
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			)
		);
		$this->add_control(
			'number',
			array(
				'label'   => esc_html__( 'Posts to Show', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 5,
				'default' => 3,
			)
		);

		$this->add_control(
			'categories',
			array(
				'label'    => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_terms( 'category', array( 'hide_empty' => false ) ),
				'default'  => array(),

			)
		);
		$this->add_control(
			'tags',
			array(
				'label'    => esc_html__( 'Tags', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_terms( 'post_tag', array( 'hide_empty' => false ) ),
				'default'  => array(),
			)
		);
		$this->add_control(
			'sorting_order',
			array(
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'recent'         => esc_html__( 'Recent', 'studentwp-core' ),
					'most_commented' => esc_html__( 'Most Commented', 'studentwp-core' ),
					'author'         => esc_html__( 'Author', 'studentwp-core' ),
					'rand'           => esc_html__( 'Random', 'studentwp-core' ),
					'tite_asc'       => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc'     => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				),
				'default' => 'Most Selling',
			)
		);

		$this->add_control(
			'includes',
			array(
				'label'    => esc_html__( 'Includes', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_posts( 'post', array( 'posts_per_page' => -1 ) ),
				'default'  => array(),
			)
		);
		$this->end_controls_section();
		// End of general content settings.

		/**
		 * Carousel Section start.
		 * Here we get the settings
		 * for owl carousel configuration 
		 */
		$this->start_controls_section(
			'section_courses_caoursel',
			array(
				'label' => esc_html__( 'Caoursel Settings', 'studentwp-core' ),
			)
		);

		$this->add_control(
			'enable_carousel',
			array(
				'label'   => esc_html__( 'Enable Carousel', 'studentwp-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);
		$this->add_control(
			'number_item',
			array(
				'label'     => esc_html__( 'Number of Items', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 3,
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'number_items_tablet',
			array(
				'label'     => esc_html__( 'Number of Items (Tablet)', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '1',
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'number_items_mobile',
			array(
				'label'     => esc_html__( 'Number of Items (Mobile)', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '1',
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'speed',
			array(
				'label'     => esc_html__( 'Speed', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 500,
				'condition' => array(
					'autoplay'        => 'yes',
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'autoplay',
			array(
				'label'              => esc_html__( 'Autoplay', 'studentwp-core' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'frontend_available' => true,
				'condition'          => array(
					'enable_carousel' => 'yes',
				),
			)
		);

		$this->add_control(
			'carousel_arrow_left_icon',
			array(
				'label'     => esc_html__( 'Left Arrow Icon', 'studentwp-core' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => array(
					'library' => 'fa-solid',
					'value'   => 'fa-chevron-left',
				),
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);

		$this->add_control(
			'carousel_arrow_right_icon',
			array(
				'label'     => esc_html__( 'Right Arrow Icon', 'studentwp-core' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => array(
					'library' => 'fa-solid',
					'value'   => 'fa-chevron-right',
				),
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->end_controls_section();
		// Carousel section end.

		$this->start_controls_section(
			'post_title',
			array(
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .post-title',
			)
		);
		$this->add_control(
			'Title_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .post-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_hover_color',
			array(
				'label'     => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .post-title:hover, {{WRAPPER}} .post-title:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'content',
			array(
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography2',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .conent-news',
			)
		);
		$this->add_control(
			'content_color',
			array(
				'label'     => esc_html__( 'Content Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .conent-news' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'author',
			array(
				'label' => esc_html__( 'Author', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'authortypography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .author-name',
			)
		);
		$this->add_control(
			'author_text_color',
			array(
				'label'     => esc_html__( 'Author Text Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .author-name' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'author_hover_color',
			array(
				'label'     => esc_html__( 'Author hover Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .author-name:hover, {{WRAPPER}} .author-name:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'autor_date',
			array(
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'datetypography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .date-style',
			)
		);
		$this->add_control(
			'author_date_color',
			array(
				'label'     => esc_html__( 'Date Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .date-style' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'date_hover_color',
			array(
				'label'     => esc_html__( 'date hover Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .date-style:hover, {{WRAPPER}} .date-style:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		include studentwp_file_path( 'templates/elementor/recentnews.php' );
	}
}
