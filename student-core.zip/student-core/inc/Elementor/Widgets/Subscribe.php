<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Subscribe extends Widget_Base {

	public function get_name() {
		return 'Subscribe';
	}

	public function get_title() {
		return esc_html__( 'Subscribe', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Subscribe', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_main_content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'mailchimp_list',
			[
				'label' => esc_html__( 'Mailchimp List', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT,
				'description'	=> sprintf(__('You need to install plugin <a href="%s" target="_blank">Mailchimp for WP</a> to make this widget work', 'sutdentwp-core'), 'https://wordpress.org/plugins/mailchimp-for-wp/'),
				'options'	=> student_core_mailchimp_list(),
				'label_block'	=> true
			]
		);
		$this->add_control(
			'subscribe_title', [
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'studentwp-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'content', [
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Content' , 'studentwp-core' ),
				'show_label' => true,
			]
		);
		$this->add_control(
			'logo',
			[
				'label' => esc_html__( 'Choose Logo', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_control(
			'placehonder_text',
			[
				'label' => esc_html__( 'Placeholder Text', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Enter your name ...', 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'subscribe_icon',
			[
				'label' => esc_html__( 'Icon', 'studentwp-core' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'fa-solid',
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'wrapper-box',
			[
				'label' => esc_html__( 'Wrapper/Box', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'wrapper-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.subscribe-warpper',
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .subscribe-warpper',
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label' => esc_html__( 'Padding', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_control(
			'wrapper_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .subscribeform-title',
			]
		);

		/*$this->add_control(
			'Title_color',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .subscribe-title' => 'color: {{VALUE}};',
				],
			]
		);*/

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .subscribeform-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'subscribe_content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_subscribe_content',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .subscribeform-content',
			]
		);
		
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .subscribeform-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'subscribe_icon_style',
			[
				'label' => esc_html__( 'Icon', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .sub-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Size', 'studentwp-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 6,
						'max' => 300,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .sub-icon' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'icon-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .sub-icon',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'subscribe_field',
			[
				'label' => esc_html__( 'Field', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'field_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .subscribe-field' => 'color: {{VALUE}};',
				],
			]
		);

		/*$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'field-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.subscribe-field',
			]
		);*/

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .subscribe-field',
			]
		);

		$this->add_control(
			'border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .subscribe-field' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_field',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .subscribe-field',
			]
		);

		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		extract($settings);
		if(file_exists(get_theme_file_path( 'templates/elementor/subscribe.php' ))) {
			include get_theme_file_path( 'templates/elementor/subscribe.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/subscribe.php';
	}

}