<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Heading extends Widget_Base {

	public function get_name() {
		return 'StudentwpHeading';
	}

	public function get_title() {
		return esc_html__( 'Heading', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Heading', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your title', 'studentwp-core' ),
				'default' => esc_html__( 'Add Your Heading Text Here', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'tagline',
			[
				'label' => esc_html__( 'Tagline', 'studentwp-core' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your tagline', 'studentwp-core' ),
				'default' => esc_html__( 'Add Your Tagline Text Here', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'size',
			[
				'label' => esc_html__( 'Size', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => [
					'default' => esc_html__( 'Default', 'studentwp-core' ),
					'small' => esc_html__( 'Small', 'studentwp-core' ),
					'medium' => esc_html__( 'Medium', 'studentwp-core' ),
					'large' => esc_html__( 'Large', 'studentwp-core' ),
					'xl' => esc_html__( 'XL', 'studentwp-core' ),
					'xxl' => esc_html__( 'XXL', 'studentwp-core' ),
				],
			]
		);

		$this->add_control(
			'header_size',
			[
				'label' => esc_html__( 'HTML Tag', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				],
				'default' => 'h2',
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label' => esc_html__( 'Alignment', 'studentwp-core' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'studentwp-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'studentwp-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'studentwp-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'studentwp-core' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'width',
			[
				'label' => esc_html__( 'Border Width', 'studentwp-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'px' => [
						'max' => 1000,
					],
				],
				'default' => [
					'size' => 100,
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .heading-icon' => 'width: {{SIZE}}{{UNIT}};',
				],
				'condition'	=> [
					'enable_border'	=> 'yes'
				],
			]
		);
		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Border Hight', 'studentwp-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ '%', 'px' ],
				'range' => [
					'px' => [
						'max' => 1000,
					],
				],
				'default' => [
					'size' => 100,
					'unit' => '%',
				],
				'tablet_default' => [
					'unit' => '%',
				],
				'mobile_default' => [
					'unit' => '%',
				],
				'selectors' => [
					'{{WRAPPER}} .heading-icon' => 'hight: {{SIZE}}{{UNIT}};',
				],
				'condition'	=> [
					'enable_border'	=> 'yes'
				],
			]
		);

		$this->add_control(
			'enable_border',
			[
				'label' => esc_html__( 'Enabler Border', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .heading-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .heading-title',
			]
		);

		$this->add_control(
			'tagline_color',
			[
				'label' => esc_html__( 'Tagline Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'selectors' => [
					'{{WRAPPER}} .heading-tagline' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'tagline_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
				'selector' => '{{WRAPPER}} .heading-tagline',
			]
		);

		$this->add_control(
			'border_color',
			[
				'label' => esc_html__( 'Border Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'global' => [
					'default' => Global_Colors::COLOR_PRIMARY,
				],
				'condition'	=> [
					'enable_border'	=> 'yes'
				],
				'selectors' => [
					'{{WRAPPER}} .heading-icon' => 'color: {{VALUE}};',
				],
			]
		);
	


		$this->add_group_control(
			Group_Control_Text_Shadow::get_type(),
			[
				'name' => 'text_shadow',
				'selector' => '{{WRAPPER}} .heading-title',
			]
		);


		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/heading.php' ))) {
			include get_theme_file_path( 'templates/elementor/heading.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/heading.php';
	}
}