<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class CoursesListView extends Widget_Base {

	public function get_name() {
		return 'StudentwpCoursesListView';
	}

	public function get_title() {
		return esc_html__( 'CoursesListView', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'CoursesListView', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}
	protected function _register_controls() {
		$this->start_controls_section(
			'section_popularcourses_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'Popular Courses to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 500,
					'default'   => 3,
				]
			);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('course_category', ['hide_empty' => false]),
				'default' => [],

			]
		);
		$this->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('course_tag', ['hide_empty' => false]),
				'default' => [],
			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		$this->add_control(
			'only_free_courses',
			[
				'label' => esc_html__( 'Only Free Courses', 'plugin-domain' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'includes',
			[
				'label' => esc_html__( 'Includes', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_posts('lp_course', ['courses_per_page' => -1]),
				'default' => [],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_courses_listview',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'courses_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-title',
			]
		);

		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .courses-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .courses-title:hover, {{WRAPPER}} .courses-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		/**
		 * Free course badge typography 
		 * and colors styling control 
		 * section starts.
		 */
		$this->start_controls_section(
			'free_course_bage',
			[
				'label' => esc_html__( 'Free Course Badge', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography1',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .free-bage_courses',
			]
		);
		$this->add_control(
			'free_course_bage_text_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .free-bage_courses' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'free_course_bage_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6588fe',
				'selectors' => [
					'{{WRAPPER}} .free-bage_courses' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		/**
		 * Pricing and symbol 
		 * styling and typography 
		 * constrol section started.
		 */
		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'symbol_color',
			[
				'label' => esc_html__( 'Symbol Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6588fe',
				'selectors' => [
					'{{WRAPPER}} .courses-symbol' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Symbol Typography', 'studentwp-core' ),
				'name' => 'symbol_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-symbol',
			]
		);

		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .courses-price' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography', 'studentwp-core' ),
				'name' => 'price_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-price',
			]
		);

		$this->end_controls_section();

		/**
		 * Date styling 
		 * Contorl section stared.
		 */
		$this->start_controls_section(
			'Date_style',
			[
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'date_icon',
			[
				'label' => esc_html__( 'Icon', 'studentwp-core' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'far fa-calendar-alt',
					'library' => 'fa-regular',
				],
			]
		);
		
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .date-courses-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_color',
			[
				'label' => esc_html__( 'Date Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .date-courses' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Date Typography', 'studentwp-core' ),
				'name' => 'date_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .date-courses',
			]
		);

		$this->end_controls_section();

		/**
		 * Instructor Styling control 
		 * section started.
		 */
		$this->start_controls_section(
			'Instructor_style',
			[
				'label' => esc_html__( 'Instructor', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'instructor_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .courses-instructor' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'instructor__typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-instructor',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content_listview_style',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'content_listview_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .courses-content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_list_view_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-content',
			]
		);

		$this->end_controls_section();

		/**
		 * Buy now button styling
		 * and typography
		 */
		$this->start_controls_section(
			'content_listview_button_style',
			[
				'label' => esc_html__( 'Button', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs('buy_now_button_colors');

		$this->start_controls_tab('buy_now_button_normal_colors', [
			'label'	=> esc_html__('Normal', 'studetnwp-core')
		]);
		$this->add_control(
			'buy_now_button_normal_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .lp-button' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'buy_now_button_normal_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6588fe',
				'selectors' => [
					'{{WRAPPER}} .lp-button' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'buy_now_button_normal_border',
				'label' => __( 'Border', 'studentwp-core' ),
				'selector' => '{{WRAPPER}} .lp-button',
			]
		);
		$this->end_controls_tab();

		$this->start_controls_tab('buy_now_button_hover_colors', [
			'label'	=> esc_html__('Hover', 'studetnwp-core')
		]);

		$this->add_control(
			'buy_now_button_hover_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#fff',
				'selectors' => [
					'{{WRAPPER}} .lp-button:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'buy_now_button_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#0e1951',
				'selectors' => [
					'{{WRAPPER}} .lp-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'buy_now_button_hover_border',
				'label' => __( 'Border', 'studentwp-core' ),
				'selector' => '{{WRAPPER}} .lp-button:hover',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_list_view_button_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .lp-button',
			]
		);

		$this->add_responsive_control(
			'buy_now_button_padding',
			[
				'label' => esc_html__( 'Padding', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	=> [
					'top'	=> '17',
					'bottom'=> '17',
					'right'	=> '45',
					'left'	=> '45',
					'unit'	=> 'px',
					'isLinked'	=> false,
				],
				'selectors' => [
					'{{WRAPPER}} .lp-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'buy_now_button_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default'	=> [
					'top'	=> '0',
					'bottom'=> '0',
					'right'	=> '0',
					'left'	=> '0',
					'unit'	=> 'px',
					'isLinked'	=> false,
				],
				'selectors' => [
					'{{WRAPPER}} .lp-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Arrows Controler section started.
		 */
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/courseslistview.php' ))) {
			include get_theme_file_path( 'templates/elementor/courseslistview.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/courseslistview.php';
	}
}