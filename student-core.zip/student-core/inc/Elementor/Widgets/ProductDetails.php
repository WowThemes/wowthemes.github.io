<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ProductDetails extends Widget_Base {

	public function get_name() {
		return 'StudentwpProductDetails';
	}

	public function get_title() {
		return esc_html__( 'ProductDetails', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'ProductDetails', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_productdetails_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('product_cat', ['hide_empty' => false]),
				'default' => [ 'HTML', 'description' ],

			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		
		$this->end_controls_section();


		 $this->start_controls_section(
			'product_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .product-name',
			]
		);
		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .product-name' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .product-name:hover, {{WRAPPER}} .product-name:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .product-price' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography', 'studentwp-core' ),
				'name' => 'price typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .product-price',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_section();
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'button_text_color',
			[
				'label' => esc_html__( 'Button Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .add-cart-button' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Button Text Typography', 'studentwp-core' ),
				'name' => 'Button typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .add-cart-button',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'icon-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.add-cart-button',
			]
		);
		$this->end_controls_tab();
		$this->end_controls_section();


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/productdetails.php' ))) {
			include get_theme_file_path( 'templates/elementor/productdetails.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/productdetails.php';
	}
}