<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class CoursesGridView extends Widget_Base {

	public function get_name() {
		return 'StudentwpCoursesGridView';
	}

	public function get_title() {
		return esc_html__( 'Courses grid View', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'CoursesGridView', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}



	protected function _register_controls() {
		$this->start_controls_section(
			'section_coursesgridview_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		
		
		$this->add_control(
			'cols',
			[
				'label'     => esc_html__( 'Number of Columns', 'studentwp-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'       => [
					2		=> esc_html__('2', 'studentwp-core'),
					3		=> esc_html__('3', 'studentwp-core')
				],
				'default'   => 3,
			]
		);
		$this->add_control(
			'number',
			[
				'label'     => esc_html__( 'Courses to Show', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 500,
				'default'   => 3,
			]
		);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('course_category', ['hide_empty' => false]),
				'default' => [],

			]
		);
		$this->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('course_tag', ['hide_empty' => false]),
				'default' => [],
			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		$this->add_control(
			'only_free_courses',
			[
				'label' => __( 'Only Free Courses', 'plugin-domain' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'includes',
			[
				'label' => esc_html__( 'Includes', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_posts('lp_course', ['courses_per_page' => -1]),
				'default' => [],
			]
		);
		$this->end_controls_section();

		 $this->start_controls_section(
			'student_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-grid-view-title',
			]
		);
		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .courses-grid-view-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .courses-grid-view-title:hover, {{WRAPPER}} .courses-grid-view-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		/**
		 * Pricing and symbol 
		 * styling and typography 
		 * constrol section started.
		 */
		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'symbol_color',
			[
				'label' => esc_html__( 'Symbol Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6588fe',
				'selectors' => [
					'{{WRAPPER}} .courses-symbol' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Symbol Typography', 'studentwp-core' ),
				'name' => 'symbol_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-symbol',
			]
		);

		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#222',
				'selectors' => [
					'{{WRAPPER}} .courses-price' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography', 'studentwp-core' ),
				'name' => 'price_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-price',
			]
		);

		$this->end_controls_section();


		/**
		 * Instructor Styling control 
		 * section started.
		 */
		$this->start_controls_section(
			'instructor_style',
			[
				'label' => esc_html__( 'Instructor', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'instructor_grid_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .teacher-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'instructor_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .teacher-name',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'duration_style',
			[
				'label' => esc_html__( 'Duration', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'duration_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .courses-content' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .courses-content',
			]
		);

		$this->end_controls_section();

		/**
		 * Arrows Controler section started.
		 */
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/coursesgridview.php' ))) {
			include get_theme_file_path( 'templates/elementor/coursesgridview.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/coursesgridview.php';
	}

}