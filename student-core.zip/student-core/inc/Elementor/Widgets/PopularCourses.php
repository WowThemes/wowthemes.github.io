<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Controls_Stack;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class PopularCourses extends Widget_Base {

	public function get_name() {
		return 'StudentwpPopularCourses';
	}

	public function get_title() {
		return esc_html__( 'PopularCourses', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return array( 'PopularCourses', 'icon' );
	}
	public function get_categories() {
		return array( 'we-widget' );
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @since  0.0.1
	 * @access public
	 * @return array Element script dependencies.
	 */
	public function get_script_depends() {
		return array( 'owl-carousel', 'studentwp-scripts' );
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_popularcourses_query_setting',
			array(
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			)
		);

		$this->add_control(
			'number',
			array(
				'label'   => esc_html__( 'Popular Courses to Show', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 500,
				'default' => 3,
			)
		);

		$this->add_control(
			'categories',
			array(
				'label'    => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_terms( 'course_category', array( 'hide_empty' => false ) ),
				'default'  => array(),

			)
		);
		$this->add_control(
			'tags',
			array(
				'label'    => esc_html__( 'Tags', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_terms( 'course_tag', array( 'hide_empty' => false ) ),
				'default'  => array(),
			)
		);
		$this->add_control(
			'sorting_order',
			array(
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => array(
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated'    => esc_html__( 'Top rated', 'studentwp-core' ),
					'date'         => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price'    => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price'   => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc'    => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc'   => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				),
				'default' => '',
			)
		);
		$this->add_control(
			'only_free_courses',
			array(
				'label'        => esc_html__( 'Only Free Courses', 'plugin-domain' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'studentwp-core' ),
				'label_off'    => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);
		$this->add_control(
			'includes',
			array(
				'label'    => esc_html__( 'Includes', 'studentwp-core' ),
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'options'  => student_get_posts( 'lp_course', array( 'courses_per_page' => -1 ) ),
				'default'  => array(),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_popularcourses_caoursel',
			array(
				'label' => esc_html__( 'Caoursel Settings', 'studentwp-core' ),
			)
		);

		$this->add_control(
			'enable_carousel',
			array(
				'label'   => esc_html__( 'Enable Carousel', 'studentwp-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			)
		);
		$this->add_control(
			'number_item',
			array(
				'label'     => esc_html__( 'Number of Items', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 3,
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'number_items_tablet',
			array(
				'label'     => esc_html__( 'Number of Items (Tablet)', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '1',
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'number_items_mobile',
			array(
				'label'     => esc_html__( 'Number of Items (Mobile)', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => '1',
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'speed',
			array(
				'label'     => esc_html__( 'Speed', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'default'   => 500,
				'condition' => array(
					'autoplay'        => 'yes',
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->add_control(
			'autoplay',
			array(
				'label'              => esc_html__( 'Autoplay', 'studentwp-core' ),
				'type'               => Controls_Manager::SWITCHER,
				'default'            => 'yes',
				'frontend_available' => true,
				'condition'          => array(
					'enable_carousel' => 'yes',
				),
			)
		);

		$this->add_control(
			'carousel_arrow_left_icon',
			array(
				'label'     => esc_html__( 'Left Arrow Icon', 'studentwp-core' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => array(
					'library' => 'fa-solid',
					'value'   => 'fa-chevron-left',
				),
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);

		$this->add_control(
			'carousel_arrow_right_icon',
			array(
				'label'     => esc_html__( 'Right Arrow Icon', 'studentwp-core' ),
				'type'      => Controls_Manager::ICONS,
				'default'   => array(
					'library' => 'fa-solid',
					'value'   => 'fa-chevron-right',
				),
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'student_title',
			array(
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .post-title',
			)
		);
		$this->add_control(
			'Title_text_color',
			array(
				'label'     => esc_html__( 'Text Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .post-title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'title_hover_color',
			array(
				'label'     => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .post-title:hover, {{WRAPPER}} .post-title:focus' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		/**
		 * Free course badge typography
		 * and colors styling control
		 * section starts.
		 */
		$this->start_controls_section(
			'free_course_bage',
			array(
				'label' => esc_html__( 'Free Course Badge', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'typography1',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .free-bage_courses',
			)
		);
		$this->add_control(
			'free_course_bage_text_color',
			array(
				'label'     => esc_html__( 'Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .free-bage_courses' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'free_course_bage_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6588fe',
				'selectors' => array(
					'{{WRAPPER}} .free-bage_courses' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->end_controls_section();

		/**
		 * Pricing and symbol
		 * styling and typography
		 * constrol section started.
		 */
		$this->start_controls_section(
			'price_style',
			array(
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);
		$this->add_control(
			'symbol_color',
			array(
				'label'     => esc_html__( 'Symbol Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6588fe',
				'selectors' => array(
					'{{WRAPPER}} .price-symbol' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'label'    => esc_html__( 'Symbol Typography', 'studentwp-core' ),
				'name'     => 'symbol_typography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .price-symbol',
			)
		);

		$this->add_control(
			'price_color',
			array(
				'label'     => esc_html__( 'Price Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#222',
				'selectors' => array(
					'{{WRAPPER}} .post-price' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'label'    => esc_html__( 'Price Typography', 'studentwp-core' ),
				'name'     => 'price_typography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .post-price',
			)
		);

		$this->end_controls_section();

		/**
		 * Date styling
		 * Contorl section stared.
		 */
		$this->start_controls_section(
			'Date_style',
			array(
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'date_icon',
			array(
				'label'            => esc_html__( 'Icon', 'studentwp-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default'          => array(
					'value'   => 'far fa-calendar-alt',
					'library' => 'fa-regular',
				),
			)
		);

		$this->add_control(
			'icon_color',
			array(
				'label'     => esc_html__( 'Icon Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .date-courses-icon' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'date_color',
			array(
				'label'     => esc_html__( 'Date Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .date-courses' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'label'    => esc_html__( 'Date Typography', 'studentwp-core' ),
				'name'     => 'date_typography1',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .date-courses',
			)
		);

		$this->end_controls_section();

		/**
		 * Instructor Styling control
		 * section started.
		 */
		$this->start_controls_section(
			'Instructor_style',
			array(
				'label' => esc_html__( 'Instructor', 'studentwp-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'instructor_color',
			array(
				'label'     => esc_html__( 'Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .post-instructor' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'instructor__typography',
				'global'   => array(
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				),
				'selector' => '{{WRAPPER}} .post-instructor',
			)
		);

		$this->end_controls_section();

		/**
		 * Arrows Controler section started.
		 */
		$this->start_controls_section(
			'carousel_arrows_style',
			array(
				'label'     => esc_html__( 'Arrows', 'studentwp-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => array(
					'enable_carousel' => 'yes',
				),
			)
		);

		$this->start_controls_tabs( 'carousel_arrows_style_tabs' );

		$this->start_controls_tab(
			'carousel_arrows_style_tabs_normal',
			array(
				'label' => esc_html__( 'Normal', 'student-core' ),
			)
		);

		$this->add_control(
			'carousel_arrows_color',
			array(
				'label'     => esc_html__( 'Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .owl-nav > button' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'carousel_arrows_bg_color',
			array(
				'label'     => esc_html__( 'Background Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#6588fe',
				'selectors' => array(
					'{{WRAPPER}} .owl-nav > button' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'carousel_arrows_style_tabs_hover',
			array(
				'label' => esc_html__( 'Hover', 'student-core' ),
			)
		);

		$this->add_control(
			'carousel_arrows_hover_color',
			array(
				'label'     => esc_html__( 'Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#fff',
				'selectors' => array(
					'{{WRAPPER}} .owl-nav > button:hover' => 'color: {{VALUE}};',
				),
			)
		);
		$this->add_control(
			'carousel_arrows_bg_hover_color',
			array(
				'label'     => esc_html__( 'Background Color', 'studentwp-core' ),
				'type'      => Controls_Manager::COLOR,
				'default'   => '#0e1951',
				'selectors' => array(
					'{{WRAPPER}} .owl-nav > button:hover' => 'background-color: {{VALUE}};',
				),
			)
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 *
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if ( file_exists( get_theme_file_path( 'templates/elementor/popularcourses.php' ) ) ) {
			include get_theme_file_path( 'templates/elementor/popularcourses.php' );
			return;
		}

		include STUDENT_CORE_PATH . 'templates/elementor/popularcourses.php';
	}
}
