<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Testimonials extends Widget_Base {

	public function get_name() {
		return 'StudentwpTestimonials';
	}

	public function get_title() {
		return esc_html__( 'Testimonials', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Testimonials', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'title_name', [
				'label' => esc_html__( 'Name', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Name' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'designation', [
				'label' => esc_html__( 'Designation', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Designation' , 'studentwp-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_content', [
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'List Content' , 'studentwp-core' ),
				'show_label' => false,
			]
		);

		$repeater->add_control(
			'list_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
				],
			]
		);

		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title_name' => esc_html__( 'Name', 'studentwp-core' ),
						'list_content' => esc_html__( 'Content', 'studentwp-core' ),
					],
				
				],
				'title_field' => '{{{ title_name }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_courses_caoursel',
			[
				'label' => esc_html__( 'Caoursel Settings', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'enable_carousel',
			[
				'label'   => esc_html__( 'Enable Carousel', 'studentwp-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'number_items',
			[
				'label'   => esc_html__( 'Number of Items', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'number_items_tablet',
			[
				'label'   => esc_html__( 'Number of Items tablet', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '1',
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'number_items_mobile',
			[
				'label'   => esc_html__( 'Number of Items Mobile', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '1',
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'speed',
			[
				'label' => esc_html__( 'Speed', 'studentwp-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 5000,
				'condition' => [
					'autoplay' => 'yes',
				],
				'render_type' => 'none',
				'frontend_available' => true,
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'frontend_available' => true,
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);

		$this->add_control(
           'carousel_arrow_left_icon',
           [
               'label'     => esc_html__( 'Left Arrow Icon', 'studentwp-core' ),
               'type'      => Controls_Manager::ICONS,
               'default'   => ['library' => 'fa-solid', 'value' => 'fa-chevron-left'],
               'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
           ]
        );

        $this->add_control(
           'carousel_arrow_right_icon',
           [
               'label'     => esc_html__( 'Right Arrow Icon', 'studentwp-core' ),
               'type'      => Controls_Manager::ICONS,
               'default'   => ['library' => 'fa-solid', 'value' => 'fa-chevron-right'],
               'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
           ]
        );
		$this->end_controls_section();

		 $this->start_controls_section(
			'testimonial_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .testimonial-title',
			]
		);
		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .testimonial-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .testimonial-title:hover, {{WRAPPER}} .testimonial-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'designation',
			[
				'label' => esc_html__( 'Designation', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .testimonial-designation',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'designation_color',
			[
				'label' => esc_html__( 'Designation Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .testimonial-designation' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'paragraph_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .testi-paragraph',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .testimonial-paragraph' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'arrows_style',
			[
				'label' => esc_html__( 'Arrows', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'arrows_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .owl-prev, {{WRAPPER}} .owl-next' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'arrows_hover_color',
			[
				'label' => esc_html__( 'Arrows hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .owl-prev:hover, {{WRAPPER}} .owl-next:focus' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'arrows_size',
			[
				'label' => esc_html__( 'Size', 'studentwp-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 20,
						'max' => 60,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .elementor-swiper-button.elementor-swiper-button-prev, {{WRAPPER}} .elementor-swiper-button.elementor-swiper-button-next' => 'font-size: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'navigation' => [ 'arrows', 'both' ],
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'arrowsbackground',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .owl-prev, {{WRAPPER}} .owl-next',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'arrows_background_hover',
				'label' => esc_html__( 'Background Hover', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .owl-prev:hover, {{WRAPPER}} .owl-next:hover',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);


		$this->end_controls_section();


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if(file_exists(get_theme_file_path( 'templates/elementor/testimonials.php' ))) {
			include get_theme_file_path( 'templates/elementor/testimonials.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/testimonials.php';
	}

}