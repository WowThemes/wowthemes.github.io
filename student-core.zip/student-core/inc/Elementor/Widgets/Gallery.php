<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Gallery extends Widget_Base {

	public function get_name() {
		return 'StudentwpGallery';
	}

	public function get_title() {
		return esc_html__( 'Gallery', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Gallery', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @since  0.0.1
	 * @access public
	 * @return array Element script dependencies.
	 */
	public function get_script_depends() {
		return [ 'isotope', 'imagesloaded', 'studentwp-scripts' ];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_gallery_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'title_name', [
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$repeater->add_control(
			'url', [
				'label' => esc_html__( 'URL', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::URL,
			]
		);
		$repeater->add_control(
			'tags', [
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Tags' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title_name' => esc_html__( 'Title', 'studentwp-core' ),
						'image' => esc_html__( 'Image', 'studentwp-core' ),
					],
				
				],
				'title_field' => '{{{ title_name }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'gallery_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .gallery-title',
			]
		);
		$this->add_control(
			'Title_color',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .gallery-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .gallery-title:hover, {{WRAPPER}} .gallery-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();
		$this->start_controls_section(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography1',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .gallery-tag',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'tags_color',
			[
				'label' => esc_html__( 'Tags Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}}.gallery-tag' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		if(file_exists(get_theme_file_path( 'templates/elementor/gallery.php' ))) {
			include get_theme_file_path( 'templates/elementor/gallery.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/gallery.php';
	}
}