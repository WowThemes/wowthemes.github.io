<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class AcademicTabs extends Widget_Base {

	public function get_name() {
		return 'StudentwpAcademicTabs';
	}

	public function get_title() {
		return esc_html__( 'AcademicTabs', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'AcademicTabs', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_academictabs_query_setting',
			[
				'label' => esc_html__( 'Tabs', 'studentwp-core' ),
			]
		);

		$repeater = new \Elementor\Repeater();
		
		$repeater->add_control(
			'source',
			[
				'label' => esc_html__( 'Source', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'default'  => esc_html__( 'Default', 'studentwp-core' ),
					'elementor_template' => esc_html__( 'Elementor Template', 'studentwp-core' ),
				],
				'default' => [ 'default', 'elementor template' ],
			]
		);
		$repeater->add_control(
			'template',
			[
				'label' => esc_html__( 'Template', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => student_get_posts('elementor_library', ['posts_per_page' => -1]),
				'template' => [ 'Display', 'elementor template' ],
				'condition' => ['source' => 'elementor_template'],
			]
		);
		$repeater->add_control(
			'title_name', [
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'image1',
			[
				'label' => esc_html__( 'Choose Image', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition'=>['source'=>'default'],
			]
		);
		$repeater->add_control(
			'image2',
			[
				'label' => esc_html__( 'Choose Image', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition'=>['source'=>'default'],

			]
		);
		
		$repeater->add_control(
			'content', [
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Content' , 'studentwp-core' ),
				'show_label' => true,
				'condition'=>['source'=>'default'],
			]
		);
		
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'title_name' => esc_html__( 'Title', 'studentwp-core' ),
						'image1' => esc_html__( 'Image', 'studentwp-core' ),
					],
				
				],
				'title_field' => '{{{ title_name }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'tabs_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .acadmic-btn',
			]
		);
		$this->add_control(
			'Title_color',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .acadmic-btn' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .acadmic-btn:hover, {{WRAPPER}} .acadmic-btn:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'content_acadmic',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .acadmic-content' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_content',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .acadmic-content',
			]
		);
		$this->end_controls_section();

	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract($settings);
		if(file_exists(get_theme_file_path( 'templates/elementor/academictabs.php' ))) {
			include get_theme_file_path( 'templates/elementor/academictabs.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/academictabs.php';
	}

}