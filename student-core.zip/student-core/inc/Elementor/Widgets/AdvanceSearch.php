<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Controls_Stack;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class AdvanceSearch extends Widget_Base {

	public function get_name() {
		return 'StudentwpAdvanceSearch';
	}

	public function get_title() {
		return esc_html__( 'AdvanceSearch', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'AdvanceSearch', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @since  0.0.1
	 * @access public
	 * @return array Element script dependencies.
	 */

	protected function _register_controls() {
		$this->start_controls_section(
			'section_advancesearch_query_setting',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'show_categories',
			[
				'label' => esc_html__( 'Show Categories', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_duration',
			[
				'label' => esc_html__( 'Show Duration', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_level',
			[
				'label' => esc_html__( 'Show Level', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
		$this->add_control(
			'show_location',
			[
				'label' => esc_html__( 'Show Location', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'studentwp-core' ),
				'label_off' => esc_html__( 'Hide', 'studentwp-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);
	
		$this->add_control(
			'button_text', [
				'label' => esc_html__( 'Button Text', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Standard' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		
		$this->end_controls_section();


		 $this->start_controls_section(
			'category_style',
			[
				'label' => esc_html__( 'Category', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .category_search',
			]
		);
		$this->add_control(
			'category_text_color',
			[
				'label' => esc_html__( 'Category Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .category_search' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Pricing and symbol 
		 * styling and typography 
		 * constrol section started.
		 */
		$this->start_controls_section(
			'duration_style',
			[
				'label' => esc_html__( 'Duration', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'duration_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .duration_search',
			]
		);
		$this->add_control(
			'duration_text_color',
			[
				'label' => esc_html__( 'Duration Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .duration_search' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * Date styling 
		 * Contorl section stared.
		 */
		$this->start_controls_section(
			'level_style',
			[
				'label' => esc_html__( 'Level', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'level_color',
			[
				'label' => esc_html__( 'Level Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .level_search' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'level Typography', 'studentwp-core' ),
				'name' => 'level_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .level_search',
			]
		);

		$this->end_controls_section();


		/**
		 * Instructor Styling control 
		 * section started.
		 */
		$this->start_controls_section(
			'Location_style',
			[
				'label' => esc_html__( 'Location', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'location_color',
			[
				'label' => esc_html__( 'Location Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .location_search' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'location_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .location_search',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'keyword_style',
			[
				'label' => esc_html__( 'Keyword', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'keyword_color',
			[
				'label' => esc_html__( 'Keyword Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .keyword_search' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'keyword_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .keyword_search',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
				
		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .button_search' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'Button_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .button_search',
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.button-search',
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/advancesearch.php' ))) {
			include get_theme_file_path( 'templates/elementor/advancesearch.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/advancesearch.php';
	}

}