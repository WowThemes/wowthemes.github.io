<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class InstructorColumnTwo extends Widget_Base {

	public function get_name() {
		return 'StudentwpInstructorColumnTwo';
	}

	public function get_title() {
		return esc_html__( 'InstructorColumnTwo', 'studentwp-core' );
	}
	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'InstructorColumnTwo', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_instructorcolumntwo_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'Instructor to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 500,
					'default'   => 3,
				]
			);

		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-name',
			]
		);
		$this->add_control(
			'instructor_text_color',
			[
				'label' => esc_html__( 'Instructor Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'instructor_hover_color',
			[
				'label' => esc_html__( 'Instructor hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-name:hover, {{WRAPPER}} .instructor-name:focus' => 'color: {{VALUE}};'
				],
			]
		);	
		$this->end_controls_section();
		$this->start_controls_section(
			'subject',
			[
				'label' => esc_html__( 'Subject', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subject_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-subject',
			]
		);
		$this->add_control(
			'subject_color',
			[
				'label' => esc_html__( 'Subject Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-subject' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'subject_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-subject:hover, {{WRAPPER}} .instructor-subject:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor-content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-content',
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-content' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if(file_exists(get_theme_file_path( 'templates/elementor/instructor-column-two.php' ))) {
			include get_theme_file_path( 'templates/elementor/instructor-column-two.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/instructor-column-two.php';
	}

}