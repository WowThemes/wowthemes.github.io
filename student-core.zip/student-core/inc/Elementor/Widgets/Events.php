<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Events extends Widget_Base {

	public function get_name() {
		return 'StudentwpEvents';
	}

	public function get_title() {
		return esc_html__( 'Events', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Events', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_event_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);		
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'Events to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 50,
					'default'   => 3,
				]
			);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('tribe_events_cat', ['hide_empty' => false]),
				'default' => [],

			]
		);
		$this->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('post_tag', ['hide_empty' => false]),
				'default' => [],
			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'recent' => esc_html__( 'Recent', 'studentwp-core' ),
					'most_commented' => esc_html__( 'Most Commented', 'studentwp-core' ),
					'author' => esc_html__( 'Author', 'studentwp-core' ),
					'rand' => esc_html__( 'Random', 'studentwp-core' ),
					'tite_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => 'Most Selling',
			]
		);
		
		$this->add_control(
			'includes',
			[
				'label' => esc_html__( 'Includes', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_posts('tribe_events', ['posts_per_page' => -1]),
				'default' => [],
			]
		);
		$this->end_controls_section();


		 $this->start_controls_section(
			'title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .event-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .event-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Title hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .event-title:hover, {{WRAPPER}} .event-title:focus' => 'color: {{VALUE}};'
				],
			]
		);

		$this->add_control(
			'title_color_sub',
			[
				'label' => esc_html__( 'Title Sub Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .event-title-sub' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_sub_event',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .event-title-sub',
			]
		);
		$this->add_control(
			'title__sub_hover_color',
			[
				'label' => esc_html__( 'Title Sub hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .event-title-sub:hover, {{WRAPPER}} .event-title-sub:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();
		$this->start_controls_section(
			'date',
			[
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography2',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .event-date',
			]
		);
		$this->add_control(
			'date_color',
			[
				'label' => esc_html__( 'Date Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .event-date' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'event_date_hover_color',
			[
				'label' => esc_html__( 'Date hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .event-date:hover, {{WRAPPER}} .event-date:focus' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'time_style',
			[
				'label' => esc_html__( 'Time', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'time_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .event-time' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'time typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .event-time',
			]
		);
		$this->add_control(
			'date_hover_color',
			[
				'label' => esc_html__( 'Date hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .event-time:hover, {{WRAPPER}} .event-time:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'free_event_bage',
			[
				'label' => esc_html__( 'Free Event Badge', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography1',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .bage-title',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'free_event_bage_text_color',
			[
				'label' => esc_html__( 'Free Event Badge Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .bage-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bage_background_hover',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bage-title, {{WRAPPER}} .bage-title',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->end_controls_tabs();
		$this->end_controls_section();

	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/events.php' ))) {
			include get_theme_file_path( 'templates/elementor/events.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/events.php';
	}

}