<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Blog extends Widget_Base {

	public function get_name() {
		return 'StudentwpBlog';
	}

	public function get_title() {
		return esc_html__( 'Blog', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'Blog', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_blog_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'number',
			[
				'label'     => esc_html__( 'Posts to Show', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 50,
				'default'   => 3,
			]
		);
		$this->add_control(
			'columns',
			[
				'label'     => esc_html__( 'Columns', 'studentwp-core' ),
				'type'      => Controls_Manager::SELECT2,
				'options'	=> [6 => esc_html__('Two Columns'), 4 => esc_html__('Three Columns')],
				'default'   => 4,
			]
		);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('category', ['hide_empty' => false]),
				'default' => [],

			]
		);
		$this->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('post_tag', ['hide_empty' => false]),
				'default' => [],
			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'recent' => esc_html__( 'Recent', 'studentwp-core' ),
					'most_commented' => esc_html__( 'Most Commented', 'studentwp-core' ),
					'author' => esc_html__( 'Author', 'studentwp-core' ),
					'rand' => esc_html__( 'Random', 'studentwp-core' ),
					'tite_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => 'Most Selling',
			]
		);
		
		$this->add_control(
			'includes',
			[
				'label' => esc_html__( 'Includes', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_posts('post', ['posts_per_page' => -1]),
				'default' => [],
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'post_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .post-title',
			]
		);

		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .post-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-title:hover, {{WRAPPER}} .post-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
	    $this->end_controls_section();

		$this->start_controls_section(
			'content_blog',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .blog-content',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .blog-content' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'author',
			[
				'label' => esc_html__( 'Author', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'authortypography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .author-name',
			]
		);

		$this->add_control(
			'author_text_color',
			[
				'label' =>esc_html__( 'Author Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .author-name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'author_hover_color',
			[
				'label' => esc_html__( 'Author hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .author-name:hover, {{WRAPPER}} .author-name:focus' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'autor_date',
			[
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'datetypography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .date-style',
			]
		);

		$this->add_control(
			'author_date_color',
			[
				'label' => esc_html__( 'Date Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .date-style' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_hover_color',
			[
				'label' => esc_html__( 'date hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .date-style:hover, {{WRAPPER}} .date-style:focus' => 'color: {{VALUE}};'
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'free_course_bage',
			[
				'label' => esc_html__( 'Free Course Badge', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography1',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .free-bage_courses',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'free_course_bage_text_color',
			[
				'label' => esc_html__( 'Free Course Badge Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .free-bage_courses' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'bage_background_hover',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .free-bage_courses, {{WRAPPER}} .free-bage_courses',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->end_controls_tabs();

		$this->end_controls_section();

			$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'symbol_color',
			[
				'label' => esc_html__( 'Symbol Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .price-symbol' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Symbol Typography', 'studentwp-core' ),
				'name' => 'symbol_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .price-symbol',
			]
		);

		$this->add_control(
			'Month_color',
			[
				'label' => esc_html__( 'Month Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .post-price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Month Typography', 'studentwp-core' ),
				'name' => 'month_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .post-price',
			]
		);

		$this->end_controls_tab();

		$this->end_controls_section();

		$this->start_controls_section(
			'Date_style',
			[
				'label' => esc_html__( 'Date', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'date_icon',
			[
				'label' => esc_html__( 'Icon', 'studentwp-core' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'fa-solid',
				],
			]
		);
		

		$this->start_controls_tabs( 'date_style' );
			$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Icon Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .date-courses-icon' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'date_color',
			[
				'label' => esc_html__( 'Date Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .date-courses' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Date Typography', 'studentwp-core' ),
				'name' => 'date_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .date-courses',
			]
		);

		$this->end_controls_tabs();

		$this->end_controls_section();

		$this->start_controls_section(
			'Instructor_style',
			[
				'label' => esc_html__( 'Instructor', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs( 'instructor_style' );

		
		$this->add_control(
			'instructor_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .post-instructor' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'instructor_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .post-instructor',
			]
		);

		$this->end_controls_tabs();
		
		$this->end_controls_section();


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/blog.php' ))) {
			include get_theme_file_path( 'templates/elementor/blog.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/blog.php';
	}

}