<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class MeetOurExpert extends Widget_Base {

	public function get_name() {
		return 'StudentwpMeetOurExpert';
	}

	public function get_title() {
		return esc_html__( 'MeetOurExpert', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'MeetOurExpert', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	/**
	 * Get script dependencies.
	 * Retrieve the list of script dependencies the element requires.
	 *
	 * @since  0.0.1
	 * @access public
	 * @return array Element script dependencies.
	 */
	public function get_script_depends() {
		return array( 'owl-carousel', 'studentwp-scripts' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'meet_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'meetourexpert_title', [
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Title' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'meetourexpert_content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'meet_content', [
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Content' , 'studentwp-core' ),
				'show_label' => true,
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'section_meetourexpert_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		
		
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'teacher to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 500,
					'default'   => 3,
				]
			);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		
		
		$this->end_controls_section();

		$this->start_controls_section(
			'section_courses_caoursel',
			[
				'label' => esc_html__( 'Caoursel Settings', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'enable_carousel',
			[
				'label'   => esc_html__( 'Enable Carousel', 'studentwp-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);
		$this->add_control(
			'number_item',
			[
				'label'   => esc_html__( 'Number of Items', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 3,
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'number_items_tablet',
			[
				'label'   => esc_html__( 'Number of Items (Tablet)', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '1',
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'number_items_mobile',
			[
				'label'   => esc_html__( 'Number of Items (Mobile)', 'studentwp-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => '1',
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);
		$this->add_control(
			'speed',
			[
				'label' => esc_html__( 'Speed', 'studentwp-core' ),
				'type' => Controls_Manager::NUMBER,
				'default' => 500,
				'condition' => [
					'autoplay' => 'yes',
					'enable_carousel'	=> 'yes'
				],
			]
		);
		$this->add_control(
			'autoplay',
			[
				'label' => esc_html__( 'Autoplay', 'studentwp-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'frontend_available' => true,
				'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
			]
		);

		$this->add_control(
           'carousel_arrow_left_icon',
           [
               'label'     => esc_html__( 'Left Arrow Icon', 'studentwp-core' ),
               'type'      => Controls_Manager::ICONS,
               'default'   => ['library' => 'fa-solid', 'value' => 'fa-chevron-left'],
               'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
           ]
        );

        $this->add_control(
           'carousel_arrow_right_icon',
           [
               'label'     => esc_html__( 'Right Arrow Icon', 'studentwp-core' ),
               'type'      => Controls_Manager::ICONS,
               'default'   => ['library' => 'fa-solid', 'value' => 'fa-chevron-right'],
               'condition'	=> [
					'enable_carousel'	=> 'yes'
				]
           ]
        );
		$this->end_controls_section();

		$this->start_controls_section(
			'title',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'meet_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .meet-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .meet-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'meet_hover_color',
			[
				'label' => esc_html__( 'Meet hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .meet-title:hover, {{WRAPPER}} .meet-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();
		$this->start_controls_section(
			'meet_style',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .meet-content',
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .meet-content' => 'color: {{VALUE}};',
				],
			]
		);
			
		$this->end_controls_section();

		 $this->start_controls_section(
			'subject_title',
			[
				'label' => esc_html__( 'Subject', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .subject-name',
			]
		);
		$this->add_control(
			'subject_text_color',
			[
				'label' => esc_html__( 'Subject Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .subject-name' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'subject_hover_color',
			[
				'label' => esc_html__( 'Subject hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .subject-name:hover, {{WRAPPER}} .subject-name:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		 $this->start_controls_section(
			'description_style',
			[
				'label' => esc_html__( 'Description', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'description typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .description-user',
			]
		);
		$this->add_control(
			'description_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .description-user' => 'color: {{VALUE}};',
				],
			]
		);
			
		$this->end_controls_section();
		$this->start_controls_section(
			'Instructor_style',
			[
				'label' => esc_html__( 'Instructor', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'instructor_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .teacher-name' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'instructor typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .teacher-name',
			]
		);
		$this->add_control(
			'instructor_hover_color',
			[
				'label' => esc_html__( 'Instructor hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .teacher-name:hover, {{WRAPPER}} .teacher-name:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_tab();

		$this->end_controls_tabs();
		$this->end_controls_section();


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/meetourexpert.php' ))) {
			include get_theme_file_path( 'templates/elementor/meetourexpert.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/meetourexpert.php';
	}
}