<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class ShopListGrid extends Widget_Base {

	public function get_name() {
		return 'StudentwpShopListGrid';
	}

	public function get_title() {
		return esc_html__( 'ShopListGrid', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'ShopListGrid', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_shopListgrid_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'cols',
			[
				'label'     => esc_html__( 'Number of Columns', 'studentwp-core' ),
				'type'      => Controls_Manager::SELECT,
				'options'       => [
					2		=> esc_html__('2', 'studentwp-core'),
					3		=> esc_html__('3', 'studentwp-core')
				],
				'default'   => 2,
			]
		);
		$this->add_control(
		'number',
			[
				'label'     => esc_html__( 'Number of Products', 'studentwp-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 1,
				'max'       => 500,
				'default'   => 3,
			]
		);

		$this->add_control(
			'categories',
			[
				'label' => esc_html__( 'Select Categories:', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('product_cat', ['hide_empty' => false]),
				'default' => [],

			]
		);
		$this->add_control(
			'tags',
			[
				'label' => esc_html__( 'Tags', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_terms('product_tag', ['hide_empty' => false]),
				'default' => [],
			]
		);
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => 'date',
			]
		);
		$this->add_control(
			'includes',
			[
				'label' => esc_html__( 'Includes', 'studentwp-core' ),
				'type' => Controls_Manager::SELECT2,
				'multiple' => true,
				'options' => student_get_posts('product', ['posts_per_page' => -1]),
				'default' => [],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'categories_style',
			[
				'label' => esc_html__( 'Categories Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'ccategories_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .tag-shoplist',
			]
		);
		$this->add_control(
			'category_color',
			[
				'label' => esc_html__( 'Category Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .tag-shoplist' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'category_hover_color',
			[
				'label' => esc_html__( 'Category Hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .tag-shoplist:hover, {{WRAPPER}} .tag-shoplist:focus' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		 $this->start_controls_section(
			'shoplist_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .shoplist-title',
			]
		);
		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .shoplist-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .shoplist-title:hover, {{WRAPPER}} .shoplist-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .shoplist-price' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Price Typography', 'studentwp-core' ),
				'name' => 'price_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .shoplist-price',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'add_to_cart_style_tabs'
		);
		$this->start_controls_tab(
			'add_to_cart_style_normal_tab',
			[
				'label' => esc_html__( 'Normal', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'add_to_cart_button_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .button' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'add_to_cart_button_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#6588fe',
				'selectors' => [
					'{{WRAPPER}} .button' => 'background-color: {{VALUE}};',
				],
			]
		);
		
		$this->end_controls_tab();

		$this->start_controls_tab(
			'add_to_cart_style_hover_tab',
			[
				'label' => esc_html__( 'Hover', 'studentwp-core' ),
			]
		);

		$this->add_control(
			'add_to_cart_button_hover_color',
			[
				'label' => esc_html__( 'Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default'	=> '#fff',
				'selectors' => [
					'{{WRAPPER}} .button:hover, {{WRAPPER}} .button:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'add_to_cart_button_hover_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default'	=> '#0e1951',
				'selectors' => [
					'{{WRAPPER}} .button:hover, {{WRAPPER}} .button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tab(); // End of Control tab.

		$this->end_controls_tabs(); // End of Control Tabs.

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'add_to_cart_button_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .button',
			]
		);
		$this->add_responsive_control(
			'add_to_cart_button_padding',
			[
				'label' => esc_html__( 'Button Padding', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'default'	=> ['top' => 15, 'right' => 40, 'bottom' => 15, 'left' => 40, 'unit' => 'px', 'isLinked' => false],
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'add_to_cart_button_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default'	=> ['top' => 50, 'right' => 50, 'bottom' => 50, 'left' => 50, 'unit' => 'px', 'isLinked' => true],
				'selectors' => [
					'{{WRAPPER}} .button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .button',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'add_to_cart_border',
				'label' => esc_html__( 'Border', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .button',
			]
		);
		
		$this->end_controls_section();


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		if(file_exists(get_theme_file_path( 'templates/elementor/shoplistgrid.php' ))) {
			include get_theme_file_path( 'templates/elementor/shoplistgrid.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/shoplistgrid.php';
	}

}