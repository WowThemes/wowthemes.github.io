<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class PricingPlans extends Widget_Base {

	public function get_name() {
		return 'PricingPlans';
	}

	public function get_title() {
		return esc_html__( 'PricingPlans', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'PricingPlans', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function register_controls() {
		
		$this->start_controls_section(
			'Content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'pricingplan_name', [
				'label' => esc_html__( 'Plan Name', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Standard' , 'studentwp-core' ),
				'label_block' => true,
			]
		);

		
		/*$this->add_control(
			'symbol',
			[
				'label' => esc_html__( 'Symbol', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::ICON,
			]
		);*/
		
		$this->add_control(
			'symbol',
			[
				'label' => esc_html__( 'Symbol', 'studentwp-core' ),
				'type' => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'default' => [
					'value' => 'fas fa-star',
					'library' => 'fa-solid',
				],
			]
		);
		
		
		$this->add_control(
			'price', [
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( '' , 'studentwp-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'duration', [
				'label' => esc_html__( 'Duration', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'button_text', [
				'label' => esc_html__( 'Button Text', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		
		$this->add_control(
			'button_link',
			[
				'label' => esc_html__( 'Button Link', 'studentwp-core' ),
				'type' => Controls_Manager::URL,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'https://your-link.com', 'studentwp-core' ),
				'separator' => 'before',
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'feature',
			[
				'label' => esc_html__( 'Features', 'studentwp-core' ),
			]
		);

		$repeater = new \Elementor\Repeater()
		;
		$repeater->add_control(
			'feature_name', [
				'label' => esc_html__( 'Feature Name', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Feature Name' , 'studentwp-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Features', 'studentwp-core' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'feature_name' => esc_html__( 'Features Name', 'studentwp-core' ),
					],
				
				],
				'title_field' => '{{{ feature_name }}}',
			]
		);
		$this->end_controls_section();
		

		$this->start_controls_section(
			'header',
			[
				'label' => esc_html__( 'Header', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'header-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.subscribe-warpper',
			]
		);
	

		$this->add_responsive_control(
			'header_padding',
			[
				'label' => esc_html__( 'Padding', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'height',
			[
				'label' => esc_html__( 'Height', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 500,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .ss' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);
			
		$this->end_controls_section();

		 $this->start_controls_section(
			'plan_style',
			[
				'label' => esc_html__( 'Plan', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .peicingplanename',
			]
		);
		$this->add_control(
			'plan_color',
			[
				'label' => esc_html__( 'Plan Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .peicingplanename' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'symbol_style',
			[
				'label' => esc_html__( 'Symbol', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'symbol_color',
			[
				'label' => esc_html__( 'Symbol Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .symbol-price' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'symbol_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .symbol-price',
			]
		);
		
		$this->end_controls_section();


		$this->start_controls_section(
			'price_style',
			[
				'label' => esc_html__( 'Price', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'price_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .price',
			]
		);
		$this->add_control(
			'price_color',
			[
				'label' => esc_html__( 'Price Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .price' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'duration_style',
			[
				'label' => esc_html__( 'Duration', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'duration_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .plan_duration',
			]
		);
		$this->add_control(
			'duration_color',
			[
				'label' => esc_html__( 'Duration Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .plan_duration' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
		$this->start_controls_section(
			'feature_style',
			[
				'label' => esc_html__( 'Feature', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'feature_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .feature_name',
			]
		);
		$this->add_control(
			'feature_color',
			[
				'label' => esc_html__( 'Feature Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .feature_name' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'button_color',
			[
				'label' => esc_html__( 'Button Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .price_button' => 'color: {{VALUE}};',
				],
			]
		);
		
		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button-background',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}}.price_button',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .price_button',
			]
		);
		$this->add_responsive_control(
			'button_padding',
			[
				'label' => esc_html__( 'Button Padding', 'studentwp-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .price_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button_box_shadow',
				'selector' => '{{WRAPPER}} .price_button',
			]
		);
		$this->add_control(
			'button_hover_color',
			[
				'label' => esc_html__( 'Button Hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .price_button:hover, {{WRAPPER}} .price_button:focus' => 'color: {{VALUE}};',
					'{{WRAPPER}} .price_button:hover svg, {{WRAPPER}} .price_button:focus svg' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'button_background_hover',
				'label' => esc_html__( 'Background', 'studentwp-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .price_button:hover, {{WRAPPER}} .price_button:focus',
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
				],
			]
		);

		$this->end_controls_section();

		
		


	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings();
		extract($settings);
		if(file_exists(get_theme_file_path( 'templates/elementor/pricingplans.php.php' ))) {
			include get_theme_file_path( 'templates/elementor/pricingplans.php.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/pricingplans.php';
	}
}