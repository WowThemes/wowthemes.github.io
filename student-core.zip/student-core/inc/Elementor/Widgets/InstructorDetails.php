<?php
namespace StudentCore\Elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Icons_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Background;
use Elementor\Controls_Stack;
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class InstructorDetails extends Widget_Base {

	public function get_name() {
		return 'StudentwpInstructorDetails';
	}

	public function get_title() {
		return esc_html__( 'InstructorDetails', 'studentwp-core' );
	}

	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_keywords() {
		return [ 'InstructorDetails', 'icon' ];
	}
	public function get_categories() {
		return ['we-widget'];
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
			]
		);
		$this->add_control(
			'progress_title',
			[
				'label' => esc_html__( 'Progress Title', 'studentwp-core' ),
				'type' => Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => esc_html__( 'Enter your title', 'studentwp-core' ),
				'default' => esc_html__( 'My Skill', 'studentwp-core' ),
				'label_block' => true,
			]
		);
       $this->end_controls_section();
       $this->start_controls_section(
			'section_meetourexpert_query_setting',
			[
				'label' => esc_html__( 'Query Settings', 'studentwp-core' ),
			]
		);
		
		
		$this->add_control(
			'number',
				[
					'label'     => esc_html__( 'teacher to Show', 'studentwp-core' ),
					'type'      => Controls_Manager::NUMBER,
					'min'       => 1,
					'max'       => 500,
					'default'   => 3,
				]
			);
		
		$this->add_control(
			'sorting_order',
			[
				'label'   => esc_html__( 'Sorting Order', 'studentwp-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'most_selling' => esc_html__( 'Most Selling', 'studentwp-core' ),
					'top_rated' => esc_html__( 'Top rated', 'studentwp-core' ),
					'date' => esc_html__( ' Recent', 'studentwp-core' ),
					'low_price' => esc_html__( 'Lower Price', 'studentwp-core' ),
					'high_price' => esc_html__( 'Higher Price', 'studentwp-core' ),
					'title_asc' => esc_html__( 'Title (A-Z)', 'studentwp-core' ),
					'title_desc' => esc_html__( 'Title (Z-A)', 'studentwp-core' ),
				],
				'default' => '',
			]
		);
		
		$this->end_controls_section();
		 $this->start_controls_section(
			'instructor_title',
			[
				'label' => esc_html__( 'Title', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-title',
			]
		);
		$this->add_control(
			'Title_text_color',
			[
				'label' => esc_html__( 'Text Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-title' => 'color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'title_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-title:hover, {{WRAPPER}} .instructor-title:focus' => 'color: {{VALUE}};'
				],
			]
		);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'designation',
			[
				'label' => esc_html__( 'Designation', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-designation',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'designation_color',
			[
				'label' => esc_html__( 'Designation Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-designation' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'designation_hover_color',
			[
				'label' => esc_html__( 'Text hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-designation:hover, {{WRAPPER}} .instructor-designation:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'content',
			[
				'label' => esc_html__( 'Content', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-content',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'instructor_content_color',
			[
				'label' => esc_html__( 'Content Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-content' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor-location',
			[
				'label' => esc_html__( 'Location', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'location_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-location',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'instructor_location',
			[
				'label' => esc_html__( 'Location Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-location' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'location_hover_color',
			[
				'label' => esc_html__( 'Location hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-location:hover, {{WRAPPER}} .instructor-location:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'instructor-graduate',
			[
				'label' => esc_html__( 'Graduate', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'graduate_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-graduate',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'graduate_color',
			[
				'label' => esc_html__( 'Graduate Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-graduate' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'graduate_hover_color',
			[
				'label' => esc_html__( 'Graduate hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-graduate:hover, {{WRAPPER}} .instructor-graduate:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor-experience',
			[
				'label' => esc_html__( 'Experience', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'experience_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-experience',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'instructor_graduate_color',
			[
				'label' => esc_html__( 'Experience Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-experience' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'experience_hover_color',
			[
				'label' => esc_html__( 'Experience hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-experience:hover, {{WRAPPER}} .instructor-experience:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor-phone',
			[
				'label' => esc_html__( 'Phone', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'phone_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-phone',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'instructor_phone_color',
			[
				'label' => esc_html__( 'Phone Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-phone' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'phone_hover_color',
			[
				'label' => esc_html__( 'Phone hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-phone:hover, {{WRAPPER}} .instructor-phone:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'instructor-email',
			[
				'label' => esc_html__( 'Email', 'studentwp-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'email_typography',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_ACCENT,
				],
				'selector' => '{{WRAPPER}} .instructor-email',
			]
		);
          /*$this->start_controls_tabs( 'free_course_bage_style' );*/
		$this->add_control(
			'instructor_email_color',
			[
				'label' => esc_html__( 'Email Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .instructor-email' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'email_hover_color',
			[
				'label' => esc_html__( 'Email hover Color', 'studentwp-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .instructor-email:hover, {{WRAPPER}} .instructor-email:focus' => 'color: {{VALUE}};'
				],
			]
		);
		$this->end_controls_section();

	}

	/**
	 * Render the output of the widget.
	 * 
	 * @return void
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if(file_exists(get_theme_file_path( 'templates/elementor/instructordetails.php' ))) {
			include get_theme_file_path( 'templates/elementor/instructordetails.php' );
			return;
		}

		include STUDENT_CORE_PATH  . 'templates/elementor/instructordetails.php';
	}
}