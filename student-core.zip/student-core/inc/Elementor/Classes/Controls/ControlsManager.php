<?php

namespace StudentCore\Elementor\Classes\Controls;

class ControlsManager
{
	const AJAXSELECT2 = 'ajaxselect2';
}