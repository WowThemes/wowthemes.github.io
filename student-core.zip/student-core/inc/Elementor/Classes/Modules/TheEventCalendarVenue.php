<?php
/**
 * @author Shahbaz Ahmed <shehbaz2009@gmail.com>
 * @package   Student Elementor
 * @version   0.0.1
 **/
namespace StudentCore\Elementor\Classes\Modules;

use Elementor\Modules\DynamicTags\Module;
use Elementor\Core\DynamicTags\Tag;
use Elementor\Controls_Manager;
use StudentCore\Elementor\Classes\StudentModules;

class TheEventCalendarVenue extends Tag {

	public function get_name() {
		return 'WE_The_Event_Calendar_Venue';
	}

	public function get_group() {
		return StudentModules::THE_EVENT_GROUP;
	}

	public function get_categories() {
		return [ Module::TEXT_CATEGORY ];
	}

	public function get_title() {
		return __( 'Event Venue', 'student-core' );
	}

	protected function _register_controls() {
		$this->add_control(
			'opt',
			[
				'label'       => __( 'Info', 'student-core' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '_VenueCity',
				'label_block' => true,
				'options'     => [
					'_name'          => __( 'Name', 'student-core' ),
					'_VenueCity'          => __( 'City', 'student-core' ),
					'_VenueCountry'       => __( 'Country', 'student-core' ),
					'_VenueStateProvince' => __( 'State or Province', 'student-core' ),
					'_VenueAddress'       => __( 'Address', 'student-core' ),
					'_VenueZip'           => __( 'Zip', 'student-core' ),
					'_VenuePhone'         => __( 'Phone', 'student-core' ),
					'_VenueURL'           => __( 'URL', 'student-core' ),
				],
			]
		);
	}

	public function render() {
		$settings = $this->get_settings();
		$setting  = get_post_meta( get_the_ID() );
		$setting  = get_post_meta( webinane_el_set( webinane_el_set( $setting, '_EventVenueID' ), 0 ), $settings['opt'], true );
		?>
		<?php if($settings['opt'] == '_name'): ?>

			<span class="<?php echo esc_attr( $settings['opt'] ) ?>>"><?php echo esc_html( get_the_title(get_post_meta(get_the_ID(), '_EventVenueID', true) ) ); ?></span>

			<?php else: ?>
				<span class="<?php echo esc_attr( $settings['opt'] ) ?>>"><?php echo esc_html( $setting ); ?></span>
			<?php endif; ?>
		<?php
	}
}
