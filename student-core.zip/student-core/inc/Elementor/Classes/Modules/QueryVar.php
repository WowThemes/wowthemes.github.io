<?php
/**
 * @author Shahbaz Ahmed <shehbaz2009@gmail.com>
 * @package   Student Elementor
 * @version   0.0.1
 **/
namespace StudentCore\Elementor\Classes\Modules;

use Elementor\Core\DynamicTags\Tag;
use Elementor\Modules\DynamicTags\Module;
use StudentCore\Elementor\Classes\StudentModules;
use Elementor\Controls_Manager;

class QueryVar extends Tag {

	public function get_name() {
		return 'WE_Query_Var';
	}

	public function get_title() {
		return __( 'Query Var', 'student-core' );
	}

	public function get_group() {
		return StudentModules::POST_GROUP;
	}

	public function get_categories() {
		return [ Module::TEXT_CATEGORY, Module::IMAGE_CATEGORY ];
	}

	public function get_panel_template() {
		return ' ({{{ key }}})';
	}

	public function render() {
		$key = $this->get_settings( 'key' );


		if ( empty( $key ) ) {
			return;
		}

		$value = '';
		if( get_query_var($key)) {
			$allowed_html = wp_kses_allowed_html( 'post' );
			echo wp_kses( get_query_var($key), $allowed_html );
		}

	}

	public function get_panel_template_setting_key() {
		return 'key';
	}

	protected function register_controls() {
		$this->add_control(
			'key',
			[
				'type'	=> Controls_Manager::SELECT2,
				'label' => __( 'Query Var Key', 'student-core' ),
				'options'	=> apply_filters( 'webinane_elementor/dynamic_tag/query_var_keys', [] )
			]
		);
	}
}
