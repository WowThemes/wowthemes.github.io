<?php

/*student_taxonomy(
	esc_html__('Gallery Tag', 'student-core'),
	esc_html__( 'Gallery Tags', 'student-core' )
)->setId('gallery-tags')
 ->addToPermalinks()
 ->addPostType('studentwp_gallery');*/