<?php

// Clients Post type
/*student_post_type(
	esc_html__('Client', 'student-core'),
	esc_html__('Clients', 'student-core')
)->setId('studentwp_clients')
 ->addToPermalinks()
 ->setArgument('supports', ['title', 'thumbnail'])
 ->setIcon('dashicons-admin-comments');
*/
/*// Gallery Post Type
student_post_type(
	esc_html__('Gallery', 'student-core'),
	esc_html__('Galleries', 'student-core')
)->setId('studentwp_gallery')
 ->setArgument('supports', ['title', 'editor', 'thumbnail'])
 ->addToPermalinks()
 ->setIcon('dashicons-schedule');
*/