<?php

Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Footer Widget Heading', 'studentwp-core' ),
    'id'         => 'footer-widget-heading',
    'desc'       => '',
    'icon'       => '',
    'subsection' => true,
    'fields'     => array(
        array(
            'id'       => 'footer-widget-font-family',
            'type'     => 'select',
            'title'    => esc_html__('<b>Font Family</b>', 'studentwp-core'),
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'Default',
                '2' => 'Standered',
                '3' => 'Font Awesome ',
            ),
            'default'  => '1',
        ),
        array(
            'id'       => 'footer-widget-font-weight',
            'type'     => 'select',
            'title'    => esc_html__('<b>Font Weight</b>', 'studentwp-core'),
            'subtitle'    => __('Important: Not all fonts support every font-weight.', 'studentwp-core'),
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'Default',
                '2' => 'Thin:100',
                '3' => 'Light:200',
                '4' => 'Book:300',
                '5' => 'Book:400',
                '6' => 'Medium:500',
                '7' => 'Semibold:600',
                '8' => 'Bold:700',
                '9' => 'Extra Bold:800',
                '10' => 'Black:900',
            ),
            'default'  => '1',
        ),
        array(
            'id'       => 'footer-widget-font-style',
            'type'     => 'select',
            'title'    => esc_html__('<b>Font Style</b>', 'studentwp-core'),
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'Default',
                '2' => 'Normal',
                '3' => 'Italic',
            ),
            'default'  => '1',
        ),
        array(
            'id'       => 'footer-widget-text-transform',
            'type'     => 'select',
            'title'    => esc_html__('<b>Text Transform</b>', 'studentwp-core'),
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'Default',
                '2' => 'Capitalize',
                '3' => 'Lowercase',
                '4' => 'Upercase',
                '5' => 'None',
            ),
            'default'  => '1',
        ),  
        array(
            'id'      => 'footer-widget-font-size',
            'type'    => 'text',
            'title'   => esc_html__( 'Font Size', 'studentwp-core' ),
            'desc'    => esc_html__( '', 'studentwp-core' ),
            'default' => '14px',
        ),
        array(
            'id' => 'footer-widget-font_color',
            'type' => 'color',
            'title' => esc_html__('Font Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'footer_widget_line_height',
            'type' => 'typography',
            'line-height' => true,
            'title' => esc_html__( 'Line Height
            ' , 'studentwp-core' ),
            'desc' => esc_html__( 'Line Height
            ' , 'studentwp-core' ),
        ),
        array(
            'id' => 'footer_widget_latter_spacing',
            'type' => 'typography',
            'letter-spacing' => true,
            'title' => esc_html__( 'Letter Spacing (px)
            ' , 'studentwp-core' ),
            'desc' => esc_html__( 'Letter Spacing (px)
            ' , 'studentwp-core' ),
        ),

    ),
) );
