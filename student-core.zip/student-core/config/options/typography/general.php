<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Typography', 'studentwp-core' ),
    'id'         => 'typography',
    'desc'       => '',
    'icon'       => 'el el-fontsize',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General', 'studentwp-core' ),
    'id'         => 'general',
    'desc'       => '',
    'icon'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
            'id'       => 'typography_general_google_fonts',
            'type'     => 'checkbox',
            'title'    => esc_html__('', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'DISABLE GOOGLE FONTS', 
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'font-subsets',
            'type'     => 'checkbox',
            'title'    => esc_html__('Font Subsets', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'latin', 
                '2' => 'latin-ext',
                '3' => 'cyrillic',
                '4' => 'cyrillic-ext',
                '5' => 'greek',
                '6' => 'greek-ext',
                '7' => 'vietnamese',

            ),
            'default' => '1'
        ),


    ),
) );
?>