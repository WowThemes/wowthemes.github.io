<?php

Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Footer Widgets', 'studentwp-core' ),
    'id'         => 'fixed_footer',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'    => false,
    'fields'     => array(
        array(
            'id'       => 'enable_footer_widget',
            'type'     => 'switch',
            'title'     => esc_html__('Enable Footer Widgets', 'studentwp-core'),
            'default' => true,
        ),
        array(
            'id'       => 'footer_widget_source',
            'type'     => 'select',
            'title'     => esc_html__('Source', 'studentwp-core'),
            'options' => array(
                'default' => esc_html__('Default', 'studentwp-core'),
                'elementor' => esc_html__('Elementor', 'studentwp-core'),
            ), 
            'default' => 'default',
        ),
        array(
            'id'       => 'footer_visibility',
            'type'     => 'select',
            'title'    => esc_html__('Visibility', 'studentwp-core'),
            'desc'     => esc_html__('Show or hide the footer widget area on various devices.', 'studentwp-core'),
            'options'  => array(
                'all'           => esc_html__('Show on All Devices', 'studentwp-core'),
                'hide_tablet'   => esc_html__('Hide on Tablet', 'studentwp-core'),
                'hide_mobile'   => esc_html__('Hide on Mobile', 'studentwp-core'),
                'hide_both'     => esc_html__('Hide on Tablet & Mobile', 'studentwp-core'),
                'hide_all'      => esc_html__('Hide on All Devices', 'studentwp-core')
            ),
            'default'  => 'all',
        ),
        array(
            'id'       => 'footer_widget_sidebar',
            'type'     => 'select',
            'title'    => esc_html__('Sidebar', 'studentwp-core'),
            'data'     => 'sidebars',
            'required' => ['footer_widget_source', '=', 'default'],
            'default'   => 'default-sidebar'
        ),
        array(
            'id'       => 'footer_widget_elementor_template',
            'type'     => 'select',
            'title'     => esc_html__('Elementor Template', 'studentwp-core'),
            'desc'      => sprintf(__('You can create elementor template <a href="%s" target="_blank">here</a>'), admin_url('post-new.php?post_type=elementor_library')),
            'data'      => 'posts',
            'args'    => array( 'post_type' => 'elementor_library'),
            'required' => ['footer_widget_source', '=', 'elementor'],
        ),
        array(
            'id'       => 'footer_widget_default_content_start',
            'type'     => 'section',
            'indent'      => true,
            'title'    => esc_html__('Footer Content', 'studentwp-core'),
            'required' => ['footer_widget_source', '=', 'default'],
        ),        
        array(
            'id'       => 'fixed_footer',
            'type'     => 'switch',
            'title'    => esc_html__( 'Fixed Footer', 'studentwp-core' ),
            'subtitle'    => esc_html__( 'This option add a height to your content to keep your footer at the bottom of your page.', 'studentwp-core' ),
            'default'   => true,
            'required' => [ 'footer_source_type', '=', 'd' ],
        ),
        array(
            'id'       => 'parallax_footer_effect',
            'type'     => 'switch',
            'title'    => esc_html__( 'Parallax Footer Effect', 'studentwp-core' ),
            'subtitle'    => esc_html__( 'Add a parallax effect to your footer.', 'studentwp-core' ),
            'default'   => true,
            'required' => [ 'footer_source_type', '=', 'd' ],
        ),
        
        array(
            'id'       => 'footer_heading_tag',
            'type'     => 'select',
            'title'    => esc_html__('Heading Tag','studentwp-core'),
            'options' => array(
                '1' => 'H1', 
                '2' => 'H2', 
                '3' => 'H3', 
                '4' => 'H4', 
                '5' => 'H5', 
                '6' => 'H6', 
                '7' => 'DIV', 
                '8' => 'span', 
                '9' => 'p',
            ), 
            'default' => '3'
        ),
        array(
            'id' => 'footer_widget_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
        array(
            'id'       => 'footer_widget_container',
            'title' => esc_html__( 'Container' , 'studentwp-core' ),
            'desc' => esc_html__( 'Enable container to turn off the full width footer' , 'studentwp-core' ),
            'type'     => 'checkbox',
            'options' => array(
                'container' => esc_html__('Add Container', 'studentwp-core')
            ), 
            'default' => '1',
        ),
        array(
            'id' => 'footer_widget_background',
            'type' => 'background',
            'title' => esc_html__('Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('footer .bg-img'),
            
        ),
        array(
            'id' => 'footer_text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'compiler'  => true,  
        ),
        array(
            'id' => 'footer_border_color',
            'type' => 'color',
            'title' => esc_html__('Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('border-color' => 'footer .footer-widgets'),
            
        ),
        array(
            'id' => 'footer_link_color',
            'type' => 'color',
            'title' => esc_html__('Links Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'    => array('color' => 'footer .footer-widgets a')
        ),
        array(
            'id' => 'footer_links_hover_color',
            'type' => 'color',
            'title' => esc_html__('Link Color:hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'    => array('color' => 'footer .footer-widgets a:hover')
        ),
        array(
            'id'            => 'footer_widget_padding',
            'type'          => 'spacing',
            'mode'          => 'padding',
            'units'         => array('em', 'px'),
            'units_extended' => 'false',
            'title'         => esc_html__('Padding', 'studentwp-core'),
            'desc'          => esc_html__('Padding(px)', 'studentwp-core'),
            'output'        => 'footer .footer-widgets'
        ),
        array(
            'id'       => 'footer_widget_default_content_end',
            'type'     => 'section',
            'indent'   => false,
            'required' => ['footer_widget_source', '=', 'default'],
        ),
        
        // Footer Widgets.
        
    ),
) );