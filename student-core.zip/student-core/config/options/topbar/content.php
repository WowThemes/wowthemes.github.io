<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Content', 'studentwp-core' ),
    'id'         => 'topbar-content',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'topbar_content_template',
            'type'     => 'select',
            'title'    => esc_html__('Select Template', 'studentwp-core'), 
            'subtitle'    => esc_html__('Choose a template created in Theme Panel > My Library to replace the content.', 'studentwp-core'),
            'required' => ['topbar_source', '=', 'elementor'],
            'data' => 'posts',
            'args'  => ['post_type' => 'elementor_library'],
            'default' => '1'

        ),
        array(
            'id'       => 'topbar_source',
            'type'     => 'select',
            'title'     => esc_html__('Source', 'studentwp-core'),
            'options' => array(
                'default' => esc_html__('Default', 'studentwp-core'),
                'elementor' => esc_html__('Elementor', 'studentwp-core'),
            ), 
            'default' => 'default',
        ),
        array(
            'id'=>'topbar_textarea',
            'type' => 'textarea',
            'title' => esc_html__('Content', 'studentwp-core'), 

            'default' => 'Place your content here.',
            'allowed_html' => array(
                'a' => array(
                    'href' => array(),
                    'title' => array()
                ),
                'br' => array(),
                'em' => array(),
                'strong' => array()
            ),
        ),
        array(
            'id'        => 'topbar_list_menus',
            'type'      => 'select',
            'title'     => esc_html__('List Menus', 'student-core'), 
            'data'      => 'menus',
            'required' => ['topbar_source', '=', 'default'],
            'default'   => 2
        ),
        array(
            'id'       => 'header_topbar_email',
            'type'     => 'textarea',
            'title'    => esc_html__( 'Email', 'studentwp-core' ),
            'required' => ['topbar_source', '=', 'default'],
            'default' => '<i class="ion-ios-clock-outline"></i> Student opening hours: 8AM to 7PM. Open all days',
            'desc'  => esc_html__('You can use HTML tags', 'studentwp-core')
        ),
        array(
            'id'       => 'header_topbar_phone',
            'type'     => 'text',
            'title'    => esc_html__( 'Phone Number', 'studentwp-core' ),
            'required' => ['topbar_source', '=', 'default'],
            'default' => '1800 123 4659',
        ),

    ),
) );
