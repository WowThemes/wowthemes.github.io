<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Top Bar', 'studentwp-core' ),
    'id'         => 'topbar',
    'desc'       => '',
    'icon'       => 'el el-list',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General', 'studentwp-core' ),
    'id'         => 'general-topbar',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
    array(
        'id'       => 'topbar_enable',
        'type'     => 'switch',
        'title'    => esc_html__('ENABLE TOP BAR', 'studentwp-core'), 
        'default' => '1'
    ),
    array(
        'id'       => 'topbar_fullwidth',
        'type'     => 'switch',
        'title'    => esc_html__('Topbar Full Width', 'studentwp-core'), 
        'default' => '1'
    ),
    
    array(
        'id'       => 'top_bar_visibility',
        'type'     => 'select',
        'title'    => esc_html__('Visibility', 'studentwp-core'), 
        'options'  => array(
            'all-devices' => 'Show on All Devices',
            'hide-tablet' => 'Hide on Tablet',
            'hide-mobile' => 'Hide on Mobile',
            'hide-tablet-mobile' => 'Hide on Tablet & Mobile',
            ),
        'default'  => 'all-devices',
        ),
        array(
            'id'       => 'topbar_styling_option',
            'type'     => 'select',
            'title'    => esc_html__('Style', 'studentwp-core'), 
            'options'  => array(
                'one' => 'Left Content/Right Social', 
                'two' => 'Left Social/Right Content',
                'three' => 'Centered Content & Social',
            ),
            'default' => '1',
        ),
         array(
            'id' => 'topbar_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => array('padding' => '#top-bar-inner #top-bar-content .topbar-content')
        ),
        array(
            'id' => 'topbar_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => '#top-bar-wrap')
            
        ),
        array(
            'id' => 'topbar_text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' => '#top-bar-inner #top-bar-content .topbar-content')
            
        ),
        array(
            'id' => 'topbar_link_color',
            'type' => 'color',
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'#top-bar-inner #top-bar-content .top-links a')
            
        ),
        array(
            'id' => 'topbar_link_hover_color',
            'type' => 'color',
            'title' => esc_html__('link Hover Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'#top-bar-inner #top-bar-content .top-links a:hover ')
        ),
    ),
) );
?>