<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Social', 'studentwp-core' ),
    'id'         => 'topbar-social',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'social',
            'type'     => 'checkbox',
            'title'    => esc_html__('ENABLE TOP BAR', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            'options'  => array(
                '1' => 'ENABLE Social',  
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'top_bar_social_profiles',
            'type'     => 'repeater',
            'title'    => esc_html__('Social Icons', 'studentwp-core'), 
            'group_values'  => true,
            'fields'  => array(
                array(
                    'id'       => 'icon',
                    'type'     => 'select',
                    'title'    => esc_html__('Icons', 'studentwp-core'), 
                    'subtitle'    => esc_html__('Choose a template created in Theme Panel > My Library.', 'studentwp-core'),
                    'options'   => get_theme_file_path('config/social-icons.php') ? include get_theme_file_path('config/social-icons.php') : array()
                ),
                array(
                    'id'    => 'title',
                    'type'  => 'text',
                    'title' => esc_html__('Title', 'studentwp-core'),
                    'default'   => esc_html__('Like on Facebook', 'studentwp-core')
                ),
                array(
                    'id'    => 'link',
                    'type'  => 'text',
                    'title' => esc_html__('URL', 'studentwp-core'),
                    'default'   => 'https://facebook.com/wptech'
                ),
            ),
        ),
        array(
            'id'       => 'topbar_social_template',
            'type'     => 'select',
            'title'    => esc_html__('Social Alternative', 'studentwp-core'), 
            'subtitle'    => esc_html__('Choose a template created in Theme Panel > My Library.', 'studentwp-core'),
            'desc'     => esc_html__(''),
            'data' => 'posts',
            'args'  => ['post_type' => 'elementor_library'],
            'default' => '1'
        ),
        array(
            'id'       => 'social_link_target',
            'type'     => 'select',
            'title'    => esc_html__('Social Link Target', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            
            'options'  => array(
                'blank' => 'New Window',
                'self' => 'Same Window',  
            ),
            'default' => 'blank'
        ),
         array(
            'id' => 'topbar_social_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => ['padding'=>'#top-bar-social ul li a']
        ),
         array(
            'id' => 'topar_social_fontsize',
            'type' => 'spacing',
            'title' => esc_html__( 'Font Size (px)
            ' , 'studentwp-core' ),
            'desc' => esc_html__( 'Font Size (px)
            ' , 'studentwp-core' ),
            'output'    => ['padding'=>'#top-bar-social ul li a']        ),
        array(
            'id' => 'social_link_color',
            'type' => 'color',
            'title' => esc_html__('Social Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'social_link_hover_color',
            'type' => 'color',
            'title' => esc_html__('Social link Hover Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
        ),
    ),
) );
