<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Header Social Icon', 'studentwp-core' ),
    'id'         => 'header-social-icon',
    'desc'       => '',
    'icon'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
            'id'       => 'menu_social_profiles',
            'type'     => 'repeater',
            'title'    => esc_html__('Social Icons', 'studentwp-core'), 
            'group_values'  => true,
            'fields'  => array(
                array(
                    'id'       => 'icon',
                    'type'     => 'select',
                    'title'    => esc_html__('Icons', 'studentwp-core'), 
                    'options'   => get_theme_file_path('config/social-icons.php') ? include get_theme_file_path('config/social-icons.php') : array()
                ),
                array(
                    'id'    => 'title',
                    'type'  => 'text',
                    'title' => esc_html__('Title', 'studentwp-core'),
                    'default'   => esc_html__('Like on Facebook', 'studentwp-core')
                ),
                array(
                    'id'    => 'link',
                    'type'  => 'text',
                    'title' => esc_html__('URL', 'studentwp-core'),
                    'default'   => 'https://facebook.com/wptech'
                ),
            ),
        ),
        array(
            'id' => 'header_social_border',
            'type' => 'border',
            'title' => esc_html__(' Border', 'studentwp-core'),
            'compiler'  => true,
            'output'    => array('.social-menu ul li a'),
            'default'  => array(
                'border-color'  => '#555555', 
                'border-style'  => 'dashed', 
                'border-top'    => '1px', 
                'border-right'  => '1px', 
                'border-bottom' => '1px', 
                'border-left'   => '1px'
            )
        ),
        array(
            'id'       => 'header_social_height_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Dimensions (Width/Height) Option', 'studentwp-core'),
            'subtitle' => esc_html__('Enter the custom height width of the icons', 'studentwp-core'),
            'desc'     => esc_html__('Leave empty if you want to use the default', 'studentwp-core'),
            'default'  => array(
                'width'   => '42', 
                'height'  => '42',
                'unit'  => 'px'
            ),
            'output'    => array('.social-menu ul li a'),
        ),
        array(
            'id' => 'header_social_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => 'header .social-area .social-list li a')
            
        ),
        array(
            'id' => 'header_social_text_color',
            'type' => 'color',
            'title' => esc_html__('Icon Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'header .social-area .social-list li a')
            
        ),
        array(
            'id' => 'header_social_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => 'header .social-area .social-list li a:hover')
            
        ),
        array(
            'id' => 'header_social_text_color_hover',
            'type' => 'color',
            'title' => esc_html__('Icon Color:Hover', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'header .social-area .social-list li a:hover')
            
        ),
    ),
) );
?>