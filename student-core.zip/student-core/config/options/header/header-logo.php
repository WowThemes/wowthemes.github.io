<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Logo', 'studentwp-core' ),
    'id'         => 'header-logo',
    'desc'       => '',
    'icon'       => '',
    'subsection'       => true,
    'fields'     => array(
    array(
            'id'       => 'logo-header',
            'type'     => 'media',
            'url'      => true,
            'title'    => esc_html__( 'Logo', 'studentwp-core' ),
            'subtitle' => esc_html__( 'Insert site logo image', 'studentwp-core' ),
            'default'  => array( 'url' => get_template_directory_uri() . '/assets/images/logo.png' ),
        ),
    array(
        'id'       => 'retina-logo',
        'type'     => 'media', 
        'url'      => true,
        'title'    => esc_html__('Retina Logo', 'studentwp-core'),
        'subtitle'    => esc_html__('Select a retina logo twice the normal logo size.', 'studentwp-core'),
        'default'  => array(
            'url'=>''
         ),
    ),
    array(
            'id' => 'header_logo_colorss',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
            'id' => 'logo_hover_colorss',
            'type' => 'color',
            'title' => esc_html__('Color: Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),

    array(
            'id'       => 'logo_dimension',
            'type'     => 'dimensions',
            'title'    => esc_html__( 'Logo Dimentions', 'studentwp-core' ),
            'subtitle' => esc_html__( 'Select Logo Dimentions', 'studentwp-core' ),
            'units'    => array( 'em', 'px', '%' ),
            'default'  => array( 'Width' => '183', 'Height' => '45' ),
            'output'    => ['#site-logo img']
        ),
    ),
) );
