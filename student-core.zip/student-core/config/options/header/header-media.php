<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Header Media', 'studentwp-core' ),
    'id'         => 'media',
    'desc'       => '',
    'icon'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
        'id'       => 'header-media',
        'type'     => 'media', 
        'url'      => true,
        'title'    => esc_html__('Media w/ URL', 'studentwp-core'),
        'desc'     => esc_html__('Basic media uploader with disabled URL input field.', 'studentwp-core'),
        'subtitle' => esc_html__('Upload any media using the WordPress native uploader', 'studentwp-core'),
        'default'  => array(
            'url'=>''
        ),
        array(
            'id' => 'media_overlay_color',
            'type' => 'color',
            'title' => esc_html__('Overlay Color', 'studentwp-core'),
             'compiler'  => true,
            'default' => '',
           
            
        ),
            ),
        array(
            'id'       => 'header_position',
            'type'     => 'select',
            'title'    => esc_html__('Position', 'studentwp-core'), 
            'options'  => array(
                '1' => 'Default', 
                '2' => 'Top Left',
                 '3' => 'Top Right', 
                '4' => 'Top Center',
                '5' => 'Center Left',
                 '6' => 'Center Right', 
                '7' => 'Center Center',
                '8' => 'Bottom Left',
                 '9' => 'Bottom Right', 
                '10' => 'Bottom Center',
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'header_attachment',
            'type'     => 'select',
            'title'    => esc_html__('Attachment', 'studentwp-core'), 
            'options'  => array(
                '1' => 'Default', 
                '2' => 'Scroll',
                 '3' => 'Fixed', 
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'header_repeat',
            'type'     => 'select',
            'title'    => esc_html__('Repeat', 'studentwp-core'), 
            'options'  => array(
                '1' => 'Default', 
                '2' => 'Repeat',
                 '3' => 'No Repeat', 
                 '2' => 'Repeat-x',
                 '3' => 'Repeat-y', 
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'header_size',
            'type'     => 'select',
            'title'    => esc_html__('Size', 'studentwp-core'), 
            'options'  => array(
                '1' => 'Default', 
                '2' => 'Auto',
                 '3' => 'Cover', 
                 '2' => 'Contain',
            ),
            'default' => '1'
        ),   
    ),
) );
?>