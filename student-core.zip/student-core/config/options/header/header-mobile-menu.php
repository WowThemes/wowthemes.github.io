<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Mobile Menu', 'studentwp-core' ),
    'id'         => 'header-mobile-menu',
    'desc'       => '',
    'icon'       => '',
    'subsection'       => true,
    'fields'     => array(
    array(
        'id'       => 'header-menu-mobile',
        'type'     => 'select',
        'title'    => esc_html__('Breakpoints','studentwp-core'),
        'subtitle'    => esc_html__('Choose the media query where you want to display the mobile menu.','studentwp-core'),
        'options' => array(
            '959' => 'From 959px', 
            '1080' => 'From 1080px', 
            '767' => 'From 767px', 
            '480' => 'From 480px', 
            '320' => 'From 320px', 
            'custom' => 'Custom Media Query', 
         ), 
        'default' => '3'
    ),
    array(
            'id' => 'mobile_menu_height',
            'type' => 'slider',
            'title' => esc_html__('Height (px)', 
                'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
        'id'       => 'header-mobile_menu_logo',
        'type'     => 'media', 
        'url'      => true,
        'title'    => esc_html__('Logo (optional)', 'studentwp-core'),
        'subtitle' => esc_html__('<br>Select a custom responsive logo for tablet and mobile.', 'studentwp-core'),
        'default'  => array(
            'url'=>'',
        ),
    ),
    array(
            'id'       => 'header-mobile-menu-position',
            'type'     => 'select',
            'title'    => esc_html__('Elements Positioning', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            'options'  => array(
                'logo_cart_link' => 'Logo/Cart/Link', 
                'cart_logo_link' => 'Cart/Logo/Link',
                'link_logo_cart' => 'Link/Logo/Cart',
            ),
            'default' => '1',
        ),
   array(
        'id'       => 'header_mobile_menu_style',
        'type'     => 'select',
        'title'    => esc_html__('Mobile Menu Style','studentwp-core'),
        'options' => array(
            'sidebar' => 'Sidebar', 
            'dropdown' => 'DropDown', 
            'fullscreen' => 'Full Screen', 
         ), 
        'default' => '1',
    ),
   array(
        'id'       => 'header_mobile_menu_display',
        'type'     => 'checkbox',
        'title'    => esc_html__('','studentwp-core'),
        'options' => array(
            '1' => 'DISPLAY MENU TEXT',
         ), 
        'default' => '1',
    ),
   array(
        'id'       => 'header_mobile_menu_text',
        'type'     => 'text',
        'title'    => esc_html__('Menu Text','studentwp-core'),
        'default' => 'Menu',
    ),
   array(
        'id'       => 'header_mobile_menu__close_text',
        'type'     => 'text',
        'title'    => esc_html__('Close Menu Text','studentwp-core'),
        'default' => 'Close',
    ),
    array(
        'id'       => 'header_mobile_menu_icon',
        'type'     => 'text',
        'title'    => esc_html__('Hamburger Icon Class','studentwp-core'),
        'subtitletitle'    => esc_html__('Enter the full icon class','studentwp-core'),
        'default' => 'fa fa-bars',
    ),
   array(
        'id'       => 'header_mobile_menu_button',
        'type'     => 'select',
        'title'    => esc_html__('Custom Hamburger Button','studentwp-core'),
        'options' => array(
            '1' => 'Default Icon', 
            '2' => '3D X', 
            '3' => '3D X Reverse', 
            '4' => '3D Y', 
            '5' => '3D Y Reverse', 
            '6' => '3D XY', 
            '7' => '3D XY Reverse', 
            '8' => 'Arrow', 
            '9' => 'Arrow Reverse', 
            '10' => 'Arrowwalt',
            '11' => 'Arrowwalt Reverse',
         ), 
        'default' => '1',
    ),
   array(
        'id'       => 'header_mobile_menu_height',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Drop Down Max Height (px)', 'studentwp-core'),
        'subtitle'    => esc_html__('Add the height from which you want to display the scrollbar in the drop down', 'studentwp-core'),
        'mode'  => [
            'height'    => true,
        ],
        'width' => false,
        'height'    => true,
    ),
   array(
        'id'       => 'header_mobile_menu_target',
        'type'     => 'button_set',
        'title'    => esc_html__('Dropdown Target','studentwp-core'),
        'options' => array(
            '1' => 'ICON', 
            '2' => 'LINK', 
         ), 
        'default' => '1',
    ),
   array(
        'id'       => 'header_mobile_menu_search',
        'type'     => 'checkbox',
        'title'    => esc_html__('','studentwp-core'),
        'options' => array(
            '1' => 'MOBILE MENU SEARCH', 
         ), 
        'default' => '1',
    ),
   array(
            'id' => 'mobile_menu_background',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => ''),
            
        ),
   array(
            'id' => 'mobile_menu_background',
            'type' => 'color',
            'title' => esc_html__('Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => ''),
            
        ),
   array(
            'id' => 'mobile_menu_link_color',
            'type' => 'color',
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
   array(
            'id' => 'mobile_menu_link_hover_color',
            'type' => 'color',
            'title' => esc_html__('Link Color:hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
     array(
            'id' => 'mobile_menu_dropdown_background',
            'type' => 'color',
            'title' => esc_html__('Dropdowns Menus: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => ''),
            
        ),
     array(
            'id' => 'mobile_menu_searchbar_background',
            'type' => 'color',
            'title' => esc_html__('Searchbar Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => ''),
            
        ),
     array(
            'id' => 'mobile_menu_searchbar_color',
            'type' => 'color',
            'title' => esc_html__('Searchbar Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
     array(
            'id' => 'mobile_menu_searchbar_bordercolor',
            'type' => 'color',
            'title' => esc_html__('Searchbar Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => ''),
            
        ),
     array(
            'id' => 'mobile_menu_searchbar_border_focus',
            'type' => 'color',
            'title' => esc_html__('Searchbar Border Color: Focus', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => ''),
        ),
     array(
            'id' => 'mobile_menu_searchbar_button-color',
            'type' => 'color',
            'title' => esc_html__('Searchbar Button Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
     array(
            'id' => 'mobile_menu_searchbar_button-hover',
            'type' => 'color',
            'title' => esc_html__('Searchbar Button Color: Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    ),
) );
?>