<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Header', 'studentwp-core' ),
    'id'         => 'header',
    'desc'       => '',
    'icon'       => 'el el-screen',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General', 'studentwp-core' ),
    'id'         => 'header_general',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
            'id'       => 'header_style',
            'type'     => 'select',
            'title'    => esc_html__('Style', 'studentwp-core'), 
            'options'  => array(
                'minimal' => esc_html__( 'Minimal', 'studentwp-core' ), 
                'transparent' => esc_html__( 'Transparent', 'studentwp-core' ), 
                'top' => esc_html__( 'Top Menu', 'studentwp-core' ),
                'full_screen' => esc_html__( 'Full Screen', 'studentwp-core' ),
                'center' => esc_html__( 'Full Center', 'studentwp-core' ),
                'medium' => esc_html__( 'Medium', 'studentwp-core' ),  
                'vertical' => esc_html__( 'Vertical', 'studentwp-core' ), 
                'custom' => esc_html__( 'Custom Header', 'studentwp-core' ),   
            ),
            'default' => 'medium'
        ),
        array(
            'id'       => 'header_height',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Height (px)', 'studentwp-core'),
            'width' => false,
            'height'    => true,
            'output'    => ['#site-header:not(.vertical-header)']
        ),
        array(
            'id' => 'header_full_width',
            'type' => 'switch',
            'title' => esc_html__('Header Full Width' , 'studentwp-core' ),
            'desc' => esc_html__('Padding(px)' , 'studentwp-core' ),
            'required' => [['header_style', '!=', 'vertical'], ['header_style', '!=', 'custom']],
        ),
        array(
            'id'       => 'header_border_bottom',
            'type'     => 'switch',
            'title'    => esc_html__('Header Border Bottom', 'studentwp-core'), 
            'desc'     => esc_html__('Enable to add the border bottom to the header', 'studentwp-core'),
            'required'=>[['header_style', '!=', 'vertical'], ['header_style', '!=', 'custom']],
            'default' => ''
        ),
        array(
            'id' => 'header_border_color',
            'type' => 'color',
            'title' => esc_html__(' Border Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('border-color' => '#site-header')
        ),
        array(
            'id' => 'header_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('background-color' => '#site-header')            
        ),
        // End of center header settings.

        // Medium Header Settings starts.
        array(
        'id' => 'medium-header-section-start-seven',
        'type' => 'section',
        'required'=>['header_style', '=', 'medium'],
        'title' => esc_html__('Medium Header Settings', 'student-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'medium_header_transparent',
            'type'     => 'switch',
            'title'    => esc_html__('Add transparent header', 'student-core'), 
            'default' => '',
        ),
        array(
            'id'       => 'medium_header_hidden_menu',
            'type'     => 'switch',
            'title'    => esc_html__('Hide menu when scrolling', 'student-core'), 
            'default' => '',
        ),
        array(
            'id'       => 'medium_header_stick_menu',
            'type'     => 'switch',
            'title'    => esc_html__('Stick only the menu', 'student-core'), 
            'default' => true
        ),
        array(
            'id'       => 'medium_header_show_registration_btn',
            'type'     => 'switch',
            'title'    => esc_html__('Show Registration Button', 'student-core'), 
            'default' => true
        ),
        array(
            'id'        => 'medium_header_registration_page',
            'type'      => 'select',
            'title'     => esc_html__('Registration Page', 'student-core'), 
            'desc'      => esc_html__('Select the registration page where use will be able to register or login', 'studentwp-core'),
            'data'      => 'pages',
            'required'  =>['medium_header_show_registration_btn', '=', true],
            'default'   => 2
        ),


        array(
            'id'       => 'medium_header_show_login_link',
            'type'     => 'switch',
            'title'    => esc_html__('Show Login Link', 'student-core'), 
            'default' => true
        ),

        array(
            'id'       => 'medium_header_login_link_type',
            'type'     => 'select',
            'title'    => esc_html__('Login Link Type', 'studentwp-core'), 
             'required'=>['medium_header_show_login_link', '=', '1'],
            'options'  => array(
                'popup' => esc_html__( 'Popup', 'studentwp-core' ), 
                'page' => esc_html__( 'Page', 'studentwp-core' ),  
            ),
            'default' => 'popup'
        ),
        array(
            'id'        => 'medium_header_login_link_page',
            'type'      => 'select',
            'title'     => esc_html__('Login Pages', 'studentwp-core'), 
             'required' =>['medium_header_login_link_type', '=', 'page'],
             'data'     => 'pages',
            'default'   => '2'
        ),

         array(
            'id'       => 'medium_header_show_register_link',
            'type'     => 'switch',
            'title'    => esc_html__('Show Register Link', 'student-core'), 
            'default' => true
        ),

        array(
            'id'       => 'medium_header_register_link_type',
            'type'     => 'select',
            'title'    => esc_html__('Register Link Type', 'studentwp-core'), 
             'required'=>['medium_header_show_register_link', '=', '1'],
            'options'  => array(
                'popup' => esc_html__( 'Popup', 'studentwp-core' ), 
                'page' => esc_html__( 'Page', 'studentwp-core' ),  
            ),
            'default' => 'popup'
        ),
        array(
            'id'        => 'medium_header_register_link_page',
            'type'      => 'select',
            'title'     => esc_html__('Registration Page', 'studentwp-core'), 
            'required'  =>['medium_header_register_link_type', '=', 'page'],
            'data'      => 'pages',
            'default'   => '2'
        ),
        array(
            'id'     => 'medium-header-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        
        array(
            'id' => 'header_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => ['#site-header']
        ),
         
  /*      array(
            'id' => 'header_text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'default' => '#222',
            'compiler'  => true,
            'output'    => array('color' =>'#site-header')
        ),
        array(
            'id' => 'header_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('background-color' => '#site-header:hover')
        ),
        array(
            'id' => 'header_text_color_hover',
            'type' => 'color',
            'title' => esc_html__('Text Color:Hover', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'#site-header:hover')
        ),
        array(
            'id' => 'header_registration_background',
            'type' => 'color',
            'title' => esc_html__('Button  Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#6588fe',
            'output'    => array('background-color' => 'header .menu-bar .header-btn')  
        ),
        array(
            'id' => 'header_registration_text_color',
            'type' => 'color',
            'title' => esc_html__('Button Text Color', 'studentwp-core'),
            'default' => '#fff',
            'compiler'  => true,
            'output'    => array('color' =>'header .menu-bar a')
        ),
        array(
            'id' => 'header_registration_background_hover',
            'type' => 'color',
            'title' => esc_html__('Button  Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#6588fe',
            'output'    => array('background-color' => 'header .menu-bar .header-btn:hover')
            
        ),
        array(
            'id' => 'header_registration_text_color_hover',
            'type' => 'color',
            'title' => esc_html__('Button Text Color:Hover', 'studentwp-core'),
            'default' => '#fff',
            'compiler'  => true,
            'output'    => array('color' =>'header .menu-bar  a:hover')
            
        ),*/
        
        array(
            'id'=>'header_textarea',
            'type' => 'textarea',
            'title' => esc_html__('Content After Header', 'studentwp-core'), 
            'desc' => esc_html__(''),
            'validate' => 'html_custom',
            'default' => '',
            'allowed_html' => array(
                'a' => array(
                    'href' => array(),
                    'title' => array()
                ),
                'br' => array(),
                'em' => array(),
                'strong' => array()
            )
        ),
        array(
        'id' => 'section-start',
        'type' => 'section',
        'required'=>['header_style', '=', 'transparent'],
        'title' => esc_html__('Transparent Header Settings', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id' => 'header_background_transparent',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'transparent'],
            'output'    => array('background-color' => 'header nav')
            
        ),
        array(
            'id'     => 'transparent-header-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        //Transparent header section end.

        // Top menu header section start.
        array(
        'id' => 'top-menu-header-section-start-two',
        'type' => 'section',
        'required'=>['header_style', '=', 'top'],
        'title' => esc_html__('Top menu header settings', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'menu_position',
            'type'     => 'select',
            'title'    => esc_html__('Menu Position', 'studentwp-core'), 
            'required'=>['header_style', '=', 'top'],
            'options'  => array(
                'before_the_logo' => 'Before the Logo', 
                'after_the_logo' => 'After the Logo', 
                    
            ),
            'default' => 'before_the_logo'
        ),
        array(
            'id' => 'menu_background_general1',
            'type' => 'color',
            'title' => esc_html__(' Menu Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            'output'    => array('background-color' => 'header nav')
            
        ),
        array(
            'id' => 'search_button_border_color1',
            'type' => 'color',
            'title' => esc_html__(' Search Button Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'search_button_color1',
            'type' => 'color',
            'title' => esc_html__(' Search Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'search_button_hover_color1',
            'type' => 'color',
            'title' => esc_html__(' Search Button Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id'     => 'section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // Section end.

        // Section Start
        array(
        'id' => 'section-start-four',
        'type' => 'section',
        'required'=>['header_style', '=', 'full_screen'],
        'title' => esc_html__('STYLE', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id' => 'menu_bar_color_general',
            'type' => 'color',
            'title' => esc_html__(' Menu Bar Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('color' => '#site-header nav li > a')
            
        ),
        array(
            'id' => 'menu_bar_close_color_general',
            'type' => 'color',
            'title' => esc_html__(' Menu Bar Close Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => 'header nav')
            
        ),
        array(
            'id' => 'background_color_general',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('background-color' => '#site-header nav')
            
        ),
        array(
            'id' => 'style_links_background_color',
            'type' => 'color',
            'title' => esc_html__('Links Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('background-color' => '#site-header nav')
            
        ),
        array(
            'id' => 'style_links_background_color_hover',
            'type' => 'color',
            'title' => esc_html__('Links Hover Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('background-color' => '#site-header nav')
            
        ),
        array(
            'id' => 'style_links_color',
            'type' => 'color',
            'title' => esc_html__('Links Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('color' => '#site-header nav')
            
        ),
         array(
            'id' => 'style_links_color_hover',
            'type' => 'color',
            'title' => esc_html__('Links Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('color' => '#site-header nav')
            
        ),
        array(
            'id'     => 'full-secreent-se-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // section End

        // Full screen header section start.
        array(
        'id' => 'section-start-three',
        'type' => 'section',
        'required'=>['header_style', '=', 'full_screen'],
        'title' => esc_html__('Full screen header settings', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'full_screen_header_transparent1',
            'type'     => 'checkbox',
            'title'    => esc_html__('', 'studentwp-core'), 
            'required'=>['header_style', '=', 'full_screen'],
            'options'  => array(
                'transparent' => 'ADD TRANSPARENT HEADER', 
                
            ),
            'default' => 'full_screen'
        ),
        array(
            'id'       => 'full_screen_logo_header',
            'type'     => 'media',
            'url'      => true,
            'required'=>['header_style', '=', 'full_screen'],
            'title'    => esc_html__( 'Logo', 'studentwp-core' ),
            'subtitle' => esc_html__( 'Insert site logo image', 'studentwp-core' ),
            'default'  => array( 'url' => get_template_directory_uri() . '/assets/images/logo.png' ),
        ),
        array(
            'id'       => 'full_screen_retina_logo',
            'type'     => 'media', 
            'url'      => true,
            'required'=>['header_style', '=', 'full_screen'],
            'title'    => esc_html__('Retina Logo', 'studentwp-core'),
            'subtitle'    => esc_html__('Select a retina logo twice the normal logo size.', 'studentwp-core'),
            'default'  => array(
                'url'=>''
            ),
        ),
        array(
            'id' => 'menu_background_general',
            'type' => 'color',
            'title' => esc_html__(' Menu Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            'output'    => array('background-color' => 'header nav')
            
        ),
        array(
            'id' => 'search_button_border_color',
            'type' => 'color',
            'title' => esc_html__(' Search Button Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'search_button_color',
            'type' => 'color',
            'title' => esc_html__(' Search Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'search_button_hover_color',
            'type' => 'color',
            'title' => esc_html__(' Search Button Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'top'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id'     => 'top-header-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End of top header section
        
        // Search Styling section start.
        array(
        'id' => 'section-start-five',
        'type' => 'section',
        'required'=>['header_style', '=', 'full_screen'],
        'title' => esc_html__('Search Styling', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id' => 'search_input_color',
            'type' => 'color',
            'title' => esc_html__(' Input Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'input_dashed_text_color',
            'type' => 'color',
            'title' => esc_html__(' Input Dashed Text Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'input_border_bottom_color',
            'type' => 'color',
            'title' => esc_html__(' Input Border Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'input_border_bottom_hover_color',
            'type' => 'color',
            'title' => esc_html__(' Input Hover Border Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'input_focus_border_bottom_color',
            'type' => 'color',
            'title' => esc_html__(' Input Focus Border Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id'     => 'full-screen-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End of full screen section.

        // Center Header settings start.
        array(
        'id' => 'center-header-settings-section-start-six',
        'type' => 'section',
        'required'=>['header_style', '=', 'center'],
        'title' => esc_html__('Center Header Settings', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'left_menu',
            'type'     => 'select',
            'title'    => esc_html__('Left Menu', 'studentwp-core'), 
            'required'=>['header_style', '=', 'center'],

            'options'  => array(
                '1' => 'select you menu', 
                'main-menu' => 'primary', 
                
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'center_menu_position',
            'type'     => 'select',
            'title'    => esc_html__('Menu Position', 'studentwp-core'), 
            'required'=>['header_style', '=', 'center'],
            'options'  => array(
                'wider' => 'Wider Spacing', 
                'centered' => 'Centered Menus', 
                'closer' => 'Closer Spacing', 
                
            ),
            'default' => '1'
        ),
        array(
            'id'     => 'section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        

        // Top header section start
        array(
            'id' => 'top-header-section-start-eigth',
            'type' => 'section',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('TOP HEADER', 'studentwp-core'),
            'indent' => true 
        ),
        array(
            'id' => 'medium_header_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'medium'],
            'output'    => array('background-color' => '#site-header')
        ),
        array(
            'id' => 'medium_header_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
             'output'    => ['#site-header']
        ),
        array(
            'id' => 'medium_sticky_header_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Sticky Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => ['#site-header']
        ),
        array(
            'id' => 'medium_header_top_header_elements',
            'type' => 'sorter',
            'title' => esc_html__( 'Select Elements' , 'studentwp-core' ),
            'desc' => esc_html__( 'Enable, disable or sort the elemnts ' , 'studentwp-core' ),
            'options' => array(
                'Enabled' => array(
                    'logo' => 'Logo',
                    'searchform' => 'Search From',
                ),
                'Disabled'  => array(
                    'social'      => esc_html__('Social', 'studentwp-core'),
                )
            )
        ),
        array(
            'id'     => 'top-header-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // Top Header section end.

        // Menu Section Start.
        array(
        'id' => 'section-start-nine',
        'type' => 'section',
        'required'=>['header_style', '=', 'medium'],
        'title' => esc_html__('MENU', 'student-core'),
        'indent' => true 
        ),
        array(
            'id' => 'medium_menu_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => ['#site-header.medium-header #site-navigation-wrap #menu-main-menu li a ']
        ),
        array(
            'id' => 'medium_menu_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'medium'],
            'output'    => ['background-color'=>'#site-navigation-wrap']
        ),
        array(
            'id'       => 'menu_height',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Height (px)', 'studentwp-core'),
            'width' => false,
            'height'    => true,
            'output'    => ['#site-navigation-wrap']
        ),
        array(
            'id'       => 'medium_menu_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Position','student-core'),
            'options' => array(
                'left-menu' => esc_html__('Left', 'student-core'), 
                'right-menu' => esc_html__( 'Right', 'student-core' ), 
                'center-menu' => esc_html__( 'Center', 'student-core' ), 
            ), 
            'default' => 'left'
        ),
        array(
            'id'     => 'header-menu-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // Header menu Section end.

        array(
            'id' => 'search_form_input_bgcolor',
            'type' => 'color',
            'title' => esc_html__(' Input Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'full_screen'],
            'output'    => array('color' => '#searchform-dropdown .search-field')
        ),

        // Search form section start.
        array(
        'id' => 'search-form-section-start-ten',
        'type' => 'section',
        'required' => ['header_style', '=', 'medium'],
        'title' => esc_html__('Search Form', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id' => 'search_form_input_bgcolor',
            'type' => 'color',
            'title' => esc_html__(' Input Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => 'input.search-field')   
        ),
        array(
            'id' => 'search_form_input_color',
            'type' => 'color',
            'title' => esc_html__(' Input Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => 'input.search-field')   
        ),
        array(
            'id' => 'search_form_placeholder_color',
            'type' => 'color',
            'title' => esc_html__(' Placeholder Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => 'input.search-field')
        ),
        array(
            'id' => 'search_form_button_color',
            'type' => 'color',
            'title' => esc_html__(' Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => 'input.search-submit')
        ),
        array(
            'id' => 'search_form_button_hover_color',
            'type' => 'color',
            'title' => esc_html__(' Button Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => 'input.search-submit:hover')
        ),
        array(
            'id'     => 'search-form-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // Search form section end.

        // Vertical header section start.
        array(
        'id' => 'vertical-header-section-start-eleven',
        'type' => 'section',
        'required'=>['header_style', '=', 'vertical'],
        'title' => esc_html__('Vertical Header Settings', 'studentwp-core'),
        'indent' => true 
    ),
        array(
            'id'       => 'vertical_select_template',
            'type'     => 'select',
            'title'    => esc_html__('Select Template', 'studentwp-core'),
            'required'=>['header_style', '=', 'vertical'],
            'data' => 'posts',
            'args'  => ['post_type' => 'elementor_library'],
            'default' => '1'
        ),
        array(
            'id'       => 'vertical_select_bottom_template',
            'type'     => 'select',
            'title'    => esc_html__('Select Bottom Template', 'studentwp-core'),
            'required'=>['header_style', '=', 'vertical'],
            'data' => 'posts',
            'args'  => ['post_type' => 'elementor_library'],
            'default' => '1'
        ),
        array(
            'id'       => 'add_transparent_header',
            'type'     => 'switch',
            'title'    => esc_html__('ADD TRANSPARENT HEADER', 'studentwp-core'), 
            'required'=>['header_style', '=', 'vertical'],
        ),
        array(
            'id'       => 'add_header_shadow',
            'type'     => 'switch',
            'title'    => esc_html__('ADD HEADER SHADOW', 'studentwp-core'), 
            'required'=>['header_style', '=', 'vertical'],
        ),
        array(
            'id'       => 'closed_header',
            'type'     => 'switch',
            'title'    => esc_html__('CLOSED HEADER', 'studentwp-core'), 
            'required'=>['header_style', '=', 'vertical'],
        ),
        array(
            'id' => 'custom_button_color',
            'type' => 'color',
            'title' => esc_html__(' Custom Hamburger Button Color', 'studentwp-core'),
            'subtitle' => esc_html__('Used for the hamburger menu to open the header in small screens and if closed header.', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id'       => 'vertical_collapse_width',
            'type'     => 'dimensions',
            'required'=>['header_style', '=', 'vertical'],
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Collapse Width (px)', 'studentwp-core'),
            'subtitle'    => esc_html__('This field is to control the width where you want to collapse the header.', 'studentwp-core'),

            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id'       => 'vertical_width',
            'type'     => 'dimensions',
            'required'=>['header_style', '=', 'vertical'],
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Width (px)', 'studentwp-core'),
            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id' => 'vertical_padding',
            'type' => 'spacing',
            'required'=>['header_style', '=', 'vertical'],
            'title' => esc_html__( 'Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
        array(
            'id'       => 'vertical_position',
            'type'     => 'button_set',
            'required'=>['header_style', '=', 'vertical'],
            'title'    => esc_html__('Position','studentwp-core'),
            'options' => array(
                'left' => esc_html__('Left', 'studentwp-core'), 
                'right' => esc_html__('Right', 'studentwp-core'), 
            ), 
            'default' => 'left'
        ),
        array(
            'id'       => 'vertical_logo_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Logo Position','studentwp-core'),
            'required'=>['header_style', '=', 'vertical'],
            'options' => array(
                'left' => esc_html__('Left', 'studentwp-core'),
                'right' => esc_html__('Right', 'studentwp-core'),
                'center' => esc_html__('Center', 'studentwp-core'),
            ), 
            'default' => 'left'
        ),
        array(
            'id' => 'vertical_top_bottom_padding',
            'type' => 'spacing',
            'required'=>['header_style', '=', 'vertical'],
            'title' => esc_html__( 'Menu Items Top/Bottom Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
        array(
            'id'       => 'vertical_submenu_target',
            'type'     => 'button_set',
            'title'    => esc_html__('Dropdown Target','studentwp-core'),
            'subtitle'    => esc_html__('Choose your opening target for your submenus','studentwp-core'),
            'required'=>['header_style', '=', 'vertical'],
            'options' => array(
                'icon' => esc_html__('Icon', 'studentwp-core'),
                'link' => esc_html__('Link', 'studentwp-core'), 
            ), 
            'default' => 'icon'
        ),
        array(
            'id' => 'menu_item_border_color',
            'type' => 'color',
            'title' => esc_html__(' Menu Items Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'submenu_background_color',
            'type' => 'color',
            'title' => esc_html__('Sub Menu Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'submenu_links_color',
            'type' => 'color',
            'title' => esc_html__('Sub Menu Links Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'submenu_links_hover_color',
            'type' => 'color',
            'title' => esc_html__('Sub Menu Links Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'submenu_links_background_color',
            'type' => 'color',
            'title' => esc_html__('Sub Menu Links Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'submenu_links_background_hover_color',
            'type' => 'color',
            'title' => esc_html__('Sub Menu Links Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id'     => 'section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End section

        // Search Form Section Start.
        array(
        'id' => 'section-start-twelve',
        'type' => 'section',
        'required'=>['header_style', '=', 'vertical'],
        'title' => esc_html__('SEARCH FORM', 'studentwp-core'),
        'indent' => true 
    ),
        array(
            'id'       => 'vertical_search_form',
            'type'     => 'checkbox',
            'title'    => esc_html__('', 'studentwp-core'),

            'required'=>['header_style', '=', 'vertical'],
            'options'  => array(
                '1' => 'DISPLAY SEARCH FORM', 
                
            ),
            'default' => '1'
        ),
        array(
            'id'       => 'vertical_border_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Border Width', 'studentwp-core'),
            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id'       => 'vertical_border_radius',
            'type'     => 'text',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Border radius', 'studentwp-core'),
        ),
        array(
            'id' => 'vertical_serch_background_color',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'vertical_search_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')  
        ),
        array(
            'id' => 'vertical_search_border_color',
            'type' => 'color',
            'title' => esc_html__(' Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'vertical_search_border_hover_color',
            'type' => 'color',
            'title' => esc_html__(' Border Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'vertical_search_border_color_focus',
            'type' => 'color',
            'title' => esc_html__(' Border Color: Focus', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'vertical_search_button_color',
            'type' => 'color',
            'title' => esc_html__('Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'vertical_search_hover_color',
            'type' => 'color',
            'title' => esc_html__(' Button Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'required'=>['header_style', '=', 'vertical'],
            // 'output'    => array('color' => '')
        ),
        array(
            'id'     => 'search-form-ssection-end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End of search form seciton.

        // Custom Header Settings start.
        array(
        'id' => 'custom-header-settings-section-start-thirteen',
        'type' => 'section',
        'required'=>['header_style', '=', 'custom'],
        'title' => esc_html__('Custom Header Settings', 'studentwp-core'),
        'indent' => true 
    ),
        array(
            'id'       => 'custom_header_select_template',
            'type'     => 'select',
            'title'    => esc_html__('Select Template', 'studentwp-core'), 
            'required'=>['header_style', '=', 'custom'],
            'data' => 'posts',
            'args'  => ['post_type' => 'elementor_library'],
            'default' => '1'
        ),
        array(
            'id'       => 'custom_header_container',
            'type'     => 'switch',
            'title'    => esc_html__('Add Container', 'studentwp-core'), 
            'required'=>['header_style', '=', 'custom'],
            'default' => '1'
        ),
        array(
            'id'     => 'customer-header-section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
            'id'       => 'center_header_transparent',
            'type'     => 'checkbox',
            'title'    => esc_html__('Center Header Settings', 'student-core'), 
            'required'=>['header_style', '=', 'center'],
            'options'  => array(
                'center_header_transparent' => esc_html__( 'Add transparent header', 'student-core' ),
            ),
            'default' => 'center_header_transparent'
        ),

    ),
) );
?>