<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Social Menu', 'studentwp-core' ),
    'id'         => 'header-social-menu',
    'desc'       => '',
    'icon'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'header_social_menu',
            'type'     => 'switch',
            'title'    => esc_html__('Enable Social Menu', 'studentwp-core'), 
            'default' => true
        ),
        array(
            'id'        => 'menu_social_template',
            'type'      => 'select',
            'required'  =>['header_social_menu', '=', '1'],
            'title'     => esc_html__('Select Template', 'studentwp-core'), 
            'data'      => 'posts',
            'args'      => ['post_type' => 'elementor_library'],
            'default'   => '1'
        ),
    ),
) );
?>