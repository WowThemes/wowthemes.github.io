<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Menu', 'studentwp-core' ),
    'id'         => 'header-menu',
    'desc'       => '',
    'icon'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'header_menu_template',
            'type'     => 'select',
            'title'    => esc_html__('Select Template','studentwp-core'),
            'subtitle'    => esc_html__('Choose a template created in Elementor > Templates to replace the navigation.','studentwp-core'),
            'data' => 'posts',
                'args'  => ['post_type' => 'elementor_library'], 
            'default' => '1'
        ),
        array(
            'id'       => 'header_menu_top_level_dropdown_icon',
            'type'     => 'switch',
            'title'    => esc_html__('TOP LEVEL DROPDOWN ICON', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'header_menu_second_level_dropdown_icon',
            'type'     => 'switch',
            'title'    => esc_html__('SECOND+ LEVEL DROPDOWN ICON', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'header_menu_dropdown_top_border',
            'type'     => 'switch',
            'title'    => esc_html__('DROPDOWN TOP BORDER', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'menu_links_effect',
            'type'     => 'select',
            'title'    => esc_html__('Links Effect','studentwp-core'),
            'options' => array(
                'no' => 'No Effect', 
                'one' => 'Underline From Left', 
                'two' => 'Underline Up', 
                'three' => 'Underline Down', 
                'four' => 'Brackets', 
                'five' => 'Overline & Fixed Underline', 
                'six' => 'Circular Reveal', 
                'seven' => 'Tripple Dot Under', 
                'eight' => 'X Marks The Spot', 
                'nine' => 'Under & Overline',
                'ten' => 'Backlighting',
            ), 
            'default' => 'no'
        ),
        array(
            'id' => 'link_effects_color',
            'type' => 'color',
            'title' => esc_html__('Links Effect: Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,

            'output'    => array('background-color' =>
                '#site-header #site-navigation-wrap .sf-menu >li>a.menu-link>span:before,#site-header  #site-navigation-wrap .sf-menu > li > a.menu-link > span:after'
            ),

        ),
         array(
        'id' => 'section_start_search_icon_style',
        'type' => 'section',
        'title' => esc_html__('SEARCH ICON', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'        => 'menu_search_style',
            'type'      => 'select',
            'title'     => esc_html__('Search Icon Style', 'studentwp-core'),
            'options' 				=> array(
                'disabled' 			=> esc_html__( 'Disabled','studentwp' ),
                'drop_down' 		=> esc_html__( 'Drop Down','oceanwp' ),
                'overlay' 			=> esc_html__( 'Overlay','studentwp' ),
                'header_replace'           => esc_html__( 'Header Replace','studentwp' ),
            ),
        ),

        array(
            'id' => 'menu_search_style_input_background_color',
            'type' => 'color',
            'title' => esc_html__('Input Background Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'drop_down'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('background-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_input_color',
            'type' => 'color',
            'title' => esc_html__('Input Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'drop_down'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_input_border_color',
            'type' => 'color',
            'title' => esc_html__('Input Border Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'drop_down'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('border-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_input_border_color_focus',
            'type' => 'color',
            'required'  =>['menu_search_style', '=', 'drop_down'],
            'title' => esc_html__('Input Border Color:Focus', 'studentwp-core'),
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('border-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_background_color',
            'type' => 'color',
            'title' => esc_html__('Overlay Input Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_color',
            'type' => 'color',
            'title' => esc_html__('Overlay Input Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_placeholder_color',
            'type' => 'color',
            'title' => esc_html__('Input Placeholder Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_dashed_text_color',
            'type' => 'color',
            'title' => esc_html__('Input Dashed Text Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_border_color',
            'type' => 'color',
            'title' => esc_html__('Input Border Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('border-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_border_color_hover',
            'type' => 'color',
            'title' => esc_html__('Input Border Color:hover', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('border-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_input_border_color_focus',
            'type' => 'color',
            'title' => esc_html__('Input Border Color:focus', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('border-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id' => 'menu_search_style_overlay_close_button_color',
            'type' => 'color',
            'title' => esc_html__('Close Button Color', 'studentwp-core'),
            'required'  =>['menu_search_style', '=', 'overlay'],
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section_start_main_style',
        'type' => 'section',
        'title' => esc_html__('MAIN STYLING', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id' => 'navbar_background_color',
            'type' => 'color',
            'title' => esc_html__('Navbar Background Color', 'studentwp-core'),
            'default' => '#0e1951',
            'compiler'  => true,
            'output'    => array('background-color' =>
                '#site-header #site-navigation-wrap'
            ),
        ),
       
        array(
            'id' => 'main_style_menu_link_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'=>['color'=>''],
            
        ),
        array(
            'id' => 'main_style_menu_link_hover_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Link Color:hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'main_style_menu_link_background',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Link Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'main_style_menu_background_hover',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__(' Link Background:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'header_menu_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => array('padding' => '.text-wrap'),
        ),
        array(
            'id' => 'menu_item_color',
            'type' => 'color',
            'title' => esc_html__('Link Color: Curent menu Item', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'    => array('color' => '.text-wrap')
            
        ),
        
        array(
            'id' => 'menu_background_item',
            'type' => 'color',
            'title' => esc_html__(' Link Background:Current Menu Item', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_dropdowns_styling',
        'type' => 'section',
        'title' => esc_html__('DROPDOWNS STYLING', 'studentwp-core'),
        'indent' => true 
        ),

        array(
            'id' => 'dropdowns_link_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'=>['color'=>''],
            
        ),
        array(
            'id' => 'dropdowns_top_borders_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Top Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => '')
            
        ),
        array(
            'id' => 'dropdowns_borders_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => '')
            
        ),
        array(
            'id' => 'dropdowns_link_hover_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Link Color:hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id'       => 'header_menu_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Width(px)', 'studentwp-core'),
            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id' => 'dropdowns_link_background',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'dropdowns_background_hover',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__(' Link Background:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'dropdowns_menu_item_color',
            'type' => 'color',
            'title' => esc_html__('Link Color: Curent menu Item', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'    => array('color' => '.text-wrap')
            
        ),
        
        array(
            'id' => 'dropdowns_menu_background_item',
            'type' => 'color',
            'title' => esc_html__(' Link Background:Current Menu Item', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_dropdowns_categories_posts',
        'type' => 'section',
        'title' => esc_html__('DROPDOWNS CATEGORIES POSTS', 'studentwp-core'),
        'indent' => true 
        ),

        array(
            'id' => 'dropdowns_category_title_bgcolor',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Category Title: Background', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'=>['background_color'=>''],
            
        ),
        array(
            'id' => 'dropdowns_category_title_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Category Title: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'dropdowns_post_links_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Posts Links: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'dropdowns__posts_link_hover_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Posts Links Hover: Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            // 'output'    => array('color' => '')
            
        ),
        array(
            'id' => 'dropdowns_post_link_date_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'medium'],
            'title' => esc_html__('Posts Date: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
            
        ),


        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),















        array(
            'id' => 'menu_link_background',
            'type' => 'color',
            'required'=>['header_style', '=', 'full_screen'],
            'title' => esc_html__('Link Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'menu_background_hover',
            'type' => 'color',
            'required'=>['header_style', '=', 'full_screen'],
            'title' => esc_html__(' Link Background:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id' => 'menu_link_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'full_screen'],
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            'output'=>['color'=>''],
            
        ),
        array(
            'id' => 'menu_link_hover_color',
            'type' => 'color',
            'required'=>['header_style', '=', 'full_screen'],
            'title' => esc_html__('Link Color:hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    ),
) );
?>