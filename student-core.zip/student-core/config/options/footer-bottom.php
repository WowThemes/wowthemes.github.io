<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Footer Bottom', 'studentwp-core' ),
    'id'         => 'footer_bottom',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'fields'     => array(
        array(
            'id'        => 'enable_footer_bottom',
            'title'     => esc_html__('Enable Footer Botoom', 'studentwp-core'),
            'type'      => 'switch',
            'default'   => '',
        ),
        array(
            'id'       => 'footer_bottom_source',
            'type'     => 'select',
            'title'     => esc_html__('Source', 'studentwp-core'),
            'options' => array(
                'default' => esc_html__('Default', 'studentwp-core'),
                'elementor' => esc_html__('Elementor', 'studentwp-core'),
            ), 
            'required'  => array('enable_footer_bottom', '=', true),
            'default' => 'default',
        ),
        array(
            'id'       => 'footer_bottom_elementor_template',
            'type'     => 'select',
            'title'     => esc_html__('Elementor Template', 'studentwp-core'),
            'desc'      => sprintf(__('You can create elementor template <a href="%s" target="_blank">here</a>'), admin_url('post-new.php?post_type=elementor_library')),
            'data'      => 'posts',
            'args'    => array( 'post_type' => 'elementor_library'),
            'required' => ['footer_bottom_source', '=', 'elementor'],
        ),
        array(
            'id'        => 'footer_bottom_settings_section_start',
            'title'     =>esc_html__('Footer Settings', 'studentwp-core'),
            'type'      => 'section',
            'indent'    => true,
            'required'  => array(
                array('enable_footer_bottom', '=', true),
                array('footer_bottom_source', '=', 'default'),
            ),
        ),
        array(
            'id'       => 'footer_bottom_visibility',
            'type'     => 'select',
            'title'    => esc_html__('Visibility', 'studentwp-core'), 
            'options'  => array(
                'all'           => esc_html__('Show on All Devices', 'studentwp-core'),
                'hide_tablet'   => esc_html__('Hide on Tablet', 'studentwp-core'),
                'hide_mobile'   => esc_html__('Hide on Mobile', 'studentwp-core'),
                'hide_both'     => esc_html__('Hide on Tablet & Mobile', 'studentwp-core'),
                'hide_all'      => esc_html__('Hide on All Devices', 'studentwp-core')
            ),
            'default'  => 'all',
        ),
        array(
            'id'       => 'fixed_footer',
            'type'     => 'switch',
            'title'    => esc_html__( 'Fixed Footer', 'studentwp-core' ),
            'subtitle'    => esc_html__( 'This option add a height to your content to keep your footer at the bottom of your page.', 'studentwp-core' ),
            'default'   => true,
        ),
        array(
            'id'=>'footer_copyright',
            'type' => 'textarea',
            'title' => esc_html__('Copyright', 'studentwp-core'), 
            'default' => 'Copyright [studentwp_date] - Studentwp Theme by Nick',
            'allowed_html' => array(
                'a' => array(
                    'href' => array(),
                    'title' => array()
                ),
                'br' => array(),
                'em' => array(),
                'strong' => array()
            ),
        ),
        array(
            'id' => 'footerbottom_twitter',
            'type' => 'text',
            'title' => esc_html__('Twitter', 'studentwp-core'),
            'default' => 'https://twitter.com/wptech',
            'compiler'  => true,
        ),
        array(
            'id' => 'footerbottom_facebook',
            'type' => 'text',
            'title' => esc_html__('Facebook', 'studentwp-core'),
            'default' => 'https://facebook.com/wptech',
            'compiler'  => true,
        ),
        array(
            'id' => 'footerbottom_pinterest',
            'type' => 'text',
            'title' => esc_html__('Pinterest', 'studentwp-core'),
            'default' => 'https://pinterest.com',
            'compiler'  => true,
        ),
        array(
            'id' => 'footer_bottom_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'    => array('padding' => '.footer-btm'),
        ),
        array(
            'id' => 'footer_bottom_background',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => '.footer-btm'),
        ),
        array(
            'id' => 'footer_bottom_text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,  
            'output'    => array('color' =>'.footer-btm .copyright')
        ),
        array(
            'id' => 'footerbotttom_icon_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => '.footer-btm .social-list li a')
            
        ),
        array(
            'id' => 'footerbotttom_icon_color',
            'type' => 'color',
            'title' => esc_html__('Icon Color', 'studentwp-core'),
            'default' => '#616566',
            'compiler'  => true,
            'output'    => array('color' =>'.footer-btm .social-list li a')
        ),
        array(
            'id' => 'footerbottom_icon_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            'output'    => array('background-color' => '.footer-btm .social-list li a:hover')
            
        ),
        array(
            'id'        => 'footer_bottom_settings_section_end',
            'type'      => 'section',
            'indent'    => false,
        ),
    ),
) );
?>