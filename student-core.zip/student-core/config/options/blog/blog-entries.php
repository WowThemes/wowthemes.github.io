<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Blog', 'studentwp-core' ),
    'id'         => 'blog',
    'desc'       => '',
    'icon'       => 'el el-blogger',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Blog Entries', 'studentwp-core' ),
    'id'         => 'blog_entries',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'archives_entries_layout',
            'type'     => 'image_select',
            'title'    => esc_html__( 'Archives & Entries Layout', 'studentwp-core' ),
            'options'  => array(
                'left'  => array(
                    'alt' => esc_html__( 'Left sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/left.png',
                ),
                'full'  => array(
                    'alt' => esc_html__( 'Full width', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/full.png',
                ),
                'right' => array(
                    'alt' => esc_html__( 'Right sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/right.png',
                ),
            ),

            'default' => 'right',
        ),
        array(
            'id'       => 'archive_page_sidebar',
            'type'     => 'select',
            'title'    => esc_html__('Sidebar', 'studentwp-core'), 
            'data'      => 'sidebars',
            'default'  => 'default-sidebar',
            'required' => array(
                array('archives_entries_layout', '!=', 'full')
            )
        ),
        array(
            'id'       => 'blog_mobile_sidebar_order',
            'type'     => 'select',
            'title'    => esc_html__('Mobile Sidebar Order', 'studentwp-core'), 
            'options'  => array(
                'sidebar_content'   => esc_html__('Sidebar/Content'),
                'content_siebar'    => esc_html__('Content/Sidebar')
            ),
            'default'  => 'content_sidebar',
        ),
        array(
            'id'       => 'blog_overlay_image_hover',
            'type'     => 'switch',
            'title'    => esc_html__('Add Overlay on Image Hover','studentwp-core'),
            'default' => true,
        ),
        array(
            'id'       => 'blog_list_style',
            'type'     => 'select',
            'title'    => esc_html__('Blog Style','studentwp-core'),
            'default' => 'grid',
            'options' => array(
                'large-entry' => 'Large Image', 
                'grid-entry' => 'Grid', 
                'thumbnail-entry' => 'Thumbnail', 
            ), 
        ),
        array(
            'id'       => 'blog_grid_images_size',
            'type'     => 'select',
            'title'    => esc_html__('Images Size','studentwp-core'),
            'default' => '1',
            'options' => [
                'thumbnail'     => esc_html__('Thumbnail', 'studentwp-core'),
                'medium'        => esc_html__('Medium', 'studentwp-core'),
                'large'         => esc_html__('Large', 'studentwp-core'),
                'full'          => esc_html__('Full', 'studentwp-core'),
            ], 
            'default' => 'medium'
        ),
        array(
            'id'       => 'blog_grid_columns',
            'type'     => 'select',
            'title'    => esc_html__('Grid Columns','studentwp-core'),
            'options' => array(
                6 => '2', 
                4 => '3', 
                3 => '4',
                2 => '6',
            ), 
            'default' => 3,
            'required'  => ['blog_list_style', '=', 'grid-entry']
        ),
        array(
            'id'       => 'blog_grid_styles',
            'type'     => 'select',
            'title'    => esc_html__('Grid Style','studentwp-core'),
            'default' => '1',
            'options' => array(
                'fit_rows' => esc_html__('Fit Rows', 'studentwp-core'), 
                'masonry' => esc_html__('Masonry', 'studentwp-core'),
            ), 
            'default' => 'fit_rows',
            'required'  => ['blog_list_style', '=', 'grid-entry']
        ),
        array(
            'id'       => 'blog_grid_equal_heights',
            'type'     => 'switch',
            'title'    => esc_html__('Equal Heights','studentwp-core'),
            'default' => true,
            'required'  => ['blog_list_style', '=', 'grid-entry']
        ),
        array(
            'id'       => 'blog_entries_image_height',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Custom Image height (px)', 'studentwp-core'),
            'mode'  => [
                'height'    => true,
            ],
            'width' => false,
            'height'    => true,
        ),
        array(
            'id'       => 'blog_entries_image_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Custom Image Width (px)', 'studentwp-core'),
            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id'       => 'blog_entries_excerpt_length',
            'type'     => 'slider',
            'title'    => esc_html__('Excerpt Length', 'studentwp-core'),
            'subtitle'    => esc_html__('Add 500 to display full content', 'studentwp-core'),
            'default'  => '10',
        ),
        array(
            'id'       => 'blog_pagination_style',
            'type'     => 'select',
            'title'    => esc_html__('Blog Pagination Style','studentwp-core'),
            'options' => array(
                'standard' => esc_html__('Standard','studentwp-core'),
                'infinite_scroll' => esc_html__('Infinite Scroll','studentwp-core'),
                'next_prev' => esc_html__('Next/Prev','studentwp-core'),
            ), 
            'default' => 'standard'
        ),
        array(
            'id'       => 'blog_meta_separator',
            'type'     => 'select',
            'title'    => esc_html__('Meta Separator','studentwp-core'),
            'options' => array(
                'default' => esc_html__('Default', 'studentwp-core'),
                'modern' => esc_html__('Modern', 'studentwp-core'),
                '' => esc_html__('None', 'studentwp-core'),
            ), 
            'default' => 'default'
        ),
    ),
) );
?>