<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Single Post', 'studentwp-core' ),
    'id'         => 'blog_single_post',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'single_post_layout',
            'type'     => 'image_select',
            'title'    => esc_html__( 'Archives & Entries Layout', 'studentwp-core' ),
            'options'  => array(

                'left-sidebar'  => array(
                    'alt' => esc_html__( 'Left sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/left.png',
                ),
                'full-width'  => array(
                    'alt' => esc_html__( 'Full width', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/full.png',
                ),
                'right-sidebar' => array(
                    'alt' => esc_html__( 'Right sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/right.png',
                ),
            ),

            'default' => 'right',
        ),
        
        array(
            'id'       => 'blog_single_sidebar',
            'type'     => 'select',
            'title'    => esc_html__( 'Sidebar', 'studentwp-core' ),
            'desc'     => esc_html__( 'Select sidebar to show at page', 'studentwp-core' ),
            'required' => array(
                array( 'single_post_layout', '!=', 'full' ),
            ),
            'data'  => 'sidebars'
        ),
        array(
            'id'       => 'blog_single_mobile_sidebar_order',
            'type'     => 'select',
            'title'    => esc_html__('Mobile Sidebar Order', 'studentwp-core'), 
            'desc'     => esc_html__(''),
            'options'  => array(
                'sidebar_content' => 'Sidebar/Content',
                'content_sidebar' => 'Content/Sidebar'
            ),
            'default'  => '1',
        ),
        array(
            'id'       => 'page_header_title',
            'type'     => 'select',
            'title'    => esc_html__('Page Header Title','studentwp-core'),
            'default' => '1',
            'options' => array(
                'blog' => 'Blog', 
                'post_title' => 'Post Title',  
            ), 
            'default' => 'blog'
        ),
        array(
            'id'       => 'blog_featured_image',
            'type'     => 'switch',
            'title'    => esc_html__('Featured Image in page Header','studentwp-core'),
            'default' => true
        ),
        array(
            'id'       => 'blog_single_elements_positioning',
            'type'     => 'sorter',
            'title'    => esc_html__('Elements Positioning','studentwp-core'),
            'default' => ['enabled' => ['featured_image', 'title', 'meta', 'content', 'tags', 'social_share', 'next_prev', 'author_box', 'single_comments'], 'disabled' => ['related_posts']],
            'options'   => array(
                'enabled' => array(
                    'featured_image' => esc_html__('Featured Image'),
                    'title' => esc_html__('Title'),
                    'meta' => esc_html__('Meta'),
                    'content' => esc_html__('Content'),
                    'tags' => esc_html__('Tags'),
                    'social_share' => esc_html__('Social Sharing'),
                    'next_prev' => esc_html__('Next/Prev Links'),
                    'author_box' => esc_html__('Author Box'),
                    'single_comments' => esc_html__('Comments')
                ), 
                'disabled' => array(
                    'related_posts' => esc_html__('Related Posts'),
                )
            )
        ),
        array(
            'id'       => 'single_full_width_content',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Full Width Content', 'studentwp-core'),
            'subtitle'    => esc_html__('Enter the max width your the content with the full width layout. Add 0 to disable the max width.', 'studentwp-core'),

            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id'       => 'blog_single_meta_separator',
            'type'     => 'select',
            'title'    => esc_html__('Meta Separator','studentwp-core'),
            'options' => array(
                'default' => 'Default',
                'modern' => 'Modern',
                '' => 'None',
            ), 
            'default' => 'default'
        ),
        array(
            'id'       => 'single_taxonomy',
            'type'     => 'button_set',
            'title'    => esc_html__('Next/Prev Taxonomy','studentwp-core'),
            'options' => array(
                'category' => esc_html__('Category'), 
                'post-tag' => esc_html__('Tag'), 
                'date' => esc_html__('Date'), 
            ), 
            'default' => '1'
        ),
        array(
            'id'       => 'single_related_post_count',
            'type'     => 'slider',
            'title'    => esc_html__('Related Posts Count', 'studentwp-core'),
            'desc'     => esc_html__('Number of related posts to be visible'),
            'default'  => 3,
        ),
        array(
            'id'       => 'single_related_post_columns',
            'type'     => 'slider',
            'title'    => esc_html__('Related Posts Columns', 'studentwp-core'),
            'desc'     => esc_html__('Number of columns per row'),
            'default'  => 3,
        ),
        array(
            'id'       => 'single_taxonomy',
            'type'     => 'button_set',
            'title'    => esc_html__('Related Posts Taxonomy','studentwp-core'),
            'options' => array(
                'category' => esc_html__('Category'), 
                'post-tag' => esc_html__('Tag'), 
            ), 
            'default' => '1'
        ),
        array(
            'id'       => 'single_related_post_image_height',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Related Posts Image Height (px)', 'studentwp-core'),
            'mode'  => [
                'height'    => true,
            ],
            'width' => false,
            'height'    => true,
            /*'default'  => array(
                'Width'   => '200', 
                'Height'  => '100'
            ),*/
        ),
        array(
            'id'       => 'single_related_post_image_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Related Posts Image width (px)', 'studentwp-core'),
            'mode'  => [
                'width'    => true,
            ],
            'width' => true,
            'height'    => false,
        ),
        array(
            'id'       => 'comment_form_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Comment Form Position','studentwp-core'),
            'options' => array(
                'before' => esc_html__('Before'), 
                'after' => esc_html__('After'), 
            ), 
            'default' => 'before'
        ),
    ),
) );
