<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Checkout', 'studentwp-core' ),
    'id'         => 'woocommerce_checkout',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
       array(
            'id'       => 'checkout_company_field',
            'type'     => 'select',
            'title'    => esc_html__('Company name field', 'studentwp-core'), 

            'options'  => array(
                'hidden' => esc_html__('Hidden','studentwp-core'), 
                'optional' => esc_html__('Optional','studentwp-core'), 
                'required' => esc_html__('Required','studentwp-core'), 
            ),
            'default' => 'hidden'
        ),
       array(
            'id'       => 'checkout_address_2_line_field',
            'type'     => 'select',
            'title'    => esc_html__('Address line 2 field', 'studentwp-core'), 

            'options'  => array(
                'hidden' => esc_html__('Hidden','studentwp-core'), 
                'optional' => esc_html__('Optional','studentwp-core'), 
                'required' => esc_html__('Required','studentwp-core'), 
            ),
            'default' => 'hidden'
        ),
       array(
            'id'       => 'checkout_phone_field',
            'type'     => 'select',
            'title'    => esc_html__('Phone field', 'studentwp-core'), 

            'options'  => array(
                'hidden' => esc_html__('Hidden','studentwp-core'), 
                'optional' => esc_html__('Optional','studentwp-core'), 
                'required' => esc_html__('Required','studentwp-core'), 
            ),
            'default' => 'hidden'
        ),
       array(
            'id'       => 'checkout_highlight_required_field',
            'type'     => 'switch',
            'title'    => esc_html__('HIGHLIGHT REQUIRED FIELDS WITH AN ASTERISK', 'studentwp-core'), 
            'default' => ''
        ),
       array(
            'id'       => 'checkout_privacy_policy_page',
            'type'     => 'select',
            'title'    => esc_html__('Privacy policy page', 'studentwp-core'), 

            'options'  => array(
                '' => 'Not page set', 
                '109' =>'All courses', 
                '117'=>'All Courses',
                '118'=>'All Courses',
                '119'=>'All Courses',
                '120'=>'All Courses',
                '121'=>'All Courses',
                '122'=>'Become A Teacher',
                '123'=>'Become A Teacher',
                '124'=>'Become A Teacher',
                '125'=>'Become A Teacher',
                '126'=>'Become A Teacher', 
                '17' => 'Blog', 
                '95' => 'Checkout',
                '114'=>'Checkout',
                '115'=>'Checkout',
                '116'=>'Checkout',
                '15' => 'Home', 
                '3' => 'Privacy Policy', 
                '104' => 'Profile',
                '104'=>'Profile',
                '105'=>'Profile',
                '2' => 'Sample Page',
                '133' => 'Shop',
                '127' => 'Term Conditions',
                '128'=>'Term Conditions',
                '129'=>'Term Conditions',
                '130'=>'Term Conditions',
                '131'=>'Term Conditions',
            ),

            'default' => ''
        ),
       array(
            'id'       => 'checkout_term_conditions_page_id',
            'type'     => 'select',
            'title'    => esc_html__('Terms and conditions page', 'studentwp-core'), 

            'options'  => array(
                '' => 'Not page set', 
                '109' =>'All courses', 
                '117'=>'All Courses',
                '118'=>'All Courses',
                '119'=>'All Courses',
                '120'=>'All Courses',
                '121'=>'All Courses',
                '122'=>'Become A Teacher',
                '123'=>'Become A Teacher',
                '124'=>'Become A Teacher',
                '125'=>'Become A Teacher',
                '126'=>'Become A Teacher', 
                '17' => 'Blog', 
                '95' => 'Checkout',
                '114'=>'Checkout',
                '115'=>'Checkout',
                '116'=>'Checkout',
                '15' => 'Home', 
                '3' => 'Privacy Policy', 
                '104' => 'Profile',
                '104'=>'Profile',
                '105'=>'Profile',
                '2' => 'Sample Page',
                '133' => 'Shop',
                '127' => 'Term Conditions',
                '128'=>'Term Conditions',
                '129'=>'Term Conditions',
                '130'=>'Term Conditions',
                '131'=>'Term Conditions',
            ),

            'default' => '1'
        ),
        array(
        'id'      => 'checkout_privacy_policy_text',
        'type'    => 'textarea',
        'title'   => esc_html__( 'Privacy policy', 'studentwp-core' ),
        'subtitle'    => esc_html__( 'Optionally add some text about your store privacy policy to show during checkout.' ),
        'placeholder'=>'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].',
        'default' => '',
    ), 
        array(
            'id'       => 'checkout_distraction_free_checkout',
            'type'     => 'switch',
            'title'    => esc_html__('DISTRACTION FREE CHECKOUT', 'studentwp-core'), 
            'default' => ''
        ),

        array(
            'id'       => 'checkout_free_multi_step_checkout',
            'type'     => 'switch',
            'title'    => esc_html__('MULTI-STEP CHECKOUT', 'studentwp-core'), 

            'default' => ''
        ),

        array(
            'id'       => 'checkout_multistep_timeline_style',
            'type'     => 'select',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title'    => esc_html__('Timeline Style', 'studentwp-core'), 
            
            'options'  => array(
                'arrow' => esc_html__('Arrow','studentwp-core'), 
                'square' => esc_html__('Square','studentwp-core'), 
               
            ),

            'default' => 'arrows'
        ),
        array(
            'id' => 'checkout_timeline_background',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__(' Timeline: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '#owp-checkout-timeline .timeline-wrapper')            
        ),
        array(
            'id' => 'checkout_timeline_color',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__(' Timeline: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '#owp-checkout-timeline .timeline-wrapper')            
        ),
        array(
            'id' => 'checkout_timeline_number_bgcolor',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__(' Timeline Number: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '#owp-checkout-timeline .timeline-step')            
        ),
        array(
            'id' => 'checkout_timeline_number_color',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__(' Timeline Number: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '#owp-checkout-timeline .timeline-step'),            
        ),
        array(
            'id' => 'checkout_timeline_number_border_color',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__('Timeline Number: Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '#owp-checkout-timeline .timeline-step')            
        ),
        array(
            'id' => 'checkout_timeline_active_bgcolor',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__('Timeline Active: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '#owp-checkout-timeline .active .timeline-wrapper')            
        ),
        array(
            'id' => 'checkout_timeline_active_color',
            'type' => 'color',
            'required' => ['checkout_free_multi_step_checkout', '=', '1'],
            'title' => esc_html__('Timeline Active: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '#owp-checkout-timeline .active .timeline-wrappers')            
        ),

    ),
) );
?>