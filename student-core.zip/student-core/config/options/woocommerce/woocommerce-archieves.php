<?php
Redux::setSection($opt_name, array(
	'title'      => esc_html__('Archives', 'studentwp-core'),
	'id'         => 'woocommerce_archives',
	'desc'       => '',
	'subsection' => true,
	'fields'     => array(
		array(
			'id'       => 'woocommerce_shop_page_display',
			'type'     => 'select',
			'title'    => esc_html__('Shop page display', 'studentwp-core'),
			'subtitle'    => esc_html__('Choose what to display on the main shop page.', 'studentwp-core'),
			'options'  => array(
				'' => esc_html__('Show products', 'studentwp-core'),
				'subcategories' => esc_html__('Show categories', 'studentwp-core'),
				'both' => esc_html__('Show products & categories', 'studentwp-cores'),
			),
			'default' => ''
		),
		array(
			'id'       => 'woocommerce_category_archive_display',
			'type'     => 'select',
			'title'    => esc_html__('Category display', 'studentwp-core'),
			'subtitle'    => esc_html__('Choose what to display on the main shop page.', 'studentwp-core'),
			'options'  => array(
				'' => esc_html__('Show products', 'studentwp-core'),
				'subcategories' => esc_html__('Show subcategories', 'studentwp-core'),
				'both' => esc_html__('Show products & subcategories', 'studentwp-core'),
			),
			'default' => ''
		),
		array(
			'id'       => 'woocommerce_product_sorting',
			'type'     => 'select',
			'title'    => esc_html__('Default product sorting', 'studentwp-core'),
			'subtitle'    => esc_html__('How should products be sorted in the catalog by default?'),
			'options'  => array(
				'menu_order' => esc_html__('Default Sorting (Custom ordering + name)', 'studentwp-core'),
				'popularity' => esc_html__('Popularity (sales)', 'studentwp-core'),
				'rating' => esc_html__('Average rating', 'studentwp-core'),
				'date' => esc_html__('Sort by most recent', 'studentwp-core'),
				'price' => esc_html__('Sort by price (asc)', 'studentwp-core'),
				'price-desc' => esc_html__('Sort by price (desc)', 'studentwp-core'),

			),
			'default' => 'date'
		),
		array(
			'id'       => 'woocommerce_archieves_layout',
			'type'     => 'image_select',
			'title'    => esc_html__('Layout', 'studentwp-core'),
			'options'  => array(

				'left'  => array(
					'alt' => esc_html__('Left sidebar', 'studentwp-core'),
					'img' => get_template_directory_uri() . '/assets/images/left.png',
				),
				'full'  => array(
					'alt' => esc_html__('Full width', 'studentwp-core'),
					'img' => get_template_directory_uri() . '/assets/images/full.png',
				),
				'right' => array(
					'alt' => esc_html__('Right sidebar', 'studentwp-core'),
					'img' => get_template_directory_uri() . '/assets/images/right.png',
				),
			),

			'default' => 'right',
		),
		// array(
		// 	'id'        => 'woocommerce_shop_sidebar',
		// 	'type'      => 'select',
		// 	'title'     => esc_html__('Sidebar', 'studentwp-core'),
		// 	'data'      => 'sidebars',
		// 	'default'   => 'shop',
		// 	'required'  => array('woocommerce_archieves_layout', '!=', 'full')
		// ),
		array(
			'id'       => 'woocommerce_mobile_sidebar_order',
			'type'     => 'select',
			'title'    => esc_html__('Mobile Sidebar Order', 'studentwp-core'),
			'options'  => array(
				'content-sidebar' => esc_html__('Content / Sidebar', 'studentwp-core'),
				'sidebar-content' => esc_html__('Sidebar / Content', 'studentwp-core'),
			),
			'default' => 'content-sidebar'
		),
		array(
			'id'       => 'woo_product_elements_positioning',
            'type'     => 'sorter',
            'title'    => esc_html__('Elements Positioning','studentwp-core'),
            'default' => ['enabled' => ['image', 'category', 'title', 'price-rating', 'woo-rating', 'button'], 'disabled' => ['description']],
            'options'   => array(
                'enabled' => array(
                    'image' => esc_html__('Featured Image'),
                    'category' => esc_html__('Category'),
                    'title' => esc_html__('Title'),
                    'price-rating' => esc_html__('Price and Rating'),
                    'woo-rating' => esc_html__('Rating'),
                    'button' => esc_html__('Add to Cart Button'),
                ), 
                'disabled' => array(
                    'description' => esc_html__('Description'),
                )
            )
		),
		array(
			'id'        => 'woocommerce_shop_post_perpage',
			'type'      => 'slider',
			'title'     => esc_html__('Shop Posts Per Page', 'studentwp-core'),
			'default'   => 12,
			'max'       => 36
		),
		array(
			'id'        => 'woocommerce_shop_column',
			'type'      => 'select',
			'title'     => esc_html__('Shop Column', 'studentwp-core'),
			'options'   => array(
				3   => esc_html__('4 Columns', 'studentwp-core'),
				4   => esc_html__('3 Columns', 'studentwp-core'),
				6   => esc_html__('2 Columns', 'studentwp-core'),
				12   => esc_html__('1 Column', 'studentwp-core'),
			),
			'default'   => 6
		),
		array(
			'id' => 'section_start_toolbar',
			'type' => 'section',
			'title' => esc_html__('TOOLBAR', 'studentwp-core'),
			'indent' => true
		),
		array(
			'id'       => 'woocommerce_toolbar_grid_buttons',
			'type'     => 'switch',
			'title'    => esc_html__('GRID/LIST BUTTONS', 'studentwp-core'),
			'default' => false
		),
		array(
			'id'        => 'woocommerce_toolbar_catalog_view',
			'type'      => 'select',
			'title'     => esc_html__('Default Catalog View', 'studentwp-core'),
			'required'  => ['woocommerce_toolbar_grid_buttons', '=', '1'],
			'options'   => array(
				'grid'  => esc_html__('Grid View', 'studentwp-core'),
				'list'  => esc_html__('List View', 'studentwp-core'),
			),
			'default'   => 'grid'
		),
		array(
			'id'        => 'woocommerce_shop_sort',
			'type'      => 'switch',
			'title'     => esc_html__('SHOP SORT', 'studentwp-core'),
			'default'   => false
		),
		array(
			'id'       => 'woocommerce-shop-result-count',
			'type'     => 'switch',
			'title'    => esc_html__('SHOP RESULT COUNT', 'studentwp-core'),
			'default' => ''
		),
		array(
			'id'     => 'toolbar_section_end',
			'type'   => 'section',
			'indent' => false,
		),
		array(
			'id' => 'section_start_filtering',
			'type' => 'section',
			'title' => esc_html__('OFF CANVAS FILTERING', 'studentwp-core'),
			'indent' => true
		),
		array(
			'id'       => 'woocommerce_off_canvas_display_filter_button',
			'type'     => 'switch',
			'title'    => esc_html__('DISPLAY FILTER BUTTON', 'studentwp-core'),
			'default' => ''
		),
		array(
			'id'       => 'woo_off_canvas_filter_text',
			'type'     => 'text',
			'required' => ['woocommerce_off_canvas_display_filter_button', '=', '1'],
			'title'    => esc_html__('Filter Button Text', 'studentwp-core'),
			'default' => 'Filter'
		),
		array(
			'id'       => 'woocommerce_filtering_close_button',
			'type'     => 'switch',
			'title'    => esc_html__('ADD CLOSE BUTTON', 'studentwp-core'),
			'default' => false
		),
		array(
			'id'        => 'close_button_color',
			'type'      => 'color',
			'required'  => ['woocommerce_filtering_close_button', '=', '1'],
			'title'     => esc_html__('Close Button Color', 'studentwp-core'),
			'compiler'  => true,
			'default'   => '#0e1951',
			'output'    => array('color' => '.oceanwp-off-canvas-close svg')
		),
		array(
			'id' => 'close_button_hover_color',
			'type' => 'color',
			'required' => ['woocommerce_filtering_close_button', '=', '1'],
			'title' => esc_html__('Close Button Color:Hover', 'studentwp-core'),
			'compiler'  => true,
			'default'  => '#0e1951',
			'output'    => array('color' => '.oceanwp-off-canvas-close svg:hover')
		),
		array(
			'id'     => 'filtering_section_end',
			'type'   => 'section',
			'indent' => false,
		),
		array(
			'id' => 'section_start_products',
			'type' => 'section',
			'title' => esc_html__('PRODUCTS', 'studentwp-core'),
			'indent' => true
		),
		array(
			'id'       => 'woocommerce_product_style',
			'type'     => 'select',
			'title'    => esc_html__('Products Style', 'studentwp-core'),
			'options'  => array(
				'default' => esc_html__('Default Style', 'studentwp'),
				'hover' => esc_html__('Hover Style', 'studentwp-core'),
			),
			'default' => 'default'
		),
		array(
			'id'       => 'woocommerce_product_entry_media',
			'type'     => 'select',
			'title'    => esc_html__('Product Entry Media', 'studentwp-core'),
			'options'  => array(
				'featured-image' => esc_html__('Featured Image', 'studentwp-core'),
				'image-swap' => esc_html__('Image Swap', 'studentwp-core' ),
				'gallery-slider' => esc_html__('Gallery Slider', 'studentwp-core'),
			),
			'default' => 'image-swap'
		),

		array(
			'id'       => 'woocommerce_display_quick_view_button',
			'type'     => 'switch',
			'title'    => esc_html__('DISPLAY QUICK VIEW BUTTON', 'studentwp-core'),
			'default' => ''
		),
		array(
			'id'       => 'woo_product_entry_content_alignment',
			'type'     => 'button_set',
			'title'    => esc_html__('Content Alignment', 'studentwp-core'),
			'options'  => array(
				'left' => 'Left',
				'center' => 'Center',
				'right' => 'Right',
			),
			'default' => 'left'
		),
		array(
			'id'     => 'products_section_end',
			'type'   => 'section',
			'indent' => false,
		),
		array(
			'id' => 'section_start_shop_conditional',
			'type' => 'section',
			'title' => esc_html__('SHOP CONDITIONAL', 'studentwp-core'),
			'indent' => true
		),
		array(
			'id'       => 'woocommerce_display_price_cart_button',
			'type'     => 'switch',
			'title'    => esc_html__('DISPLAY PRICE AND ADD TO CART BUTTON ONLY TO LOGGED IN USERS', 'studentwp-core'),
			'default' => ''
		),

		array(
			'id'       => 'woocommerce_shop_cond_msg',
			'type'     => 'switch',
			'required' => ['woocommerce_display_price_cart_button', '=', '1'],
			'title'    => esc_html__('Display message to logged out users', 'studentwp-core'),

			'default' => ''
		),
		array(
			'id'       => 'woocommerce_shop_msg_text',
			'type'     => 'text',
			'required' => ['woocommerce_display_price_cart_button', '=', '1'],
			'title'    => esc_html__('Conditional replacement message', 'studentwp-core'),
			'subtitle'    => esc_html__('Message to display to logged out users instead of the price and Add to Cart button. The message will be displayed in the position of the Add to Cart button', 'studentwp-core'),
			'placeholder' => 'Log in to view price and purchase',

			'default' => ''
		),
		array(
			'id'       => 'woocommerce_shop_add_myaccount_link',
			'type'     => 'switch',
			'required' => ['woocommerce_display_price_cart_button', '=', '1'],
			'title'    => esc_html__('INCLUDE MY ACCOUNT PAGE LINK IN CONDITIONAL MESSAGE', 'studentwp-core'),

			'default' => ''
		),
		array(
			'id'       => 'woocommerce_disable_image_product_title',
			'type'     => 'switch',
			'title'    => esc_html__('DISABLE IMAGE AND PRODUCT TITLE LINKS FUNCTIONALITY', 'studentwp-core'),

			'default' => ''
		),
		array(
			'id'       => 'woocommerce_disable_image_product_title_cond',
			'type'     => 'switch',
			'title'    => esc_html__('Disable links only for logged out users', 'studentwp-core'),
			'required' => ['woocommerce_disable_image_product_title', '=', '1'],
			'subtitle'    => esc_html__('If selected, image and title product archive links will be functional only for logged in users', 'studentwp-core'),

			'default' => ''
		),

		array(
			'id'     => 'shop_conditional_section_end',
			'type'   => 'section',
			'indent' => false,
		),
		array(
			'id' => 'section_start_pagination',
			'type' => 'section',
			'title' => esc_html__('PAGINATION', 'studentwp-core'),
			'indent' => true
		),
		array(
			'id'       => 'woocommerce_pagination',
			'type'     => 'select',
			'title'    => esc_html__('Pagination Style', 'studentwp-core'),
			'options'  => array(
				'standard' => esc_html__('Standard', 'studentwp-core'),
				'infinite_scroll' => esc_html__('Infinite Scrolls', 'studentwp-core'),
			),
			'default' => 'standard'
		),
		array(
			'id' 		=> 'woocommerce_pagination_infinite_scroll_color',
			'type' 		=> 'color',
			'required' 	=> ['woocommerce_pagination', '=', 'infinite_scroll'],
			'title' 	=> esc_html__('Infinite Scroll: Spinners Color', 'studentwp-core'),
			'compiler' 	=> true,
			'default'  	=> '#0e1951',
			// 'output'   	=> array('color' => '')
		),
		array(
			'id'       => 'woocommerce_infinite_scroll_last_text',
			'type'     => 'text',
			'required' => ['woocommerce_pagination', '=', 'infinite_scroll'],
			'title'    => esc_html__('Infinite Scroll: Last Text', 'studentwp-core'),
			'placeholder' => 'End of content',
			'default' => ''
		),
		array(
			'id'       => 'woocommerce_infinite_scroll_error_text',
			'type'     => 'text',
			'required' => ['woocommerce_pagination', '=', 'infinite_scroll'],
			'title'    => esc_html__('Infinite Scroll: Error Text', 'studentwp-core'),
			'placeholder' => 'No more pages to load',
			'default' => ''
		),
		array(
			'id'     => 'pagination_section_end',
			'type'   => 'section',
			'indent' => true,
		),
	),
));
