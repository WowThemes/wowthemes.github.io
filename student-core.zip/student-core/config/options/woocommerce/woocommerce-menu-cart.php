<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Menu Cart', 'studentwp-core' ),
    'id'         => 'woocommerce_menu_cart',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
    array(
        'id' => 'section_start',
        'type' => 'section',
        'subtitle' => esc_html__('For some options, you must save and refresh your live site to preview changes.', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'woocommerce_menu_cart_empty',
            'type'     => 'switch',
            'title'    => esc_html__('HIDE IF EMPTY CART', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'woocommerce_menu_mini_cart_mobile',
            'type'     => 'switch',
            'title'    => esc_html__('DISPLAY MINI CART ON MOBILE', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'woocommerce_visibility',
            'type'     => 'select',
            'title'    => esc_html__('Visibility', 'studentwp-core'),
            'options'  => array(
                'default' => esc_html__('Display On All Devices','studentwp-core'), 
                'disabled' => esc_html__('Disable On All Devices','studentwp-core'), 
                'disabled_desktop' => esc_html__('Disable Only On Desktop','studentwp-core'), 
            ),
            'default' => 'default'
        ),
        array(
            'id'       => 'woocommerce_bag_style',
            'type'     => 'switch',
            'title'    => esc_html__('Bag Style', 'studentwp-core'), 
            'subtitle'    => esc_html__('This setting rep^lace the cart icon by a bag with the items count in it.'), 
            'default' => ''
        ),
        array(
            'id'       => 'woocommerce_bag_icon_display',
            'type'     => 'switch',
            'title'    => esc_html__('BAG ICON DISPLAY TOTAL', 'studentwp-core'),
            'default' => ''
        ),
        array(
            'id'       => 'menu_cart_icon_display',
            'type'     => 'select',
            'title'    => esc_html__('Display', 'studentwp-core'),
            'options'  => array(
                'icon' => 'Icon', 
                'icon_total' => esc_html__('Icon and Cart Total','studentwp-core'),
                'icon_count' => esc_html__('Icon and Cart Count','studentwp-core'), 
                 'icon_count_total' => esc_html__('Icon and Cart Count + Total','studentwp-core'),  
            ),
            'default' => 'icon'
        ),
        array(
            'id'       => 'menu_cart_icon_style',
            'type'     => 'select',
            'title'    => esc_html__('Style', 'studentwp-core'),
            'options'  => array(
                'drop_down' => esc_html__('Drop-Down','studentwp-core'), 
                'cart' => esc_html__('Go To Cart','studentwp-core'),
                'custom_link' => esc_html__('Custom Link','studentwp-core'), 
            ),
            'default' => 'drop_down'
        ),
        array(
            'id'       => 'menu_cart_icon_custom_link',
            'type'     => 'text',
            'title'    => esc_html__('Custom Link', 'studentwp-core'),
            'subtitle'    => esc_html__('The Custom Link style need to be selected', 'studentwp-core'),
            'default' => ''
        ),
        array(
            'id'       => 'menu_cart_custom_icon',
            'type'     => 'text',
            'title'    => esc_html__('Custom Icon', 'studentwp-core'),
            'subtitle'    => esc_html__('Enter your full icon class', 'studentwp-core'),
            'default' => ''
        ),
        array(
            'id'=>'menu_cart_icon_select_field',
            'type' => 'icon_select', 
            //'required' => array('switch-fold','equals','0'),  
            'title' => __('Icon Select', 'studentwp-core'),
            'subtitle'  => __('Select an icon.', 'studentwp-core'),
        ),
        array(
            'id'       => 'menu_cart_icon_size',
            'type'     => 'text',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Icon Size (px)', 'studentwp-core'),
           'desc' => esc_html__( 'Size(px)' , 'studentwp-core' ),
        ),
        array(
            'id'       => 'menu_cart_center_vertically',
            'type'     => 'text',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Center Vertically', 'studentwp-core'),
            'subtitle' => esc_html__( 'Use this field to center your icon vertically' , 'studentwp-core' ),
        ),

        array(
            'id'     => 'menu_cart_section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
            'id' => 'section_start_cart_dropdown',
            'type' => 'section',
            'title' => esc_html__('CART DROPDOWN STYLING', 'studentwp-core'),
            'indent' => true 
        ),
        array(
            'id'       => 'cart_dropdown_style',
            'type'     => 'select',
            'title'    => esc_html__('Style', 'studentwp-core'),

            'options'  => array(
                'compact' => esc_html__('Compact','studentwp-core'), 
                'spacius' => esc_html__('Spacius','studentwp-core'), 
            ),
            'default' => 'compact'
        ),
        array(
            'id'       => 'cart_dropdown_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Width (px)', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => []
        ),
        array(
            'id' => 'cart_dropdown_background_color',
            'type' => 'color',
            'title' => esc_html__(' Dropdown Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'cart_dropdown_borders_color',
            'type' => 'color',
            'title' => esc_html__(' Dropdown Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => '')
        ),
        array(
            'id' => 'cart_dropdown_link_color',
            'type' => 'color',
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_link_color_hover',
            'type' => 'color',
            'title' => esc_html__('Link Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_remove_link_color',
            'type' => 'color',
            'title' => esc_html__('Remove Link Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_remove_link_color_hover',
            'type' => 'color',
            'title' => esc_html__('Remove Link Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_quanity_color',
            'type' => 'color',
            'title' => esc_html__('Quantity Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_price_color',
            'type' => 'color',
            'title' => esc_html__('Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_subtotal_color',
            'type' => 'color',
            'title' => esc_html__('Subtotal Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_dropdown_total_price_color',
            'type' => 'color',
            'title' => esc_html__('Total Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_button_background_color',
            'type' => 'color',
            'title' => esc_html__('Cart Button Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'cart_button_background_hover_color',
            'type' => 'color',
            'title' => esc_html__('Cart Button Background: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
        array(
            'id' => 'cart_button_color',
            'type' => 'color',
            'title' => esc_html__('Cart Button', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_button_color_hover',
            'type' => 'color',
            'title' => esc_html__('Cart Button Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id' => 'cart_button_border_color',
            'type' => 'color',
            'title' => esc_html__('Cart Button Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => '')
        ),
         array(
            'id' => 'cart_button_border_hover_color',
            'type' => 'color',
            'title' => esc_html__('Cart Button Border Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('border-color' => '')
        ),
         array(
            'id' => 'checkout_button_background_color',
            'type' => 'color',
            'title' => esc_html__('Checkout Button Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
         array(
            'id' => 'checkout_button_background_color_hover',
            'type' => 'color',
            'title' => esc_html__('Checkout Button Background:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
         array(
            'id' => 'checkout_button_color',
            'type' => 'color',
            'title' => esc_html__('Checkout Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
         array(
            'id' => 'checkout_button_color_hover',
            'type' => 'color',
            'title' => esc_html__('Checkout Button Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id'     => 'cart_dropdown_section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_cart_sidebar',
        'type' => 'section',
        'title' => esc_html__('MOBILE CART SIDEBAR STYLING', 'studentwp-core'),
        'indent' => true 
        ),
      array(
            'id' => 'mobile_cart_sidebar_background',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
        ),
      array(
            'id' => 'mobile_cart_sidebar_close_button_color',
            'type' => 'color',
            'title' => esc_html__('Close Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
      array(
            'id' => 'mobile_cart_sidebar_title_color',
            'type' => 'color',
            'title' => esc_html__('Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
      array(
            'id' => 'mobile_cart_sidebar_divide-color',
            'type' => 'color',
            'title' => esc_html__('Divide Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('color' => '')
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
   
        
    ),
) );
?>