<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Woocommerce', 'studentwp-core' ),
    'id'         => 'woocommerce',
    'desc'       => '',
    'icon'       => 'el el-screen',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Store Notice', 'studentwp-core' ),
    'id'         => 'woocommerce_store_notice',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
        'id'      => 'woocommerce_demo_store_notice',
        'type'    => 'textarea',
        'title'   => esc_html__( 'Store notice', 'studentwp-core' ),
        'subtitle'    => esc_html__( 'If enabled, this text will be shown site-wide. You can use it to show events or promotions to visitors!', 'studentwp-core' ),
        'placeholder'=>'This is a demo store for testing purposes — no orders shall be fulfilled.',
        'default' => '',
    ), 
        array(
            'id'       => 'woocommerce_demo_store',
            'type'     => 'switch',
            'title'    => esc_html__('ENABLE STORE NOTICE', 'studentwp-core'), 
            'default' => ''
        ),

    ),
) );
?>