<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Single Product', 'studentwp-core' ),
    'id'         => 'woocommerce_single_product',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
            'id'       => 'woocommerce_mobie_sidebar_order',
            'type'     => 'select',
            'title'    => esc_html__('Mobile Sidebar Order', 'studentwp-core'), 

            'options'  => array(
                'content-sidebar' => esc_html__('Content/Sidebar','studentwp-core'), 
                'sidebar-content' => esc_html__('Sidebar/Content','studentwp-core'), 
            ),
            'default' => 'content-sidebar'
        ),
        array(
            'id'       => 'woocommerce_single_products_layout',
            'type'     => 'image_select',
            'title'    => esc_html__( 'Layout', 'studentwp-core' ),
            'options'  => array(

                'left'  => array(
                    'alt' => esc_html__( 'Left sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/left.png',
                ),
                'full'  => array(
                    'alt' => esc_html__( 'Full width', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/full.png',
                ),
                'right' => array(
                    'alt' => esc_html__( 'Right sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/right.png',
                ),
            ),

            'default' => 'right',
        ),
        array(
            'id'       => 'single_product_title_tag',
            'type'     => 'select',
            'title'    => esc_html__('Title HTML Tag', 'studentwp-core'), 

            'options'  => array(
                'h1' => esc_html__('H1','studentwp-core'), 
                'h2' => esc_html__('H2','studentwp-core'), 
                'h3' => esc_html__('H3','studentwp-core'), 
                'h4' => esc_html__('H4','studentwp-core'), 
                'h5' => esc_html__('H5','studentwp-core'), 
                'h6' => esc_html__('H6','studentwp-core'), 
                'div' => esc_html__('Div','studentwp-core'), 
                'span' => esc_html__('Span','studentwp-core'), 
                'p' => esc_html__('P','studentwp-core'), 
            ),
            'default' => 'h2'
        ),
        array(
            'id'       => 'single_product_navigation',
            'type'     => 'switch',
            'title'    => esc_html__('DISPLAY PRODUCT NAVIGATION', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'single_product_enable_ajax_add_to_cart',
            'type'     => 'switch',
            'title'    => esc_html__('ENABLE AJAX ADD TO CART', 'studentwp-core'), 
            'default' => true
        ),
        array(
            'id'       => 'single_product_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Image Width (%)', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => []
        ),
         array(
            'id'       => 'single_product_summary_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Summary Width (%)', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => []
        ),
         array(
            'id'       => 'single_product_thumbnails_layout',
            'type'     => 'select',
            'title'    => esc_html__('Thumbnails Layout', 'studentwp-core'), 

            'options'  => array(
                'horizontal' => esc_html__('Horizontal','studentwp-core'), 
                'vertical' => esc_html__('Vertical','studentwp-core'), 
                
            ),
            'default' => 'horizontal'
        ),
         array(
            'id'       => 'single_product_add_cart_button_style',
            'type'     => 'select',
            'title'    => esc_html__('Add To Cart Button Style', 'studentwp-core'), 
            'options'  => array(
                'normal' => esc_html__('Normal','studentwp-core'), 
                'big' => esc_html__('Big','studentwp-core'), 
                'very-big' => esc_html__('Very Big','studentwp-core'), 
                
            ),
            'default' => 'normal'
        ),
         array(
        'id' => 'section_start_single_product_conditional',
        'type' => 'section',
        'title' => esc_html__('SINGLE PRODUCT CONDITIONAL', 'studentwp-core'),
        'indent' => true 
        ),
      array(
            'id'       => 'single_product_display_price_add_cart_logged_users1',
            'type'     => 'switch',
            'title'    => esc_html__('DISPLAY PRICE AND ADD TO CART BUTTON ONLY TO LOGGED IN USERS', 'studentwp-core'), 
            'default' => true
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section_start_tabs',
        'type' => 'section',
        'title' => esc_html__('Tabs', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'single_product_tabs_layout',
            'type'     => 'select',
            'title'    => esc_html__('Tabs Layout', 'studentwp-core'), 

            'options'  => array(
                'horizontal' => esc_html__('Horizontal','studentwp-core'), 
                'vertical' => esc_html__('Vertical','studentwp-core'), 
                 'section' => esc_html__('Section','studentwp-core'), 
                
            ),
            'default' => 'horizontal'
        ),
      array(
            'id'       => 'single_product_product_meta_tabs_position',
            'type'     => 'button_set',
            'title'    => esc_html__('Tabs Position', 'studentwp-core'), 
            'subtitle'    => esc_html__('Only work for the horizontal tabs layout', 'studentwp-core'), 
            'options'  => array(
                'left' => 'Left',
                 'right' => 'Right', 
                 'center' => 'Center', 
            ),
            'default' => 'left'
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section_start_upsells_related_items',
        'type' => 'section',
        'title' => esc_html__('UP-SELLS & RELATED ITEMS', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'single_product_upsells_count',
            'type'     => 'text',
            'title'    => esc_html__('Up-Sells Count'), 
            'default' => ''
        ),
        array(
            'id'       => 'single_product_upsells_count_columns',
            'type'     => 'text',
            'title'    => esc_html__('Up-Sells Columns'), 
            'default' => ''
        ),
        array(
            'id'       => 'single_product_display_related_items',
            'type'     => 'switch',
            'title'    => esc_html__('Display Related Items', 'studentwp-core'), 
            'default' => true
        ),
        array(
            'id'        => 'single_product_related_items_counts',
            'type'      => 'text',
            'title'     => esc_html__('Related Items Count'), 
            'default'   => 3
        ),
        array(
            'id'       => 'single_product_related_product_column',
            'type'     => 'text',
            'title'    => esc_html__('Related Products Columns'), 
            'default' => 3
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section_start_floating_bar',
        'type' => 'section',
        'title' => esc_html__('FLOATING BAR', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'single_product_display_floating_bar',
            'type'     => 'switch',
            'title'    => esc_html__('Display Floating Bar', 'studentwp-core'), 
            'subtitle'    => esc_html__('The floating bar is to display the add to cart button when you scroll to increase conversions.', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id' => 'single_product_background_color',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_title_color',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_buttons_bgcolor',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Buttons: Backgrounds', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_buttons_bgcolor_hover',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Buttons Hover: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_buttons_color',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Buttons: Color', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_buttons_color_hover',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Buttons Hover: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_inputs_bgcolor',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Input: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_quantity_inputs_color',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Quantity Input: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'single_product_add_to_cart_bgcolor',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Add To Cart: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_add_to_cart_bgcolor_hover',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Add To Cart Hover: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'single_product_add_to_cart_color',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Add To Cart: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'single_product_add_to_cart_color_hover',
            'type' => 'color',
            'required' => ['single_product_display_floating_bar', '=', '0'],
            'title' => esc_html__('Add To Cart Hover: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
    ),
) );
?>