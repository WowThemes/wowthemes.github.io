<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General', 'studentwp-core' ),
    'id'         => 'woocommerce-general',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
    array(
        'id' => 'section_start',
        'type' => 'section',
        'subtitle' => esc_html__('For some options, you must save and refresh your live site to preview changes.', 'studentwp-core'),
        'indent' => true 
        ),

        array(
            'id'       => 'remove_custom_features_woocommerce',
            'type'     => 'switch',
            'title'    => esc_html__('Remove Custom WooCommerce Features', 'studentwp-core'), 
            'subtitle'    => esc_html__('Remove all the custom WooCommerce features added for StudentWP, you will have the default plugin features.', 'studentwp-core'), 
            'default' => '1'
        ),
        array(
            'id'       => 'custom_woocommerce_sidebar1',
            'type'     => 'switch',
            'title'    => esc_html__('Custom WooCommerce Sidebar', 'studentwp-core'), 
            'default' => true
        ),
        array(
            'id'       => 'display_cart_woocommerce_product',
            'type'     => 'switch',
            'title'    => esc_html__('Display Cart When Product Added', 'studentwp-core'), 
            'subtitle'    => esc_html__('Display the cart when a product is added, work in the shop and the single product pages if ajax is enabled.', 'studentwp-core'), 
            'default' => true
        ),
        array(
            'id'       => 'woocommerce_categories_widget_style',
            'type'     => 'select',
            'title'    => esc_html__('Categories Widget Style', 'studentwp-core'),
            'subtitle'    => esc_html__('Choose the WooCommerce Categories widget style.', 'studentwp-core'), 

            'options'  => array(
                'default' => esc_html__('Default','studentwp-core'), 
                'dropdown' => esc_html__('Dropdown','studentwp-core'), 
            ),
            'default' => 'default'
        ),
        array(
            'id'     => 'general_section_end',
            'type'   => 'section',
            'indent' => false,
        ),


        array(
        'id' => 'section_start_wishlist',
        'type' => 'section',
        'title' => esc_html__('WISHLIST', 'studentwp-core'),
        'desc' => esc_html__('You need to activate the TI WooCommerce Wishlist plugin to add a wishlist button and icon', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'woocommerce_wishlist_plugin_support',
            'type'     => 'select',
            'title'    => esc_html__('WooCommerce Wishlist Plugin Support', 'studentwp-core'),

            'options'  => array(
                'ti_wl' => esc_html__('TI WC Wishlist','studentwp-core'), 
                'yith_wl' => esc_html__('YITH WC Wishlist','studentwp-core'), 
            ),
            'default' => 'ti_wl'
        ),
        array(
            'id'       => 'wishlist_list_icon_header',
            'type'     => 'switch',
            'title'    => esc_html__('ADD WISHLIST ICON IN HEADER', 'studentwp-core'), 
            'default' => ''
        ),
        
        array(
            'id'     => 'wishlist_section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_bage',
        'type' => 'section',
        'title' => esc_html__('ON SALE BADGE', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'on_scale_bage',
            'type'     => 'select',
            'title'    => esc_html__('On Sale Badge Style Support', 'studentwp-core'),

            'options'  => array(
                'square' => esc_html__('Square','studentwp-core'), 
                'circle' => esc_html__('Circle','studentwp-core'), 
            ),
            'default' => 'square'
        ),

        array(
            'id'       => 'on_scale_bage_content',
            'type'     => 'select',
            'title'    => esc_html__('On Sale Badge Content', 'studentwp-core'),

            'options'  => array(
                'sale' => esc_html__('On Sale Text','studentwp-core'), 
                'percent' => esc_html__('Percentage','studentwp-core'), 
            ),
            'default' => 'sale'
        ),
        array(
            'id'     => 'sale_bage_section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section_start_account_page',
        'type' => 'section',
        'title' => esc_html__('MY ACCOUNT PAGE', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'login_register_sstyle',
            'type'     => 'select',
            'title'    => esc_html__('Login/Register Style', 'studentwp-core'),

            'options'  => array(
                'original' => esc_html__('Original','studentwp-core'), 
                'side' => esc_html__('Side by Side','studentwp-core'), 
            ),
            'default' => 'original'
        ),
        array(
            'id'     => 'sale_bage_section_end',
            'type'   => 'section',
            'indent' => false,
        ),
         array(
        'id' => 'section_start_category_page',
        'type' => 'section',
        'title' => esc_html__('CATEGORY PAGE', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'display_page_wo_category_image',
            'type'     => 'switch',
            'title'    => esc_html__('Display Featured Image', 'studentwp-core'),
            'subtitle'    => esc_html__('Display the categories featured images before the product archives.'),

        ),
        array(
            'id'     => 'category_page_section_end',
            'type'   => 'section',
            'indent' => false,
        ),
    ),
) );
?>