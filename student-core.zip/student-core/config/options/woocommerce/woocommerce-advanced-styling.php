<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Advanced Styling', 'studentwp-core' ),
    'id'         => 'woocommerce_advanced_styling',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(

        array(
            'id' => 'advance_styling_on_sale_background_color',
            'type' => 'color',
            'title' => esc_html__('On Sale Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '.woocommerce span.onsale ')            
        ),
        array(
            'id' => 'advance_styling_onsale_color',
            'type' => 'color',
            'title' => esc_html__('On Sale Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#ffffff',
            'output'    => array('color' => '.woocommerce span.onsale ')            
        ),
        array(
            'id' => 'advance_styling_outstock_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Out of Stock Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_outstock_color',
            'type' => 'color',
            'title' => esc_html__('Out of Stock Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_stars_before_color',
            'type' => 'color',
            'title' => esc_html__('Stars Color Before', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_stars_color',
            'type' => 'color',
            'title' => esc_html__('Stars Color', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')            
        ),
        array(
        'id' => 'section_start_product_entry_toolbar',
        'type' => 'section',
        'title' => esc_html__('PRODUCT ENTRY: TOOLBAR', 'studentwp-core'),
        'indent' => true 
        ),

        array(
            'id' => 'advance_styling_border_top_bottom_color',
            'type' => 'color',
            'title' => esc_html__('Border Top/Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .oceanwp-toolbar')            
        ),
        array(
            'id' => 'advance_styling_offcanvas_filter_color',
            'type' => 'color',
            'title' => esc_html__('Off Canvas Filter Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce .oceanwp-off-canvas-filter')            
        ),
        array(
            'id' => 'advance_styling_offcanvas_filter_bordercolor',
            'type' => 'color',
            'title' => esc_html__('Off Canvas Filter Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .oceanwp-off-canvas-filter')            
        ),
        array(
            'id' => 'advance_styling_offcanvas_filter_hover_color',
            'type' => 'color',
            'title' => esc_html__('Off Canvas Filter Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce .oceanwp-off-canvas-filter:hover')            
        ),
        array(
            'id' => 'advance_styling_offcanvas_filter_hover_bordercolor',
            'type' => 'color',
            'title' => esc_html__('Off Canvas Filter Hover Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .oceanwp-off-canvas-filter:hover')            
        ),
        array(
            'id' => 'advance_styling_grid_list_color',
            'type' => 'color',
            'title' => esc_html__('Grid/List Color', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.woocommerce .oceanwp-grid-list a')            
        ),
        array(
            'id' => 'advance_styling_grid_list_bordercolor',
            'type' => 'color',
            'title' => esc_html__('Grid/List Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .oceanwp-grid-list a')            
        ),
        array(
            'id' => 'advance_styling_grid_list_hover_color',
            'type' => 'color',
            'title' => esc_html__('Grid/List Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce .oceanwp-grid-list a:hover')            
        ),
        array(
            'id' => 'advance_styling_grid_list_active_color',
            'type' => 'color',
            'title' => esc_html__('Grid/List Active Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce .oceanwp-grid-list a.active')            
        ),
        array(
            'id' => 'advance_styling_grid_list_active_border_color',
            'type' => 'color',
            'title' => esc_html__('Grid/List Active Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .oceanwp-grid-list a.active')            
        ),
        array(
            'id' => 'advance_styling_select_color',
            'type' => 'color',
            'title' => esc_html__('Select Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce .woocommerce-ordering .orderby option')            
        ),
        array(
            'id' => 'advance_styling_select_border_color',
            'type' => 'color',
            'title' => esc_html__('Select Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce .woocommerce-ordering select')            
        ),
        array(
            'id' => 'advance_styling_number_of_poducts_color',
            'type' => 'color',
            'title' => esc_html__('Number of Products Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_number_of_poducts_inactive_color',
            'type' => 'color',
            'title' => esc_html__('Number of Products Inactive Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_number_of_poducts_border_color',
            'type' => 'color',
            'title' => esc_html__('Number of Products Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),


         array(
        'id' => 'section_start_product_entry',
        'type' => 'section',
        'title' => esc_html__('PRODUCT ENTRY', 'studentwp-core'),
        'indent' => true 
        ),
         array(
            'id' => 'advance_styling_product_entry_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'output'=>array('padding'=>'.woocommerce ul.products li.product')
        ),
         array(
            'id' => 'advance_styling_product_entry_margin',
            'type' => 'spacing',
            'title' => esc_html__( 'Image Margin (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Margin(px)' , 'studentwp-core' ),
             'output'=>array('margin'=>'.woocommerce ul.products li.product')
        ),
         array(
        'id'       => 'advance_styling_product_entry_border_width',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Border Width (px)', 'studentwp-core'),
        'mode'  => [
            'width'    => true,
        ],
        'width' => true,
        'height'    => false,
    ),
     array(
            'id' => 'advance_styling_product_entry_border_radius',
            'type' => 'spacing',
            'title' => esc_html__( 'Border Radius (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Border Radius (px)' , 'studentwp-core' ),
        ),

        array(
            'id' => 'advance_styling_product_entry_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '.woocommerce ul.products.list li.product')            
        ),
        array(
            'id' => 'advance_styling_product_entry_border_color',
            'type' => 'color',
            'title' => esc_html__('Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce ul.products.list li.product')          
        ),
        array(
            'id' => 'advance_styling_product_entry_category_color',
            'type' => 'color',
            'title' => esc_html__('Category Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce ul.products li.product li.category a')            
        ),
        array(
            'id' => 'advance_styling_product_entry_category_hover_color',
            'type' => 'color',
            'title' => esc_html__('Category Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce ul.products li.product li.category a:hover')            
        ),
        array(
            'id' => 'advance_styling_product_entry_title_color1',
            'type' => 'color',
            'title' => esc_html__('Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce ul.products li.product .woocommerce-loop-category__title, .woocommerce ul.products li.product .woocommerce-loop-product__title, .woocommerce ul.products li.product h3')            
        ),
        array(
            'id' => 'advance_styling_product_entry_title_color',
            'type' => 'color',
            'title' => esc_html__('Title Color: Hover', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.woocommerce ul.products li.product .woocommerce-loop-category__title, .woocommerce ul.products li.product .woocommerce-loop-product__title, .woocommerce ul.products li.product h3:hover')            
        ),
        array(
            'id' => 'advance_styling_product_entry_price_color',
            'type' => 'color',
            'title' => esc_html__('Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce ul.products li.product .price .amount')            
        ),
        array(
            'id' => 'advance_styling_product_entry_del_price_color',
            'type' => 'color',
            'title' => esc_html__('Del Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce ul.products li.product .price del .amount')          
        ),
        array(
            'id' => 'advance_styling_product_entry_conditional_notice_color',
            'type' => 'color',
            'title' => esc_html__('Conditional Notice: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_product_entry_conditional_notice_hover_color',
            'type' => 'color',
            'title' => esc_html__('Conditional Notice: Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End of Section

        // Start of section: Entry Add to cart.
        array(
            'id' => 'section_start_product_entry_add_tocart',
            'type' => 'section',
            'title' => esc_html__('PRODUCT ENTRY: ADD TO CART', 'studentwp-core'),
            'indent' => true 
        ),
        array(
            'id' => 'advance_styling_product_entry_addtocart_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '.woocommerce ul.products li.product .button')            
        ),
        array(
            'id' => 'advance_styling_product_entry_addtocart_hover_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Background Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#6588fe',
            'output'    => array('background-color' => '.woocommerce ul.products li.product .button:hover')            
        ),
        array(
            'id' => 'advance_styling_product_entry_addtocart_color',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('color' => '.woocommerce ul.products li.product .button ')            
        ),
        array(
            'id' => 'advance_styling_product_entry_addtocart_hover_color',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('color' => '.woocommerce ul.products li.product .button:hover')            
        ),
        array(
            'id'        => 'advance_styling_product_entry_addtocart_border_style',
            'type'      => 'border',
            'title'     => esc_html__('Add To Cart Bord+er: Style', 'studentwp-core'), 
            'output'    => ['.woocommerce ul.products li.product .button'],
            'default'   => [
                'border-right'      => '1px',
                'border-top'        => '1px',
                'border-bottom'     => '1px',
                'border-left'     => '1px',
                'border-color'     => '#0e1951',
                'border-style'     => 'solid',
            ]
        ),
        array(
            'id'        => 'advance_styling_product_entry_addtocart_border_style_hover',
            'type'      => 'border',
            'title'     => esc_html__('Add To Cart Bord+er: Hover Style', 'studentwp-core'), 
            'output'    => ['.woocommerce ul.products li.product .button:hover'],
            'default'   => [
                'border-right'      => '1px',
                'border-top'        => '1px',
                'border-bottom'     => '1px',
                'border-left'     => '1px',
                'border-color'     => '#6588fe',
                'border-style'     => 'solid',
            ]
        ),
        array(
            'id'       => 'wadvance_styling_product_entry_addtocart_border_radius',
            'type'     => 'text',
            'title'    => esc_html__('Add To Cart Border: Radius', 'studentwp-core'),
            'subtitle'    => esc_html__('Add a custom border radius. px - em - %.', 'studentwp-core'),
            'output'   => array('.woocommerce ul.products li.product .button'),
            'default' => ''
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        // End Section: Entry Add to cart button styling

        // Section Start: Entry Quick View.
        array(
            'id' => 'section_start_advance_styling_quick_view',
            'type' => 'section',
            'title' => esc_html__('QUICK VIEW', 'studentwp-core'),
            'indent' => true 
        ),
        array(
            'id' => 'advance_styling_quick_view_button_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Button: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'rgba(0, 0, 0, 0.6)',
            'output'    => array('background-color' => '.woocommerce .products .product-inner .owp-quick-view')            
        ),
        array(
            'id' => 'advance_styling_quick_view_button_hover_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Button: Hover Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '.woocommerce .products .product-inner:hover .owp-quick-view')            
        ),
        array(
            'id' => 'advance_styling_quick_view_button_color',
            'type' => 'color',
            'title' => esc_html__('Button: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#ffffff',
            'output'    => array('color' => '.woocommerce .products .product-inner .owp-quick-view')            
        ),
        array(
            'id' => 'advance_styling_quick_view_button_hover_color',
            'type' => 'color',
            'title' => esc_html__('Button: Hover Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#ffffff',
            'output'    => array('color' => '.woocommerce .products .product-inner:hover .owp-quick-view:hover')            
        ),
        array(
            'id' => 'advance_styling_quick_view_overlay_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Overlay: Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_quick_view_overlay_spinner_outside_color',
            'type' => 'color',
            'title' => esc_html__('Overlay Spinner: Outside Color', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')            
        ),
        array(
            'id'       => 'advance_styling_quick_view_overlay_spinner_inner_color',
            'type'     => 'color',
            'title'    => esc_html__('Overlay Spinner: Inner Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')
        ),
        array(
            'id'       => 'advance_styling_quick_view_model_bgcolor',
            'type'     => 'color',
            'title'    => esc_html__('Modal: Background', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('background-color' => '#owp-qv-wrap .summary ')
        ),
        array(
            'id'       => 'advance_styling_quick_view_model_close_color',
            'type'     => 'color',
            'title'    => esc_html__('Modal Close Button: Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.owp-qv-content-inner .owp-qv-close')
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_advance_styling_offcanvas_sidebar',
        'type' => 'section',
        'title' => esc_html__('OFF CANVAS SIDEBAR', 'studentwp-core'),
        'indent' => true 
        ),
         
        array(
            'id' => 'advance_styling_offcanvas_sidebar_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_offcanvas_sidebar_widgets_border_color',
            'type' => 'color',
            'title' => esc_html__('Widgets Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),



        array(
        'id' => 'section_start_advance_styling_single_product',
        'type' => 'section',
        'title' => esc_html__('SINGLE PRODUCT', 'studentwp-core'),
        'indent' => true 
        ),
         
        array(
            'id' => 'advance_styling_single_product_title_color',
            'type' => 'color',
            'title' => esc_html__('Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.article-txt h3')            
        ),
        array(
            'id' => 'advance_styling_single_product_price_color',
            'type' => 'color',
            'title' => esc_html__('Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.amount')            
        ),
        array(
            'id' => 'advance_styling_single_product_del_price_color',
            'type' => 'color',
            'title' => esc_html__('Del Price Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => 'del .amount ')            
        ),
        array(
            'id' => 'advance_styling_single_product_description_color',
            'type' => 'color',
            'title' => esc_html__('Description Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('color' => '.woocommerce div.product .woocommerce-tabs .panel p')            
        ),
        array(
            'id' => 'advance_styling_single_product_quantity_border_color',
            'type' => 'color',
            'title' => esc_html__('Quantity Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#eee',
            'output'    => array('border-color' => '.woocommerce .quantity .qty')            
        ),
        array(
            'id' => 'advance_styling_single_product_quantity_border_color_focus',
            'type' => 'color',
            'title' => esc_html__('Quantity Border Color Focus', 'studentwp-core'),
            'compiler' => true,
            'default'  => '#aaa',
            'output'   => array('border-color' => '.woocommerce .quantity .qty:focus')            
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_color',
            'type'     => 'color',
            'title'    => esc_html__('Quantity Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#333',
            'output'   => array('color' => '.woocommerce .quantity .qty')
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_plus_minus_color',
            'type'     => 'link_color',
            'title'    => esc_html__('Quantity Plus/Minus Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => ['regular' => '#333', 'hover' => '#fff', 'focus' => '#fff', 'active' => '#fff'],
            'output'   => array('color' => '.woocommerce .quantity .minus, .woocommerce .quantity .plus')
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_plus_minus_bg_color',
            'type'     => 'color',
            'title'    => esc_html__('Quantity Plus/Minus BG Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#fff',
            'output'   => array('background-color' => '.woocommerce .quantity .minus, .woocommerce .quantity .plus')
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_plus_minus_bg_hover_color',
            'type'     => 'color',
            'title'    => esc_html__('Quantity Plus/Minus BG Color: Hover', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('background-color' => '.woocommerce .quantity .minus:hover, .woocommerce .quantity .plus:hover')
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_plus_minus_border',
            'type'     => 'border',
            'title'    => esc_html__('Quantity Plus/Minus Border', 'studentwp-core'), 
            'compiler' => true,
            'default'  => ['border-width' => '1px', 'border-style' => 'solid', 'border-color' => '#eee'],
            'output'   => array('.quantity .minus, .quantity .plus')
        ),
        array(
            'id'       => 'advance_styling_single_product_quantity_plus_minus_border_hover',
            'type'     => 'border',
            'title'    => esc_html__('Quantity Plus/Minus Border: Hover', 'studentwp-core'), 
            'compiler' => true,
            'default'  => ['border-width' => '1px', 'border-style' => 'solid', 'border-color' => '#0e1951'],
            'output'   => array('.quantity .minus:hover, .quantity .plus:hover')
        ),
        array(
            'id'       => 'advance_styling_single_product_meta_title_color',
            'type'     => 'color',
            'title'    => esc_html__('Meta Title Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.product_meta .posted_in')
        ),
        array(
            'id'       => 'advance_styling_single_product_meta_link_color',
            'type'     => 'color',
            'title'    => esc_html__('Meta Link Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.product_meta .posted_in a')
        ),
        array(
            'id'       => 'advance_styling_single_product_meta_link_hover_color',
            'type'     => 'color',
            'title'    => esc_html__('Meta Link Color: Hover', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            'output'   => array('color' => '.product_meta .posted_in a:hover')
        ),
        array(
            'id'       => 'advance_styling_single_product_conditional_notice_color',
            'type'     => 'color',
            'title'    => esc_html__('Conditional Notice: Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')
        ),
        array(
            'id'       => 'advance_styling_single_product_conditional_notice_hover_color',
            'type'     => 'color',
            'title'    => esc_html__('Conditional Notice: Hover Color', 'studentwp-core'), 
            'compiler' => true,
            'default'  => '#0e1951',
            // 'output'   => array('color' => '')
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
            'id' => 'section_start_advance_styling_single_product_navigation',
            'type' => 'section',
            'title' => esc_html__('SINGLE PRODUCT: PRODUCT NAVIGATION', 'studentwp-core'),
            'indent' => true 
        ),
         array(
            'id' => 'advance_styling_single_product_navigation_border_radius',
            'type' => 'spacing',
            'title' => esc_html__( 'Border Radius (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Border Radius (px)' , 'studentwp-core' ),
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_hover_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Background Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_hover_color',
            'type' => 'color',
            'title' => esc_html__('Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_border_color',
            'type' => 'color',
            'title' => esc_html__('Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_navigation_border_hover_color',
            'type' => 'color',
            'title' => esc_html__('Border Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
            'id' => 'section_start_advance_styling_single_product_addtocart',
            'type' => 'section',
            'title' => esc_html__('SINGLE PRODUCT: ADD TO CART', 'studentwp-core'),
            'indent' => true 
        ),
        
        array(
            'id' => 'advance_styling_single_product_addtocart_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('background-color' => '.woocommerce div.product form.cart .button')          
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_hover_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Background Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#6588fe',
            'output'    => array('background-color' => '.woocommerce div.product form.cart .button:hover')            
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_color',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('color' => '.woocommerce div.product form.cart .button')            
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_hover_color',
            'type' => 'color',
            'title' => esc_html__('Add To Cart Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#fff',
            'output'    => array('color' => '.woocommerce div.product form.cart .button:hover')            
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_border_style',
            'type' => 'border',
            'title' => esc_html__('Add To Cart Border', 'studentwp-core'),
            'all'  => true,
            'default'  => [
                'border-width'  => '1px',
                'border-color'  => '#0e1951',
                'border-style'  => 'solid'
            ],
            'output'    => array('.woocommerce div.product form.cart .button')            
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_hover_border_style',
            'type' => 'border',
            'title' => esc_html__('Add To Cart Border: Hover', 'studentwp-core'),
            'all'  => true,
            'default'  => [
                'border-width'  => '1px',
                'border-color'  => '#6588fe',
                'border-style'  => 'solid'
            ],
            'output'    => array('.woocommerce div.product form.cart .button:hover')            
        ),
        array(
            'id' => 'advance_styling_single_product_addtocart_border_radius',
            'type' => 'dimensions',
            'output_variables' => true,
            'height'    => false,
            'title' => esc_html__( 'Add To Cart Border: Radius' , 'studentwp-core' ),
            'subtitle' => esc_html__( 'Add a custom border radius. px - em - %.' , 'studentwp-core' ),
        ),
        array(
            'id'     => 'section-end',
            'type'   => 'section',
            'indent' => false,
        ),
        array(
        'id' => 'section-start_advance_styling_single_product_tabs',
        'type' => 'section',
        'title' => esc_html__('SINGLE PRODUCT: TABS', 'studentwp-core'),
        'indent' => true 
        ),
        
        array(
            'id' => 'advance_styling_single_product_tabs_border_color',
            'type' => 'color',
            'title' => esc_html__('Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            'output'    => array('border-color' => '.woocommerce ul.products li.product .button')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_text_hover_color',
            'type' => 'color',
            'title' => esc_html__('Text Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_active_text_color',
            'type' => 'color',
            'title' => esc_html__('Active Text Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_active_text_borders_color',
            'type' => 'color',
            'title' => esc_html__('Active Text Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_description_title_color',
            'type' => 'color',
            'title' => esc_html__('Product Description: Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_tabs_description_color',
            'type' => 'color',
            'title' => esc_html__('Product Description: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),

        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_advance_styling_single_product_account',
        'type' => 'section',
        'title' => esc_html__('ACCOUNT', 'studentwp-core'),
        'indent' => true 
        ),
        
        array(
            'id' => 'advance_styling_single_product_account_links_color',
            'type' => 'color',
            'title' => esc_html__('Login/Register Links: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_navigation_borders_color',
            'type' => 'color',
            'title' => esc_html__('Navigation: Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_ccount_navigation_icons_color',
            'type' => 'color',
            'title' => esc_html__('Navigation: Icons Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_navigation_links_color',
            'type' => 'color',
            'title' => esc_html__('Navigation: Links Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_navigation_links_hover_color',
            'type' => 'color',
            'title' => esc_html__('Navigation: Links Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_title_color',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Title Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_title_border_color',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Title Border Bottom Colors', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),

        array(
            'id' => 'advance_styling_single_product_account_address_box_content_color',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Content Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_button_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Button Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_button_hover_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Button Background: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_button_color',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Button color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_single_product_account_address_box_button_hover_color',
            'type' => 'color',
            'title' => esc_html__('Addresses: Box Button color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),


        array(
        'id' => 'section_start_advance_styling_cart',
        'type' => 'section',
        'title' => esc_html__('CART', 'studentwp-core'),
        'indent' => true 
        ),
        
        array(
            'id' => 'advance_styling_cart_borders_color',
            'type' => 'color',
            'title' => esc_html__('Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_cart_navigation_head_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Head Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_cart_head_title_color',
            'type' => 'color',
            'title' => esc_html__('Head Titles Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_cart_total_tables_titles-color',
            'type' => 'color',
            'title' => esc_html__('Cart Totals Table: Titles Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_cart_remove_button_color',
            'type' => 'color',
            'title' => esc_html__('Remove Button Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_cart_remove_button_hover_color',
            'type' => 'color',
            'title' => esc_html__('Remove Button Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),

        array(
        'id' => 'section_start_advance_styling_checkout',
        'type' => 'section',
        'title' => esc_html__('CHECKOUT', 'studentwp-core'),
        'indent' => true 
        ),
        
        array(
            'id' => 'advance_styling_checkout_notices_borders_color',
            'type' => 'color',
            'title' => esc_html__('Notices: Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_notices_icon_color',
            'type' => 'color',
            'title' => esc_html__('Notices: Icon Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_notice_color',
            'type' => 'color',
            'title' => esc_html__('Notices: Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_notice_link_color',
            'type' => 'color',
            'title' => esc_html__('Notices: Link Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_notice_link_hover_color',
            'type' => 'color',
            'title' => esc_html__('Notices: Link Color: Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_notice_form_border_color',
            'type' => 'color',
            'title' => esc_html__('Notices Form: Border Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_title_color',
            'type' => 'color',
            'title' => esc_html__('Titles Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_title_border_color',
            'type' => 'color',
            'title' => esc_html__('Titles Border Bottom Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_title_main_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Table Main Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_tables_title_color',
            'type' => 'color',
            'title' => esc_html__('Table Titles Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_tables_border_color',
            'type' => 'color',
            'title' => esc_html__('Table Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_payment_methods_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Payment Methods Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_payment_methods_border_color',
            'type' => 'color',
            'title' => esc_html__('Payment Methods Borders Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('border-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_payment_box_bgcolor',
            'type' => 'color',
            'title' => esc_html__('Payment Box Background', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('background-color' => '')            
        ),
        array(
            'id' => 'advance_styling_checkout_payment_box_color',
            'type' => 'color',
            'title' => esc_html__('Payment Box Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '#0e1951',
            // 'output'    => array('color' => '')            
        ),
        array(
            'id'     => 'section_end',
            'type'   => 'section',
            'indent' => false,
        ),




    ),
) );
