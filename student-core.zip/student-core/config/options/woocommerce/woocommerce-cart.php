<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Cart', 'studentwp-core' ),
    'id'         => 'woocommerce_cart',
    'desc'       => 'For some options, you must save and refresh your live site to preview changes.',
    'subsection' =>true,
    'fields'     => array(
 
        array(
            'id'       => 'woocommerce_distraction_free_cart',
            'type'     => 'switch',
            'title'    => esc_html__('DISTRACTION FREE CART', 'studentwp-core'), 
            'default' => ''
        ),
        array(
            'id'       => 'cart_cross_sells_counts',
            'type'     => 'text',
            'title'    => esc_html__('Cart: Cross-Sells Count'), 
                'desc'    => esc_html__('Only Number', 
                'studentwp-core'),
            'default' => ''
        ),
        array(
            'id'       => 'cart_cross_sells_column',
            'type'     => 'text',
            'title'    => esc_html__('Cart: Cross-Sells Columns'), 
                'desc'    => esc_html__('Only Number', 
                'studentwp-core'),
            'default' => ''
        ),

    ),
) );
?>