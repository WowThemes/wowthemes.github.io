<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Product Catalog', 'studentwp-core' ),
    'id'         => 'woocommerce_product_catalog',
    'desc'       => '',
    'subsection' =>true,
    'fields'     => array(
        array(
        'id'      => 'woocommerce_catalog_columns',
        'type'    => 'text',
        'title'   => esc_html__( 'Products per row', 'studentwp-core' ),
        'subtitle'    => esc_html__( 'How many products should be shown per row?', 'studentwp-core' ),
        'default' => '',
    ), 
        array(
            'id'       => 'woocommerce_catalog_rows',
            'type'     => 'text',
            'title'    => esc_html__('Rows per page', 'studentwp-core'), 
            'subtitle'    => esc_html__('Rows per page', 'studentwp-core'), 
            'default' => ''
        ),

    ),
) );
?>