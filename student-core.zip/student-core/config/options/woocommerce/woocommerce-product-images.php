<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Product Images', 'studentwp-core' ),
    'id'         => 'woocommerce_product_images',
    'desc'       => 'After publishing your changes, new image sizes will be generated automatically.',
    'subsection' =>true,
    'fields'     => array(
    array(
            'id'       => 'woocommerce_single_image_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Main image width', 'studentwp-core'),
             'subtitle'    => esc_html__('Image size used for the main image on single product pages. These images will remain uncropped.', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => []
        ),
    array(
            'id'       => 'woocommerce_thumbnail_image_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Thumbnail width', 'studentwp-core'),
             'subtitle'    => esc_html__('Image size used for products in the catalog.', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => []
        ),
    array(
        'id' => 'section_start_product_images_thumbnail-cropping',
        'type' => 'section',
        'title' => esc_html__('Thumbnail cropping', 'studentwp-core'),
        'indent' => true 
        ),
        array(
            'id'       => 'woocommerce_thumbnail_cropping',
            'type'     => 'radio',
            'title'    => esc_html__('Thumbnail cropping', 'studentwp-core'), 
            'desc'    => esc_html__('Images will be cropped into a square', 'studentwp-core'),
            'options'  => array(
                '1:1' => ' 1:1', 
                'custom' => 'Custom', 
                'uncropped' => ' Uncropped', 
            ),
            'default' => '1:1'
        ),
        array(
            'id'       => 'woocommerce_thumbnail_cropping_custom_width',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Custom Width (px)', 'studentwp-core'),
            'width' => true,
            'height'    => false,
            'output'    => ['']
        ),
        array(
            'id'       => 'woocommerce_thumbnail_cropping_custom_height',
            'type'     => 'dimensions',
            'units'    => array('em','px','%'),
            'title'    => esc_html__('Custom Height (px)', 'studentwp-core'),
            'width' => false,
            'height'    => true,
            'output'    => ['']
        ),
         array(
            'id'     => 'section-end',
            'type'   => 'section',
            'indent' => false,
        ),

    ),
) );
?>