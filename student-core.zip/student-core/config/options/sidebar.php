<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Sidebar', 'studentwp-core' ),
    'id'         => 'sidebar',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection' => false,
    'fields'     => array(
        array(
            'id' => 'custom_sidebar_section_start',
            'type' => 'section',
            'indent'    => true,
            'title' => esc_html__('Custom Sidebar', 'student-core'),
            'desc' => esc_html__('This section is used to create custom sidebar', 'student-core')
        ),
        array(
            'id' => 'custom_sidebar_name',
            'type' => 'multi_text',
            'title' => esc_html__('Dynamic Custom Sidebar', 'student-core'),
            'desc' => esc_html__('This section is used to create custom sidebar', 'student-core')
        ),
        array(
            'id' => 'custom_sidebar_section_end',
            'type' => 'section',
            'indent'    => false,
        ),
        array(
            'id' => 'sidebar_background',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => ''),
        ),
        array(
            'id' => 'sidebar_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
        array(
            'id'       => 'sidebar_heading_tag',
            'type'     => 'select',
            'title'    => esc_html__('Heading Tag','studentwp-core'),
            'options' => array(
                '1' => 'H1', 
                '2' => 'H2', 
                '3' => 'H3', 
                '4' => 'H4', 
                '5' => 'H5', 
                '6' => 'H6', 
                '7' => 'DIV', 
                '8' => 'span', 
                '9' => 'p',
            ), 
            'default' => '3'
        ),
        array(
            'id' => 'sidebar_widget_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Widget Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
        array(
            'id' => 'sidebar_widget_margin',
            'type' => 'spacing',
            'mode'=>'margin',
            'title' => esc_html__( 'Widget Margin' , 'studentwp-core' ),
            'desc' => esc_html__( 'Widget Margin' , 'studentwp-core' ),
        ),
        array(
            'id' => 'sidebar_widgets_background',
            'type' => 'color',
            'title' => esc_html__('Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => ''),
        ),
        array(
            'id' => 'sidebar_border_color',
            'type' => 'color',
            'title' => esc_html__('Titles Border Color', 'studentwp-core'),
            'compiler'  => true,  
        ),
        array(
            'id' => 'sidebar_title_margin_bottom',
            'type' => 'spacing',
            'mode'=>'margin',
            'title' => esc_html__('Titles Margin Bottom (px)', 'studentwp-core'),
            'compiler'  => true,  
        ),
    ),
) );
?>