<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Themes Icons', 'studentwp-core' ),
    'id'         => 'theme-icons',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
        'id'       => '404_layout',
        'type'     => 'select',
        'title'    => esc_html__('Select Icons', 'studentwp-core'),
        'subtitle'    => esc_html__('Choose icons you would like to use in the theme', 'studentwp-core'),
        'options'  => array(
            '1' => 'Simple Line Icons',
            '2' => 'Studentwp SVG Icons',
            '3' => 'Font Awesome Icons',
        ),
        'default'  => '1',
        ),
    array(
        'id'       => 'studentwp_svg_icons',
        'type'     => 'checkbox',
        'title'    => esc_html__(' DISABLE Studentwp SVG ICONS', 'studentwp-core'), 
        'default'  => '1'// 1 = on | 0 = off
    ),
    array(
            'id' => 'entries_icon',
            'type' => 'color',
            'title' => esc_html__(' Blog Entries Icons: Color', 'studentwp-core'),
            'compiler'  => true,
            
        ),
    array(
            'id' => 'post_icons',
            'type' => 'color',
            'title' => esc_html__(' Single Post Icons: Color', 'studentwp-core'),
            'compiler'  => true,
            
        ),  
    ),
) );
?>