<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Pagination', 'studentwp-core' ),
    'id'         => 'pagination',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(

   array(
        'id'       => 'pagination_align',
        'type'     => 'button_set',
        'title'    => esc_html__('Align','studentwp-core'),
         'default' => '1',
        'options' => array(
            '1' => 'LEFT', 
            '2' => 'RIGHT', 
            '3' => 'CENTER', 
         ), 
        'default' => '1'
    ),
   array(
            'id' => 'pagination_font_size',
            'type' => 'typography',
            'font-size' => true,
            'title' => esc_html__( 'Font Size (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Font Size (px)' , 'studentwp-core' ),
        ),
   array(
        'id'       => 'pagination_border_width',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Border Width (px)', 'studentwp-core'),
        'mode'  => [
            'width'    => true,
        ],
        'width' => true,
        'height'    => false,
    ),
     array(
            'id' => 'pagination_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
     array(
            'id' => 'pagination_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
      array(
            'id' => 'pagination_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
       array(
            'id' => 'pagination_color_hover',
            'type' => 'color',
            'title' => esc_html__('Color:Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'border_color',
            'type' => 'color',
            'title' => esc_html__('Border Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
       array(
            'id' => 'border_color_hover',
            'type' => 'color',
            'title' => esc_html__('Border Color:Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    ),
) );
?>