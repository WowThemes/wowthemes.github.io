<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General Options', 'studentwp-core' ),
    'id'         => 'general_options',
    'desc'       => '',
    'icon'       => 'el el-wrench',
));
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General Styling', 'studentwp-core' ),
    'id'         => 'general_styling',
    'desc'       => '',
    'subsection'       => true,
    'fields'     => array(
        array(
            'id'       => 'styling_option_location',
            'type'     => 'radio',
            'title'    => esc_html__('Styling Options Location', 'studentwp-core'), 
            'subtitle' => esc_html__('If you choose Custom File, a CSS file will be created in your uploads folder.', 'studentwp-core'),
            'options'  => array(
                'wp_head' => esc_html__('WP Head'), 
                'custom_file' => esc_html__('Custom File')
            ),
            'default' => '1'
        ),
        array(
            'id' => 'primary_color',
            'type' => 'color',
            'title' => esc_html__('Primary Color', 'studentwp-core'),
            'default' => '#6588fe',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'hover_primary_color',
            'type' => 'color',
            'title' => esc_html__('Hover Primary Color', 'studentwp-core'),
            'default' => '#0e1951',
            'compiler'  => true,
        ),
        array(
            'id' => 'main_border_color',
            'type' => 'color',
            'title' => esc_html__('Main Border Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
        array(
            'id' => 'site_background',
            'type' => 'color',
            'title' => esc_html__('Site Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
        array(
            'id'      => 'bg_image',
            'type'    => 'media',
            'title'   => esc_html__( 'Background Image', 'studentwp-core' ),
            'desc'    => esc_html__( 'Choose the background image', 'studentwp-core' ),
            ),
        array(
            'id' => 'links_color',
            'type' => 'color',
            'title' => esc_html__('Links Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
           ),
        array(
            'id' => 'links_hover_color',
            'type' => 'color',
            'title' => esc_html__('Hover Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
           ),
    ),
) );
?>