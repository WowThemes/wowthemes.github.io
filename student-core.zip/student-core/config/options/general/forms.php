<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Forms (Input - Textarea)', 'studentwp-core' ),
    'id'         => 'forms',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
            'id' => 'label_color',
            'type' => 'color',
            'title' => esc_html__('Label Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
            'id' => 'forms_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
    array(
            'id' => 'forms_font_size',
            'type' => 'typography',
            'font-size' => true,
            'title' => esc_html__( 'Font Size (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Font Size (px)' , 'studentwp-core' ),
        ),
     array(
            'id' => 'border_color',
            'type' => 'color',
            'title' => esc_html__('Border Color', 'studentwp-core'),
            'compiler'  => true,
             'default'  => '',
            // 'output'    => array('border-color' => '')
            
        ),
     array(
            'id' => 'border_color_focus',
            'type' => 'color',
            'title' => esc_html__(' Border Color:Focus', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '',
            // 'output'    => array('border-color' => '')
            
        ),
     array(
            'id' => 'froms_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),  
     array(
            'id' => 'froms_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '',
            
        ),  
    ),
) );
?>