<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'General Setting', 'studentwp-core' ),
    'id'         => 'general_setting',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
        'id'       => 'button-set-single',
        'type'     => 'button_set',
        'title'    => esc_html__('Layout Style','studentwp-core'),
         'default' => '1',
        'options' => array(
            '1' => 'WIDE', 
            '2' => 'BOXED', 
            '3' => 'SEPARATE'
         ), 
        'default' => '1'
    ),
    array(
        'id'       => 'general_maintain_container_width',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Main Container Width (px)', 'studentwp-core'),
        'mode'  => [
            'width'    => true,
        ],
        'width' => true,
        'height'    => false,
    ),
    array(
        'id'       => 'general_content_width',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Content Width (%)', 'studentwp-core'),
        'mode'  => [
            'width'    => true,
        ],
        'width' => true,
        'height'    => false,
    ),
    array(
        'id'       => 'general_sidebar_width',
        'type'     => 'dimensions',
        'units'    => array('em','px','%'),
        'title'    => esc_html__('Sidebar Width (%)', 'studentwp-core'),
        'mode'  => [
            'width'    => true,
        ],
        'width' => true,
        'height'    => false,
    ),
     array(
            'id' => 'general_sidebar_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
    array(
        'id'       => 'enable_schema_markup',
        'type'     => 'checkbox',
        'title'    => esc_html__('ENABLE SCHEMA MARKUP', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        'default'  => '1'// 1 = on | 0 = off
    ),
    array(
            'id'       => 'page_sidebar_layout',
            'type'     => 'image_select',
            'title'    => esc_html__( 'Layout', 'studentwp-core' ),
            'options'  => array(

                'left'  => array(
                    'alt' => esc_html__( 'Left sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/left.png',
                ),
                'full'  => array(
                    'alt' => esc_html__( 'Full width', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/full.png',
                ),
                'right' => array(
                    'alt' => esc_html__( 'Right sidebar', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/right.png',
                ),
            ),

            'default' => 'right',
        ),
    array(
        'id'       => 'mobile_sidebar_order',
        'type'     => 'select',
        'title'    => esc_html__('Mobile Sidebar Order', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'Sidebar/Content',
            '2' => 'Content/Sidebar'
        ),
        'default'  => '1',
    ),
    array(
        'id'       => 'source',
        'type'     => 'select',
        'title'    => esc_html__('Source', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'All Types Posts',
            '2' => 'Posts',
            '3' => 'Pages'
        ),
        'default'  => '1',
    ),
    array(
            'id'      => 'post_per_page',
            'type'    => 'number',
            'title'   => esc_html__( 'Search Posts Per Page', 'studentwp-core' ),
            'desc'    => esc_html__( '', 'studentwp-core' ),
            'default' => '1',
        ),
    array(
        'id'       => 'custom_sidebar',
        'type'     => 'checkbox',
        'title'    => esc_html__('Ccustom Sidebar', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        'default'  => '1'// 1 = on | 0 = off
    ),
    array(
        'id'      => 'twitter_username',
        'type'    => 'text',
        'title'   => esc_html__( 'Twitter Username', 'studentwp-core' ),
        'desc'    => esc_html__( '', 'studentwp-core' ),
        'default' => '',
    ), 
    array(
        'id'      => 'facebook_page_url',
        'type'    => 'text',
        'title'   => esc_html__( 'Facebook Page URL', 'studentwp-core' ),
        'desc'    => esc_html__( '', 'studentwp-core' ),
        'default' => '',
    ), 
    array(
        'id'      => 'facebook_app_id',
        'type'    => 'text',
        'title'   => esc_html__( 'Facebook App ID', 'studentwp-core' ),
        'desc'    => esc_html__( '', 'studentwp-core' ),
        'default' => '',
    ), 
      
    array(
        'id'       => 'enable_opengraph',
        'type'     => 'checkbox',
        'title'    => esc_html__('ENABLE OPENGRAPH', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        'default'  => '1'// 1 = on | 0 = off
    ),
    ),
) );
?>