<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Page Title', 'studentwp-core' ),
    'id'         => 'page-title',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
        'id'       => 'visibility',
        'type'     => 'select',
        'title'    => esc_html__('Visibility', 'studentwp-core'), 
        'options'  => array(
            '1' => 'Show on All Devices',
            '2' => 'Hide on Tablet',
            '3' => 'Hide on Mobile',
            '4' => 'Hide on Tablet & Mobile',
            '5' => 'Hide on All Devices'
        ),
        'default'  => '1',
    ),
     array(
        'id'       => 'heading_tag',
        'type'     => 'select',
        'title'    => esc_html__('Heading Tag', 'studentwp-core'), 
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'H1',
            '2' => 'H2',
            '3' => 'H3',
            '4' => 'H4',
            '5' => 'H5',
            '6' => 'H6',
            '7' => 'div',
            '8' => 'span',
            '9' => 'p'
        ),
        'default'  => '1',
    ),
    array(
        'id'       => 'style',
        'type'     => 'select',
        'title'    => esc_html__('Style', 'studentwp-core'), 
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'Default',
            '2' => 'Centered',
            '3' => 'Centered Minimal',
            '4' => 'Background Image',
            '5' => 'Hidden',
        ),
        'default'  => '1',
    ),
    array(
            'id' => 'page_title_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
     array(
            'id' => 'page_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
      array(
            'id' => 'page_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    
    array(
        'id'       => 'enable_breadcrumbs',
        'type'     => 'checkbox',
        'title'    => esc_html__('ENABLE BREADCRUMBS', 'studentwp-core'), 
        'default'  => '1'// 1 = on | 0 = off
    ),
    array(
        'id'       => 'show_item_title',
        'type'     => 'checkbox',
        'title'    => esc_html__('show Item Title', 'studentwp-core'), 
        'default'  => '1'// 1 = on | 0 = off
    ),
   
    array(
        'id'       => 'position',
        'type'     => 'select',
        'title'    => esc_html__('Position', 'studentwp-core'), 
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'Under Title',
            '2' => 'Absolute Right',  
        ),
        'default'  => '1',
    ),
    array(
        'id'      => 'breadcrumb_seperator',
        'type'    => 'text',
        'title'   => esc_html__( 'Breadcrumb Seperator', 'studentwp-core' ),
        'default' => '',
    ), 
    array(
        'id'       => 'home_item',
        'type'     => 'button_set',
        'title'    => esc_html__('Home Item','studentwp-core'),
         'default' => '1',
        'options' => array(
            '1' => 'ICON', 
            '2' => 'TEXT', 
         ), 
        'default' => '1'
    ),
    array(
        'id'      => 'translation_homepage',
        'type'    => 'text',
        'title'   => esc_html__( 'Translation for Homepage', 'studentwp-core' ),
        'default' => '',
    ),
    array(
        'id'      => 'translation_404"',
        'type'    => 'text',
        'title'   => esc_html__( 'Translation for "404 Not Found"', 'studentwp-core' ),
        'default' => '',
    ),
    array(
        'id'      => 'translation_search_result"',
        'type'    => 'text',
        'title'   => esc_html__( 'Translation for "Search results for"', 'studentwp-core' ),
        'default' => '',
    ),
     array(
        'id'       => 'posts_taxonomy',
        'type'     => 'select',
        'title'    => esc_html__('Posts Taxonomy', 'studentwp-core'), 
        // Must provide key => value pairs for select options
        'options'  => array(
            '1' => 'None', 
            '2' => 'Category',
            '3' => 'Tag',  
            '4' => 'Blog Page',  
        ),
        'default'  => '1',
    ),
    array(
        'id'       => 'products_taxonomy',
        'type'     => 'select',
        'title'    => esc_html__('Products Taxonomy', 'studentwp-core'), 
        // Must provide key => value pairs for select options
        'options'  => array(
           '1' => 'None', 
            '2' => 'Category',
            '3' => 'Tag',  
            '4' => 'Shop Page', 
        ),
        'default'  => '1',
    ),
    array(
            'id' => 'text_color',
            'type' => 'color',
            'title' => esc_html__('Text Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
            'id' => 'separator_color',
            'type' => 'color',
            'title' => esc_html__('Separator Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
            'id' => 'link_color',
            'type' => 'color',
            'title' => esc_html__('Link Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    array(
            'id' => 'link_color_hover',
            'type' => 'color',
            'title' => esc_html__('Link Color:Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    ),
) );
?>