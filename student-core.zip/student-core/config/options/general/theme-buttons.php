<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Themes Buttons', 'studentwp-core' ),
    'id'         => 'theme-buttons',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
            'id' => 'themes_button_padding',
            'type' => 'spacing',
            'title' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Padding(px)' , 'studentwp-core' ),
        ),
    array(
            'id' => 'theme_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
     array(
            'id' => 'themes_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
     array(
            'id' => 'themes_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'compiler'  => true,
             'default'  => '',
            // 'output'    => array('border-color' => '')
            
        ), 
     array(
            'id' => 'themes_hover_color',
            'type' => 'color',
            'title' => esc_html__('Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => '',
            
        ),  
    ),
) );
?>