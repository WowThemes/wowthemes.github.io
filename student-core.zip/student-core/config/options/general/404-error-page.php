<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( '404 Error Page', 'studentwp-core' ),
    'id'         => '404-error-page',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
    array(
            'id'       => 'enable_404_page',
            'type'     => 'switch',
            'title'    => esc_html__( 'Blank Page', 'studentwp-core' ),
            'desc'     => esc_html__('Enable this option to remove all the elements and have full control of the 404 error page '),
            'default'   => true,
            'required' => [ '404_source_type', '=', 'd' ],
        ), 
        array(
            'id'       => 'page_layout',
            'type'     => 'image_select',
            'title'    => esc_html__( 'Layout', 'studentwp-core' ),
            'options'  => array(
                'full'  => array(
                    'alt' => esc_html__( 'Full width', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/full.png',
                ),
                '100% full width' => array(
                    'alt' => esc_html__( ' 100% full', 'studentwp-core' ),
                    'img' => get_template_directory_uri() . '/assets/images/fs.png',
                ),
            ),

            'default' => 'full',
        ), 
        array(
        'id'       => '404_layout',
        'type'     => 'select',
        'title'    => esc_html__('<b>Select Template</b>', 'studentwp-core'),
        'subtitle'    => __('<br>Choose a template created in Theme Panel > My Library.', 'studentwp-core'),
        'desc'     => esc_html__(''),
        'options'  => array(
            '1' => '-select-',
        ),
        'default'  => '1',
        ),
    ),
) );
?>