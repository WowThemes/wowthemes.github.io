<?php
Redux::setSection( $opt_name, array(
    'title'      => esc_html__( 'Scroll To Top', 'studentwp-core' ),
    'id'         => 'scroll_to_top',
    'desc'       => '',
    'icon'       => 'el el-wrench',
    'subsection'       => true,
    'fields'     => array(
   array(
        'id'       => 'scroll_top',
        'type'     => 'checkbox',
        'title'    => esc_html__('SCROLL UP BUTTON', 'studentwp-core'), 
        'desc'     => esc_html__(''),
        'default'  => '1'// 1 = on | 0 = off
    ),
   array(
        'id'       => 'scroll_position',
        'type'     => 'button_set',
        'title'    => esc_html__('Position','studentwp-core'),
        'options' => array(
            '1' => 'LEFT', 
            '2' => 'RIGHT', 
         ), 
        'default' => '1'
    ),
   array(
            'id' => 'scroll_bottom_position',
            'type' => 'range',
            'title' => esc_html__( 'Bottom Position (px)' , 'studentwp-core' ),
            'desc' => esc_html__( 'Bottom Position (px)' , 'studentwp-core' ),
        ),
     array(
            'id' => 'scroll_background',
            'type' => 'color',
            'title' => esc_html__(' Background Color', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
     array(
            'id' => 'scroll_background_hover',
            'type' => 'color',
            'title' => esc_html__(' Background Color:Hover', 'studentwp-core'),
            'compiler'  => true,
            'default'  => 'transparent',
            // 'output'    => array('background-color' => '')
            
        ),
      array(
            'id' => 'scroll_color',
            'type' => 'color',
            'title' => esc_html__('Color', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
       array(
            'id' => 'scroll_color_hover',
            'type' => 'color',
            'title' => esc_html__('Color:Hover', 'studentwp-core'),
            'default' => '',
            'compiler'  => true,
            
        ),
    ),
) );
?>