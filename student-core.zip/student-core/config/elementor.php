<?php

return [
	'modules'	=> [
		StudentCore\Elementor\Modules\Form\Init::class
	],
	'widgets'	=> [
		StudentCore\Elementor\Widgets\WpForms::class,
		StudentCore\Elementor\Widgets\IconBox::class,
		StudentCore\Elementor\Widgets\Courses::class,
		StudentCore\Elementor\Widgets\HonorCollege::class,
		StudentCore\Elementor\Widgets\Testimonials::class,
		StudentCore\Elementor\Widgets\Blog::class,
		StudentCore\Elementor\Widgets\Events::class,
		StudentCore\Elementor\Widgets\Gallery::class,
		StudentCore\Elementor\Widgets\Subscribe::class,
		StudentCore\Elementor\Widgets\AroundUniversity::class,
		StudentCore\Elementor\Widgets\EducationServices::class,
		StudentCore\Elementor\Widgets\MeetOurExpert::class,
		StudentCore\Elementor\Widgets\ProductDetails::class,
		StudentCore\Elementor\Widgets\AcademicTabs::class,
		StudentCore\Elementor\Widgets\PopularCourses::class,
		StudentCore\Elementor\Widgets\StudentLearning::class,
		StudentCore\Elementor\Widgets\RecentNews::class,
		StudentCore\Elementor\Widgets\CoursesListView::class,
		StudentCore\Elementor\Widgets\CoursesGridView::class,
		StudentCore\Elementor\Widgets\PricingPlans::class,
		StudentCore\Elementor\Widgets\InstructorDetails::class,
		StudentCore\Elementor\Widgets\Instructor::class,
		StudentCore\Elementor\Widgets\InstructorColumnTwo::class,
		StudentCore\Elementor\Widgets\InstructorList::class,
		StudentCore\Elementor\Widgets\ContactUs2::class,
		StudentCore\Elementor\Widgets\ShopList::class,
		StudentCore\Elementor\Widgets\ShopListGrid::class,
		StudentCore\Elementor\Widgets\Heading::class,
		StudentCore\Elementor\Widgets\AdvanceSearch::class,
		StudentCore\Elementor\Widgets\NavMenu::class,
		(!class_exists('ElementorPro\Base\Base_Widget')) ? StudentCore\Elementor\Widgets\Template::class : ''
	]
];