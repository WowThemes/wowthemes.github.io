<?php

namespace MuseumCore\Elementor\Classes\Controls;

class ControlsManager
{
	const AJAXSELECT2 = 'ajaxselect2';
}