<?php

Redux::setSection( $opt_name, array(

    'title'         => esc_html__( 'Typography Settings', 'museum-core' ),
    'id'            => 'typography_setting',
    'desc'          => '',
    'icon'          => 'el el-edit'
) );