<?php
/*
Plugin Name: Theme Support Student
Plugin URI: http://themeforest.net/user/wptech
Description: This plugin is compatible with all wptech wordpress themes. 
Author: WP Tech
Author URI: http://wptech.co
Version: 1.1.4
Text Domain: theme_support_student
*/


add_action( 'plugins_loaded', '_wow_themes_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */

if ( ! defined( 'TSS_PLUGIN_PATH' ) ) {
	define( 'TSS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TSS_PLUGIN_URL' ) ) {
	define( 'TSS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
require_once TSS_PLUGIN_PATH . '/includes/Loader.php';

if( ! class_exists('Redux_Framework_Plugin')) {
	require_once TSS_PLUGIN_PATH .'Redux/redux-framework.php';
	\Redux::setExtensions( 'studentwp_options', TSS_PLUGIN_PATH . 'ReduxExtensions' );
}

/**
 * [studentwp_put_content description]
 *
 * @param  [type] $filename [description]
 * @param  [type] $data     [description]
 * @return [type]           [description]
 */
function studentwp_put_content( $filename, $data) {

	return file_put_contents($filename, $data);
}

/**
 * [studentwp_fontawesome_plug description]
 * @return [type] [description]
 */
function studentwp_fontawesome_plug() {
    $subject = wp_remote_get(TSS_PLUGIN_URL . 'assets/data/font-awesome-4-7-0.json');
    $subject = studentwp()->get($subject, 'body');
    return json_decode($subject, true);
}

function _wow_themes_load_textdomain() {

	load_plugin_textdomain( 'theme_support_builder', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}
