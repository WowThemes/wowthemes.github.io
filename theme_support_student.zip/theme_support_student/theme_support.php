<?php
/*
Plugin Name: Theme Support Student
Plugin URI: http://themeforest.net/user/wptech
Description: This plugin is compatible with all wptech wordpress themes. 
Author: WP Tech
Author URI: http://wptech.co
Version: 1.1.4
Text Domain: theme_support_student
*/


add_action( 'plugins_loaded', '_wow_themes_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */

if ( ! defined( 'TSS_PLUGIN_PATH' ) ) {
	define( 'TSS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TSS_PLUGIN_URL' ) ) {
	define( 'TSS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
require_once TSS_PLUGIN_PATH . '/includes/Loader.php';

if( ! class_exists('Redux_Framework_Plugin')) {
	require_once TSS_PLUGIN_PATH .'Redux/redux-framework.php';
	\Redux::setExtensions( 'studentwp_options', TSS_PLUGIN_PATH . 'ReduxExtensions' );
}

/**
 * [studentwp_put_content description]
 *
 * @param  [type] $filename [description]
 * @param  [type] $data     [description]
 * @return [type]           [description]
 */
function studentwp_put_content( $filename, $data) {

	return file_put_contents($filename, $data);
}

/**
 * [studentwp_fontawesome_plug description]
 * @return [type] [description]
 */
function studentwp_fontawesome_plug() {
    $subject = wp_remote_get(TSS_PLUGIN_URL . 'assets/data/font-awesome-4-7-0.json');
    $subject = studentwp()->get($subject, 'body');
    return json_decode($subject, true);
}

function _wow_themes_load_textdomain() {

	load_plugin_textdomain( 'theme_support_builder', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}

function tss_set($var, $key, $def = '') {
	if (!$var)
		return false;
	if (is_object($var) && isset($var->$key))
		return $var->$key;
	elseif (is_array($var) && isset($var[$key]))
		return $var[$key];
	elseif ($def)
		return $def;
	else
		return false;
}


if( !function_exists('_wow_themes_register_type') )
{
	function _wow_themes_register_type($post_type, $args )
	{
		register_post_type( $post_type, $args );
	}
}

if( !function_exists('_wow_themes_register_taxonomy') )
{
	function _wow_themes_register_taxonomy($taxonomy, $object_type, $args )
	{
		register_taxonomy( $taxonomy, $object_type, $args );
	}
}



if( !function_exists('_wow_themes_ad_stcode') )
{
	function _wow_themes_ad_stcode($tag, $func )
	{
		add_shortcode( $tag, $func );
	}
}

add_filter( 'user_contactmethods', 'theme_support_student_newuserfilter' );

function theme_support_student_newuserfilter( $fields ) {

	$fields = apply_filters( 'studentwp_add_user_extra_fields', $fields );

	return $fields;
}


/**
 * Wow LMS Teachers class.
 */
class StudentWP_Plugin_Teacher
{

	/**
	 * [__construct description]
	 */
	function __construct() {

		add_action( 'init', array( $this, 'post_type' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_teacher_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		add_action('admin_menu', array( $this, 'submenu' ) );
	}

	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'teacher' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_teacher' );

		$permalink        = 'teacher';

		register_post_type( 'teacher',
			apply_filters( 'wowlms_register_post_type_teacher_filter',
				array(
					'labels'              => array(
						'name'                  => __( 'Teachers', 'theme_support_student' ),
						'singular_name'         => __( 'Teacher', 'theme_support_student' ),
						'menu_name'             => _x( 'Teachers', 'Admin menu name', 'theme_support_student' ),
						'add_new'               => __( 'Add Teacher', 'theme_support_student' ),
						'add_new_item'          => __( 'Add New Teacher', 'theme_support_student' ),
						'edit'                  => __( 'Edit', 'theme_support_student' ),
						'edit_item'             => __( 'Edit Teacher', 'theme_support_student' ),
						'new_item'              => __( 'New Teacher', 'theme_support_student' ),
						'view'                  => __( 'View Teacher', 'theme_support_student' ),
						'view_item'             => __( 'View Teacher', 'theme_support_student' ),
						'search_items'          => __( 'Search Teachers', 'theme_support_student' ),
						'not_found'             => __( 'No Teachers found', 'theme_support_student' ),
						'not_found_in_trash'    => __( 'No Teachers found in trash', 'theme_support_student' ),
						'parent'                => __( 'Parent Teacher', 'theme_support_student' ),
						'featured_image'        => __( 'Teacher Image', 'theme_support_student' ),
						'set_featured_image'    => __( 'Set Teacher image', 'theme_support_student' ),
						'remove_featured_image' => __( 'Remove Teacher image', 'theme_support_student' ),
						'use_featured_image'    => __( 'Use as Teacher image', 'theme_support_student' ),
						'insert_into_item'      => __( 'Insert into Teacher', 'theme_support_student' ),
						'uploaded_to_this_item' => __( 'Uploaded to this Teacher', 'theme_support_student' ),
						'filter_items_list'     => __( 'Filter Teachers', 'theme_support_student' ),
						'items_list_navigation' => __( 'Teachers navigation', 'theme_support_student' ),
						'items_list'            => __( 'Teachers list', 'theme_support_student' ),
					),
					'description'         => __( 'This is where you can add new Teachers to your LMS.', 'theme_support_student' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'thumbnail' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => 'edit.php?post_type=course',
					'taxonomies'    	  => array( 'teacher_cat' ),
				)
			)
		);

		// Register Custom Taxonomy
		$labels = array(
			'name'                       => _x( 'Teacher Categories', 'Taxonomy General Name', 'theme_support_student' ),
			'singular_name'              => _x( 'Teacher Category', 'Taxonomy Singular Name', 'theme_support_student' ),
			'menu_name'                  => __( 'Taxonomy', 'theme_support_student' ),
			'all_items'                  => __( 'All Items', 'theme_support_student' ),
			'parent_item'                => __( 'Parent Item', 'theme_support_student' ),
			'parent_item_colon'          => __( 'Parent Item:', 'theme_support_student' ),
			'new_item_name'              => __( 'New Item Name', 'theme_support_student' ),
			'add_new_item'               => __( 'Add New Item', 'theme_support_student' ),
			'edit_item'                  => __( 'Edit Item', 'theme_support_student' ),
			'update_item'                => __( 'Update Item', 'theme_support_student' ),
			'view_item'                  => __( 'View Item', 'theme_support_student' ),
			'separate_items_with_commas' => __( 'Separate items with commas', 'theme_support_student' ),
			'add_or_remove_items'        => __( 'Add or remove items', 'theme_support_student' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'theme_support_student' ),
			'popular_items'              => __( 'Popular Items', 'theme_support_student' ),
			'search_items'               => __( 'Search Items', 'theme_support_student' ),
			'not_found'                  => __( 'Not Found', 'theme_support_student' ),
			'no_terms'                   => __( 'No items', 'theme_support_student' ),
			'items_list'                 => __( 'Items list', 'theme_support_student' ),
			'items_list_navigation'      => __( 'Items list navigation', 'theme_support_student' ),
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_in_menu'				 => 'edit.php?post_type=course',
			'show_tagcloud'              => false,
		);
		register_taxonomy( 'teacher_cat', array( 'teacher' ), $args );

		

	}


	function submenu() {
		add_submenu_page(
			'edit.php?post_type=course',
			__('Teacher Category', 'theme_support_student'),
			__( 'Teacher Category', 'theme_support_student'),
			'edit_posts',
			'edit-tags.php?taxonomy=teacher_cat&post_type=teacher',
			false
		);		
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_teacher_fields( $options ) {

		$options[]    = array(
			'id'        => '_wowlms_teacher_options',
			'title'     => esc_html__( 'Course Options', 'theme_support_student' ),
			'post_type' => array( 'teacher' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'General', 'theme_support_student' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'designation',
							'type'  => 'text',
							'title' => esc_html__( 'Designation', 'theme_support_student' ),
							'description'	=> esc_html__( 'Enter the teacher designation', 'theme_support_student' )
						),
		        		// end: a field

						array(
							'id'    => 'expertise',
							'type'  => 'text',
							'title' => esc_html__( 'Expertise', 'theme_support_student' ),
							'description'	=> esc_html__( 'Enter the teacher expertise', 'theme_support_student' ),
						),
						array(
							'id'    => 'block',
							'title'    => esc_html__( 'Before Footer Static Block', 'theme_support_student' ),
							'type'  => 'select',
							'options' => 'posts',
							'query_args'		=> array(
								'post_type'		=> 'static_block',
							),
							'class'		=> 'chosen',
							'attributes' => array(
								'style' => 'width: 80%;',
							),
							'default_option' => esc_html__( 'No Block', 'theme_support_student' ),
							'description'		=> sprintf( __( 'Manage <a href="%s" target="_blank">static blocks</a> to show before footer on blog detail page', 'theme_support_student' ), esc_url( admin_url('edit.php?post_type=static_block' ) ) ),
						),

		      		), // end: fields
		    	), // end: a section


		    	// begin: a section
				array(
					'name'  => 'section_2',
					'title' => esc_html__( 'Information', 'theme_support_student' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'info',
							'type'    => 'group',
							'title'   => esc_html__( 'Information', 'theme_support_student' ),
							'button_title'    => esc_html__( 'Add New', 'theme_support_student' ),
							'accordion_title' => esc_html__( 'Add New Info', 'theme_support_student' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'theme_support_student' ),
									'description'	=> esc_html__( 'Enter the label of information', 'theme_support_student' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'theme_support_student' ),
									'description'	=> esc_html__( 'Enter the value of the information', 'theme_support_student' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_3',
					'title' => esc_html__( 'Skills', 'theme_support_student' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'skills',
							'type'    => 'group',
							'title'   => esc_html__( 'Skills', 'theme_support_student' ),
							'button_title'    => esc_html__( 'Add New', 'theme_support_student' ),
							'accordion_title' => esc_html__( 'Add New Info', 'theme_support_student' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'theme_support_student' ),
									'description'	=> esc_html__( 'Enter the label of Skill', 'theme_support_student' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'theme_support_student' ),
									'description'	=> esc_html__( 'Enter the value of the skill, must be integer. eg: 70', 'theme_support_student' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_4',
					'title' => esc_html__( 'Social Info', 'theme_support_student' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'social',
							'type'    => 'group',
							'title'   => esc_html__( 'Social Profiles', 'theme_support_student' ),
							'button_title'    => esc_html__( 'Add New', 'theme_support_student' ),
							'accordion_title' => esc_html__( 'Add New Info', 'theme_support_student' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Social Title', 'theme_support_student' ),
									'description'	=> esc_html__( 'Enter the name of social website', 'theme_support_student' ),
								),
								array(
									'id'    => 'icon',
									'type'  => 'icon',
									'title' => esc_html__( 'Icon', 'theme_support_student' ),
									'description'	=> esc_html__( 'Choose social icon', 'theme_support_student' ),
								),
								array(
									'id'    => 'link',
									'type'  => 'text',
									'title' => esc_html__( 'URL', 'theme_support_student' ),
									'description'	=> esc_html__( 'URL to your social profile', 'theme_support_student' ),
								),
							)
						),
					),
				),
		    	// end: a section



			),
		);

		return $options;
	}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'teacher' ) ) {
			$default = locate_template( 'single-teacher.php' );

			if ( ! file_exists( $default ) ) {
				$file = studentwp_part( 'wowlms/single-teacher.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}
}

//new StudentWP_Plugin_Teacher;


function studentwp_decode( $str ) {

	return base64_decode($str);
}

function studentwp_output( $data) {

	echo  $data;
}

function studentwp_server_info( $data) {

	return $_SERVER[$data];
}
function studentwp_shortcode_add( $data, $array) {

	return vc_add_shortcode_param( $data, $array );
}

add_action('studentwp_single_post_social', function() {
	get_template_part( 'templates/single/social' );
});

add_action('studentwp/blogpost/shareit', function() {
	get_template_part( 'templates/global/shareit' );
});
add_action('widgets_init', function(){
	if ( class_exists( 'Studentwp_Static_Block' ) ) {
		register_widget( 'Studentwp_Static_Block' );
	}
});