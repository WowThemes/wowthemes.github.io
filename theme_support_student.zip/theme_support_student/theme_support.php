<?php
/*
Plugin Name: Theme Support Student
Plugin URI: http://themeforest.net/user/wptech
Description: This plugin is compatible with all wptech wordpress themes. 
Author: WP Tech
Author URI: http://wptech.co
Version: 1.1.4
Text Domain: theme_support_student
*/


add_action( 'plugins_loaded', '_wow_themes_load_textdomain' );
/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 */
function _wow_themes_load_textdomain() {

	load_plugin_textdomain( 'theme_support_builder', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}
function tss_set($var, $key, $def = '') {
	if (!$var)
		return false;
	if (is_object($var) && isset($var->$key))
		return $var->$key;
	elseif (is_array($var) && isset($var[$key]))
		return $var[$key];
	elseif ($def)
		return $def;
	else
		return false;
}

if ( ! defined( 'TSS_PLUGIN_PATH' ) ) {
	define( 'TSS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'TSS_PLUGIN_URL' ) ) {
	define( 'TSS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
}
require_once TSS_PLUGIN_PATH . '/includes/loader.php';
if( !function_exists('_wow_themes_register_type') )
{
	function _wow_themes_register_type($post_type, $args )
	{
		register_post_type( $post_type, $args );
	}
}

if( !function_exists('_wow_themes_register_taxonomy') )
{
	function _wow_themes_register_taxonomy($taxonomy, $object_type, $args )
	{
		register_taxonomy( $taxonomy, $object_type, $args );
	}
}



if( !function_exists('_wow_themes_ad_stcode') )
{
	function _wow_themes_ad_stcode($tag, $func )
	{
		add_shortcode( $tag, $func );
	}
}

add_filter( 'user_contactmethods', 'theme_support_student_newuserfilter' );

function theme_support_student_newuserfilter( $fields ) {

	$fields = apply_filters( 'studentwp_add_user_extra_fields', $fields );

	return $fields;
}


/**
 * Wow LMS Teachers class.
 */
class StudentWP_Plugin_Teacher
{

	/**
	 * [__construct description]
	 */
	function __construct() {

		add_action( 'init', array( $this, 'post_type' ) );

		add_filter( 'cs_metabox_options', array( $this, 'cs_teacher_fields' ) );

		add_filter( 'template_include', array( $this, 'locate_template' ), 99 );

		add_action('admin_menu', array( $this, 'submenu' ) );
	}

	/**
	 * [lesson description]
	 *
	 * @return [type] [description]
	 */
	function post_type() {

		if ( post_type_exists( 'teacher' ) ) {
			return;
		}

		do_action( 'wowlms_register_post_type_teacher' );

		$permalink        = 'teacher';

		register_post_type( 'teacher',
			apply_filters( 'wowlms_register_post_type_teacher_filter',
				array(
					'labels'              => array(
						'name'                  => __( 'Teachers', 'wow-lms' ),
						'singular_name'         => __( 'Teacher', 'wow-lms' ),
						'menu_name'             => _x( 'Teachers', 'Admin menu name', 'wow-lms' ),
						'add_new'               => __( 'Add Teacher', 'wow-lms' ),
						'add_new_item'          => __( 'Add New Teacher', 'wow-lms' ),
						'edit'                  => __( 'Edit', 'wow-lms' ),
						'edit_item'             => __( 'Edit Teacher', 'wow-lms' ),
						'new_item'              => __( 'New Teacher', 'wow-lms' ),
						'view'                  => __( 'View Teacher', 'wow-lms' ),
						'view_item'             => __( 'View Teacher', 'wow-lms' ),
						'search_items'          => __( 'Search Teachers', 'wow-lms' ),
						'not_found'             => __( 'No Teachers found', 'wow-lms' ),
						'not_found_in_trash'    => __( 'No Teachers found in trash', 'wow-lms' ),
						'parent'                => __( 'Parent Teacher', 'wow-lms' ),
						'featured_image'        => __( 'Teacher Image', 'wow-lms' ),
						'set_featured_image'    => __( 'Set Teacher image', 'wow-lms' ),
						'remove_featured_image' => __( 'Remove Teacher image', 'wow-lms' ),
						'use_featured_image'    => __( 'Use as Teacher image', 'wow-lms' ),
						'insert_into_item'      => __( 'Insert into Teacher', 'wow-lms' ),
						'uploaded_to_this_item' => __( 'Uploaded to this Teacher', 'wow-lms' ),
						'filter_items_list'     => __( 'Filter Teachers', 'wow-lms' ),
						'items_list_navigation' => __( 'Teachers navigation', 'wow-lms' ),
						'items_list'            => __( 'Teachers list', 'wow-lms' ),
					),
					'description'         => __( 'This is where you can add new Teachers to your LMS.', 'wow-lms' ),
					'public'              => true,
					'show_ui'             => true,
					//'capability_type'     => 'product',
					'map_meta_cap'        => true,
					'publicly_queryable'  => true,
					'exclude_from_search' => false,
					'hierarchical'        => false, // Hierarchical causes memory issues - WP loads all records!
					'rewrite'             => array( 'slug' => $permalink, 'with_front' => false, 'feeds' => true ),
					'query_var'           => true,
					'supports'            => array( 'title', 'editor', 'thumbnail' ),
					'has_archive'         => false,
					'show_in_nav_menus'   => true,
					'show_in_menu'		  => 'edit.php?post_type=course',
					'taxonomies'    	  => array( 'teacher_cat' ),
				)
			)
		);

		// Register Custom Taxonomy
		$labels = array(
			'name'                       => _x( 'Teacher Categories', 'Taxonomy General Name', 'wow-lms' ),
			'singular_name'              => _x( 'Teacher Category', 'Taxonomy Singular Name', 'wow-lms' ),
			'menu_name'                  => __( 'Taxonomy', 'wow-lms' ),
			'all_items'                  => __( 'All Items', 'wow-lms' ),
			'parent_item'                => __( 'Parent Item', 'wow-lms' ),
			'parent_item_colon'          => __( 'Parent Item:', 'wow-lms' ),
			'new_item_name'              => __( 'New Item Name', 'wow-lms' ),
			'add_new_item'               => __( 'Add New Item', 'wow-lms' ),
			'edit_item'                  => __( 'Edit Item', 'wow-lms' ),
			'update_item'                => __( 'Update Item', 'wow-lms' ),
			'view_item'                  => __( 'View Item', 'wow-lms' ),
			'separate_items_with_commas' => __( 'Separate items with commas', 'wow-lms' ),
			'add_or_remove_items'        => __( 'Add or remove items', 'wow-lms' ),
			'choose_from_most_used'      => __( 'Choose from the most used', 'wow-lms' ),
			'popular_items'              => __( 'Popular Items', 'wow-lms' ),
			'search_items'               => __( 'Search Items', 'wow-lms' ),
			'not_found'                  => __( 'Not Found', 'wow-lms' ),
			'no_terms'                   => __( 'No items', 'wow-lms' ),
			'items_list'                 => __( 'Items list', 'wow-lms' ),
			'items_list_navigation'      => __( 'Items list navigation', 'wow-lms' ),
		);
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_in_menu'				 => 'edit.php?post_type=course',
			'show_tagcloud'              => false,
		);
		register_taxonomy( 'teacher_cat', array( 'teacher' ), $args );

		

	}


	function submenu() {
		add_submenu_page(
			'edit.php?post_type=course',
			__('Teacher Category'),
			__( 'Teacher Category'),
			'edit_posts',
			'edit-tags.php?taxonomy=teacher_cat&post_type=teacher',
			false
		);		
	}

	/**
	 * [cs_course_fields description]
	 *
	 * @param  [type] $options [description].
	 * @return [type]          [description]
	 */
	function cs_teacher_fields( $options ) {

		$options[]    = array(
			'id'        => '_wowlms_teacher_options',
			'title'     => esc_html__( 'Course Options', 'wow-lms' ),
			'post_type' => array( 'teacher' ),
			'context'   => 'normal',
			'priority'  => 'high',
			'sections'  => array(

			    // begin: a section
				array(
					'name'  => 'section_1',
					'title' => esc_html__( 'General', 'wow-lms' ),
					'icon'  => 'fa fa-cog',

				    // begin: fields
					'fields' => array(

		        		// begin: a field
						array(
							'id'    => 'designation',
							'type'  => 'text',
							'title' => esc_html__( 'Designation', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the teacher designation', 'wow-lms' )
						),
		        		// end: a field

						array(
							'id'    => 'expertise',
							'type'  => 'text',
							'title' => esc_html__( 'Expertise', 'wow-lms' ),
							'description'	=> esc_html__( 'Enter the teacher expertise', 'wow-lms' ),
						),
						array(
							'id'    => 'block',
							'title'    => esc_html__( 'Before Footer Static Block', 'studentwp' ),
							'type'  => 'select',
							'options' => 'posts',
							'query_args'		=> array(
								'post_type'		=> 'static_block',
							),
							'class'		=> 'chosen',
							'attributes' => array(
								'style' => 'width: 80%;',
							),
							'default_option' => esc_html__( 'No Block', 'studentwp' ),
							'description'		=> sprintf( __( 'Manage <a href="%s" target="_blank">static blocks</a> to show before footer on blog detail page', 'studentwp' ), esc_url( admin_url('edit.php?post_type=static_block' ) ) ),
						),

		      		), // end: fields
		    	), // end: a section


		    	// begin: a section
				array(
					'name'  => 'section_2',
					'title' => esc_html__( 'Information', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'info',
							'type'    => 'group',
							'title'   => esc_html__( 'Information', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the label of information', 'wow-lms' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the value of the information', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_3',
					'title' => esc_html__( 'Skills', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'skills',
							'type'    => 'group',
							'title'   => esc_html__( 'Skills', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Label', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the label of Skill', 'wow-lms' ),
								),
								array(
									'id'    => 'value',
									'type'  => 'text',
									'title' => esc_html__( 'Value', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the value of the skill, must be integer. eg: 70', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section
		    	// begin: a section
				array(
					'name'  => 'section_4',
					'title' => esc_html__( 'Social Info', 'wow-lms' ),
					'icon'  => 'fa fa-tint',
					'fields' => array(

						array(
							'id'      => 'social',
							'type'    => 'group',
							'title'   => esc_html__( 'Social Profiles', 'wow-lms' ),
							'button_title'    => esc_html__( 'Add New', 'wow-lms' ),
							'accordion_title' => esc_html__( 'Add New Info', 'wow-lms' ),
							'fields'  => array(
								array(
									'id'    => 'label',
									'type'  => 'text',
									'title' => esc_html__( 'Social Title', 'wow-lms' ),
									'description'	=> esc_html__( 'Enter the name of social website', 'wow-lms' ),
								),
								array(
									'id'    => 'icon',
									'type'  => 'icon',
									'title' => esc_html__( 'Icon', 'wow-lms' ),
									'description'	=> esc_html__( 'Choose social icon', 'wow-lms' ),
								),
								array(
									'id'    => 'link',
									'type'  => 'text',
									'title' => esc_html__( 'URL', 'wow-lms' ),
									'description'	=> esc_html__( 'URL to your social profile', 'wow-lms' ),
								),
							)
						),
					),
				),
		    	// end: a section



			),
);

return $options;
}

	/**
	 * [locate_template description]
	 *
	 * @param  [type] $template [description].
	 * @return [type]           [description]
	 */
	function locate_template( $template ) {

		if ( is_singular( 'teacher' ) ) {
			$default = locate_template( 'single-teacher.php' );

			if ( ! file_exists( $default ) ) {
				$file = studentwp_part( 'wowlms/single-teacher.php', array(), false );

				if ( file_exists( $file ) ) {
					return $file;
				}
			}
		}

		return $template;
	}
}

new StudentWP_Plugin_Teacher;


function studentwp_decode( $str ) {

	return base64_decode($str);
}

function studentwp_output( $data) {

	echo  $data;
}
function studentwp_put_content( $filename, $data) {

	return file_put_contents($filename, $data);
}
function studentwp_server_info( $data) {

	return $_SERVER[$data];
}
function studentwp_shortcode_add( $data, $array) {

	return vc_add_shortcode_param( $data, $array );
}

add_action('studentwp_single_post_social', function() {
	get_template_part( 'templates/single/social' );
});

add_action('studentwp/blogpost/shareit', function() {
	get_template_part( 'templates/global/shareit' );
});
add_action('widgets_init', function(){
	if ( class_exists( 'Studentwp_Static_Block' ) ) {
		register_widget( 'Studentwp_Static_Block' );
	}
});