jQuery(document).ready(function ($) {
    'use strict';
    $('.image-list-pack > .image-list > ul > li').each(function () {
        $(this).children('input').on('click', function () {
            $('.image-list-pack > .image-list > ul li').removeClass('checked-set');
            $('.image-list-pack > .image-list > ul li span').removeClass('checked-span');
            var parent = $(this).parent('li');
            parent.addClass('checked-set');
            $(this).next('span').addClass('checked-span');
        });
    });
});