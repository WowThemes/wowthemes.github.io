<?php
/**
 * image_list field class.
 *
 * @version     1.0
 */
/* exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
/* don't duplicate me! */
if ( ! class_exists( 'Redux_Image_List', false ) ) {

	class Redux_Image_List extends Redux_Field {

		/**
		 * Field Constructor.
		 * Required - must call the parent constructor, then assign field and value to vars
		 *
		 * @param array $field Field array.
		 * @param mixed $value Field values.
		 * @param object $parent ReduxFramework pointer.
		 */
		public function __construct( $field = array(), $value = '', $parent ) {
			parent::__construct( $field, $value, $parent );

			// Set default args for this field to avoid bad indexes. Change this to anything you use.
			$defaults = array(
				'options'          => array(),
				'stylesheet'       => '',
				'output'           => true,
				'enqueue'          => true,
				'enqueue_frontend' => true,
			);

			$this->field = wp_parse_args( $this->field, $defaults );
		}

		/**
		 * Field Render Function.
		 * Takes the vars and outputs the HTML for the field in the settings
		 *
		 * @return      void
		 */
		public function render() {
			$counter      = 0;
			$img_list_w_k = array();

			$img_list_dir_list = glob( $this->dir . basename( $this->dir ) . '/pattern/*.png' );
			foreach ( $img_list_dir_list as $list ) {
				$file_name                                             = basename( $list );
				$img_list_w_k[ str_replace( '.png', '', $file_name ) ] = $this->url . 'pattern/' . $file_name;
			}
			$image_list = $img_list_w_k;
			?>
			<div class="image-list-pack">
				<div class="image-list">
					<ul>
						<?php

						foreach ( $image_list as $k => $v ) {
							?>
							<li <?php echo ( $k === $this->value ) ? 'class="checked-set"' : ''; ?>>
								<input type="radio" id="<?php echo $this->field[ 'id' ] . '_' . $k; ?>" name="<?php echo $this->field[ 'name' ] . $this->field[ 'name_suffix' ]; ?>" value="<?php echo $k; ?>" <?php echo checked( $this->value, $k, false ); ?>/>
								<?php echo ( $k === $this->value ) ? '<span class="checked-span">' : '<span>'; ?>
								<img src="<?php echo $v; ?>" alt="<?php echo $k; ?>" date-key-set="">
								</span>
							</li>
							<?php
							$counter ++;
						}
						?>
					</ul>
				</div>
			</div>
			<?php
		}
		/* render() */

		/**
		 * enqueue styles and/or scripts.
		 */
		public function enqueue() {
			wp_enqueue_style(
				'redux-field-image-list', $this->url . 'image-list.css', false, 'all'
			);
			// Field dependent JS
			wp_enqueue_script(
				'redux-field-image-list', $this->url . 'image-list.js', array( 'jquery' ), true
			);
		}

		/* enqueue() */
	}
}
