<?php

/**
 * switch_label field class.
 *
 * @version     1.0.0
 */
/* exit if accessed directly. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'Redux_Social_Media' ) ) {

	/**
	 *  ReduxFramework_switch_label class.
	 *
	 * @since       1.0.0
	 */
	class Redux_Social_Media extends Redux_Field {

		/**
		 * Field Constructor.
		 * Required - must call the parent constructor, then assign field and value to vars
		 *
		 * @param array $field Field array.
		 * @param mixed $value Field values.
		 * @param object $parent ReduxFramework pointer.
		 */
		public function __construct( $field = array(), $value = '', $parent ) {
			parent::__construct( $field, $value, $parent );

			// Set default args for this field to avoid bad indexes. Change this to anything you use.
			$defaults = array(
				'options'          => array(),
				'stylesheet'       => '',
				'output'           => true,
				'enqueue'          => true,
				'enqueue_frontend' => true,
			);

			$this->field = wp_parse_args( $this->field, $defaults );
		}

		/**
		 * render field output.
		 *
		 * @access      public
		 * @return      void
		 * @since       1.0.0
		 */
		public function render() {
			$counter = 0;
			$id      = isset( $this->field[ 'id' ] ) ? $this->field[ 'id' ] : '';
			$title   = isset( $this->field[ 'title' ] ) ? $this->field[ 'title' ] : '';
			?>
			<div class="icons-pack" data-opt-name=""
				 data-id="opt-<?php echo esc_attr( $id ) ?>">
				<?php if ( isset( $this->field[ 'heading' ] ) && $this->field[ 'heading' ] === true ): ?>
					<h2 class="sec-title1"><?php echo esc_html( $title ) ?></h2>
				<?php endif; ?>
				<div class="icons-sec">
					<ul>
						<?php
						$profiler = array(
							'adn'                 => 'fa-adn',
							'android'             => 'fa-android',
							'apple'               => 'fa-apple',
							'behance'             => 'fa-behance',
							'behance_square'      => 'fa-behance-square',
							'bitbucket'           => 'fa-bitbucket',
							'bitcoin'             => 'fa-btc',
							'css3'                => 'fa-css3',
							'delicious'           => 'fa-delicious',
							'deviantart'          => 'fa-deviantart',
							'dribbble'            => 'fa-dribbble',
							'dropbox'             => 'fa-dropbox',
							'drupal'              => 'fa-drupal',
							'empire'              => 'fa-empire',
							'facebook'            => 'fa-facebook',
							'four_square'         => 'fa-foursquare',
							'git_square'          => 'fa-git-square',
							'github'              => 'fa-github',
							'github_alt'          => 'fa-github',
							'github_square'       => 'fa-github-square',
							'git_tip'             => 'fa-gittip',
							'google'              => 'fa-google',
							'google_plus'         => 'fa-google-plus',
							'google_plus_square'  => 'fa-google-plus-square',
							'hacker_news'         => 'fa-hacker-news',
							'html5'               => 'fa-html5',
							'instagram'           => 'fa-instagram',
							'joomla'              => 'fa-joomla',
							'js_fiddle'           => 'fa-jsfiddle',
							'linkedIn'            => 'fa-linkedin',
							'linkedIn_square'     => 'fa-linkedin-square',
							'linux'               => 'fa-linux',
							'MaxCDN'              => 'fa-maxcdn',
							'OpenID'              => 'fa-openid',
							'page_lines'          => 'fa-pagelines',
							'pied_piper'          => 'fa-pied-piper',
							'pinterest'           => 'fa-pinterest',
							'pinterest_square'    => 'fa-pinterest-square',
							'QQ'                  => 'fa-qq',
							'rebel'               => 'fa-rebel',
							'reddit'              => 'fa-reddit',
							'reddit_square'       => 'fa-reddit-square',
							'ren-ren'             => 'fa-renren',
							'share_alt'           => 'fa-share-alt',
							'share_square'        => 'fa-share-alt-square',
							'skype'               => 'fa-skype',
							'slack'               => 'fa-slack',
							'sound_cloud'         => 'fa-soundcloud',
							'spotify'             => 'fa-spotify',
							'stack_exchange'      => 'fa-stack-exchange',
							'stack_overflow'      => 'fa-stack-overflow',
							'steam'               => 'fa-steam',
							'steam_square'        => 'fa-steam-square',
							'stumble_upon'        => 'fa-stumbleupon',
							'stumble_upon_circle' => 'fa-stumbleupon-circle',
							'tencent_weibo'       => 'fa-tencent-weibo',
							'trello'              => 'fa-trello',
							'tumblr'              => 'fa-tumblr',
							'tumblr_square'       => 'fa-tumblr-square',
							'twitter'             => 'fa-twitter',
							'twitter_square'      => 'fa-twitter-square',
							'vimeo_square'        => 'fa-vimeo-square',
							'vine'                => 'fa-vine',
							'vK'                  => 'fa-vk',
							'weibo'               => 'fa-weibo',
							'weixin'              => 'fa-weixin',
							'windows'             => 'fa-windows',
							'wordPress'           => 'fa-wordpress',
							'xing'                => 'fa-xing',
							'xing_square'         => 'fa-xing-square',
							'yahoo'               => 'fa-yahoo',
							'yelp'                => 'fa-yelp',
							'youTube'             => 'fa-youtube',
							'youTube_play'        => 'fa-youtube-play',
							'youTube_square'      => 'fa-youtube-square',
						);
						foreach ( $profiler as $k => $v ) {
							$getTitle = str_replace( '_', ' ', $k );
							$title    = ucwords( $getTitle );

							$getVal   = isset( $this->value[ $counter ] ) ? $this->value[ $counter ] : '';
							$getVal   = isset( $getVal[ 'data' ] ) ? $getVal[ 'data' ] : '';
							$fieldVal = json_decode( urldecode( $getVal ) );

							$fieldVal = isset( $fieldVal->enable ) ?$fieldVal->enable : '';
							$selected = ( $fieldVal == 'true' ) ? 'class=active' : '';
							echo '<li ' . esc_attr( $selected ) . ' data-key="' . $counter ++ . '" data-id="' . $k . '" ><i class="fa ' . $v . '"></i></li>';
						}
						?>
					</ul>
				</div>
				<div class="socialmedia-settingsec">
					<ul>
						<?php
						$counter2 = 0;
						foreach ( $profiler as $k => $v ) {
							$getTitle = str_replace( '_', ' ', $k );
							$title    = ucwords( $getTitle );
							$getVal   = isset( $this->value[ $counter ] ) ? $this->value[ $counter ] : '';
							$getVal   = isset( $getVal[ 'data' ] ) ? $getVal[ 'data' ] : '';
							$fieldVal = json_decode( urldecode( $getVal ) );
							$fieldVal = isset($fieldVal->enable ) ? $fieldVal->enable : '';
							$selected = ( $fieldVal == 'true' ) ? 'style=display:block' : 'style=display:none';
							if ( ! empty( $fieldVal ) ) {
								$val = json_encode( array(
									'icon'       => $v,
									'enable'     => $fieldVal->enable,
									'url'        => $fieldVal->url,
									'background' => $fieldVal->background,
									'color'      => $fieldVal->color
								) );
							} else {
								$val = json_encode( array(
									'icon'       => $v,
									'enable'     => '',
									'url'        => '',
									'background' => '',
									'color'      => ''
								) );
							}
							?>
							<li id="redux-social_meida-<?php echo esc_attr( $counter2 ) ?>"
								data-key="<?php echo esc_attr( $counter2 ) ?>" <?php echo esc_attr( $selected ) ?> >
								<div class="socialmedia-setting">
									<input class="redux-social_media-hidden-data-<?php echo esc_attr( $counter2 ) ?>"
										   type="hidden" id="opt-social-media-<?php echo esc_attr( $counter2 ) ?>"
										   name="<?php echo esc_attr( $this->field[ 'name' ] ) . '[' . $counter2 . ']' ?>[data]"
										   value="<?php echo urlencode( $val ) ?>">
									<span class="icon-title">
                                        <i class="fa <?php echo esc_attr( $v ) ?>"></i>
                                        <?php echo esc_html( $title ) ?>
                                    </span>
									<span class="del-btn">
                                        <i class="fa fa-close"></i>
                                    </span>
									<div class="socialmedia-link">
										<div class="inner">
											<label
													for="social_link"><?php esc_html_e( 'Link URL', 'theme_support_student' ) ?></label>
											<input id="social_link"
												   class="redux-social_media-url-text-<?php echo esc_attr( $counter2 ) ?>"
												   data-key="<?php echo esc_attr( $counter2 ) ?>" type="text"/>
										</div>
										<div class="inner">
											<label for="social_color"><?php esc_html_e( 'Color', 'theme_support_student' ) ?></label>
											<input id="social_color"
												   class="redux-social_media-color-picker-<?php echo esc_attr( $counter2 ) ?>"
												   type="text" value="">
										</div>
										<div class="inner">
											<label
													for="social_bg"><?php esc_html_e( 'Background', 'theme_support_student' ) ?></label>
											<input id="social_bg"
												   class="redux-social_media-background-picker-<?php echo esc_attr( $counter2 ) ?>"
												   type="text" value="">
										</div>
										<button data-value="<?php echo esc_attr( $counter2 ) ?>" data-v="value"
												class="clear-btn">
											<?php esc_html_e( 'Clear', 'theme_support_student' ) ?>
										</button>
									</div>
								</div>
							</li>
							<?php
							$counter2 ++;
						}
						?>
					</ul>
				</div>
			</div>
			<?php
		}
		/* render() */

		/**
		 * enqueue styles and/or scripts.
		 *
		 * @access      public
		 * @return      void
		 * @since       1.0.0
		 */
		public function enqueue() {
			wp_enqueue_script(
				'redux-field-social_media-color-plate', $this->url . 'spectrum.js', array( 'jquery' ), time(), true

			);
			wp_enqueue_script(
				'redux-field-social_media', $this->url . 'social_media.min.js', array(
				'jquery',
				'jquery-ui-core'
			), time(), true
			);

			wp_enqueue_script(
				'redux-field-social_media-scroll', $this->url . 'social_media_scroll.min.js', array( 'jquery' ), time(), true
			);

			wp_enqueue_style(
				'redux-field-social_media-font', $this->url . 'font-awesome.min.css', time(), 'all'
			);

			wp_enqueue_style(
				'redux-field-social_media', $this->url . 'social_media.css', time(), 'all'
			);
			if ( isset( $this->field[ 'full_width' ] ) && $this->field[ 'full_width' ] === true ) {
				$custom_css = "
                .redux-container-social_media > div:nth-child(1){
                        display: none;
                }";
				wp_add_inline_style( 'redux-field-social_media', $custom_css );
			}
		}
	}
}
