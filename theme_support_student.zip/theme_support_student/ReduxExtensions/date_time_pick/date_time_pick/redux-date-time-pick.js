(function( $ ) {
	'use strict';

	$('body').find(".datetimepicker").datetimepicker();
})( jQuery );
