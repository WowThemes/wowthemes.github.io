<?php 

// Posts Layouts settings
$options['course']    = array(
	'id'        => '_sh_layout_settings',
	'title'     => esc_html__('Post Settings', 'studentwp'),
	'sections'  => array(

		
		array(
			'name'   => '_sh_General_settings',
			'title' => 'General',
			'fields' => array(
				array(
					'id'        => 'course-video-embed',
					'type'      => 'text',
					'desc'    => esc_html__('Paste the embed code for your video (e.g. YouTube, Vimeo etc.) in the box above.', 'studentwp' ),
					'title'     => esc_html__('Video Embed Code', 'studentwp' ),

				),

				array(

					'id'        => 'course_notifications',

					'type'      => 'switcher',

					'title'     => esc_html__('Course Notifications', 'studentwp' ),

					'desc'    => esc_html__('Disable notifications on this course ?', 'studentwp' ),


				),

				array(
					'id'        => '_course_woocommerce_product',
					'type'      => 'select',
					'title'     => esc_html__('Woocommerce Product', 'studentwp' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'product',
						'order'        => 'DESC',
					),
				),

				array(
					'id'        => '_course_prerequisite',
					'type'      => 'select',
					'title'     => esc_html__('Choose Prerequisite', 'studentwp' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'course',
						'order'        => 'DESC',
					),
				),
			),
		),
	),
);


return $options;