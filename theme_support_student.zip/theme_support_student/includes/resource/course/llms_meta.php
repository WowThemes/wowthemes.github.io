<?php 

// Posts Layouts settings
$options['course']    = array(
	'id'        => '_sh_layout_settings',
	'title'     => esc_html__('Post Settings', 'studentwp'),
	'sections'  => array(

				array(
				'name'   => '_sh_salepage_settings',
				'title' => 'Sales Page',
				'fields' => array(

					array(
  'id'             => '_llms_sales_page_content_type',
  'type'           => 'select',
  'title'          => 'Select Field',
  'options'        => array(
    ''             => 'Display default course content',
    'content'      => 'Show custom content',
    'page'         => 'Redirect to WordPress Page',
    'url'          => 'Redirect to custom URL'
  ),
  'class'			  => 'chosen',
),
				),
				),
				array(
				'name'   => '_sh_General_settings',
				'title' => 'General',
				'fields' => array(
					array(
						'id'        => '_llms_length',
						'type'      => 'text',
						'title'     => esc_html__('Course Length', 'studentwp' ),

					),
					array(
						'id'        => '_llms_post_course_difficulty',
						'type'      => 'select',
						'title'     => esc_html__('Course Difficulty Category', 'studentwp' ),
						'options'        => 'categories',
							  'query_args'     => array(
							  	 /*'taxonomies'   => array( 'course_difficulty'),*/
							  	'type'         => 'course',
    							'taxonomy'     => 'course_difficulty',
    							'hide_empty' => false,
							    'orderby'      => 'name',
							    'order'        => 'ASC',
							  ),
						 'class'			  => 'chosen',

					),

					array(
						'id'        => '_llms_video_embed',
						'type'      => 'text',
						'title'     => esc_html__('Featured Video', 'studentwp' ),

					),

					array(

						'id'        => '_llms_tile_featured_video',

						'type'      => 'switcher',

						'title'     => esc_html__('Display Featured Video on Course Tile', 'studentwp' ),

					),

					array(
						'id'        => '_llms_audio_embed',
						'type'      => 'text',
						'title'     => esc_html__('Featured Audio', 'studentwp' ),

					),
				),
			),
				array(
				'name'   => '_sh_Restrictions_settings',
				'title' => 'Restrictions',
				'fields' => array(

					array(
						'id'        => '_llms_content_restricted_message',
						'type'      => 'text',
						'title'     => esc_html__('Content Restricted Message', 'studentwp' ),

					),

					array(

						'id'        => '_llms_enrollment_period',

						'type'      => 'switcher',

						'title'     => esc_html__('Enable Enrollment Period', 'studentwp' ),

					),

					array(
						'id'        => '_llms_enrollment_start_date',
						'type'      => 'text',
						'title'     => esc_html__('Enrollment Start Date like this mm/dd/yy', 'studentwp' ),
						 'dependency'   => array( '_llms_enrollment_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_enrollment_end_date',
						'type'      => 'text',
						'title'     => esc_html__('Enrollment End Date like this mm/dd/yy', 'studentwp' ),
						 'dependency'   => array( '_llms_enrollment_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_enrollment_opens_message',
						'type'      => 'text',
						'title'     => esc_html__('Enrollment Opens Message', 'studentwp' ),
						'help'          => esc_html__('This message will be displayed to non-enrolled visitors before the Enrollment Start Date. You may use shortcodes like [lifterlms_course_info id="737" key="enrollment_start_date"] in this message.
', 'studentwp' ),
						 'dependency'   => array( '_llms_enrollment_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_enrollment_close_message',
						'type'      => 'text',
						'title'     => esc_html__('Enrollment Close Message', 'studentwp' ),
						'help'          => esc_html__('This message will be displayed to non-enrolled visitors once the Enrollment End Date has passed. You may use shortcodes like [lifterlms_course_info id="737" key="enrollment_end_date"] in this message', 'studentwp' ),

						 'dependency'   => array( '_llms_enrollment_period', '==', 'true' ),
					),

					array(

						'id'        => '_llms_time_period',

						'type'      => 'switcher',

						'title'     => esc_html__('Enable Course Time Period', 'studentwp' ),

					),

					array(
						'id'        => '_llms_start_date',
						'type'      => 'text',
						'title'     => esc_html__('Course Start Date like this mm/dd/yy', 'studentwp' ),
						 'dependency'   => array( '_llms_time_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_end_date',
						'type'      => 'text',
						'title'     => esc_html__('Course End Date like this mm/dd/yy', 'studentwp' ),
						 'dependency'   => array( '_llms_time_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_course_opens_message',
						'type'      => 'text',
						'title'     => esc_html__('Course Opens Message', 'studentwp' ),
						'help'          => esc_html__('This message will be displayed to non-enrolled visitors before the Course Start Date. You may use shortcodes like [lifterlms_course_info id="737" key="start_date"] in this message.
', 'studentwp' ),
						 'dependency'   => array( '_llms_time_period', '==', 'true' ),
					),

					array(
						'id'        => '_llms_course_close_message',
						'type'      => 'text',
						'title'     => esc_html__('Course Close Message', 'studentwp' ),
						'help'          => esc_html__('This message will be displayed to non-enrolled visitors once the Course End Date has passed. You may use shortcodes like [lifterlms_course_info id="737" key="end_date"] in this message.', 'studentwp' ),

						 'dependency'   => array( '_llms_time_period', '==', 'true' ),
					),

					array(

						'id'        => '_llms_has_prerequisite',

						'type'      => 'switcher',

						'title'     => esc_html__('Enable Prerequisite', 'studentwp' ),

					),
					array(
						'id'        => '_llms_prerequisite',
						'type'      => 'select',
						'title'     => esc_html__('Choose Prerequisite', 'studentwp' ),
						'dependency'   => array( '_llms_has_prerequisite', '==', 'true' ),
						'options'        => 'posts',
						'class'			  => 'chosen',
  'query_args'     => array(
    'post_type'    => 'course',
    'order'        => 'DESC',
  ),
),

					array(

						'id'        => '_llms_enable_capacity',

						'type'      => 'switcher',

						'title'     => esc_html__('Enable Course Capacity', 'studentwp' ),

					),
					array('id'        => '_llms_capacity',
						'type'      => 'number',
						'title'     => esc_html__('Course Capacity', 'studentwp' ),
						 'dependency'   => array( '_llms_enable_capacity', '==', 'true' ),
					),
					array('id'        => '_llms_capacity_message',
						'type'      => 'text',
						'title'     => esc_html__('Capacity Reached Message', 'studentwp' ),
						 'dependency'   => array( '_llms_enable_capacity', '==', 'true' ),
					),
				),
			),
				array(
				'name'   => '_Reviews_setting',
				'title' => 'Reviews',
				'fields' => array(

					array(

						'id'        => '_llms_reviews_enabled',

						'type'      => 'switcher',

						'title'     => esc_html__('Enable Reviews', 'studentwp' ),

					),

					array(

						'id'        => '_llms_display_reviews',

						'type'      => 'switcher',

						'title'     => esc_html__('Display Reviews', 'studentwp' ),

					),

					array(

						'id'         => '_llms_num_reviews',

						'type'       => 'number',

						'title'      => esc_html__('Number of Reviews', 'studentwp' ),

						'dependency' => array( '_llms_display_reviews', '==', 'true' )

					),

					array(

						'id'        => '_llms_multiple_reviews_disabled',

						'type'      => 'switcher',

						'title'     => esc_html__('Prevent Multiple Reviews', 'studentwp' ),

					),

					
				),
				),

	),
);


return $options;