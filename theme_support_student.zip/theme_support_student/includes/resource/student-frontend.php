<?php

$config['settings'] = array(
	'show_profile'		=> true,
	'profile_icon'		=> '',
	'user_role'			=> 'which can access the account area',
	'login_page_id'		=> get_option('login_page_id'),
	'data'				=> tss_profile_fields()
);

$config['tabs']['course'] = array(
	'type'			=> 'view',
	'menu_title'	=> esc_html__( 'Courses', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-sticky-note"></i>',
	'support'		=> array( 'title', 'editor', 'thumbnail' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'course',
	'taxonomies'	=> array( 'course_cat' ),
);

/**
$config['settings'] = array(
	'show_profile'		=> true,
	'profile_icon'		=> '',
	'user_role'			=> 'which can access the account area',
	'login_page_id'		=> get_option('login_page_id'),
);
$config['tabs'][] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Products' ),
	'support'		=> array( 'title', 'content', 'thumbnial' ),
	'post_status'	=> 'pending or draft ( default pending )',
	'menu_icon'		=> '<i class="fa fa-user"></i> or <img src="url" />',
	'post_type'		=> 'product',
	'taxonomies'	=> array( 'product_cat' ),
	'show_search'	=> true,
	'pagination'	=> 10,
	'table'			=> array(
							'title'	=> 'title',
							'category'	=> 'product_cat',
							'status'	=> 'status',
							'date'		=> 'date',
							'custom'	=> 'callback_function',
						)
);
$config['tabs'][] = array(
	'type'			=> 'wishlist',
	'menu_title'	=> esc_html__( 'Wishlist' ),
	'menu_icon'		=> '<i class="fa fa-user"></i> or <img src="url" />',
	'meta_key'		=> 'user meta key where whilch list ids are stored',
);



*/

return $config;


