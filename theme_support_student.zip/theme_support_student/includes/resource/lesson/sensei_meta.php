<?php 

// Posts Layouts settings
$options['lesson']    = array(
	'id'        => '_sh_layout_settings',
	'title'     => esc_html__('Post Settings', 'studentwp'),
	'post_type' => array( 'lesson' ),
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(

		array(
			'name'   => '_sh_General_settings',
			'title'  =>'General',
			'fields' => array(

				array(
					'id'        => '_lesson_prerequisite',
					'type'      => 'select',
					'title'     => esc_html__('Choose Prerequisite', 'studentwp' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'lesson',
						'order'        => 'DESC',
					)
				),
				array(
					'id'        => '_lesson_course',
					'type'      => 'select',
					'title'     => esc_html__('Course', 'studentwp' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'Course',
						'order'        => 'DESC',
					),
				),

				array(
					'id'        => '_lesson_length',
					'type'      => 'number',
					'title'     => esc_html__('Lesson Length in minutes', 'studentwp' ),
				),

				array(
					'id'        => '_lesson_complexity',
					'type'      => 'select',
					'title'     => esc_html__('Lesson Complexity', 'studentwp' ),
					'options'   => array(

						''     => esc_html__('None', 'studentwp' ),
						'easy' => esc_html__('Easy' , 'studentwp'),
						'std'  => esc_html__('Stanard', 'studentwp' ),
						'hard' => esc_html__('Hard ', 'studentwp'),
						

					),
					'class'   => 'chosen',

				),

				array(
					'id'    => '_lesson_video_embed',
					'type'  => 'textarea',
					'title' => esc_html__('Video Embed Code:', 'studentwp' ),
					'desc'  => esc_html__('Paste the embed code for your video (e.g. YouTube, Vimeo etc.) in the box above.', 'studentwp' ),
				),

				
			),
		),

	),
);


return $options;