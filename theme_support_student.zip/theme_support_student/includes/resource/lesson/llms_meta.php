<?php 

// Posts Layouts settings
$options['lesson']    = array(
	'id'        => '_sh_layout_settings',
	'title'     => esc_html__('Post Settings', 'studentwp'),
	'post_type' => array( 'course' ),
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(

				array(
				'name'   => '_sh_General_settings',
				'title'  =>'General',
				'fields' => array(

					array(
						'id'        => '_llms_video_embed',
						'type'      => 'text',
						'title'     => esc_html__('Video Embed Url', 'studentwp' ),
					),

					array(
						'id'        => '_llms_audio_embed',
						'type'      => 'text',
						'title'     => esc_html__('Audio Embed Url', 'studentwp' ),
					),

					array(
						'id'        => '_llms_free_lesson',
						'type'      => 'switcher',
						'title'     => esc_html__('Free Lesson', 'studentwp' ),
					),
				),
			),
					array(
				'name'   => '_sh_Prerequisites_settings',
				'title'  =>'Prerequisites',
				'fields' => array(

					array(
						'id'        => '_llms_has_prerequisite',
						'type'      => 'switcher',
						'title'     => esc_html__('Enable Prerequisite', 'studentwp' ),
					),
					array(
						'id'        => '_llms_prerequisite',
						'type'      => 'select',
						'title'     => esc_html__('Choose Prerequisite', 'studentwp' ),
						'dependency'   => array( '_llms_has_prerequisite', '==', 'true' ),
						'options'        => 'posts',
						'class'			  => 'chosen',
  'query_args'     => array(
    'post_type'    => 'lesson',
    'order'        => 'DESC',
  ),
),

				),
			),
						array(
				'name'   => '_sh_Drip_settings',
				'title'  =>'Drip Settings',
				'fields' => array(
					array(
						'id'        => '_llms_drip_method',
						'type'      => 'select',
						'title'     => esc_html__('Method', 'studentwp' ),
						'options'   => array(

							''              => 'None',
							'date'          => 'On a specific date',
							'enrollment'    => 'After course enrollment',
							'start'         => 'After course start date',
							'prerequisite'  => 'After prerequisite completion',

						),
						'class'			  => 'chosen',

					),
					array(
						'id'        => '_llms_days_before_available',
						'type'      => 'text',
						'title'     => esc_html__('Delay (In Days)', 'studentwp' ),
						 'dependency'   => array( '_llms_drip_method', 'any', 'enrollment,start,prerequisite' ),
					),
					array(
						'id'        => '_llms_date_available',
						'type'      => 'text',
						'title'     => esc_html__('Date Available like this mm/dd/yyyy', 'studentwp' ),
						 'dependency'   => array( '_llms_drip_method', '==', 'date' ),
					),
					array(
						'id'        => '_llms_time_available',
						'type'      => 'text',
						'title'     => esc_html__('Time Available like this HH:MM AM', 'studentwp' ),
						 'dependency'   => array( '_llms_drip_method', '==', 'date' ),
					),

				),
			),
						array(
				'name'   => '_sh_QUIZ_settings',
				'title'  =>'QUIZ Settings',
				'fields' => array(

					array(
						'id'        => '_llms_require_passing_grade',
						'type'      => 'switcher',
						'title'     => esc_html__('Require Passing Grade', 'studentwp' ),
					),
					

					
				),

			),
			

	),
);


return $options;