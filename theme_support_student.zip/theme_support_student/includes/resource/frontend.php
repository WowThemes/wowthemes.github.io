<?php 

if( function_exists('Sensei') ) {
	$config = array(
		'tabs'		=> array(
			'instructor'		=> apply_filters('tss/lms/frontent_instructor_tabs', array(
				'profile'			=> array( 'name' => esc_html__('Profile', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'courses'			=> array( 'name' => esc_html__('Courses', 'wow-lms'), 'icon' => 'fa fa-book' ),
				'lessons'			=> array( 'name' => esc_html__('Lessons', 'wow-lms'), 'icon' => 'fa fa-scribd' ),

				'questions'			=> array( 'name' => esc_html__('Questions', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
			)),
			'student'			=> array(
				'profile'			=> array( 'name' => esc_html__('Profile', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'courses'			=> array( 'name' => esc_html__('Courses', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'assignments'		=> array( 'name' => esc_html__('Assignments', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
			),
		)
	);
}
else{

	$config = array(
		'tabs'		=> array(
			'instructor'		=> apply_filters('tss/lms/frontent_instructor_tabs', array(
				'profile'			=> array( 'name' => esc_html__('Profile', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'courses'			=> array( 'name' => esc_html__('Courses', 'wow-lms'), 'icon' => 'fa fa-book' ),
				'lessons'			=> array( 'name' => esc_html__('Lessons', 'wow-lms'), 'icon' => 'fa fa-scribd' ),

			//'statement'			=> array( 'name' => esc_html__('Statement', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
			)),
			'student'			=> array(
				'profile'			=> array( 'name' => esc_html__('Profile', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'courses'			=> array( 'name' => esc_html__('Courses', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
				'assignments'		=> array( 'name' => esc_html__('Assignments', 'wow-lms'), 'icon' => 'fa fa-sticky-note' ),
			),
		)
	);
}
/*$config['settings'] = array(
	'show_profile'		=> true,
	'profile_icon'		=> '',
	'user_role'			=> 'which can access the account area',
	'login_page_id'		=> get_option('login_page_id'),
	'data'				=> wowlms_profile_fields()
);
$config['tabs']['course'] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Courses', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-sticky-note"></i>',
	'support'		=> array( 'title', 'editor', 'thumbnail' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'course',
	'taxonomies'	=> array( 'course_cat' ),
);
$config['tabs']['lesson'] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Lessons', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-book"></i>',
	'support'		=> array( 'title', 'editor', 'thumbnail' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'lesson',
	//'taxonomies'	=> array( 'course_cat' ),
);
$config['tabs']['quiz'] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Quizzes', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-book"></i>',
	'support'		=> array( 'title', 'editor' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'quiz',
	//'taxonomies'	=> array( 'course_cat' ),
);
$config['tabs']['question'] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Questions', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-book"></i>',
	'support'		=> array( 'title', 'editor' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'question',
	//'taxonomies'	=> array( 'course_cat' ),
);
$config['tabs']['assignment'] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Assignments', 'wowlms' ),
	'menu_icon'		=> '<i class="fa fa-bookmark"></i>',
	'support'		=> array( 'title', 'editor', 'thumbnail' ),
	'post_status'	=> 'pending',
	'post_type'		=> 'assignment',
	//'taxonomies'	=> array( 'course_cat' ),
);*/

/**
$config['settings'] = array(
	'show_profile'		=> true,
	'profile_icon'		=> '',
	'user_role'			=> 'which can access the account area',
	'login_page_id'		=> get_option('login_page_id'),
);
$config['tabs'][] = array(
	'type'			=> 'crud',
	'menu_title'	=> esc_html__( 'Products' ),
	'support'		=> array( 'title', 'content', 'thumbnial' ),
	'post_status'	=> 'pending or draft ( default pending )',
	'menu_icon'		=> '<i class="fa fa-user"></i> or <img src="url" />',
	'post_type'		=> 'product',
	'taxonomies'	=> array( 'product_cat' ),
	'show_search'	=> true,
	'pagination'	=> 10,
	'table'			=> array(
							'title'	=> 'title',
							'category'	=> 'product_cat',
							'status'	=> 'status',
							'date'		=> 'date',
							'custom'	=> 'callback_function',
						)
);
$config['tabs'][] = array(
	'type'			=> 'wishlist',
	'menu_title'	=> esc_html__( 'Wishlist' ),
	'menu_icon'		=> '<i class="fa fa-user"></i> or <img src="url" />',
	'meta_key'		=> 'user meta key where whilch list ids are stored',
);



*/

return $config;


