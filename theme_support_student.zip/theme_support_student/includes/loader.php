<?php


require_once TSS_PLUGIN_PATH . '/includes/classes/class-dotnoation.php';
require_once TSS_PLUGIN_PATH . '/includes/classes/class-validation.php';
require_once TSS_PLUGIN_PATH . '/includes/classes/class-ajax.php';

if ( ! is_admin() ) {
	
	require_once TSS_PLUGIN_PATH . '/includes/classes/class-frontend.php';

	require_once TSS_PLUGIN_PATH . '/includes/classes/sensei-class-frontend.php';

	require_once TSS_PLUGIN_PATH . '/includes/classes/class-student-frontend.php';
}

if ( function_exists('vc_map') ) {

	vc_map(array(
		'name' => esc_html__('Student Panel', 'studentwp'),
		'base' => 'wowlsm_student_frontend',
		'class' => '',
		'category' => esc_html__('studentwp', 'studentwp'),
		'icon'  => get_template_directory_uri() . '/images/resource/graduation.png',
		'description' => esc_html__('Show about us.', 'studentwp'),
		'params' => array(
			array(
				'type'  => 'textfield',
				'heading' => esc_html__('Title', 'studentwp'),
				'param_name'  => 'title',
				'description' => esc_html__('about us.', 'studentwp'),
				'value' => array('add_text' => esc_html__('Add about us', 'studentwp')),

			)
		)
	));

	if(class_exists('LifterLMS'))

	{

		vc_map(array(
			'name' => esc_html__('Instuctor Panel', 'studentwp'),
			'base' => 'wowlsm_user_frontend',
			'class' => '',
			'category' => esc_html__('studentwp', 'studentwp'),
			'icon'  => get_template_directory_uri() . '/images/resource/graduation.png',
			'description' => esc_html__('This Shortcode is used for Lifter LMS.', 'studentwp'),
			'params' => array(
				array(
					'type'  => 'textfield',
					'heading' => esc_html__('Title', 'studentwp'),
					'param_name'  => 'title',
					'description' => esc_html__('about us.', 'studentwp'),
					'value' => array('add_text' => esc_html__('Add about us', 'studentwp')),

				)
			)
		));

	}
	else
	{
		vc_map(array(
			'name' => esc_html__('Instuctor Panel', 'studentwp'),
			'base' => 'wowlsm_user_frontend',
			'class' => '',
			'category' => esc_html__('studentwp', 'studentwp'),
			'icon'  => get_template_directory_uri() . '/images/resource/graduation.png',
			'description' => esc_html__('This Shortcode is used for Senssei.', 'studentwp'),
			'params' => array(
				array(
					'type'  => 'textfield',
					'heading' => esc_html__('Title', 'studentwp'),
					'param_name'  => 'title',
					'description' => esc_html__('about us.', 'studentwp'),
					'value' => array('add_text' => esc_html__('Add about us', 'studentwp')),

				)
			)
		));
	}

	

}

if ( ! function_exists( 'tss_template_part' ) ) {

	/**
	 * [tss_template_part description]
	 *
	 * @param  [type]  $template [description].
	 * @param  array   $vars     [description].
	 * @param  boolean $load     [description].
	 * @return string              [description]
	 */
	function tss_template_part( $template, $vars = array(), $load = true ) {


		$dir = '';
		if( function_exists('Sensei' ) ) {
			$dir = 'sensei';
		} elseif ( class_exists('LifterLMS' ) ) {
			$dir = 'lifterlms';
		}

		$locate = locate_template( 'wowlms/' . $dir . '/' . $template );


		$return = '';

		extract( $vars );

		if( $locate ) {
			$return = $locate;
		} else {
			if(file_exists(TSS_PLUGIN_PATH . 'templates/'. $dir . '/' . $template) ) {
				$return = TSS_PLUGIN_PATH . 'templates/'. $dir . '/' . $template;	
			}
		}
		
		if ( $load && $return ) {
			include $return;
		} else {
			return $return;
		}
	}
}

function tss_profile_fields() {

	$data = array(
		'user_email'	=> array(
			'type'			=> 'core',
			'validation'	=> 'valid_email',
		),
		'confirm_email'	=> array(
			'type'			=> 'core',
			'validation'	=> 'valid_email',
		),
		'description'	=> array(
			'type'			=> 'core',
			'validation'	=> '',
		),
		'first_name'	=> array(
			'type'			=> 'core',
			'validation'	=> 'alpha',
		),
		'last_name'	=> array(
			'type'			=> 'core',
			'validation'	=> 'alpha',
		),
		'country'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'numeric',
		),
		'phone'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'is_natural',
		),
		'dob'	=> array(
			'type'			=> 'meta',
			'validation'	=> '',
		),
		'avatar'	=> array(
			'type'			=> 'meta',
			'validation'	=> 'alpha',
		),

	);

	return apply_filters( 'tss_profile_fields', $data );
}

function wowlms_get_author_posts( $post_type ) {

	$current_user = wp_get_current_user();

	if ( ! $current_user ) {
		return false;
	}

	$args = array( 'post_type' => $post_type, 'post_status' => array( 'publish', 'pending', 'draft' ), 'orderby' => 'date', 'order' => 'DESC' );

	if ( ! in_array( 'administrator', $current_user->roles ) ) {
		$args['author'] = $current_user->ID;
	}

	$query = new WP_Query( $args );

	return $query;
}
function wowlms_edit_post_link( $screen ) {

	if ( ! is_user_logged_in() ) {
		return false;
	}

	$post_id = base64_encode( 'wowlmsgetpostid_'. get_the_id() ); ?>

	<a href="javascript:void(0);" data-screen="<?php echo esc_attr( $screen ); ?>" data-id="<?php echo esc_attr( $post_id ); ?>" onclick="WOWLMSOBJECT.edit_post( this );">
		<?php the_title(); ?>
	</a>

	<?php
}


/**
 * [wowlms_is_student description]
 *
 * @return [type] [description]
 */
function wowlms_is_student() {

	$role = _WSH()->option( 'student_role' );

	if ( ! $role ) {
		$role = 'subscriber';
	}

	if ( in_array( $role, wp_get_current_user()->roles ) ) {
		return true;
	}

	if ( in_array( 'administrator', wp_get_current_user()->roles ) ) {
		return true;
	}

	return false;
}

/**
 * [wowlms_is_teacher description]
 *
 * @return [type] [description]
 */
function wowlms_is_teacher() {

	$role = _WSH()->option( 'teacher_role' );

	if ( ! $role ) {
		$role = 'instructor';
	}

	if ( in_array( $role, wp_get_current_user()->roles ) ) {
		return true;
	}

	if ( in_array( 'administrator', wp_get_current_user()->roles ) ) {
		return true;
	}

	return false;
}


function wowlms_frontend_terms( $tax, $author = false ) {

	$user = get_current_user_id();
	$args = array( 'taxonomy' => $tax, 'number' => -1, 'hide_empty' => false );

	if ( $author ) {
		$args['author'] = $user;
	}
	$terms = get_terms( $args );

	$return = array( '' => esc_html__( '--Select--', 'wow-lms' ) );

	if ( ! is_wp_error( $terms ) ) {

		foreach ( $terms as $key => $value ) {
			
			$return[ $value->term_id ] = $value->name;
		}
	}

	return $return;
}


function tss_lms_frontent_instructor_tabs( $tabs ) {

	if( function_exists('Sensei') ) {
		array_merge($tabs, array('quizes'			=> array( 'name' => esc_html__('Quizes', 'wow-lms'), 'icon' => 'fa fa-quora' ),
			'questions'			=> array( 'name' => esc_html__('Questions', 'wow-lms'), 'icon' => 'fa fa-question-circle' ),
			'assignments'		=> array( 'name' => esc_html__('Assignments', 'wow-lms'), 'icon' => 'fa fa-share-square' )
		));
	}
	return $tabs;
}

add_filter('tss/lms/frontent_instructor_tabs', 'tss_lms_frontent_instructor_tabs');

/**
 * [render_meta_box_content description]
 *
 * @param  [type] $post     [description].
 * @param  [type] $callback [description].
 * @return [type]           [description]
 */
function wowlms_render_meta_box_content( $post, $callback ) {

	global $post, $cs_errors, $typenow;

	wp_nonce_field( 'cs-framework-metabox', 'cs-framework-metabox-nonce' );

	$unique     = $callback['args']['id'];
	$sections   = $callback['args']['sections'];
	$meta_value = get_post_meta( $post->ID, $unique, true );
	$transient  = get_transient( 'cs-metabox-transient' );
	$cs_errors  = $transient['errors'];
	$has_nav    = ( count( $sections ) >= 2 && $callback['args']['context'] != 'side' ) ? true : false;
	$show_all   = ( ! $has_nav ) ? ' cs-show-all' : '';
	$section_id = ( ! empty( $transient['ids'][$unique] ) ) ? $transient['ids'][$unique] : '';
	$section_id = cs_get_var( 'cs-section', $section_id );

	echo '<div class="cs-framework cs-metabox-framework">';

	echo '<input type="hidden" name="cs_section_id['. $unique .']" class="cs-reset" value="'. $section_id .'">';

	echo '<div class="cs-body'. $show_all .'">';

	if( $has_nav ) {

		echo '<div class="cs-nav">';

		echo '<ul>';
		$num = 0;
		foreach( $sections as $value ) {

			if( ! empty( $value['typenow'] ) && $value['typenow'] !== $typenow ) { continue; }

			$tab_icon = ( ! empty( $value['icon'] ) ) ? '<i class="cs-icon '. $value['icon'] .'"></i>' : '';

			if( isset( $value['fields'] ) ) {
				$active_section = ( ( empty( $section_id ) && $num === 0 ) || $section_id == $value['name'] ) ? ' class="cs-section-active"' : '';
				echo '<li><a href="#"'. $active_section .' data-section="'. $value['name'] .'">'. $tab_icon . $value['title'] .'</a></li>';
			} else {
				echo '<li><div class="cs-seperator">'. $tab_icon . $value['title'] .'</div></li>';
			}

			$num++;
		}
		echo '</ul>';

		echo '</div>';

	}

	echo '<div class="cs-content">';

	echo '<div class="cs-sections">';
	$num = 0;
	foreach( $sections as $v ) {

		if( ! empty( $v['typenow'] ) && $v['typenow'] !== $typenow ) { continue; }

		if( isset( $v['fields'] ) ) {

			$active_content = ( ( empty( $section_id ) && $num === 0 ) || $section_id == $v['name'] ) ? ' style="display: block;"' : '';

			echo '<div id="cs-tab-'. $v['name'] .'" class="cs-section"'. $active_content .'>';
			echo ( isset( $v['title'] ) ) ? '<div class="cs-section-title"><h3>'. $v['title'] .'</h3></div>' : '';

			foreach ( $v['fields'] as $field_key => $field ) {

				if ( tss_set( $field, 'hide_on_frontend' )) {
					continue;
				}

				$default    = ( isset( $field['default'] ) ) ? $field['default'] : '';
				$elem_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';

				$elem_value = ( is_array( $meta_value ) && isset( $meta_value[$elem_id] ) ) ? $meta_value[$elem_id] : $default;
				echo cs_add_element( $field, $elem_value, $unique );

			}
			echo '</div>';

		}

		$num++;
	}
	echo '</div>';

	echo '<div class="clear"></div>';

	echo '</div>';

	echo ( $has_nav ) ? '<div class="cs-nav-background"></div>' : '';

	echo '<div class="clear"></div>';

	echo '</div>';

	echo '</div>';

}

function wowlms_frontend_post_form_taxonomies_set( $post_data, $ajax_data ) {

	$post_type = tss_set( $post_data, 'post_type' );

	if ( ! $post_type ) {
		return $post_data;
	}

	$taxonomies = get_object_taxonomies( $post_type );

	$tax_terms = array();

	foreach ( $taxonomies as $tax ) {
		# code...
		$posted_data = tss_set( $ajax_data, $tax );

		if ( $posted_data ) {
			$tax_terms[ $tax ][] = $posted_data;
		}
	}

	if ( $tax_terms ) {
		$post_data['tax_input'] = $tax_terms;
	}

	return $post_data;
}

function TSS() {

	if ( ! class_exists( 'Tss' ) ) {
		require_once TSS_PLUGIN_PATH . 'includes/classes/class-tss.php';
	}

	return $GLOBALS['TSS'];
}