<?php

namespace Tss\Includes\Classes;

/**
* Courses
*
* @package WordPress
* @subpackage WowThemes LMS
* @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
* @version 1.0
*/

if ( ! defined( 'ABSPATH' ) ) {
die( 'Restricted' );
}


if ( ! class_exists( 'Tss' ) ) {
/**
* The class to register post types.
*/
class Tss
{

	/**
	* [$instance description]
	*
	* @var [type]
	*/
	public static $instance;

	/**
	* [__construct description]
	*/
	function __construct() {
	register_activation_hook( WOWLMS_PATH, array( $this, 'activation' ) );
}

/**
* [instance description]
*
* @return [type] [description]
*/
static function instance() {
if ( is_null( self::$instance ) ) {
self::$instance = new self();
}
return self::$instance;
}

/**
* [__get description]
*
* @param  [type] $name [description].
* @return [type]       [description]
*/
function __get( $name ) {

$classname = 'Tss_' . ucwords( $name );

if ( class_exists( $classname ) ) {
$this->$name = $classname::instance(); //new $classname;
} else {

$file = TSS_PLUGIN_PATH . '/includes/classes/class-' . $name . '.php';

if ( file_exists( $file ) ) {
require_once $file;
}

if ( class_exists( $classname ) ) {
$this->$name = $classname::instance();
}
}

return $this->$name;
}

function activation() {

}

function getProtectedValue( $obj,$name ) {
$array = (array)$obj;
$prefix = chr(0).'*'.chr(0);
return $array[$prefix.$name];
}
}
}

$GLOBALS['TSS'] = new Tss;

