<?php
/**
 * Courses
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}


if ( ! class_exists( 'Tss_Student_Frontend' ) ) {
	/**
	 * The class to register post types.
	 */
	class Tss_Student_Frontend
	{

		/**
		 * [$post_types description]
		 *
		 * @var array
		 */
		protected $post_types = array( 'course' );

		/**
		 * [$instance description]
		 *
		 * @var [type]
		 */
		static $instance;
		/**
		 * [__construct description]
		 */
		function __construct() {

			$this->set_screen();

			$this->set_config();

			add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
			add_shortcode( 'wowlsm_student_frontend', array( $this, 'shortcode_frontend' ) );

			
		}

		static function instance() {
			if ( is_null( self::$instance ) ) {
		      self::$instance = new self();
		    }
		    return self::$instance;
		}

		function scripts() {
			wp_enqueue_media();

			wp_register_script( 'codestar-framework-plugins', home_url('/wp-content/plugins/codestar-framework/assets/js/cs-plugins.min.js'), '', '', true );
			wp_register_script( 'codestar-framework-core', home_url( '/wp-content/plugins/codestar-framework/assets/js/cs-framework.js' ), '', '', true );
			wp_register_script( 'wowlms-shortcode-frontend', TSS_PLUGIN_URL . '/assets/js/shortcode-frontend.js', '', '', true );
			wp_enqueue_style( 'codestar-framework-core', home_url( '/wp-content/plugins/codestar-framework/assets/css/cs-framework.css' ) );
			
			wp_register_style( 'jquery-ui-style', TSS_PLUGIN_URL . '/assets/css/jquery-ui.css' );
			wp_register_style( 'jquery-ui-theme', TSS_PLUGIN_URL . '/assets/css/jquery-ui.theme.css' );

			wp_enqueue_style( array( 'jquery-ui-style', 'jquery-ui-theme' ) );
		}

		function set_screen() {
			$screen = isset( $_GET['wowscreen'] ) ? esc_attr( $_GET['wowscreen'] ) : false;

			$this->screen = $screen;
		}

		function get_screen() {
			return esc_attr( $this->screen );
		}

		function set_config() {
			$config = include TSS_PLUGIN_PATH . '/includes/resource/student-frontend.php';

			$this->_config = $config;
		}

		function get_config( $key = '' ) {

			if ( $key && isset( $this->_config[ $key ] ) ) {
				return $this->_config[ $key ];
			}

			return $this->_config;
		}

		function shortcode_frontend( $atts, $content = null ) {

			wp_enqueue_media();

			$options = apply_filters( 'cs_metabox_options', array() );

			wp_enqueue_script( array( 'jquery-ui-accordion', 'jquery-ui-datepicker', 'codestar-framework-plugins', 'codestar-framework-core', 'wowlms-shortcode-frontend' ) );

			//wp_enqueue_style( array( 'jquery-ui-style', 'jquery-ui-theme' ) );

			ob_start();

			$object = $this;
			$posts = wp_list_pluck( $options, 'post_type' );

			/**
			 * Hookup before the main content of the shortcode.
			 */
			do_action( 'wowlms_frontend_before_main' );

			tss_template_part( 'my-account/header.php', compact( 'options' ) );

			/**
			 * Hookup before the tab content area of the shortcode.
			 */
			do_action( 'wowlms_frontend_before_content' );

			if ( is_user_logged_in() ) {
				tss_template_part( 'my-account/navigation.php', compact( 'options', 'object' ) );
				tss_template_part( 'my-account/content.php', compact( 'options', 'object' ) );
			} else {

				tss_template_part( 'my-account/login.php', compact( 'object' ) );
			}

			/**
			 * Hookup after the tab content area of the shortcode.
			 */
			do_action( 'wowlms_frontend_after_content' );

			tss_template_part( 'my-account/footer.php', compact( 'options' ) );

			/**
			 * Hookup after the main content of the shortcode.
			 */
			do_action( 'wowlms_frontend_after_main' );

			return ob_get_clean();
			
		}

		function get_tabs() {

			$tabs = $this->get_config( 'tabs' );
			$settings = $this->get_config( 'settings' );

			if ( tss_set( $settings, 'show_profile' ) ) {
				$tabs['profile'] = array(
						'type'			=> 'profile',
						'menu_title'	=> esc_html__( 'Profile', 'wowlms' ),
						'menu_icon'		=> '<i class="fa fa-user"></i>',
						'fields'		=> array( 'google_plus', 'facebook', 'twitter' ),
				);
			}

			return $tabs;

		}

		function get_navigations() {

			
			$tabs = $this->get_tabs();
			$tab_keys = array_keys( $tabs );

			$screen = $this->get_screen();

			// Check whether the current screen is in configuration, otherwise return the defualt screen.
			if ( ! in_array( $screen, $tab_keys ) ) {
				$this->screen = current( $tab_keys );
			}

			return $tabs;
		}

		function nav_url( $nav_tab ) {

			$permalink = get_permalink();

			$url = add_query_arg( array( 'wowscreen' => $nav_tab ), $permalink );

			return esc_url( $url );
		}

		function process_metabox( $options, $p_type ) {


			require_once ABSPATH . '/wp-admin/includes/admin.php';

			$count = 0;

			foreach ( $options as $key => $value ) {
				
				$this->metaboxe_value = $value;

				$post_type = tss_set( $value, 'post_type' );

				if ( is_string( $post_type ) ) {

					if ( $post_type === $p_type ) $this->metabox( $post_type, $value );
					
				} else if ( is_array( $post_type ) ) {
					foreach ( $post_type as $post_type_set ) {

						if ( $post_type_set === $p_type ) $this->metabox( $post_type_set, $value );
					}
				}
			}
		}

		function metabox( $post_type, $current_tab ) {
			$post = get_default_post_to_edit( $post_type, true );
			wowlms_render_meta_box_content( $post, array( 'args' => $current_tab ) );
		}

	}

	new Tss_Student_Frontend;
}
