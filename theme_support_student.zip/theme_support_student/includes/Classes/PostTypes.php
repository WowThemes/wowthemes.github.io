<?php

namespace StudentWP\Plugin\Classes;

class PostTypes
{
	static $opt;
	static function init() {
		static::$opt = studentwp()->option();
		self::services();
		self::testimonials();
		self::gallery();
		self::static_block();
	}

	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function services() {

		$services_slug = studentwp()->get(static::$opt , 'services_permalink' , 'our-services') ;

		$services = new PostType(
			'sh_services', 
			esc_html__('Service', 'theme_support_student'), 
			esc_html__('Services', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
			'menu_icon'=>'dashicons-slides', 
			'taxonomies'=>array('services_category'),
			'public' => false,
			'publicly_queryable' => false,
		])->register();
	}

	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function testimonials() {

		$services_slug = studentwp()->get(static::$opt , 'testimonials_permalink' , 'our-services') ;

		$services = new PostType(
			'sh_testimonials', 
			esc_html__('Testimonial', 'theme_support_student'), 
			esc_html__('Testimonials', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
			'menu_icon'=>'dashicons-feedback', 
			'taxonomies'=>array('testimonials_category'),
			'public' => false,
			'publicly_queryable' => false,
		])->register();
	}
	
	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function gallery() {

		$services_slug = studentwp()->get(static::$opt , 'gallery_permalink' , 'our-services') ;

		$services = new PostType(
			'wow_gallery', 
			esc_html__('Gallery', 'theme_support_student'), 
			esc_html__('Galleries', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
			'menu_icon'=>'dashicons-format-gallery', 
		])->register();
	}
	
	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function static_block() {

		$services_slug = studentwp()->get(static::$opt , 'static_block_permalink' , 'our-services') ;

		$services = new PostType(
			'static_block', 
			esc_html__('Static Block', 'theme_support_student'), 
			esc_html__('Static Blocks', 'theme_support_student')
		);
		
		$services->setArgs([
			'menu_icon' 			=> 'dashicons-businessman',
			'public' 				=> false,
			'has_archive' 			=> false,
			'publicaly_queryable'	=> false,
			'query_var'				=> false,
			'exclude_from_search'	=> true,
			'can_export'			=> true,
			'show_in_menu' 			=> true,
			'show_in_admin_bar'		=> false,
			'show_in_nav_menus'		=> false,
			'capabilities'			=> array( 'create_posts' => true ),
			'map_meta_cap'       	=> true,
		])->register();
	}
}
