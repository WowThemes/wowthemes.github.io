<?php 

namespace StudentWP\Plugin\Classes;

class Metaboxes
{
	public static function register($metaboxes) {
		$metaboxes[] = self::layout();
		$metaboxes[] = self::posts();
		$metaboxes[] = self::services();
		$metaboxes[] = self::banner();
		$metaboxes[] = self::header_style();
		$metaboxes[] = self::wow_gallery();
		$metaboxes[] = self::testimonials();

		return $metaboxes;
	}

	/**
	 * [layout description]
	 * 
	 * @return [type] [description]
	 */
	public static function layout() {
		return array(
			'title'      => esc_html__('Layout Settings', 'theme_support_student'),
			'id'         => '_sh_layout_settings',
			'position'   => 'nomal',
			'priority'   => 'core',
			'post_types' => array('sh_services', 'page', 'lp_course', 'product', 'wow_gallery'),
			'sections'   => array(
				array(
					'id'		=> '_sh_layout_settings',
					'fields' => [
						array(
							'id'        => 'layout',
							'type'      => 'image_select',
							'title'     => esc_html__( 'Page Layout', 'theme_support_student' ),
							'options'   => array(
								'left' => get_template_directory_uri() . '/images/2cl.png',
								'full' => get_template_directory_uri() . '/images/1col.png',
								'right' => get_template_directory_uri() . '/images/2cr.png',

							),
							'default'     => 'full',
						),
						array(
							'id'        => 'sidebar',
							'type'      => 'select',
							'title'     => 'Select with Chosen',
							'data'   => 'sidebar',
						),

						array(
							'id'    => 'footer_type',
							'title'    => esc_html__( 'Before Footer Static Block', 'theme_support_student' ),
							'type'  => 'select',
							'data' => 'posts',
							'args'        => array(
								'post_type'     => 'static_block',
								'posts_per_page'    => -1,
							),
							'default_option' => esc_html__( 'No Block', 'theme_support_student' ),
							'description'       => sprintf( __( 'Manage <a href="%s" target="_blank">static blocks</a> to show before footer on blog detail page', 'theme_support_student' ), esc_url( admin_url( 'edit.php?post_type=static_block' ) ) ),
						),

				 	],
				),
				
			)
		);
	}

	/**
	 * [posts description]
	 * 
	 * @return [type] [description]
	 */
	public static function posts() {
		return array(
			'title'      => esc_html__('Post Settings', 'theme_support_student'),
			'id'         => '_sh_layout_settings',
			'position'   => 'nomal',
			'priority'   => 'core',
			'post_types' => array('post'),
			'sections'   => array(
				array(
					'id'		=> '_sh_layout_settings',
					'fields' => [
						array(
							'id'        => 'layout',
							'type'      => 'image_select',
							'title'     => esc_html__( 'Page Layout', 'theme_support_student' ),
							'options'   => array(
								'left' => get_template_directory_uri() . '/images/2cl.png',
								'full' => get_template_directory_uri() . '/images/1col.png',
								'right' => get_template_directory_uri() . '/images/2cr.png',

							),
							'default'     => 'full',
						),
						array(
							'id'        => 'sidebar',
							'type'      => 'select',
							'title'     => 'Select with Chosen',
							'data'   => 'sidebar',
						),

						array(
							'id'    => 'footer_type',
							'title'    => esc_html__( 'Before Footer Static Block', 'theme_support_student' ),
							'type'  => 'select',
							'data' => 'posts',
							'args'        => array(
								'post_type'     => 'static_block',
								'posts_per_page'    => -1,
							),
							'default_option' => esc_html__( 'No Block', 'theme_support_student' ),
							'description'       => sprintf( __( 'Manage <a href="%s" target="_blank">static blocks</a> to show before footer on blog detail page', 'theme_support_student' ), esc_url( admin_url( 'edit.php?post_type=static_block' ) ) ),
						),

						array(
							'id' => 'gallery',
							'type' => 'gallery',
							'title' => esc_html__( 'Select with Chosen', 'theme_support_student' ),
							'options' => esc_html__( 'Only choose when post format is Gallery', 'theme_support_student' ),
						),
						array(
							'id' => 'video',
							'type' => 'textarea',
							'title' => esc_html__( 'Video', 'theme_support_student' ),
							'options' => esc_html__( 'Insert the embed code of the video', 'theme_support_student' ),
							'sanitize' => false,
						),
						array(
							'id' => 'audio',
							'type' => 'textarea',
							'title' => esc_html__( 'Audio', 'theme_support_student' ),
							'options' => esc_html__( 'Insert the embed code of the audio', 'theme_support_student' ),
							'sanitize' => false,
						),
				 	],
				),
				
			)
		);
	}

	/**
	 * [services description]
	 * @return [type] [description]
	 */
	public static function services() {
		return array(
			'title'      => esc_html__('Services Settings', 'theme_support_student'),
			'id'         => 'services_settings',
			'position'   => 'nomal',
			'priority'   => 'core',
			'post_types' => array('sh_services'),
			'sections'   => array(
				array(
					'id'		=> 'services_settings',
					'fields' => [
						array(
							'id'      => 'icon',
							'type'  => 'social_media',
							'title'   => 'Icon',
							'desc'    => 'Choose Icon for Services.',
						),
						array(
							'id'              => 'sh_broucher_image',
							'type'            => 'repeater',
							'title'           => 'Add Brouchers',
							'desc'            => 'This section is used to add Brouchers.',
							'button_title'    => 'Add More broucher image',
							'accordion_title' => 'Brouchers',
							'fields'          => array(
								array(
									'id'          => 'broucher_title',
									'type'        => 'text',
									'title'       => 'Broucher Title',
									'description' => 'Enter the Broucher Title.',
								),
								array(
									'id'      => 'broucher_icon',
									'type'  => 'select',
									'title'   => 'Icon',
									'options' => studentwp_fontawesome_plug(),
									'desc'    => 'Choose Icon for Broucher.',
									'class'     => 'chosen',
								),
								array(
									'id'    => 'broucher',
									'type'  => 'media',
									'title' => esc_html__( 'broucher', 'theme_support_student' ),
									'label' => esc_html__( 'Choose the broucher', 'theme_support_student' ),
									'attributes' => array(
										'style' => 'width: 80%;',
									),
								),
							),
						),
				 	],
				),
				
			)
		);
	}

	/**
	 * [services description]
	 * @return [type] [description]
	 */
	public static function banner() {
		return array(
			'title'      => esc_html__('Banner Settings', 'theme_support_student'),
			'id'         => 'student_banner_settings',
			'position'   => 'nomal',
			'priority'   => 'core',
			'post_types' => array('sh_services', 'post', 'page', 'products', 'lp_course', 'lp_lession', 'wow_gallery'),
			'sections'   => array(
				array(
					'id'		=> 'student_banner_settings',
					'fields' => array(

						array(
							'id'    => 'bg_image',
							'type'  => 'media',
							'title' => esc_html__( 'Header Background Image', 'theme_support_student' ),
							'label' => esc_html__( 'Choose the header background image', 'theme_support_student' ),
							'attributes' => array(
								'style' => 'width: 80%;',
							),
						),
						array(
							'id'    => 'header_title',
							'type'  => 'text',
							'title' => esc_html__( 'Header Title', 'theme_support_student' ),
							'label' => esc_html__( 'Enter header title', 'theme_support_student' ),
							'attributes' => array(
								'style' => 'width: 90%;',
							),
						),

						array(
							'id'    => 'slogan',
							'type'  => 'text',
							'title' => esc_html__( 'Header Slogan', 'theme_support_student' ),
							'label' => esc_html__( 'Enter header slogan', 'theme_support_student' ),
							'attributes' => array(
								'style' => 'width: 90%;',
							),
						),


					),
				),
				
			)
		);
	}

	/**
	 * [services description]
	 * @return [type] [description]
	 */
	public static function header_style() {
		return array(
			'title'      => esc_html__('Header Style', 'theme_support_student'),
			'id'         => 'student_header_style',
			'position'   => 'side',
			'priority'   => 'core',
			'post_types' => array('page'),
			'sections'   => array(
				array(
					'id'		=> 'student_header_style',
					'fields' => array(
						array(
							'id'    => 'header_style',
							'title'    => esc_html__( 'Choose Header Style', 'theme_support_student' ),
							'type'  => 'select',
							'options'        => array(
								'default'       => esc_html__( 'Default', 'theme_support_student' ),
								'two'           => esc_html__( 'Header Style 2', 'theme_support_student' ),

							),
							'class'     => 'chosen',
							'attributes' => array(
								'style'     => 'width: 80%;',
							),
						),


					),
				),
				
			)
		);
	}
	/**
	 * [services description]
	 * @return [type] [description]
	 */
	public static function wow_gallery() {
		return array(
			'title'      => esc_html__('Gallery Settings', 'theme_support_student'),
			'id'         => 'student_gallery_settings',
			'position'   => 'side',
			'priority'   => 'core',
			'post_types' => array('wow_gallery'),
			'sections'   => array(
				array(
					'id'		=> 'student_gallery_settings',
					'fields' => array(
						array(
							'type' => 'gallery',
							'id' => 'gallery',
							'title' => esc_html__( 'Choose Image to show as gallery', 'theme_support_student' ),
						),

						array(
							'id'    => 'video',
							'type'  => 'text',
							'title' => esc_html__( 'Video Embed Code', 'theme_support_student' ),
							'label' => esc_html__( 'Enter Video Embed Code', 'theme_support_student' ),
							'attributes' => array(
								'style' => 'width: 90%;',
							),
						),
						array(
							'id'    => 'audio',
							'type'  => 'text',
							'title' => esc_html__( 'Audio Embed Code', 'theme_support_student' ),
							'label' => esc_html__( 'Enter audio Embed Code', 'theme_support_student' ),
							'attributes' => array(
								'style' => 'width: 90%;',
							),
						),
					),
				),
				
			)
		);
	}
	/**
	 * [services description]
	 * @return [type] [description]
	 */
	public static function testimonials() {
		return array(
			'title'      => esc_html__('Testimonial Settings', 'theme_support_student'),
			'id'         => 'student_testimonial_settings',
			'position'   => 'side',
			'priority'   => 'core',
			'post_types' => array('sh_testimonials'),
			'sections'   => array(
				array(
					'id'		=> 'student_testimonial_settings',
					'fields' => array(
						array(
							'type' => 'text',
							'id' => 'company',
							'title' => esc_html__( 'company', 'theme_support_student' ),
							'default' => 'Envato',
						),

						array(
							'type' => 'text',
							'id' => 'designation',
							'title' => esc_html__( 'Designation', 'theme_support_student' ),
							'default' => '',
						),
						array(
							'type' => 'text',
							'id' => 'address',
							'title' => esc_html__( 'Address', 'theme_support_student' ),
							'default' => '',
						),
						array(
							'type' => 'text',
							'id' => 'link',
							'title' => esc_html__( 'View More Link', 'theme_support_student' ),
							'default' => '',
							'description' => esc_html__( 'Leave empty to not linked', 'theme_support_student' ),
						),

					),
				),
				
			)
		);
	}
	
}