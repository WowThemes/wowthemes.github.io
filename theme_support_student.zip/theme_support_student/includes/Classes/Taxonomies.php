<?php

namespace StudentWP\Plugin\Classes;

class Taxonomies
{
	static $opt;
	static function init() {
		static::$opt = studentwp()->option();
		self::services();
		self::testimonails();
		self::gallery_tags();
	}

	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function services() {

		$services_slug = studentwp()->get(static::$opt , 'services_permalink' , 'our-services') ;

		$services = new Taxonomy(
			'services_category', 
			'sh_services', 
			esc_html__('Service Category', 'theme_support_student'), 
			esc_html__('Service Categories', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
		])->register();
	}

	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function testimonails() {

		$services_slug = studentwp()->get(static::$opt , 'services_permalink' , 'our-services') ;

		$services = new Taxonomy(
			'testimonials_category', 
			'sh_testimonials', 
			esc_html__('Category', 'theme_support_student'), 
			esc_html__('Categories', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
		])->register();
	}
	
	/**
	 * [services description]
	 * 
	 * @return [type] [description]
	 */
	static function gallery_tags() {

		$services_slug = studentwp()->get(static::$opt , 'services_permalink' , 'our-services') ;

		$services = new Taxonomy(
			'gallery_tag', 
			'wow_gallery', 
			esc_html__('Tag', 'theme_support_student'), 
			esc_html__('Tags', 'theme_support_student')
		);
		
		$services->setArgs([
			'rewrite' => $services_slug, 
			'hierarchical' => false,
		])->register();
	}
	
}