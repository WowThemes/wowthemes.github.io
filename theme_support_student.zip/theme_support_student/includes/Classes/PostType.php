<?php

namespace StudentWP\Plugin\Classes;

class PostType
{
	var $singular = '';
	var $plural = '';
	var $post_type = '';
	var $args = [];
	var $support = [];

	public function __construct( $type, $singular, $plural ) {
		$this->singular = $singular;
		$this->plural = $plural;
		$this->post_type = $type;
	}

	public function defaultLabels() {
		return [
			'name'                => '%plural%',
			'singular_name'       => '%singular%',
			'menu_name'           => '%plural%',
			'parent_item_colon'   => sprintf( esc_html__( 'Parent %s:', 'theme_support_student' ), '%singular%' ),
			'all_items'   		  => sprintf( esc_html__( 'All %s', 'theme_support_student' ), '%plural%' ),
			'view_item'   		  => sprintf( esc_html__( 'View %s', 'theme_support_student' ), '%singular%' ),
			'add_new_item'   		  => sprintf( esc_html__( 'Add New %s', 'theme_support_student' ), '%singular%' ),
			'add_new'   		  => sprintf( esc_html__( 'New %s', 'theme_support_student' ), '%singular%' ),
			'edit_item'   		  => sprintf( esc_html__( 'Edit %s', 'theme_support_student' ), '%singular%' ),
			'update_item'   		  => sprintf( esc_html__( 'Update %s', 'theme_support_student' ), '%singular%' ),
			'search_items'   		  => sprintf( esc_html__( 'Search %s', 'theme_support_student' ), '%plural%' ),
			'not_found'   		  => sprintf( esc_html__( 'No %s found', 'theme_support_student' ), '%plural%' ),
			'not_found_in_trash'  => sprintf( esc_html__( 'No %s found in Trash', 'theme_support_student' ), '%plural%' ),
		];
	}

	public function bindLabels($singular, $plural) {
		$labels = [];

		foreach( $this->defaultLabels() as $key => $value) {
			$labels[ $key ] = str_replace(['%singular%', '%plural%'], [$singular, $plural], $value);
		}

		return $labels;
	}

	public function setSupport( $args ) {
		$this->support = $args;

		return $this;
	}

	public function setArgs($args = array()) {
		$default = array(

			'label'               => $this->singular,
			'labels'              => $this->bindLabels($this->singular, $this->plural),
			'supports'            => ($this->support) ? $this->support : array( 'title', 'editor', 'thumbnail'),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'menu_icon'           => '',
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'rewrite'             => array(),
			'capability_type'     => 'post',
		);

		$this->args = wp_parse_args( $args, $default );

		return $this;
	}

	function register() {
		if( $this->post_type ) {
			register_post_type( $this->post_type, $this->args );
		}
	}
}