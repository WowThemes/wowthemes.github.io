<?php

namespace StudentWP\Plugin\Classes;

/**
 * Courses
 *
 * @package WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Frontend
{

	/**
	 * [$post_types description]
	 *
	 * @var array
	 */
	protected $post_types = array( 'course' );

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	static $instance;
	/**
	 * [__construct description]
	 */
	function __construct() {

		$this->set_screen();

		$this->set_config();

		add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		add_shortcode( 'wowlsm_user_frontend', array( $this, 'shortcode_frontend' ) );

		add_action( 'wowlms_user_account_profile_tab', array( __CLASS__, 'profile' ) );
	}

	static function instance() {
		if ( is_null( self::$instance ) ) {
	      self::$instance = new self();
	    }
	    return self::$instance;
	}

	function scripts() {
		wp_enqueue_media();

		wp_register_script( 'codestar-framework-plugins', home_url('/wp-content/plugins/codestar-framework/assets/js/cs-plugins.min.js'), '', '', true );
		wp_register_script( 'codestar-framework-core', home_url( '/wp-content/plugins/codestar-framework/assets/js/cs-framework.js' ), '', '', true );
		wp_register_script( 'wowlms-shortcode-frontend', TSS_PLUGIN_URL . '/assets/js/shortcode-frontend.js', '', '', true );
		wp_enqueue_style( 'codestar-framework-core', home_url( '/wp-content/plugins/codestar-framework/assets/css/cs-framework.css' ) );
		
		wp_register_style( 'jquery-ui-style', TSS_PLUGIN_URL . '/assets/css/jquery-ui.css' );
		wp_register_style( 'jquery-ui-theme', TSS_PLUGIN_URL . '/assets/css/jquery-ui.theme.css' );
		wp_register_style( 'tss_sheet', get_template_directory_uri() . '/css/wowlms.css' );

		wp_enqueue_style( array( 'jquery-ui-style', 'jquery-ui-theme','tss_sheet' ) );
	}

	function set_screen() {
		$screen = isset( $_GET['wowscreen'] ) ? esc_attr( $_GET['wowscreen'] ) : false;

		$this->screen = $screen;
	}

	function get_screen() {
		return esc_attr( $this->screen );
	}

	function set_config() {
		$config = include TSS_PLUGIN_PATH . '/includes/resource/frontend.php';

		$this->_config = $config['tabs']['instructor'];
	}

	function get_config( $key = '' ) {

		/*if ( $key && isset( $this->_config[ $key ] ) ) {
			return $this->_config[ $key ];
		}*/

		return $this->_config;
	}

	function shortcode_frontend( $atts, $content = null ) {

		$instructor_role = _WSH()->option('instructor_role');
		$instructor_role = ( $instructor_role ) ? $instructor_role : 'student';
		$current = wp_get_current_user();


		wp_enqueue_script( array( 'jquery-ui-accordion', 'jquery-ui-datepicker', 'codestar-framework-plugins', 'codestar-framework-core', 'wowlms-shortcode-frontend' ) );

		ob_start();

		if ( ! is_user_logged_in() ) {
			tss_template_part( 'my-account/login.php', compact( 'object' ) );
		}

		if ( in_array('administrator', $current->roles ) || in_array($instructor_role, $current->roles ) ) {


			$object = $this;

			/**
			 * Hookup before the main content of the shortcode.
			 */
			do_action( 'wowlms_frontend_before_main' );

			tss_template_part( 'my-account/header.php' );

			/**
			 * Hookup before the tab content area of the shortcode.
			 */
			do_action( 'wowlms_frontend_before_content' );

			tss_template_part( 'my-account/navigation.php', array( 'object' => $this, 'role' => 'instructor' ) );
			tss_template_part( 'my-account/content.php', compact( 'object' ) );

			/**
			 * Hookup after the tab content area of the shortcode.
			 */
			do_action( 'wowlms_frontend_after_content' );

			tss_template_part( 'my-account/footer.php' );

			/**
			 * Hookup after the main content of the shortcode.
			 */
			do_action( 'wowlms_frontend_after_main' );
		} else {

			echo $this->unauthorized();
		}

		return ob_get_clean();
		
	}

	function get_tabs() {

		$tabs = $this->get_config( 'tabs' );
		$settings = $this->get_config( 'settings' );

		if ( tss_set( $settings, 'show_profile' ) ) {
			$tabs['profile'] = array(
					'type'			=> 'profile',
					'menu_title'	=> esc_html__( 'Profile', 'theme_support_student' ),
					'menu_icon'		=> '<i class="fa fa-user"></i>',
					'fields'		=> array( 'google_plus', 'facebook', 'twitter' ),
			);
		}

		return $tabs;

	}

	function unauthorized() {
		return '<div class="alter alert-info">' .
					'<p>' . esc_html__( 'You are not authorized to view this page', 'theme_support_student' ) . '</p>' .
				'</div>';
	}

	/**
	 * @return null
	 */
	static function profile() {
		tss_template_part( 'my-account/profile.php' );
	}

	function get_navigations() {

		
		$tabs = $this->get_tabs();
		$tab_keys = array_keys( $tabs );

		$screen = $this->get_screen();

		// Check whether the current screen is in configuration, otherwise return the defualt screen.
		if ( ! in_array( $screen, $tab_keys ) ) {
			$this->screen = current( $tab_keys );
		}

		return $tabs;
	}

	function nav_url( $nav_tab ) {

		$permalink = get_permalink();

		$url = add_query_arg( array( 'wowscreen' => $nav_tab ), $permalink );

		return esc_url( $url );
	}

	public static function process_metabox( $options, $p_type ) {

		if( function_exists('Sensei') ) {
			$data = include TSS_PLUGIN_PATH . '/includes/resource/'.$p_type.'/sensei_meta.php';
		} else {
			$data = include TSS_PLUGIN_PATH . '/includes/resource/'.$p_type.'/llms_meta.php';
		}

		$current_tab = tss_set( $data, $p_type );

		wowlms_render_meta_box_content( $p_type, array( 'args' => $current_tab ) );

		return;
	}

	public static function metabox( $post_type, $current_tab ) {
		$post = get_default_post_to_edit( $post_type, true );
	}

}

