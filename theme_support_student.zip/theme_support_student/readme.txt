=== Student WordPress Plugin ===
Contributors: wptech
Donate link: https://wptech.co/
Tags: Student, Learning, LMS, University
Requires at least: 5.0
Tested up to: 5.4
Stable tag: 1.0.5
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Lifeline Donation is well designed and unique interface to collect donations. Lifeline donation can be used by NGOs, Charities. [Read Documentation](https://plugins.webinane.com/docs/lifeline-donation/)

Lifeline Donation comes with awesome styles of donations forms. It has various shortcodes to show donations forms. The shortcodes has integration with Visual Composer and Elementor. It also comes with Various blocks to show donation forms

== Installation ==

This section describes how to install the plugin and get it working.

Note: "Webinane Commerce" plugin is required for "Lifeline Donation" to work.
e.g.

1. Upload `lifeline-donation.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Go to "WP Commerce" menu to set some basic configuration

Here is demo link [http://plugins.webinane.com/webinane-donation/donation-shortcodes-for-vc/](http://plugins.webinane.com/webinane-donation/donation-shortcodes-for-vc/)
== Frequently Asked Questions ==

== Screenshots ==

1. General Settings page.  
2. Orders page  
3. In Admin orders, Add new item popup  
4. Frontend user checkout page.  
5. Frontend user Account page. 

== Changelog ==

= Version 1.0.5 =
- Fixed: Donation form validation
- Fixed: donation success page issues
- Fixed: Email template issues.
- Improved: The popup rending, now be possible using vuejs component <donation-button>

= 1.0.3 =
* Fixed issues with post_data sanization. Uses recurrsive posted data senitization.

= 1.0.2 =
* Removed Image resizing lib everywhere in VC Shortcodes and Widgets
* Fixed: PSR2 Coding Sniffers with some files.
* Fixed: Dropdown Option for donation popup that if user want to hide
* Fixed: Hide recurring option if user disabled it from settings.

== More about Lifeline Donation ==

Lifeline Donation requires [WP Commerce](http://wordpress.org/plugins/webinane-commerce) to be worked perfectly. 

From admin settings user can enable donation button to be visible in header as a last menu item. Admin also setup target amount needed for specific cause or project.

Also it comes with an Elementor widget (Donation Button) which you can place anywhere on the website to collect donations. Here is demo link [Visit the Demo](http://plugins.webinane.com/webinane-donation/donation-shortcodes-for-vc/)

=== Compatible Themes ===

- [Lifeline 2](https://themeforest.net/item/lifeline-2-an-ultimate-nonprofit-wordpress-theme-for-charity-fundraising-and-ngo-organizations/16660958)
- [Actavista](https://themeforest.net/item/actavista-a-responsive-wordpress-theme-for-politicians-and-political-organizations/23221878)
- [Deeds2](https://themeforest.net/item/deeds2-religion-and-church-wordpress-theme/24756421)

=== WPBakery Shortcodes ===

- Donation Button (You can add button anywhere on the website)
- Campaigns (4 Different Styles)
- Donation Parallax (6 Different Styles)

=== WP Widgets ===

- Donor of the Month
- Recent Donations
- Top Donors
- Urgent Campaigns
- Urgent Causes
- Urgent Projects

=== Payment Gateways ===

1- PayPal Standard (Included)
2- PayPal Express (Pro Extension)
3- Stripe for Credit Cards, SEPA, iDEAL ([Pro Extension](https://codecanyon.net/item/stripe-payment-gateway-for-lifeline-donations/24447315))
4- Braintree for Credit Cards (Pro Extension)
5- Amazon Pay (Pro Extension)
6- Authorize.net (Pro Extension)
7- 2Checkout (Pro Extension)
8- PayStack (Pro Extension)
9- PayUMoney (Pro Extension)
10- PayMaster for Russian (Pro Extension)
11- Yandex for Russian (Pro Extension)
