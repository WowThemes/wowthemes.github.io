<?php
/**
 * Date Field.
 *
 * @package     ReduxFramework/Fields
 * @author      Dovy Paukstys & Kevin Provance (kprovance)
 * @version     4.0.0
 */

defined('ABSPATH') || exit;

// Don't duplicate me!
if (!class_exists('Redux_Date_Time_Pick', false)) {
    /**
     * Main Redux_date class
     *
     * @since       1.0.0
     */
    class Redux_Date_Time_Pick extends Redux_Field
    {

        /**
         * Field Render Function.
         * Takes the vars and outputs the HTML for the field in the settings
         *
         * @since         1.0.0
         * @access        public
         * @return        void
         */
        public function render()
        {

            $id     = $this->field['id'];
            $name   = $this->field['name'];
            $suffix = $this->field['name_suffix'];
            $class  = $this->field['class'];
            $value  = $this->value;

            echo '<input
			data-id="' . esc_attr($id) . '"
			type="text"
			id="' . esc_attr($this->field['id']) . '"
			name="' . esc_attr($name . $suffix) . '"
			value="' . esc_attr($value) . '"
			class="datetimepicker regular-text ' . esc_attr($class) . '" />';

        }

        /**
         * Enqueue Function.
         * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
         *
         * @since         1.0.0
         * @access        public
         * @return        void
         */
        public function enqueue()
        {

            wp_enqueue_style(
                'redux-date-time-pick', $this->url . 'redux-date-time-pick.css', false, 'all'
            );
            // Field dependent JS
            wp_enqueue_script(array('jquery-ui-core', 'jquery-ui-datepicker', 'jquery-ui-slider'));

            wp_enqueue_script(
                'redux-time-pick', $this->url . 'redux-time-pick' . Redux_Functions::is_min() . '.js', array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker'),
                $this->timestamp,
                true
            );

            wp_enqueue_script(
                'redux-date-time-pick', $this->url . 'redux-date-time-pick.js', array('jquery', 'jquery-ui-core', 'jquery-ui-datepicker'),
                $this->timestamp,
                true
            );

        }
    }
}
