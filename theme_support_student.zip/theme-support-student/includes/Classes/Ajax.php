<?php

namespace StudentWP\Plugin\Classes;

/**
 * Courses
 *
 * @package WordPress
 * @subpackage WowThemes LMS
 * @author Shahbaz Ahmed <shahbazahmed9@hotmail.com>
 * @version 1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( 'Restricted' );
}



/**
 * The class to register post types.
 */
class Ajax
{

	function __construct() {
		add_action('wp_ajax__wowlms_ajax_callback', [ $this, 'init'] );
	}

	/**
	 * [$instance description]
	 *
	 * @var [type]
	 */
	public static $instance;

	static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}


	function init() {

		$method = esc_attr( tss_set( $_REQUEST, 'subaction' ) );

		if ( method_exists( $this, $method ) ) {
			$this->$method( $_REQUEST );
		}

		exit();
	}

	/**
	 * This function hooked up when an instructor submit the form for 
	 * add/edit post or custom post types.
	 * 
	 * @param  The posted data.
	 *
	 * @return Returns the json response.
	 */
	function post_form( $data ) {

		$post_data = array();
		$current_user = wp_get_current_user();

		//check_ajax_referer( 'cs-framework-metabox-nonce', 'cs-framework-metabox' );

		if ( ! is_user_logged_in() ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized', 'theme_support_student' ) ) );
		}

		if ( ! current_user_can('edit_posts') ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized to do this', 'theme_support_student' ) ) );
		}
		

		if ( wp_verify_nonce( tss_set( $data, 'cs-framework-metabox-nonce' ), 'cs-framework-metabox' ) ) {

			$post_ID = tss_set( $data, 'post_ID' );

			if ( $value = tss_set( $data, 'post_title' ) ) {
				$post_data['post_title'] = $value;
			}

			if ( $value = tss_set( $data, 'post_content' ) ) {
				$post_data['post_content'] = $value;
			}

			if ( $post_ID ) {
				$post_data['ID'] = $post_ID;
			}



			$post_meta = tss_set($data,'_sh_layout_settings');
			
			$post_data['post_type'] = tss_set( $data, 'post_type' );
			$post_data['post_status'] = in_array( 'administrator', $current_user->roles ) ? 'publish' : 'pending';

			// Attach the terms data with the array
			$post_data = wowlms_frontend_post_form_taxonomies_set( $post_data, $data );

			if ( $post_ID && is_numeric( $post_ID ) ) {

				$post_id = wp_update_post( $post_data, true );


				if(  ! empty($post_meta))
				{
					foreach( $post_meta as $kay => $value)
					{
							print_r($kay);
						update_post_meta($post_ID, $kay, $value);

					}
				}

			} else {

				$post_id = wp_insert_post( $post_data, true );


				if(  ! empty($post_meta))
				{
					foreach( $post_meta as $kay => $value)
					{

						update_post_meta($post_id, $kay, $value);

					}
				}
			}

			if ( ! is_wp_error(  $post_id ) ) {

				$wp_post = get_post( $post_id );

				// Allow plugins to update the post meta.
				do_action( 'save_post', $post_id, $wp_post );

				// Check if post type support thumbnail, then set the post thumbnail.
				if ( post_type_supports( $wp_post->post_type, 'thumbnail' ) ) {
					if ( $thumbnail = tss_set( $data, 'thumbnail' ) ) {
						set_post_thumbnail( $post_id, $thumbnail );
					}
				}
			}

			wp_send_json( array( 'status' => 'success', 'msg' => esc_html__( 'Updated successfully', 'theme_support_student' ) ) );

		}
	}

	function edit_post_form( $data ) {


		//check_ajax_referer( 'cs-framework-metabox-nonce', 'cs-framework-metabox' );
		check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized', 'theme_support_student' ) ) );
		}
		
		if ( ! current_user_can('read') ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized to do this', 'theme_support_student' ) ) );
		}

		$post_id = tss_set( $data, 'post_id' );

		if ( ! $post_id ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'Invalide params', 'theme_support_student' ) ) );
		}

		$post_id = str_replace( 'wowlmsgetpostid_', '', base64_decode( $post_id ) );


		if ( ! is_numeric( $post_id ) ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'Invalide params for post id', 'theme_support_student' ) ) );
		}

		$query = new WP_Query( array( 'post__in' => array( $post_id ), 'posts_per_page' => 1, 'post_type' => get_post_types() ) );
		//printr(get_post_types());
		if ( ! $query->have_posts() ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'No post found for the given ID', 'theme_support_student' ) ) );
		}

		if(class_exists('LifterLMS')){

			if ( ! class_exists( 'Wowlms_Frontend' ) ) {
				require_once TSS_PLUGIN_PATH . '/includes/classes/class-frontend.php';
			}

			$object = Wowlms_Frontend::instance();
			


		}else{


			if ( ! class_exists( 'Wowlms_Sensei_Frontend' ) ) {
				require_once TSS_PLUGIN_PATH . '/includes/classes/sensei-class-frontend.php';
			}

			$object = Wowlms_Sensei_Frontend::instance();

		}


		$options = apply_filters( 'cs_metabox_options', array() );
		
		$screen = tss_set( $data, 'screen' );
		$current_tab = '';//tss_set( $object->get_tabs(), $screen );

		while( $query->have_posts() ) : $query->the_post();

			$post_type = get_post_type();

			tss_template_part( 'instructor/' . $screen . '/post-form.php', compact( 'post_type', 'current_tab', 'object', 'options' ) );
		endwhile;

		wp_reset_postdata();
	}


	function add_post_form( $data ) {

		check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

		if ( ! is_user_logged_in() ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized', 'theme_support_student' ) ) );
		}
		
		if ( ! current_user_can('read') ) {
			wp_send_json( array( 'status' => 'error', 'msg' => esc_html__( 'You are not authorized to do this', 'theme_support_student' ) ) );
		}

		if(class_exists('LifterLMS')){

			if ( ! class_exists( 'Wowlms_Frontend' ) ) {
				require_once TSS_PLUGIN_PATH . '/includes/classes/class-frontend.php';
			}
			$object = Wowlms_Frontend::instance();
			
		}
		else{


			if ( ! class_exists( 'Wowlms_Sensei_Frontend' ) ) {
				require_once TSS_PLUGIN_PATH . '/includes/classes/sensei-class-frontend.php';
			}

			$object = Wowlms_Sensei_Frontend::instance();
			
		}

		$options = apply_filters( 'cs_metabox_options', array() );
		$screen = tss_set( $data, 'screen' );
		$current_tab = '';


		$post_type = $screen;

		tss_template_part( 'instructor/'. $screen .'/post-form.php', compact( 'post_type', 'current_tab', 'object', 'options' ) );


	}

	function submit_assignment() {

		if ( isset( $_POST['comment'] ) ) {

			if ( isset( $_FILES['assignment_file'] ) ) {

				$res = WOWLMS()->assignments->assignment_comment();

				exit( $res );

			}
		}
	}

	function profile_form() {

		check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

		if ( ! is_user_logged_in() ) {
			exit( '<div class="alert alert-danger">' . esc_html__( 'Restricted Access. Please contact the administrator', 'theme_support_student' ) . '</div>' );
		}

		tss_template_part( 'my-account/profile-edit.php' );
	}

	/**
	 * Update user profile;
	 */
	function update_profile() {

		check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

		if ( ! is_user_logged_in() ) {
			exit( '<div class="alert alert-danger">' . esc_html__( 'Restricted Access. Please contact the administrator', 'theme_support_student' ) . '</div>' );
		}

		$pdata = new \Tss_Dotnotation( $_POST );

		$fields = tss_profile_fields();

		$validation = TSS()->validation;

		$core = $meta = array();

		$date 	= tss_set( $_POST, 'dob_date' );
		$month 	= tss_set( $_POST, 'dob_month' );
		$year 	= tss_set( $_POST, 'dob_year' );

		if ( $date && $month && $year ) {
			$_POST['dob'] = $year . '-' . $month . '-' . $date;
		}

		if ( $pdata->get( 'user_email' ) && $pdata->get('confirm_email') ) {
			if ( $pdata->get( 'user_email' ) !== $pdata->get('confirm_email') ) {
				exit('<div class="alert alert-error">'.__('Error! Email and Confirm email do not match', 'theme_support_student') . '</div>');
			}
		} else {
			unset( $fields['user_email'] );
			unset( $fields['confirm_email'] );
		}



		foreach ( $fields as $key => $value) {
			
			$validation->set_rules( $key, $key, $value['validation'] );

			if ( 'core' === $value['type'] ) {
				$core[ $key ] = tss_set( $_POST, $key );
			} else if ( 'meta' === $value['type'] ) {
				$meta[ $key ] = tss_set( $_POST, $key );
			}
		}

		if ( $validation->run() !== FALSE && empty( $t->validation->_error_array ) ) {

			$current_user = wp_get_current_user();
			$core['ID'] = $current_user->ID;

			wp_update_user( $core );

			foreach ( $meta as $key => $value) {
				update_user_meta( $current_user->ID, $key, $value );
			}

		} else {
			if ( is_array( $validation->_error_array ) ) {

				foreach ( $validation->_error_array as $msg ) {
					$messages .= '<div class="alert alert-error">'.__('Error! ', 'theme_support_student').$msg.'</div>';
				}
			}
			exit($messages);
		}
		exit('success');
	}


	/**
	 * @return [type]
	 */
	function nav_menu() {
		
		check_ajax_referer( 'studentwp_ajax_nonce', 'ajax_nonce' );

		if ( ! is_user_logged_in() ) {
			exit( '<div class="alert alert-danger">' . esc_html__( 'Restricted Access. Please contact the administrator', 'theme_support_student' ) . '</div>' );
		}

		$available_roles = array( 'administrator', 'instructor', 'student' );

		$current_user = wp_get_current_user();

		$menu = esc_attr( tss_set( $_POST, 'nav' ) );
		$role = esc_attr( tss_set( $_POST, 'role' ) );

		$config = include TSS_PLUGIN_PATH . '/includes/resource/frontend.php';
		$valid = false;

		if( in_array( 'administrator', $current_user->roles ) && in_array($role, $available_roles) ) {
			$valid = true; 
		}

		if( in_array($role, $available_roles) ) {
			foreach ( $available_roles as $a_role ) {
				
				if ( in_array( $a_role, $current_user->roles ) ) {
					$valid = true;
				}
			}
		}

		if ( $valid ) {

			tss_template_part( $role . '/' . $menu . '/list.php');
		}
	}
}

