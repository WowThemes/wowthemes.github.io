<?php

namespace StudentWP\Plugin\Classes;

/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
class Taxonomy
{
	var $singular = '';
	var $plural = '';
	var $post_type = '';
	var $taxonomy = '';
	var $args = [];
	var $support = [];

	public function __construct( $taxonomy, $type, $singular, $plural ) {
		$this->singular = $singular;
		$this->plural = $plural;
		$this->post_type = $type;
		$this->taxonomy = $taxonomy;
	}

	public function defaultLabels() {
		
		return [
			'name'              => '%plural%',
			'singular_name'     => '%singular%',
			'search_items'   	=> sprintf( esc_html__( 'Search %s', 'theme_support_student' ), '%plural%' ),
			'popular_items'   	=> sprintf( esc_html__( 'Popular %s', 'theme_support_student' ), '%plural%' ),
			'all_items'   		=> sprintf( esc_html__( 'All %s', 'theme_support_student' ), '%plural%' ),
			'parent_item'   	=> sprintf( esc_html__( 'Parent %s', 'theme_support_student' ), '%singular%' ),
			'parent_item_colon'   => sprintf( esc_html__( 'Parent %s:', 'theme_support_student' ), '%singular%' ),
			'edit_item'			=> sprintf( esc_html__( 'Edit %s', 'theme_support_student' ), '%singular%' ),
			'update_item'   	=> sprintf( esc_html__( 'Update %s', 'theme_support_student' ), '%singular%' ),
			'add_new_item'   	=> sprintf( esc_html__( 'Add New %s', 'theme_support_student' ), '%singular%' ),
			'new_item_name'   	=> sprintf( esc_html__( 'New %s Name', 'theme_support_student' ), '%singular%' ),
			'add_or_remove_items' => sprintf( esc_html__( 'Add or remove %s', 'theme_support_student' ), '%plural%' ),
			'choose_from_most_used' => sprintf( esc_html__( 'Choose from most used %s', 'theme_support_student' ), '%plural%' ),
			'menu_name'           => '%plural%',
		];
	}

	/**
	 * Replace labels
	 * 
	 * @param  [type] $singular [description]
	 * @param  [type] $plural   [description]
	 * @return array           [description]
	 */
	public function bindLabels($singular, $plural) {
		$labels = [];

		foreach( $this->defaultLabels() as $key => $value) {
			$labels[ $key ] = str_replace(['%singular%', '%plural%'], [$singular, $plural], $value);
		}

		return $labels;
	}

	/**
	 * Setsupport.
	 * 
	 * @param object $args [description]
	 */
	public function setSupport( $args ) {
		$this->support = $args;

		return $this;
	}

	/**
	 * Set args.
	 *
	 * @param array $args
	 */
	public function setArgs($args = array()) {
		$default = array(
			'labels'              => $this->bindLabels($this->singular, $this->plural),
			'public'            => true,
			'show_in_nav_menus' => true,
			'show_admin_column' => true,
			'hierarchical'      => true,
			'show_tagcloud'     => true,
			'show_ui'           => true,
			'query_var'         => true,
			'rewrite'           => true,
			'query_var'         => true,
			'capabilities'      => array(),
		);

		$this->args = wp_parse_args( $args, $default );

		return $this;
	}

	/**
	 * Register taxonomy.
	 *
	 * @return [type] [description]
	 */
	function register() {
		if( $this->post_type && $this->taxonomy ) {
			register_taxonomy( $this->taxonomy, $this->post_type, $this->args );
		}
	}
}
