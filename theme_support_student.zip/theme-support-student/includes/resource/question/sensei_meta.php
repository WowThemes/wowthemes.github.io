<?php 

// Posts Layouts settings
$options['lesson']    = array(
	'id'        => '_sh_layout_settings',
	'title'     => esc_html__('Post Settings', 'theme_support_student'),
	'post_type' => array( 'question' ),
	'context'   => 'normal',
	'priority'  => 'high',
	'sections'  => array(

		array(
			'name'   => '_sh_General_settings',
			'title'  =>'General',
			'fields' => array(

				array(
					'id'        => '_lesson_prerequisite',
					'type'      => 'select',
					'title'     => esc_html__('Choose Prerequisite', 'theme_support_student' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'lesson',
						'order'        => 'DESC',
					)
				),
				array(
					'id'        => '_lesson_course',
					'type'      => 'select',
					'title'     => esc_html__('Course', 'theme_support_student' ),
					'options'        => 'posts',
					'class'			  => 'chosen',
					'query_args'     => array(
						'post_type'    => 'Course',
						'order'        => 'DESC',
					),
				),

				array(
					'id'        => '_lesson_length',
					'type'      => 'number',
					'title'     => esc_html__('Lesson Length in minutes', 'theme_support_student' ),
				),

				array(
					'id'        => '_lesson_complexity',
					'type'      => 'select',
					'title'     => esc_html__('Lesson Complexity', 'theme_support_student' ),
					'options'   => array(

						''     => esc_html__('None', 'theme_support_student' ),
						'easy' => esc_html__('Easy' , 'theme_support_student'),
						'std'  => esc_html__('Stanard', 'theme_support_student' ),
						'hard' => esc_html__('Hard ', 'theme_support_student'),
						

					),
					'class'   => 'chosen',

				),

				array(
					'id'    => '_lesson_video_embed',
					'type'  => 'textarea',
					'title' => esc_html__('Video Embed Code:', 'theme_support_student' ),
					'desc'  => esc_html__('Paste the embed code for your video (e.g. YouTube, Vimeo etc.) in the box above.', 'theme_support_student' ),
				),

				
			),
		),

	),
);


return $options;