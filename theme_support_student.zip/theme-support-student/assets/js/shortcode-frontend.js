

jQuery(document).ready(function($){



	$('body').on( 'click', '.cs-framework form input[type=cancel]', function(e){

		if ( confirm( 'Are you sure to cancel it?' ) ) {
			var parent = $(this).parents('.tab-pane');
			parent.find('.table.table-bordered').removeClass('hide');
			parent.find('.cs-framework.row .wowlms-display').addClass('hide');
		}
	});
	//$('input[data-depend-id], select[data-depend-id], textarea[data-depend-id]');
	//$('input[data-depend-id=duration]').prop('checked', 'checked');
	//$('input[data-depend-id=duration]').trigger('click');
});

var WOWLMSOBJECT = {};

(function($){

	var tab_container = $('.tab-container.dashboard');
	var ajax_args = {action: '_wowlms_ajax_callback', ajax_nonce: studentwp_ajax_nonce };

	WOWLMSOBJECT = {

		ajax_wrapper: $('#ajax_processing_wrapper'),

		edit_post: function(object) {
			var $ = jQuery;
			var ajax_wrapper = this.ajax_wrapper;

			if ( studentwp_ajax_nonce === undefined ) {
				studentwp_ajax_nonce = '';
			}

			var post_id = $(object).data('id'),
			panel = $(object).parents('.tab-pane'),
			data = {action: '_wowlms_ajax_callback', subaction: 'edit_post_form', ajax_nonce: studentwp_ajax_nonce };

			if ( ! post_id ) {
				//alert('Invalid Post ID');
				data.subaction = 'add_post_form';
			}

			data.post_id = post_id;
			data.screen = $(object).data('screen');
			
			tab_container.addClass('processing').block();

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: data,
				success: function(res) {
					//$('.cs-framework').html( $(res).children() );

					//panel.find('.cs-framework .wowlms-display').removeClass('hide');
					//panel.find('.table').addClass('hide');
					panel.html(res);

					$('.cs-framework').CSFRAMEWORK_TAB_NAVIGATION();
				    $('.cs-reset-confirm, .cs-import-backup').CSFRAMEWORK_CONFIRM();
				    $('.cs-content, .wp-customizer, .widget-content, .cs-taxonomy').CSFRAMEWORK_DEPENDENCY();
				    $('.cs-field-group').CSFRAMEWORK_GROUP();
				    $('.cs-save').CSFRAMEWORK_SAVE();
				    $('.cs-taxonomy').CSFRAMEWORK_TAXONOMY();
				    $('.cs-framework, #widgets-right').CSFRAMEWORK_RELOAD_PLUGINS();
				    $.CSFRAMEWORK.ICONS_MANAGER();
				    $.CSFRAMEWORK.SHORTCODE_MANAGER();
				    $.CSFRAMEWORK.WIDGET_RELOAD_PLUGINS();

				    $('.cs-field-date-picker').each(function(i, e){
		                var format = $(this).data('date-format');

		                $(this).datepicker( { "dateFormat": format } );
		            })
				},
				complete: function(res) {
					tab_container.removeClass('processing').unblock();
				}
			});
		}, 


		edit_profile_form: function( object ) {
			
			var $ = jQuery;
			var ajax_wrapper = $('#ajax_processing_wrapper');

			if ( studentwp_ajax_nonce === undefined ) {
				studentwp_ajax_nonce = '';
			}

			post_id = $(object).data('id'),
			panel = $(object).parents('.tab-pane'),
			data = {action: '_wowlms_ajax_callback', subaction: 'profile_form', ajax_nonce: studentwp_ajax_nonce };

			data.screen = $(object).data('screen');
			//ajax_wrapper.removeClass('hide');

			tab_container.addClass('processing').block();

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: data,
				success: function(res) {

					if ( res !== '' ) {
						$('#profile #ajax-response').html( res ).removeClass('hide');

						$('#profile #profile-view-area').addClass('hide');
					}
				},
				complete: function( res) {
					//ajax_wrapper.addClass('hide');
					tab_container.unblock();
				}
			});
		},

		cancel_profile_edit : function( object ) {

			var $ = jQuery;
			$('#profile #profile-view-area').removeClass('hide');
			$('#profile #ajax-response').addClass('hide');
		},

		update_profile_settings :  function( object ) {

			var $ = jQuery;
			var ajax_wrapper = this.ajax_wrapper;

			if ( studentwp_ajax_nonce === undefined ) {
				studentwp_ajax_nonce = '';
			}

			panel = $(object).parents('.tab-pane'),
			data = {action: '_wowlms_ajax_callback', subaction: 'update_profile', ajax_nonce: studentwp_ajax_nonce };

			data.screen = $(object).data('screen');

			var thisformdata = $(object).serializeArray();
			$.each( thisformdata, function(ind, elem ){
				data[elem.name] = elem.value;
			});

			//ajax_wrapper.removeClass('hide');
			tab_container.addClass('processing').block();

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: data,
				success: function(res) {

					console.log(res.indexOf('success'));
					if ( res.indexOf('success') > -1 ) {
						$('#profile #ajax-response').html( res ).addClass('hide');

						$('#profile #profile-view-area').removeClass('hide');

						window.location = location.href;
					}
				},
				complete: function( res) {
					tab_container.removeClass('processing').unblock();
				}
			});

			return false;
		},

		post_form: function() {

			$('body').on( 'submit', '.cs-framework form', function(e){

				e.preventDefault();

				if ( studentwp_ajax_nonce === undefined ) {
					var studentwp_ajax_nonce = '';
				}

				var panel = $(this).parents('.tab-pane'),
				data = {action: '_wowlms_ajax_callback', subaction: 'post_form', ajax_nonce: studentwp_ajax_nonce };

				tab_container.addClass('processing').block();

				$.each( $(this).serializeArray(), function(i, el){
					data[el.name] = el.value;
				});

				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: data,
					success: function(res) {

					},
					complete: function(res) {
						tab_container.removeClass('processing').unblock();
					}
				});
				return false;
			});
		},

		menu_event: function() {
			tab_container.find('.tabs > li').on('click', function(e){
				e.preventDefault();

				var anchor = $(this).children(),
				nav = anchor.data('nav'),
				role = anchor.data('role'),
				thisis = this,
				data = $.extend( ajax_args, {subaction: 'nav_menu', nav: nav, role: role});

				tab_container.addClass('processing').block();

				$.ajax({
					url: ajaxurl,
					type: 'POST',
					data: data,
					success: function(res) {
						if( res !== '' ) {
							tab_container.find('.tabs > li').removeClass('active');
							$(thisis).addClass('active');
							tab_container.find('.tab-pane.fade').html(res);
						}
					},
					complete: function(res) {
						tab_container.unblock();
					}
				});
			});
		}
	};

	$(document).ready(function(){
		WOWLMSOBJECT.post_form();
		WOWLMSOBJECT.menu_event();
	});
})(jQuery);

