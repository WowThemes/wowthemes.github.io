<?php

/**
* 
*/
class SumbaKit_Metaboxes
{
	
	static function load() {

		add_action( 'cmb2_admin_init', array( __CLASS__, 'metaboxes') );
	}

	static function metaboxes() {

		global $wp_registered_sidebars;
		$sidebars = wp_list_pluck( $wp_registered_sidebars, 'name', 'id' );

		require_once SUMBAKIT_PATH . 'includes/metaboxes/layout.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/banner.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/team.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/pricing-table.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/service.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/history.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/job.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/portfolio.php';
		require_once SUMBAKIT_PATH . 'includes/metaboxes/header.php';
	}
}