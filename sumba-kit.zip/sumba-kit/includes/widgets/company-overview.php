<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Company_Overview_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-company-overview-widget', 'description' => esc_html__('Show the pages related to company overview', 'sumba-kit') );
		parent::__construct( 'sumba-company-overview-widget', esc_html__('Sumba: Company Overview', 'sumba-kit'), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) ) {
			return;
		}

		if(function_exists('sumbawp_set')):

			$options        = Sumbawp_Base::option();

			$all_companies = $options->get('company-over-views');

			?>

			<div class="company-overview-widget sumba-widget widget-bg" style="background-image: url(<?php echo esc_url(sumbawp_set( $instance,'image_url')); ?>);">

				<div class="company-overview" >

					<header>
						<h3 class="widget-title-one"><?php echo sumbawp_set( $instance,'title'); ?></h3>
					</header>
					<?php

					if(!empty($all_companies)):


						$comp_repeater = sumbawp_set($all_companies,'redux_repeater_data');

						$counter       = 0;

						?>
						<ul class="unstyled">
							<?php 

							foreach($comp_repeater as $repeater):

								$label = sumbawp_set(sumbawp_set($all_companies,'label'),$counter);

								$link = sumbawp_set(sumbawp_set($all_companies,'link'),$counter);

								?>

								<li>

									<a href="<?php echo esc_url($link); ?>">

										<?php echo esc_html($label); ?>

									</a>

								</li>


								<?php

								$counter++;

							endforeach;

							?>

						</ul>

					<?php endif; ?>

					<?php if(sumbawp_set( $instance,'show_btn')) : ?>

						<a href="<?php echo sumbawp_set( $instance,'btn_url'); ?>" class="btn btn-primary-grdnt">

							<?php echo sumbawp_set( $instance,'btn_title'); ?>


						</a>

					<?php endif; ?>
				</div>
			</div>

			<?php 

		endif;



		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(

			'title'     => '',

			'show_btn'  => '',

			'btn_title' => '',

			'btn_url'   =>  '',

			'image_url' => ''
		) );

		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('image_url')) ?>">
				<?php esc_html_e( 'Background Picture Link', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('image_url')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('image_url')) ?>" value="<?php echo esc_attr( $instance['image_url'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'show_btn' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'show_btn' ); ?>" name="<?php echo $this->get_field_name( 'show_btn' ); ?>" /> 
			<label for="<?php echo $this->get_field_id( 'show_btn' ); ?>">Show Contact Button</label>

		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('btn_title')) ?>">
				<?php esc_html_e( 'Contact Button Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('btn_title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('btn_title')) ?>" value="<?php echo esc_attr( $instance['btn_title'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('btn_url')) ?>">
				<?php esc_html_e( 'Contact Button Link', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('btn_url')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('btn_url')) ?>" value="<?php echo esc_attr( $instance['btn_url'] ) ?>">
		</p>

		<p>
			<label>
				<?php esc_html_e( 'Note: Add Company Features From Theme Settings', 'sumba-kit' ) ?>
			</label>

		</p>

		<?php
	}
}

register_widget( 'SumbaKit_Company_Overview_Widget' );
