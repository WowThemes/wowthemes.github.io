<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Specialist_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-specialist-widget', 'description' => esc_html__('Show a team member', 'sumba-kit') );
		parent::__construct( 'sumba-specialist-widget', esc_html__('Sumba: Specialist', 'sumba-kit'), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) ) {
			return;
		}

		if(class_exists('sumba_kit_Resizer'))
			$img_obj = new sumba_kit_Resizer();
		
		?>

		<div class="speclst-widget sumba-widget">
			<header>
				<h3 class="widget-title-one colr2">

					<?php echo sumbawp_set( $instance,'name'); ?>

				</h3>
			</header>

			<div class="member">
			<figure>

				<?php if(sumbawp_set( $instance,'image_url')) ?>

				<?php if(class_exists('sumba_kit_Resizer')):?>

					<?php echo balanceTags($img_obj->sumba_kit_resize(sumbawp_set( $instance,'image_url') , 200, 270, true)); ?>
					
					<?php else:?>

						<img src="<?php echo esc_html(sumbawp_set( $instance,'image_url')); ?>" alt="<?php  esc_html__('Imag Not Found','sumba-kit'); ?>">

					<?php endif;?>  

					

				</figure>

				<h3 class="colr2"><?php echo sumbawp_set( $instance,'title'); ?></h3>

				<p><?php echo sumbawp_set( $instance,'text'); ?></p>

				<a href="<?php echo sumbawp_set( $instance,'btn_url'); ?>" class="btn btn-primary-grdnt">

					<?php echo sumbawp_set( $instance,'btn_title'); ?>


				</a>
			</div>
		</div>
			<?php
		//echo $args['before_title'];
		//echo 'Title'; // Can set this with a widget option, or omit altogether
		//echo $args['after_title'];

		// Widget display logic goes here

			echo $args['after_widget'];
		}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(

			'text'      => '',

			'title'     => '',

			'btn_url'   => '',

			'btn_title' => '',

			'show_btn'  => '',

			'name'      => '',

			'image_url' => '',



		) );

		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('name')) ?>">
				<?php esc_html_e( 'Specialist Name', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('name')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('name')) ?>" value="<?php echo esc_attr( $instance['name'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('image_url')) ?>">
				<?php esc_html_e( 'Specialist Pictur Link', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('image_url')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('image_url')) ?>" value="<?php echo esc_attr( $instance['image_url'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('text')) ?>">
				<?php esc_html_e( 'Text', 'sumba-kit' ) ?>
			</label>
			<textarea name="<?php echo esc_attr( $this->get_field_name('text')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('text')) ?>" row="4"><?php echo esc_attr( $instance['text'] ) ?></textarea>
		</p>

		<p>
			<input class="checkbox" type="checkbox" <?php checked( $instance[ 'show_btn' ], 'on' ); ?> id="<?php echo $this->get_field_id( 'show_btn' ); ?>" name="<?php echo $this->get_field_name( 'show_btn' ); ?>" /> 
			<label for="<?php echo $this->get_field_id( 'show_btn' ); ?>">Show Contact Button</label>

		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('btn_title')) ?>">
				<?php esc_html_e( 'Contact Button Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('btn_title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('btn_title')) ?>" value="<?php echo esc_attr( $instance['btn_title'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('btn_url')) ?>">
				<?php esc_html_e( 'Contact Button Link', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('btn_url')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('btn_url')) ?>" value="<?php echo esc_attr( $instance['btn_url'] ) ?>">
		</p>


		<?php

		// display field names here using:
		// $this->get_field_id( 'option_name' ) - the CSS ID
		// $this->get_field_name( 'option_name' ) - the HTML name
		// $instance['option_name'] - the option value
	}
}


register_widget( 'SumbaKit_Specialist_Widget' );
