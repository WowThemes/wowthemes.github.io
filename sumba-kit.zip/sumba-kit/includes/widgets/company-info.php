<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Company_Info_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-company-info-widget', 'description' => esc_html__('Show the company info, address, email phone etc', 'sumba-kit') );
		parent::__construct( 'sumba-company-info-widget', esc_html__( 'Sumba: Company Info', 'sumba-kit' ), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) ) {
			return;
		}
		?>

		<div class="cmpny-info-widget footer-widget">
		
			<h4><?php echo wp_kses_post( $instance['title'] ) ?></h4>
		
		
		<?php $company_info = Sumbawp_Base::option('company_info'); ?>

		<?php if ( $company_info ) : ?>

			<ul class="unstyled">
				<?php foreach( $company_info['type'] as $key => $type ) : ?>

					<?php
					$info = sumbawp_set( $company_info['info'], $key );
					if ( $type == 'email' ) {
						$info = sprintf('<a href="mailto:%s">%s</a>', sanitize_email( $info ), sanitize_email( $info ) );
					}
					if ( $type == 'link' ) {
						$info = sprintf('<a href="%s">%s</a>', esc_url( $info ), esc_attr( $info ) );
					}
					?>
					<li>
						<label><?php echo wp_kses_post( sumbawp_set( $company_info['label'], $key ) ) ?></label>
						<p><?php echo wp_kses_post( $info ) ?></p>
					</li>
				<?php endforeach; ?>
				
			</ul>

		<?php endif; ?>
	</div>
		<?php 
		//echo $args['before_title'];
		//echo 'Title'; // Can set this with a widget option, or omit altogether
		//echo $args['after_title'];

		// Widget display logic goes here

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' 		=> esc_html__( 'About Us', 'sumba-kit' ),
		) );

		// display field names here using:
		// $this->get_field_id( 'option_name' ) - the CSS ID
		// $this->get_field_name( 'option_name' ) - the HTML name
		// $instance['option_name'] - the option value
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>
		<small><em><?php esc_html_e('Fill in all contact info in theme options', 'sumba-kit') ?></em></small>
		<?php
	}
}


register_widget( 'SumbaKit_Company_Info_Widget' );
