<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Tweets_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-tweets-widget', 'description' => esc_html__('Show the twitter tweets from specific twitter id', 'sumba-kit') );
		parent::__construct( 'sumba-tweets-widget', esc_html__( 'Sumba: Tweets', 'sumba-kit' ), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) ) {
			return;
		}
		?>
		<div class="twiter-widget footer-widget">
		
			<h4><?php echo wp_kses_post( $instance['title'] ) ?></h4>
		

		<?php 
		$encoded = base64_encode( json_encode($instance) );
		$exists = get_transient( 'sumbawp_widget_twitter' );

		if ( ! $exists ) {
			$exists[$encoded] = $this->fetch($instance);
			set_transient( 'sumbawp_widget_twitter', $exists, 12 * HOUR_IN_SECONDS );
		}

		?>
		
		<?php if ( $exists && !sumbawp_set( current($exists), 'errors' ) ) : ?>
			
			<?php 
			if ( ! sumbawp_set( $exists, $encoded ) ) {
				$exists[$encoded] = $this->fetch( $instance );
				set_transient( 'sumbawp_widget_twitter', $exists, 12 * HOUR_IN_SECONDS );
			}
			?>
			<?php if ( $found = sumbawp_set( $exists, $encoded ) ) :
				
				if( isset($found['httpstatus']) ) {
					unset($found['httpstatus']);
				}
				if( isset($found['rate']) ) {
					unset($found['rate']);
				}

				foreach( $found as $single ) :  ?>

					<div class="tweet">
						<h6>
							<i class="fa fa-twitter"></i>
							<?php echo esc_attr( $single->user->location ) ?>

							<span class="">
								<?php printf(
									'<a class="" href="%s" title="%s" rel="nofollow" target="_blank">@%s</a>',
									'https://twitter.com/' . esc_attr( $single->user->screen_name ),
									esc_attr( $single->user->screen_name ),
									esc_attr( $single->user->screen_name )
								) ?>

							</span>
						</h6>

						<p><?php echo wp_kses_post( $this->replaceUrl( $single->text ) ) ?></p>

						<time class="time" datetime="<?php echo esc_attr( date( DATE_W3C, strtotime( $single->created_at ) ) ) ?>">
							<i class="fa fa-clock-o"></i> 
							<?php echo date(get_option('date_format'), strtotime($single->created_at) ) ?>
						</time>
					</div> <!-- End .tweet -->

				<?php endforeach; ?>

			<?php endif; ?>

		<?php endif; ?>
	</div>

		<?php 
		//echo $args['before_title'];
		//echo 'Title'; // Can set this with a widget option, or omit altogether
		//echo $args['after_title'];

		// Widget display logic goes here

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' => esc_html__( 'Twitter', 'sumba-kit' ),
			'user'	=> 'Envato',
			'count'	=> 1
		) );

		// display field names here using:
		// $this->get_field_id( 'option_name' ) - the CSS ID
		// $this->get_field_name( 'option_name' ) - the HTML name
		// $instance['option_name'] - the option value
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('user')) ?>">
				<?php esc_html_e( 'Twitter User', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('user')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('user')) ?>" value="<?php echo esc_attr( $instance['user'] ) ?>">
			<em><?php esc_html_e( 'Example: WordPress or WooCommerce', 'sumba-kit' ) ?></em>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('count')) ?>">
				<?php esc_html_e( 'Tweets Count', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('count')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('count')) ?>" value="<?php echo esc_attr( $instance['count'] ) ?>">
			<em><?php esc_html_e( 'Enter the number of tweets you want to show', 'sumba-kit' ) ?></em>
		</p>
		
		<?php
	}

	/**
	 * Replace hashtags, mentions and links
	 *
	 * @param  string $string The tweet text to convert.
	 * @return string         returns the converted string.
	 */
	function replaceUrl( $string ) {
		$url = '~(?:(https?)://([^\s<]+)|(www\.[^\s<]+?\.[^\s<]+))(?<![\.,:])~i'; 
		$string = preg_replace($url, '<a class="" href="$0" target="_blank" title="$0">$0</a>', $string);
		$string = preg_replace('#@(\w+)#', '<a class="" href="http://twitter.com/$1" target="_blank">$0</a>', $string);
		$string = preg_replace('/#(\w+)/', '<a class="" href="http://twitter.com/search?q=%23$1&src=hash" target="_blank">$0</a>', $string);
		return $string;
	}

	/**
	 * This method used to fetch the tweets from twitter using codebird.
	 *
	 * @param  array  $instance Array of options to configure.
	 * @return array            Returns the results from twitter.
	 */
	function fetch($instance) {
		$options = Sumbawp_Base::option(); //printr($options);
		require_once SUMBAKIT_PATH . 'includes/codebird/codebird.php';
		\Codebird\Codebird::setConsumerKey( $options->get('twitter_api_key'), $options->get('twitter_api_secret' ) ); // static, see README
		$cb = \Codebird\Codebird::getInstance();
		$cb->setToken( $options->get('twitter_api_token'), $options->get('twitter_api_token_secret') );

		$reply = (array) $cb->statuses_userTimeline(['screen_name' => $instance['user'], 'count' => $instance['count'] ] );
		if ( $reply ) {
			return $reply;
		}

		return null;
	}
}


register_widget( 'SumbaKit_Tweets_Widget' );
