<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_About_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-about-widget', 'description' => esc_html__('Description', 'sumba-kit') );
		parent::__construct( 'sumba-about-widget', esc_html__( 'Sumba: About', 'sumba-kit' ), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];
		
		if ( empty( $instance ) ) {
			return;
		}
		?>
		<div class="about-widget footer-widget">
			
				<h2 class="heading-mix">
					<?php echo wp_kses_post( $instance['title'] ) ?>
					<span class="bold"><?php echo wp_kses_post( $instance['title_bold'] ); ?></span>
					<span class="colr after-title"></span>
				</h2>
		
			<p><?php echo wp_kses_post( $instance['text'] ) ?></p>
			
			<?php $footer_social_icons = Sumbawp_Base::option('footer_social_icons'); ?>

				<ul class="footer-social unstyled">
					<?php if(!empty($footer_social_icons))
						{

							foreach ($footer_social_icons as $footer_social_icon) {
							$single_social = json_decode(urldecode( sumbawp_set($footer_social_icon,'data')),true);	 
							if(sumbawp_set($single_social,'enable')){

							$bg  = sumbawp_set($single_social, 'background');

							$clr = sumbawp_set($single_social, 'color');

					?>
						
					<li>
						<a class="" href="<?php echo esc_url( sumbawp_set( $single_social, 'url') ) ?>" target="_blank" style="border-bottom-color: <?php echo esc_attr($bg); ?>; color:<?php echo esc_attr($clr); ?>;" onMouseOver="this.style.background='<?php echo esc_attr($bg); ?>'" onMouseOut="this.style.background='transparent'">
							<i class="fa <?php echo esc_attr(sumbawp_set($single_social, 'icon')) ?>" style=""></i>
						</a>
					</li>
					<?php 
							}
						} ?>

					<?php }?>
				</ul>
		</div>

		<?php

		// Widget display logic goes here

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' 		=> esc_html__( 'Go with Sumba', 'sumba-kit' ),
			'title_bold'	=> esc_html__( 'Corporate', 'sumba-kit' ),
			'text'			=> '',
			'social'		=> array('fa-facebook', 'fa-twitter', 'fa-pinterest')
		) );

		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title_bold')) ?>">
				<?php esc_html_e( 'Title Bold', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title_bold')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title_bold')) ?>" value="<?php echo esc_attr( $instance['title_bold'] ) ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('text')) ?>">
				<?php esc_html_e( 'Text', 'sumba-kit' ) ?>
			</label>
			<textarea name="<?php echo esc_attr( $this->get_field_name('text')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('text')) ?>" row="4"><?php echo esc_attr( $instance['text'] ) ?></textarea>
		</p>

		<p>
			<label>
				<?php esc_html_e( 'Note: Add Social Media From Theme Settings', 'sumba-kit' ) ?>
			</label>

		</p>
		
		<?php
	}
}


register_widget( 'SumbaKit_About_Widget' );
