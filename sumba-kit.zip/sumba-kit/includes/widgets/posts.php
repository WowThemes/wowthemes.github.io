<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Posts_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-posts-widget', 'description' => esc_html__('Show the blog posts', 'sumba-kit') );
		parent::__construct( 'sumba-posts-widget', esc_html__( 'Sumba: Blog Posts', 'sumba-kit' ), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) && ! function_exists('sumbawp_set') ) {
			return;
		}
		?>

		<div class="sumba-post-widget footer-widget">
			
			<h4><?php echo wp_kses_post( $instance['title'] ) ?></h4>
			

			<?php 
			$query_args = array( 
				'posts_per_page' => $instance['number'] ,
				'order'			 => $instance['order'],
				'orderby'		 => $instance['orderby'],
			);

			if ( sumbawp_set($instance,'cats') ) {
				$query_args['cat'] = implode(',', sumbawp_set($instance,'cats'));
			}
			if ( sumbawp_set($instance,'tags') ) {
				$query_args['tag'] = implode(',', sumbawp_set($instance,'tags'));
			}

			$query = new WP_Query( $query_args );

			$title_limit = $instance['title_limit'] ? (int) $instance['title_limit'] : 4;
			?>

			<?php if ( $query->have_posts() ) : ?>
				<ul class="unstyled">

					<?php while( $query->have_posts() ) : $query->the_post() ?>
						<li>
							<figure>
								<?php the_post_thumbnail( 'thumbnail' ) ?>
							</figure>
							<div class="pst-detail">
								<h4>
									<a href="<?php the_permalink() ?>" title="<?php the_title_attribute() ?>">
										<?php echo wp_trim_words( get_the_title(), $title_limit, '..' ) ?>
									</a>
								</h4>
								<time class="time" datetime="<?php echo esc_attr( get_the_date( DATE_W3C ) ) ?>">
									<i class="fa fa-clock-o"></i> <?php echo get_the_date() ?>
								</time>
							</div>
						</li>
						<?php

					endwhile;

					wp_reset_postdata();

					?>

				</ul>

			<?php endif; ?>
		</div>
		<?php

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' 		=> esc_html__( 'Posts', 'sumba-kit' ),
			'title_limit'	=> 4,
			'number'		=> 3,
			'cats'			=> array(),
			'tags'			=> array(),
			'order'			=> 'DESC',
			'orderby'		=> 'date',
		) );

		// display field names here using:
		// $this->get_field_id( 'option_name' ) - the CSS ID
		// $this->get_field_name( 'option_name' ) - the HTML name
		// $instance['option_name'] - the option value
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title_limit')) ?>">
				<?php esc_html_e( 'Title Words limit', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title_limit')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title_limit')) ?>" value="<?php echo esc_attr( $instance['title_limit'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('number')) ?>">
				<?php esc_html_e( 'Number of posts', 'sumba-kit' ) ?>
			</label>
			<input type="number" name="<?php echo esc_attr( $this->get_field_name('number')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('number')) ?>" value="<?php echo esc_attr( $instance['number'] ) ?>">
		</p>
		
		<p>
			<?php $social_array = get_categories(array('number' => -1)) ?>
			<label for="<?php echo esc_attr( $this->get_field_id('cats')) ?>">
				<?php esc_html_e( 'Categories', 'sumba-kit' ) ?>
			</label>

			<?php $social = $instance['cats'] ?>
			<select name="<?php echo esc_attr( $this->get_field_name('cats')) ?>[]" class="widefat" id="<?php echo esc_attr( $this->get_field_id('cats')) ?>" multiple>
				<option value=""><?php esc_html_e('--Select--', 'sumba-kit') ?></option>
				<?php foreach( $social_array as $s_array ) : ?>
					<?php $selected = in_array( $s_array->slug, $social ) ? 'selected="selected"' : '' ?>
					<option value="<?php echo esc_attr( $s_array->slug ) ?>" <?php echo wp_kses_post($selected) ?>><?php echo esc_attr($s_array->name) ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		
		<p>
			<?php $social_array = get_tags(array('number' => -1)) ?>
			<label for="<?php echo esc_attr( $this->get_field_id('tags')) ?>">
				<?php esc_html_e( 'Tags', 'sumba-kit' ) ?>
			</label>

			<?php $social = $instance['tags'] ?>
			<select name="<?php echo esc_attr( $this->get_field_name('tags')) ?>[]" class="widefat" id="<?php echo esc_attr( $this->get_field_id('tags')) ?>" multiple>
				<option value=""><?php esc_html_e('--Select--', 'sumba-kit') ?></option>
				<?php foreach( $social_array as $s_array ) : ?>
					<?php $selected = in_array( $s_array->slug, $social ) ? 'selected="selected"' : '' ?>
					<option value="<?php echo esc_attr( $s_array->slug ) ?>" <?php echo wp_kses_post($selected) ?>><?php echo esc_attr($s_array->name) ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<?php $social_array = array('desc' => esc_html__( 'Descending', 'sumba-kit' ), 'asc' => esc_html__( 'Ascending', 'sumba-kit' )) ?>
			<label for="<?php echo esc_attr( $this->get_field_id('order')) ?>">
				<?php esc_html_e( 'Order', 'sumba-kit' ) ?>
			</label>

			<?php $social = $instance['order'] ?>
			<select name="<?php echo esc_attr( $this->get_field_name('order')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('order')) ?>">
				<option value=""><?php esc_html_e('--Select--', 'sumba-kit') ?></option>
				<?php foreach( $social_array as $key => $s_array ) : ?>
					<option value="<?php echo esc_attr( $key ) ?>" <?php selected($instance['order'], $key) ?>><?php echo esc_attr($s_array) ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		<p>
			<?php $social_array = array('date' => esc_html__( 'Date', 'sumba-kit' ), 'title' => esc_html__( 'Title', 'sumba-kit' ), 'name' => esc_html__( 'Post Slug', 'sumba-kit' ), 'author' => esc_html__( 'Author', 'sumba-kit' ), 'comment_count' => esc_html__( 'Comment Count', 'sumba-kit' )) ?>
			<label for="<?php echo esc_attr( $this->get_field_id('orderby')) ?>">
				<?php esc_html_e( 'Orderby', 'sumba-kit' ) ?>
			</label>

			<?php $social = $instance['orderby'] ?>
			<select name="<?php echo esc_attr( $this->get_field_name('orderby')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('orderby')) ?>">
				<option value=""><?php esc_html_e('--Select--', 'sumba-kit') ?></option>
				<?php foreach( $social_array as $key => $s_array ) : ?>
					<option value="<?php echo esc_attr( $key ) ?>" <?php selected($instance['orderby'], $key) ?>><?php echo esc_attr($s_array) ?></option>
				<?php endforeach; ?>
			</select>
		</p>
		
		<?php
	}
}


register_widget( 'SumbaKit_Posts_Widget' );
