<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Company_Info_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-company-info-widget', 'description' => esc_html__('Show the company info, address, email phone etc', 'sumba-kit') );
		parent::__construct( 'sumba-company-info-widget', esc_html__( 'Sumba: Company Info', 'sumba-kit' ), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];

		if ( empty( $instance ) ) {
			return;
		}
		?>

		<header>
			<h4>About Us</h4>
		</header>

		<ul class="unstyled">
			<li>
				<label>Postal Address</label>
				<p>PO Box 16122 Collins Street West Victoria 8007 Australia</p>
			</li>
			<li>
				<label>Envato HQ</label>
				<p>PO Box 16122 Collins Street West Victoria 8007 Australia</p>
			</li>
			<li>
				<label>Business Phone</label>
				<p>+61 3 8376 6284</p>
			</li>

		</ul>
		<?php 
		//echo $args['before_title'];
		//echo 'Title'; // Can set this with a widget option, or omit altogether
		//echo $args['after_title'];

		// Widget display logic goes here

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title' 		=> esc_html__( 'About Us', 'sumba-kit' ),
			'address' 		=> '',
			'address2' 		=> '',
			'phone' 		=> '',
			'phone2' 		=> '',
			'fax'	 		=> '',
			'email'	 		=> '',
		) );

		// display field names here using:
		// $this->get_field_id( 'option_name' ) - the CSS ID
		// $this->get_field_name( 'option_name' ) - the HTML name
		// $instance['option_name'] - the option value
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>
		
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('address')) ?>">
				<?php esc_html_e( 'Address', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('address')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('address')) ?>" value="<?php echo esc_attr( $instance['address'] ) ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('address2')) ?>">
				<?php esc_html_e( 'Address 2', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('address2')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('address')) ?>" value="<?php echo esc_attr( $instance['address2'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('phone')) ?>">
				<?php esc_html_e( 'Phone', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('phone')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('phone')) ?>" value="<?php echo esc_attr( $instance['phone'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('phone2')) ?>">
				<?php esc_html_e( 'Phone 2', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('phone2')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('phone2')) ?>" value="<?php echo esc_attr( $instance['phone2'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('fax')) ?>">
				<?php esc_html_e( 'Fax', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('fax')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('fax')) ?>" value="<?php echo esc_attr( $instance['fax'] ) ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id('email')) ?>">
				<?php esc_html_e( 'Email', 'sumba-kit' ) ?>
			</label>
			<input type="email" name="<?php echo esc_attr( $this->get_field_name('email')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('email')) ?>" value="<?php echo esc_attr( $instance['email'] ) ?>">
		</p>
		<?php
	}
}


register_widget( 'SumbaKit_Company_Info_Widget' );
