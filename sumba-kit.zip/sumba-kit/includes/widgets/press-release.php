<?php

/**
 * new WordPress Widget format
 * Wordpress 2.8 and above
 * @see http://codex.wordpress.org/Widgets_API#Developing_Widgets
 */
class SumbaKit_Press_Release_Widget extends WP_Widget {

	/**
	 * Constructor
	 *
	 * @return void
	 */
	function __construct() {
		$widget_ops = array( 'classname' => 'sumba-press-release-widget', 'description' => esc_html__('Show the press release pages', 'sumba-kit') );
		parent::__construct( 'sumba-press-release-widget', esc_html__('Sumba: Press Release', 'sumba-kit'), $widget_ops );
	}

	/**
	 * Outputs the HTML for this widget.
	 *
	 * @param array  An array of standard parameters for widgets in this theme
	 * @param array  An array of settings for this widget instance
	 * @return void Echoes it's output
	 */
	function widget( $args, $instance ) {
		echo $args['before_widget'];
		if ( ! function_exists('sumbawp_set') ) {
			return;
		}

		$options        = Sumbawp_Base::option();

		$all_rleases    = $options->get('press-rleases');

		?>
		
		<div class="press-release sumba-widget bg bg-primary-grdnt">

	
				<header>
					<h3 class="widget-title-one">

						<?php echo sumbawp_set( $instance,'title'); ?>	
					</h3>
				</header>

				<div class="list">
					<?php

					if(!empty($all_rleases)):


						$release_repeater = sumbawp_set($all_rleases,'redux_repeater_data');

						$counter          = 0;

						foreach($release_repeater as $repeater):

							$label         = sumbawp_set(sumbawp_set($all_rleases,'label'),$counter);

							$short_desc    = sumbawp_set(sumbawp_set($all_rleases,'short_desc'),$counter);

							?>
							<div class="press">
								
									<i class="fa fa-clock-o"> </i>  <?php echo esc_html($label); ?>
								
								<p>
									<?php echo esc_html($short_desc); ?>

								</p>
							</div>
							<?php

							$counter++;

						endforeach;

					endif;

					?>	

					
				</div>
	
		</div>
		<?php 

		echo $args['after_widget'];
	}

	/**
	 * Deals with the settings when they are saved by the admin. Here is
	 * where any validation should be dealt with.
	 *
	 * @param array  An array of new settings as submitted by the admin
	 * @param array  An array of the previous settings
	 * @return array The validated and (if necessary) amended settings
	 */
	function update( $new_instance, $old_instance ) {

		// update logic goes here
		$updated_instance = $new_instance;
		return $updated_instance;
	}

	/**
	 * Displays the form for this widget on the Widgets page of the WP Admin area.
	 *
	 * @param array  An array of the current settings for this widget
	 * @return void Echoes it's output
	 */
	function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array(
			'title'     => '',
		) );

		?>
		<p>
			<label ="<?php echo esc_attr( $this->get_field_id('title')) ?>">
				<?php esc_html_e( 'Title', 'sumba-kit' ) ?>
			</label>
			<input type="text" name="<?php echo esc_attr( $this->get_field_name('title')) ?>" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title')) ?>" value="<?php echo esc_attr( $instance['title'] ) ?>">
		</p>

		<p>
			<label>
				<?php esc_html_e( 'Note: Add Press Releases from theme options', 'sumba-kit' ) ?>
			</label>

		</p>

		<?php

		
	}
}

register_widget( 'SumbaKit_Press_Release_Widget' );
