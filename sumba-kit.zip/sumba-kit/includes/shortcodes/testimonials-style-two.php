<?php

return array(

		'name'			=> esc_html__( 'Our Testimonials Style Two', 'sumba-kit' ),
		'base'			=> 'sumbawp-testimonials-style-two',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show testimonials style two', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__('Background Image', 'sumba-kit'),
				'param_name'	=> 'bg_img',
				'description'	=> esc_html__( 'Upload testimonial background image', 'sumba-kit' )
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__('Add Testimonials', 'sumba-kit'),
				'param_name'	=> 'testi',
				'description'	=> esc_html__('Enter clients reviews', 'sumba-kit'),
				'params'		=> array(
					array(
						'type' 			=> 'textarea',
						'heading'		=> esc_html__('Client Review', 'sumba-kit'),
						'param_name'	=> 'content',
						'description'	=> esc_html__('Enter client review')
					),
					array(
						'type'			=> 'attach_image',
						'heading'		=> esc_html__('Client Image', 'sumba-kit'),
						'param_name'	=> 'img',
						'description'	=> esc_html__( 'Upload client image', 'sumba-kit' )
					),
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__('Client Name', 'sumba-kit'),
						'param_name'	=> 'name',
						'description'	=> esc_html__('Enter client name', 'sumba-kit'),
					),
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__('Client designation', 'sumba-kit'),
						'param_name'	=> 'designation',
						'description'	=> esc_html__('Enter client designation', 'sumba-kit'),
					)
				)
			)

		),

);