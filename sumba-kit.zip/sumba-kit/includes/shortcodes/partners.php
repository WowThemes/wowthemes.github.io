<?php

return array(

	'name'			=> esc_html__( 'Partners', 'sumba-kit' ),
	'base'			=> 'sumbawp-partners',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show partners', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Partners', 'sumba-kit' ),
		    'param_name'    => 'partners',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Enter the partners', 'sumba-kit' ),
			'params'		=> array(
				array(
				    'type'          => 'attach_image',
				    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
				    'param_name'    => 'image',
					'description'	=> esc_html__( 'Choose the image to show', 'sumba-kit' ),
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter the title', 'sumba-kit' ),
				),
				array(
				    'type'          => 'href',
				    'heading'       => esc_html__( 'URL', 'sumba-kit' ),
				    'param_name'    => 'url',
					'description'	=> esc_html__( 'Enter the URL (optional)', 'sumba-kit' ),
				),
			)
		),
	),

);