<?php

return array(

		'name'			=> esc_html__( 'Contact information With Map', 'sumba-kit' ),
		'base'			=> 'sumbawp-contact-info-two',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show company contact information with map', 'sumba-kit' ),

		'params' => array(
			array(
			    'type'          => 'attach_image',
			    'heading'       => esc_html__( 'Map Marker', 'sumba-kit' ),
			    'param_name'    => 'marker',
				'admin_label' 	=> false,
				'description'	=> esc_html__( 'Choose map marker', 'sumba-kit' )
			),				
			array(
				'type'          => 'param_group',
			    'heading'       => esc_html__( 'Map Info', 'sumba-kit' ),
			    'param_name'    => 'map_info',
			    'group'			=> esc_html__( 'Map Info', 'sumba-kit' ),
				'description'	=> esc_html__( 'Add map info', 'sumba-kit' ),
				'params'		=> array(
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Latitude', 'sumba-kit' ),
					    'param_name'    => 'latitude',
						'description'	=> esc_html__( 'Enter latitude of google map', 'sumba-kit' )
					),	
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Longitude', 'sumba-kit' ),
					    'param_name'    => 'longitude',
						'description'	=> esc_html__( 'Enter longitude of google map', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
					    'param_name'    => 'title',
						'description'	=> esc_html__( 'Enter location title of google map if you wants to show', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Address', 'sumba-kit' ),
					    'param_name'    => 'address',
						'description'	=> esc_html__( 'Enter location address if you wants to show', 'sumba-kit' )
					),
				),
			),
				array(
					'type'          => 'textfield',
				    'heading'       => esc_html__( 'Address', 'sumba-kit' ),
				    'group'			=> esc_html__( 'Contact Info', 'sumba-kit' ),
				    'param_name'    => 'address',
					'description'	=> esc_html__( 'Enter company address', 'sumba-kit' )
				),
				array(
					'type'          => 'textfield',
				    'heading'       => esc_html__( 'Email', 'sumba-kit' ),
				    'group'			=> esc_html__( 'Contact Info', 'sumba-kit' ),
				    'param_name'    => 'email',
					'description'	=> esc_html__( 'Enter email address', 'sumba-kit' )
				),
				array(
					'type'          => 'textfield',
				    'heading'       => esc_html__( 'Phone No', 'sumba-kit' ),
				    'param_name'    => 'phone',
				    'group'			=> esc_html__( 'Contact Info', 'sumba-kit' ),
					'description'	=> esc_html__( 'Enter Phone number', 'sumba-kit' )
				),
				array(
					'type'			=> 'checkbox',
					'heading'		=> esc_html__( 'Show Contact Us Button', 'sumba-kit' ),
					'param_name'	=> 'contact_btn',
					'group'			=> esc_html__( 'Contact Info', 'sumba-kit' ),
					'value'			=> array('Show Button'=>'show_btn',),
				),
				array(
					'type'          => 'vc_link',
				    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
				    'param_name'    => 'btn',
				    'group'			=> esc_html__( 'Contact Info', 'sumba-kit' ),
					'description'	=> esc_html__( 'Enter button', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'contact_btn', 'value' => 'show_btn')
				)



		),
);