<?php

return array(

		'name'			=> esc_html__( 'Core Services', 'sumba-kit' ),
		'base'			=> 'sumbawp-core-services',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show company core services', 'sumba-kit' ),

		'params' => array(
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
			    'param_name'    => 'title',
				'admin_label' 	=> true,
				'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Post Title Limit', 'sumba-kit' ),
			    'param_name'    => 'title_limit',
				'admin_label' 	=> true,
				'description'	=> esc_html__( 'Enter the number of character for title limit', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Background Title', 'sumba-kit' ),
			    'param_name'    => 'sub_title',
				'admin_label' 	=> true,
				'description'	=> esc_html__( 'Enter the background title of the section ', 'sumba-kit' )
			),
			array(
			    'type'          => 'vc_link',
			    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
			    'param_name'    => 'btn',
				'admin_label' 	=> false,
				'description'	=> esc_html__( 'Enter the services button', 'sumba-kit' )
			),
			array(
			    'type'          => 'autocomplete',
			    'heading'       => esc_html__( 'Category', 'sumba-kit' ),
			    'param_name'    => 'cat',
				'query_args'	=> array(
					'taxonomy'		=> 'service_cat',
				),
				'description'	=> esc_html__( 'Choose the category', 'sumba-kit' )
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__('Number', 'sumba-kit'),
				'param_name'	=> 'number',
				'description'	=> esc_html__('Enter the number of service to show', 'sumba-kit')
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_html__( 'Order', 'sumba-kit' ),
				'param_name'	=> 'order',
				'value'			=> array(
					esc_html__( '--Select--', 'sumba-kit' ) => '',
					esc_html__( 'DESC', 'sumba-kit' ) => 'desc',
					esc_html__( 'ASC', 'sumba-kit' ) => 'asc',
					),
				'default'		=> 'desc',
				'description'	=>	esc_html__( 'Choose the order either Ascending or descending', 'sumba-kit' )
			),
			array(
				'type'			=> 'dropdown',
				'heading'		=> esc_html__('Order By', 'sumba-kit'),
				'param_name'	=> 'orderby',
				'value'			=> array(
					esc_html__('--Select--', 'sumba-kit') => '',
					esc_html__( 'Date', 'sumba-kit' ) => 'date',
					esc_html__( 'Author', 'sumba-kit' ) => 'author',
					esc_html__( 'Title', 'sumba-kit' ) => 'title',
					esc_html__( 'Name (Post Slug)', 'sumba-kit' ) => 'name',
					esc_html__( 'Random', 'sumba-kit' ) => 'rand',
					),
				'default'		=> 'date',
				'description'	=> esc_html__( 'Choose the orderby', 'sumba-kit' )
			)


		),



);