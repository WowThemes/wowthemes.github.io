<?php

return array(

	'name'			=> esc_html__( 'Financial Planning', 'sumba-kit' ),
	'base'			=> 'sumbawp-financial-plan',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show video tabs about financial planing', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'param_group',
			'heading'		=> esc_html__('Plans', 'sumba-kit'),
			'param_name'	=> 'tabs',
			'description'	=> esc_html__('Create Plans', 'sumba-kit'),
			'params'		=> array(
					array(
					    'type'          => 'attach_image',
					    'heading'       => esc_html__( 'Plan Image', 'sumba-kit' ),
					    'param_name'    => 'tab_image',
						'admin_label' 	=> false,
						'description'	=> esc_html__( 'Choose the image to show as tab', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Video Link', 'sumba-kit' ),
					    'param_name'    => 'vid_link',
						'description'	=> esc_html__( 'Enter the video link', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
					    'param_name'    => 'title',
						'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Experience Years', 'sumba-kit' ),
					    'param_name'    => 'year',
						'description'	=> esc_html__( 'Enter the experience years', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Tag line', 'sumba-kit' ),
					    'param_name'    => 'tagline',
						'description'	=> esc_html__( 'Enter the tag line to show under year', 'sumba-kit' )
					),
					array(
					    'type'          => 'textarea',
					    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
					    'param_name'    => 'content',
						'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
					),
					array(
						'type'			=> 'checkbox',
						'heading'		=> esc_html__( 'Show Contact Button', 'sumba-kit' ),
						'param_name'	=>	'chck_btn',
						'value'			=> array('Show' => 'shw'),
						'description'	=> esc_html__( 'Check it, if you want to show contact button', 'sumba-kit' )
					),
					array(
					    'type'          => 'vc_link',
					    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
					    'param_name'    => 'btn',
						'description'	=> esc_html__( 'Enter button', 'sumba-kit' ),
						'dependency'	=> array('element' => 'chck_btn', 'value' => 'shw')
					)
			)
		)
	)

);