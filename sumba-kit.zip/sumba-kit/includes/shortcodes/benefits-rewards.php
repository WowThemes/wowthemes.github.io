<?php
return array(

		'name'			=> 'Benefits & Rewards',
		'base'			=> 'sumbawp-benefits-rewards',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show benefits and rewards of experienced specialist', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'attach_images',
				'heading'		=> esc_html__( 'Images', 'sumba-kit' ),
				'param_name'	=> 'imgs',
				'description'	=> esc_html__( 'Attach images', 'sumba-kit' )
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
				'param_name'	=> 'title',
				'admin_label'	=> true,
				'description'	=> esc_html__( 'Enter title of the section', 'sumba-kit' ),
			),
			array(
				'type'			=> 'textarea_html',
				'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
				'param_name'	=> 'content',
				'admin_label'	=> false,
				'description'	=> esc_html__( 'Enter description of the section', 'sumba-kit' ),
			),
		)
);