<?php

return array(

		'name'			=> esc_html__( 'Request A Call Back', 'sumba-kit' ),
		'base'			=> 'sumbawp-request-callback',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show request a call back', 'sumba-kit' ),

		'params' => array(
					array(
					    'type'          => 'attach_image',
					    'heading'       => esc_html__( 'Background Image', 'sumba-kit' ),
					    'param_name'    => 'bg_image',
						'admin_label' 	=> false,
						'description'	=> esc_html__( 'Choose background image to show', 'sumba-kit' )
					),
 					array(
                        "type" => "dropdown",
                        "class" => "",
                        "heading" => esc_html__('Select Form', 'sumba-kit'),
                        "param_name" => "single_form",
                        "value" => array_flip(sumbawp_posts('wpcf7_contact_form')),
                    	"description" => esc_html__('Choose a form which you want to show', 'sumba-kit'),   
                    ),
 					array(
					    'type'          => 'attach_image',
					    'heading'       => esc_html__( 'Side Image', 'sumba-kit' ),
					    'param_name'    => 'side_image',
						'admin_label' 	=> false,
						'description'	=> esc_html__( 'Choose side image to show', 'sumba-kit' )
					),



		),



);