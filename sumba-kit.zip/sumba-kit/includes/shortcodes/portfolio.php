<?php

return array(

	'name'			=> esc_html__( 'Portfolio', 'sumba-kit' ),
	'base'			=> 'sumbawp-portfolio',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show sumba portfolio', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'checkbox',
			'heading'		=> esc_html__( 'Show Heading Style 1', 'sumba-kit' ),
			'param_name'	=> 'heading_style',
			'value'			=> array(
				'Heading Style 1'	=> 'heading_one'
				),
			'description'	=> esc_html__( 'Check if you want to show heading style 1 with title and tagline','sumba-kit' ),
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style',
				'value'		=> 'heading_one',
				)
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Tagline', 'sumba-kit' ),
		    'param_name'    => 'tagline',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the tagline of the section', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style',
				'value'		=> 'heading_one',
				)
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> esc_html__( 'Show Heading Style 2', 'sumba-kit' ),
			'param_name'	=> 'heading_style_two',
			'value'			=> array(
				'Heading Style 2'	=> 'heading_two'
				),
			'description'	=> esc_html__( 'Check if you want to show heading style 2 with title and description','sumba-kit' ),
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Experience Years', 'sumba-kit' ),
		    'param_name'    => 'year',
			'description'	=> esc_html__( 'Enter the experience years', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style_two',
				'value'		=> 'heading_two',
				)
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Tag line', 'sumba-kit' ),
		    'param_name'    => 'tagline_two',
		    'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the tag line under year', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style_two',
				'value'		=> 'heading_two',
				)
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title_two',
		    'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the title', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style_two',
				'value'		=> 'heading_two',
				)
		),
		array(
		    'type'          => 'textarea_html',
		    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
		    'param_name'    => 'content',
			'description'	=> esc_html__( 'Enter the description', 'sumba-kit' ),
			'dependency'	=> array(
				'element'	=> 'heading_style_two',
				'value'		=> 'heading_two',
				)
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Number', 'sumba-kit' ),
		    'param_name'    => 'number',
			'description'	=> esc_html__( 'Choose the number of posts to show', 'sumba-kit' )
		),
		array(
		    'type'          => 'autocomplete',
		    'heading'       => esc_html__( 'Category', 'sumba-kit' ),
		    'param_name'    => 'cat',
			'query_args'	=> array(
				'taxonomy'		=> 'portfolio_cat',
			),
			'description'	=> esc_html__( 'Choose the category', 'sumba-kit' )
		),
		array(
		    'type'          => 'autocomplete',
		    'heading'       => esc_html__( 'Tags', 'sumba-kit' ),
		    'param_name'    => 'tag',
			'query_args'	=> array(
				'taxonomy'		=> 'portfolio_tag',
			),
			'settings'		=> array( 'multiple' => true ),
			'description'	=> esc_html__( 'Choose the tags to show in filteration', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order', 'sumba-kit' ),
		    'param_name'    => 'order',
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Desc', 'sumba-kit' ) => 'desc',
				esc_html__( 'Asc', 'sumba-kit' ) => 'asc',
			),
			'default'		=> 'desc',
			'description'	=> esc_html__( 'Choose the order either Ascending or descending', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order by', 'sumba-kit' ),
		    'param_name'    => 'orderby',
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Date', 'sumba-kit' ) => 'date',
				esc_html__( 'Author', 'sumba-kit' ) => 'author',
				esc_html__( 'Title', 'sumba-kit' ) => 'title',
				esc_html__( 'Name (Post Slug)', 'sumba-kit' ) => 'name',
				esc_html__( 'Comments', 'sumba-kit' ) => 'comment_count',
				esc_html__( 'Menu Order', 'sumba-kit' ) => 'menu_order',
				esc_html__( 'Random', 'sumba-kit' ) => 'rand',
			),
			'default'		=> 'date',
			'description'	=> esc_html__( 'Choose the orderby', 'sumba-kit' )
		),
	),

);