<?php

return array(

		'name'			=> esc_html__( 'Company Financial Planning', 'sumba-kit' ),
		'base'			=> 'sumbawp-financial-planning',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show financial planning', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__('Add Plans', 'sumba-kit'),
				'param_name'	=> 'plans',
				'description'	=> esc_html__('Add company financial plans', 'sumba-kit'),
				'params'		=> array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Title', 'sumba-kit'),
							'param_name'	=> 'title',
							'admin_label' 	=> true,
							'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
						),
						array(
						    'type'          => 'textarea',
						    'heading'       => esc_html__( 'Content', 'sumba-kit' ),
						    'param_name'    => 'content',
							'admin_label' 	=> false,
							'description'	=> esc_html__( 'Enter content', 'sumba-kit' )
						),
						array(
						    'type'          => 'attach_image',
						    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
						    'param_name'    => 'image',
							'admin_label' 	=> false,
							'description'	=> esc_html__( 'Choose the image to show', 'sumba-kit' )
						),
						array(
							'type'			=> 'vc_link',
							'heading'		=> esc_html__('Button', 'sumba-kit'),
							'param_name'	=> 'btn',
							'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
						),
					)
			),

		),



);