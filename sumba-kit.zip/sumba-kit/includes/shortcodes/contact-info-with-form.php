<?php
return array(

	'name'			=> esc_html__( 'Contact Info With form', 'sumba-kit' ),
	'base'			=> 'sumbawp-contact-info-with-form',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show contact info with form ', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title',
			'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
		),
		array(
		    'type'          => 'textarea',
		    'heading'       => esc_html__( 'Address', 'sumba-kit' ),
		    'param_name'    => 'address',
			'description'	=> esc_html__( 'Enter the address', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Contact No', 'sumba-kit' ),
		    'param_name'    => 'contact_no',
			'description'	=> esc_html__( 'Enter the contact no', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Email', 'sumba-kit' ),
		    'param_name'    => 'email',
			'description'	=> esc_html__( 'Enter the email', 'sumba-kit' )
		),
		array(
            "type" => "dropdown",
            "class" => "",
            "heading" => esc_html__('Select Form', 'sumba-kit'),
            "param_name" => "single_form",
            "value" => array_flip(sumbawp_posts('wpcf7_contact_form')),
        	"description" => esc_html__('Choose a contact form which you want to show', 'sumba-kit'),   
        ),
	)
);
