<?php
return array(

	'name'			=> esc_html__( 'Blog Grid ', 'sumba-kit' ),
	'base'			=> 'sumbawp-blog-grid',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show blog grid ', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Number', 'sumba-kit' ),
		    'param_name'    => 'number',
			'description'	=> esc_html__( 'Choose the number of posts to show', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Words Count', 'sumba-kit' ),
		    'param_name'    => 'words',
		    'default'		=> 20,
			'description'	=> esc_html__( 'Enter the number of words to trim', 'sumba-kit' )
		),
		array(
		    'type'          => 'autocomplete',
		    'heading'       => esc_html__( 'Category', 'sumba-kit' ),
		    'param_name'    => 'cat',
			'query_args'	=> array(
				'taxonomy'		=> 'category',
			),
			'description'	=> esc_html__( 'Choose the category', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Columns', 'sumba-kit' ),
		    'param_name'    => 'columns',
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'One Column', 'sumba-kit' ) => '12',
				esc_html__( 'Two Columns', 'sumba-kit' ) => '6',
			),
			'default'		=> '2-colmn',
			'description'	=> esc_html__( 'Choose the column number', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order', 'sumba-kit' ),
		    'param_name'    => 'order',
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Desc', 'sumba-kit' ) => 'desc',
				esc_html__( 'Asc', 'sumba-kit' ) => 'asc',
			),
			'default'		=> 'desc',
			'description'	=> esc_html__( 'Choose the order either Ascending or descending', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order by', 'sumba-kit' ),
		    'param_name'    => 'orderby',
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Date', 'sumba-kit' ) => 'date',
				esc_html__( 'Author', 'sumba-kit' ) => 'author',
				esc_html__( 'Title', 'sumba-kit' ) => 'title',
				esc_html__( 'Name (Post Slug)', 'sumba-kit' ) => 'name',
				esc_html__( 'Comments', 'sumba-kit' ) => 'comment_count',
				esc_html__( 'Menu Order', 'sumba-kit' ) => 'menu_order',
				esc_html__( 'Random', 'sumba-kit' ) => 'rand',
			),
			'default'		=> 'date',
			'description'	=> esc_html__( 'Choose the orderby', 'sumba-kit' )
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> esc_html__('Show Read More Button'),
			'param_name'	=> 'chk_btn',
			'description'	=> esc_html__('Check it, If you want to show read more button', 'sumba-kit'),
			'value'			=> array('Show' => 'shw'),
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Button Label', 'sumba-kit' ),
		    'param_name'    => 'btn_label',
			'description'	=> esc_html__( 'Enter button label', 'sumba-kit' ),
			'dependency'	=> array('element' => 'chk_btn', 'value' => 'shw')
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> esc_html__('Show Pagination', 'sumba-kit'),
			'param_name'	=> 'pagi',
			'value'			=> array('Show' => 'shw_pagi'),
			'description'	=> esc_html__('Check it, if you want to show pagination', 'sumba-kit')
		)
	)
);
