<?php

return array(

		'name'			=> esc_html__( 'Company Core Features', 'sumba-kit' ),
		'base'			=> 'sumbawp-company-core-features',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show company main features', 'sumba-kit' ),

		'params' => array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__('Section Background Image', 'sumba-kit'),
					'param_name'	=> 'image',
					'description'	=> esc_html__('Select an image for section background')
				),
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__('Feature Background Image', 'sumba-kit'),
					'param_name'	=> 'feature_bg',
					'description'	=> esc_html__('Select an image for feature background')
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Tag Line', 'sumba-kit' ),
				    'param_name'    => 'tag_line',
					'description'	=> esc_html__( 'Enter the tag line', 'sumba-kit' ),
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
				    'admin_label'	=> 'true',
					'description'	=> esc_html__( 'Enter the title', 'sumba-kit' ),
				),
				array(
				    'type'          => 'vc_link',
				    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
				    'param_name'    => 'btn',
					'description'	=> esc_html__( 'Enter button', 'sumba-kit' ),
				),
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__('Core Features List', 'sumba-kit'),
					'param_name'	=> 'core_features',
					'description'	=> esc_html__( 'Enter Features List', 'sumba-kit' ),
					'params'		=> array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Feature', 'sumba-kit'),
							'param_name'	=> 'feature_name',
							'description'   => esc_html__('Enter feature'),
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Feature URL', 'sumba-kit'),
							'param_name'	=> 'feature_url',
							'description'   => esc_html__('Enter feature url'),
						)
					)

				)


		),



);