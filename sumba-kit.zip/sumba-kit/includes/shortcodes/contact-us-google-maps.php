<?php
return array(

	'name'			=> esc_html__( 'Contact Us Google Maps', 'sumba-kit' ),
	'base'			=> 'sumbawp-contact-us-google-maps',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show contact us google maps ', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Tag Line', 'sumba-kit' ),
			'param_name'	=> 'tagline',
			'description'	=> esc_html__( 'Enter section tag line', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter section title', 'sumba-kit' )
		),
		array(
		   'type'          => 'attach_image',
		    'heading'       => esc_html__( 'Map Marker', 'sumba-kit' ),
		    'param_name'    => 'marker',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Choose map marker', 'sumba-kit' )
		),
		array(
			'type'			=> 'param_group',
			'heading'		=> esc_html__( 'Maps', 'sumba-kit' ),
			'param_name'	=> 'map_info',
			'description'	=> esc_html__( 'Add Map', 'sumba-kit' ),
			'params'		=> array(
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Location', 'sumba-kit' ),
					'param_name'	=> 'location',
					'description'	=> esc_html__( 'Enter location to show as tab', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Latitude', 'sumba-kit' ),
				    'param_name'    => 'latitude',
					'description'	=> esc_html__( 'Enter latitude of google map', 'sumba-kit' )
				),	
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Longitude', 'sumba-kit' ),
				    'param_name'    => 'longitude',
					'description'	=> esc_html__( 'Enter longitude of google map', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter location title of google map if you wants to show', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Address', 'sumba-kit' ),
				    'param_name'    => 'address',
					'description'	=> esc_html__( 'Enter location address if you wants to show', 'sumba-kit' )
				),
			)
		),

	)
);
