<?php
return array(

		'name'			=> 'Company Benefits',
		'base'			=> 'sumbawp-company-benefits',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show company benefits', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
				'param_name'	=> 'title',
				'admin_label'	=> true,
				'description'	=> esc_html__( 'Enter section title', 'sumba-kit' ),
			),
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Video Image', 'sumba-kit' ),
				'param_name'	=> 'img',
				'description'	=> esc_html__( 'Attach video image', 'sumba-kit' )
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__( 'Video Link', 'sumba-kit' ),
				'param_name'	=> 'vid_link',
				'description'	=> esc_html__( 'Enter video link', 'sumba-kit' ),
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__( 'Benefits', 'sumba-kit' ),
				'param_name'	=> 'benefits',
				'description'	=> esc_html__( 'Add benefits', 'sumba-kit' ),
				'params'		=> array(
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
						'param_name'	=> 'title',
						'description'	=> esc_html__( 'Enter title', 'sumba-kit' ),
					),
					array(
						'type'			=> 'textarea',
						'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
						'param_name'	=> 'content',
						'description'	=> esc_html__( 'Enter descirption', 'sumba-kit' ),
					),
				)
			),
		)
);