<?php

return array(

		'name'			=> esc_html__( 'Proficient Guidance', 'sumba-kit' ),
		'base'			=> 'sumbawp-proficient-guidance',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show proficient guidance', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__('Title', 'sumba-kit'),
				'param_name'	=> 'title',
				'description'	=> esc_html__('Enter title for section Note: The grayish part of the title write like this " %colorstart% contentt %colorend% " ', 'sumba-kit')
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> esc_html__('Button', 'sumba-kit'),
				'param_name'	=> 'btn',
				'description'	=> esc_html__('Enter Button', 'sumba-kit')
			),
			array(
				'type'			=> 'textarea',
				'heading'		=> esc_html__('Description', 'sumba-kit'),
				'param_name'	=> 'desc',
				'description'	=> esc_html__('Enter description of the section', 'sumba-kit')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__('Company Name', 'sumba-kit'),
				'param_name'	=> 'company_name',
				'description'	=> esc_html__('Enter company name', 'sumba-kit')
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__('Tag Line', 'sumba-kit'),
				'param_name'	=> 'tag_line',
				'description'	=> esc_html__('Enter tag line', 'sumba-kit')
			)


		),



);