<?php

return array(

	'name'			=> esc_html__( 'Sumba Pricing Tables', 'sumba-kit' ),
	'base'			=> 'sumbawp-pricing-tables',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show pricing tables', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
		),
		array(
		    'type'          => 'textarea_html',
		    'heading'       => esc_html__( 'Content', 'sumba-kit' ),
		    'param_name'    => 'content',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Enter content', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Icon Type', 'sumba-kit' ),
		    'param_name'    => 'icon_type',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
		    'value'			=> array(
		    	esc_html__( 'Select', 'sumba-kit' ) => '',
		    	esc_html__( 'Font Icon', 'sumba-kit' ) => 'icon',
		    	esc_html__( 'Image', 'sumba-kit' ) => 'image',
		    ),
			'description'	=> esc_html__( 'Choose the type of icon', 'sumba-kit' )
		),
		array(
		    'type'          => 'iconpicker',
		    'heading'       => esc_html__( 'Play Icon', 'sumba-kit' ),
		    'param_name'    => 'playicon',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
			'dependency'	=> array( 'element' => 'icon_type', 'value' => 'icon' ),
			'description'	=> esc_html__( 'Choose the icon show with company', 'sumba-kit' )
		),
		array(
		    'type'          => 'attach_image',
		    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
		    'param_name'    => 'icon_image',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
			'dependency'	=> array( 'element' => 'icon_type', 'value' => 'image' ),
			'description'	=> esc_html__( 'Choose the icon show with company', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Video URL', 'sumba-kit' ),
		    'param_name'    => 'video',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
			'description'	=> esc_html__( 'Enter the video URL to show in popup', 'sumba-kit' )
		),

		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Company Name', 'sumba-kit' ),
		    'param_name'    => 'comp_name',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
			'description'	=> esc_html__( 'Enter the name of the company', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Designation', 'sumba-kit' ),
		    'param_name'    => 'comp_desg',
		    'group'			=> esc_html__( 'Play Icon', 'sumba-kit' ),
			'description'	=> esc_html__( 'Enter the designated person of the company', 'sumba-kit' )
		),

		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Number of Tables', 'sumba-kit' ),
		    'param_name'    => 'number',
		    'group'			=> esc_html__( 'Pricing Table', 'sumba-kit' ),
			'description'	=> esc_html__( 'Enter the number of tables to show', 'sumba-kit' )
		),
		array(
		    'type'          => 'autocomplete',
		    'heading'       => esc_html__( 'Include', 'sumba-kit' ),
		    'param_name'    => 'include',
		    'group'			=> esc_html__( 'Pricing Table', 'sumba-kit' ),
			'query_args'	=> array(
				'post_type'		=> 'pricing_table',
			),
			'settings'		=> array( 'multiple' => true ),
			'description'	=> esc_html__( 'Choose specific tables to show', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order', 'sumba-kit' ),
		    'param_name'    => 'order',
		    'group'			=> esc_html__( 'Pricing Table', 'sumba-kit' ),
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Desc', 'sumba-kit' ) => 'desc',
				esc_html__( 'Asc', 'sumba-kit' ) => 'asc',
			),
			'default'		=> 'desc',
			'description'	=> esc_html__( 'Choose the order either Ascending or descending', 'sumba-kit' )
		),
		array(
		    'type'          => 'dropdown',
		    'heading'       => esc_html__( 'Order by', 'sumba-kit' ),
		    'param_name'    => 'orderby',
		    'group'			=> esc_html__( 'Pricing Table', 'sumba-kit' ),
			'value'			=> array(
				esc_html__( '--Select--', 'sumba-kit' ) => '',
				esc_html__( 'Date', 'sumba-kit' ) => 'date',
				esc_html__( 'Author', 'sumba-kit' ) => 'author',
				esc_html__( 'Title', 'sumba-kit' ) => 'title',
				esc_html__( 'Name (Post Slug)', 'sumba-kit' ) => 'name',
				esc_html__( 'Comments', 'sumba-kit' ) => 'comment_count',
				esc_html__( 'Menu Order', 'sumba-kit' ) => 'menu_order',
				esc_html__( 'Random', 'sumba-kit' ) => 'rand',
			),
			'default'		=> 'date',
			'description'	=> esc_html__( 'Choose the orderby', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Items', 'sumba-kit' ),
		    'param_name'    => 'items',
		    'group'			=> esc_html__( 'Carousel', 'sumba-kit' ),
			'default'		=> 2,
			'description'	=> esc_html__( 'The number of items you want to see on the screen.', 'sumba-kit' )
		),
		array(
		    'type'          => 'checkbox',
		    'heading'       => esc_html__( 'Autoplay', 'sumba-kit' ),
		    'param_name'    => 'autoplay',
		    'group'			=> esc_html__( 'Carousel', 'sumba-kit' ),
			'default'		=> 'true',
			'value'			=> array( esc_html__( 'Autoplay', 'sumba-kit' ) => 'true' ),
			'description'	=> esc_html__( 'Enable to autoplay', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Autoplay Timeout', 'sumba-kit' ),
		    'param_name'    => 'autoplayTimeout',
		    'group'			=> esc_html__( 'Carousel', 'sumba-kit' ),
			'default'		=> '50000',
			'description'	=> esc_html__( 'Enter the timeout for autoplay', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Speed', 'sumba-kit' ),
		    'param_name'    => 'smartSpeed',
		    'group'			=> esc_html__( 'Carousel', 'sumba-kit' ),
			'default'		=> '250',
			'description'	=> esc_html__( 'Enter the speed in miliseconds', 'sumba-kit' )
		),

	),

);