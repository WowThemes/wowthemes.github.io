<?php
return array(

	'name'			=> esc_html__( 'Company Core Features With Images', 'sumba-kit' ),
	'base'			=> 'sumbawp-company-core-features-style-two',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show company core features with images', 'sumba-kit' ),

	'params' => array(
		array(
			'type'		 	=> 'attach_image',
			'heading'		=> esc_html__( 'Background Image', 'sumba-kit' ),
			'param_name'	=> 'bg_img',
			'description'	=> esc_html__( 'Attach background image', 'sumba-kit' )
		),
		array(
			'type'		 	=> 'textfield',
			'heading'		=> esc_html__( 'Tag Line', 'sumba-kit' ),
			'param_name'	=> 'tagline',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter tag line', 'sumba-kit' )
		),
		array(
			'type'		 	=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter title', 'sumba-kit' )
		),
		array(
			'type'		 	=> 'attach_images',
			'heading'		=> esc_html__( 'Feature Images', 'sumba-kit' ),
			'param_name'	=> 'images',
			'description'	=> esc_html__( 'Attach feature images', 'sumba-kit' )
		),
		array(
			'type'		 	=> 'textarea_html',
			'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
			'param_name'	=> 'content',
			'description'	=> esc_html__( 'Enter description', 'sumba-kit' )
		),
		array(
			'type'		 	=> 'vc_link',
			'heading'		=> esc_html__( 'Button', 'sumba-kit' ),
			'param_name'	=> 'btn',
			'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
		),
	)
);
