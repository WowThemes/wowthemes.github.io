<?php
return array(

	'name'			=> esc_html__( 'Team Contact Info ', 'sumba-kit' ),
	'base'			=> 'sumbawp-team-contact-info',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show team contact info', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> esc_html__( 'Background Image', 'sumba-kit' ),
			'param_name'	=> 'bg_img',
			'description'	=> esc_html__( 'Attach background image', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Tag Line', 'sumba-kit' ),
			'param_name'	=> 'tagline',
			'description'	=> esc_html__( 'Enter the tag line', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
		),
		array(
			'type'			=> 'textarea_html',
			'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
			'param_name'	=> 'content',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Address', 'sumba-kit' ),
			'param_name'	=> 'address',
			'description'	=> esc_html__( 'Enter the address', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Email', 'sumba-kit' ),
			'param_name'	=> 'email',
			'description'	=> esc_html__( 'Enter the email', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Contact No', 'sumba-kit' ),
			'param_name'	=> 'phone',
			'description'	=> esc_html__( 'Enter the phone number', 'sumba-kit' )
		),
		array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Social Icons', 'sumba-kit' ),
		    'param_name'    => 'social',
			'group'	 		=> esc_html__( 'Social Profiles', 'sumba-kit' ),
			'description'	=> esc_html__( 'Enter custom info. You can use html tags', 'sumba-kit' ),
			'params'		=> array(
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter the follow or like title', 'sumba-kit' )
				),
				array(
				    'type'          => 'href',
				    'heading'       => esc_html__( 'Profile Link', 'sumba-kit' ),
				    'param_name'    => 'url',
					'description'	=> esc_html__( 'Enter the social profile URL', 'sumba-kit' )
				),
				array(
				    'type'          => 'dropdown',
				    'heading'       => esc_html__( 'Icon type', 'sumba-kit' ),
				    'param_name'    => 'type',
					'description'	=> esc_html__( 'Choose the icon type', 'sumba-kit' ),
					'value'			=> array(
						esc_html__( '--Select--', 'sumba-kit' ) => '',
						esc_html__( 'Font Icon', 'sumba-kit' ) => 'icon',
						esc_html__( 'Image', 'sumba-kit' ) => 'image',
					)
				),
				array(
				    'type'          => 'iconpicker',
				    'heading'       => esc_html__( 'Icon', 'sumba-kit' ),
				    'param_name'    => 'icon',
					'description'	=> esc_html__( 'Choose the icon', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'icon' )
				),
				array(
				    'type'          => 'attach_image',
				    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
				    'param_name'    => 'image',
					'description'	=> esc_html__( 'Choose the image to show', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'image' )
				),
			)
		),
		array(
			'type'			=> 'vc_link',
			'heading'		=> esc_html__( 'Button', 'sumba-kit' ),
			'param_name'	=> 'btn',
			'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
		),
	)
);
