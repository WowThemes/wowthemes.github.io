<?php

return array(

		'name'			=> esc_html__( 'About Company Tabs', 'sumba-kit' ),
		'base'			=> 'sumbawp-about-company-tabs',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show about company tabs', 'sumba-kit' ),

		'params' => array(
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__('Company Tabs', 'sumba-kit'),
					'param_name'	=> 'tabs',
					'description'	=> esc_html__('Create company tabs', 'sumba-kit'),
					'params'		=> array(
							array(
							    'type'          => 'attach_image',
							    'heading'       => esc_html__( 'Tab Image', 'sumba-kit' ),
							    'param_name'    => 'tab_image',
								'admin_label' 	=> false,
								'description'	=> esc_html__( 'Choose the image to show as tab', 'sumba-kit' )
							),
							array(
							    'type'          => 'textfield',
							    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
							    'param_name'    => 'title',
								'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
							),
							array(
							    'type'          => 'textfield',
							    'heading'       => esc_html__( 'Tag Line', 'sumba-kit' ),
							    'param_name'    => 'tagline',
								'description'	=> esc_html__( 'Enter the tag line', 'sumba-kit' )
							),
							array(
							    'type'          => 'textarea',
							    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
							    'param_name'    => 'content',
								'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
							),
							array(
							    'type'          => 'vc_link',
							    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
							    'param_name'    => 'btn',
								'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
							),
						)
					),
				),

);