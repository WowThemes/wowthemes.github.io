<?php 
return array(

		'name'			=> esc_html__( 'Our Experienced Specialist', 'sumba-kit' ),
		'base'			=> 'sumbawp-experienced-specialist',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show our experienced specialist', 'sumba-kit' ),

		'params' => array(
			array(
				'type'		=> 'checkbox',
				'heading'		=> esc_html__( 'Show Specialist Description', 'sumba-kit' ),
				'param_name'	=> 'spec_sec',
				'group'			=>	esc_html__('Specialist Content', 'sumba-kit'),
				'value'			=>  array('' => 'show_spec'),
				'description'	=> esc_html__('Check it if you want to show specialist section.')
			),
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Specialist Image', 'sumba-kit' ),
				'param_name'	=> 'img',
				'group'			=> esc_html__('Specialist Content', 'sumba-kit'),
				'description'	=> esc_html__( 'Attach experienced specialist image', 'sumba-kit' ),
				'dependency'		=> array( 'element' => 'spec_sec', 'value' => 'show_spec' ),
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
				'param_name'	=> 'title',
				'admin_label'	=> true,
				'group'			=> esc_html__('Specialist Content', 'sumba-kit'),
				'description'	=> esc_html__( 'Enter title of the section', 'sumba-kit' ),
				'dependency'		=> array( 'element' => 'spec_sec', 'value' => 'show_spec' ),
			),
			array(
				'type'			=> 'textarea_html',
				'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
				'param_name'	=> 'content',
				'admin_label'	=> false,
				'group'			=> esc_html__('Specialist Content', 'sumba-kit'),
				'description'	=> esc_html__( 'Enter description of the section', 'sumba-kit' ),
				'dependency'		=> array( 'element' => 'spec_sec', 'value' => 'show_spec' ),
			),
			array(
				'type'		=> 'checkbox',
				'heading'		=> esc_html__( 'Show Accordion', 'sumba-kit' ),
				'param_name'	=> 'accor_sec',
				'group'			=> esc_html__('Accordion', 'sumba-kit'),
				'value'			=>  array('' => 'show_accor'),
				'description'	=> esc_html__('Check it if you want to show accordion section.')
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__( 'Accordion', 'sumba-kit' ),
				'param_name'	=> 'experiences',
				'group'			=> esc_html__('Accordion', 'sumba-kit'),
				'description'	=> esc_html__( 'Add Accordion', 'sumba-kit' ),
				'dependency'	=> array( 'element' => 'accor_sec', 'value' => 'show_accor' ),
				'params'		=> array(
					array(
						'type'			=> 'textfield',
						'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
						'param_name'	=> 'title',
						'admin_label'	=> true,
						'description'	=> esc_html__( 'Enter title', 'sumba-kit' ),
					),
					array(
						'type'			=> 'textarea',
						'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
						'param_name'	=> 'content',
						'admin_label'	=> false,
						'description'	=> esc_html__( 'Enter description', 'sumba-kit' ),
					),
				)
			)
		)
	);	
