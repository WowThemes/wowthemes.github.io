<?php

return array(

		'name'			=> esc_html__( 'Get A Quote', 'sumba-kit' ),
		'base'			=> 'sumbawp-get-quote',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show get a quote', 'sumba-kit' ),

		'params' => array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__('Background Image', 'sumba-kit'),
					'param_name'	=> 'image',
					'description'	=> esc_html__('Select an image for background')
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html('Title', 'sumba-kit'),
					'param_name'	=> 'title',
					'description'	=> esc_html__('Enter the title of section', 'sumba-kit'),
				),
				array(
					'type'			=> 'vc_link',
					'heading'		=> esc_html__( 'Button', 'sumba-kit' ),
					'param_name'	=> 'btn',
					'description'	=> esc_html__( 'Enter Button', 'sumba-kit'),
				),
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__('Contact Info', 'sumba-kit'),
					'param_name'	=> 'contact_info',
					'description'	=> esc_html__( 'Enter contact information', 'sumba-kit' ),
					'params'		=> array(
						array(
						    'type'          => 'iconpicker',
						    'heading'       => esc_html__( 'Icon', 'sumba-kit' ),
						    'param_name'    => 'icon',
							'description'	=> esc_html__( 'Choose icon', 'sumba-kit' ),
						),
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__('Info', 'sumba-kit'),
							'param_name'	=> 'info',
							'description'   => esc_html__('Enter info'),
						)
					)

				)






		),



);