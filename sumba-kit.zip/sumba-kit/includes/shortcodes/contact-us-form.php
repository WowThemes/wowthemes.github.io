<?php
return array(

	'name'			=> esc_html__( 'Contact Us Form', 'sumba-kit' ),
	'base'			=> 'sumbawp-contact-us-form',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show contact us form', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'desciption'	=> esc_html__( 'Enter the title', 'sumba-kit' )
		),
		array(
            "type" => "dropdown",
            "class" => "",
            "heading" => esc_html__('Select Form', 'sumba-kit'),
            "param_name" => "single_form",
            "value" => array_flip(sumbawp_posts('wpcf7_contact_form')),
        	"description" => esc_html__('Choose a contact form which you want to show', 'sumba-kit'),   
        )
	)

);
