<?php
return array(

		'name'			=> esc_html__( 'Sumba Social Media', 'sumba-kit' ),
		'base'			=> 'sumbawp-sumba-social-media',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show sumba social media', 'sumba-kit' ),

		'params' => array(
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__('Social Media', 'sumba-kit'),
					'param_name'	=> 'social_media',
					'description'	=> esc_html__('Add social media', 'sumba-kit'),
					'params'		=> array(
							array(
							    'type'          => 'iconpicker',
							    'heading'       => esc_html__( 'Icon', 'sumba-kit' ),
							    'param_name'    => 'icon',
								'description'	=> esc_html__( 'Choose icon', 'sumba-kit' ),	
							),
							array(
							    'type'          => 'colorpicker',
							    'heading'       => esc_html__( 'Icon Color', 'sumba-kit' ),
							    'param_name'    => 'icon_color',
								'description'	=> esc_html__( 'Choose icon color', 'sumba-kit' ),
							),
							array(
							    'type'          => 'textfield',
							    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
							    'param_name'    => 'title',
							    'admin_label' 	=> false,
								'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
							),
							array(
							    'type'          => 'textfield',
							    'heading'       => esc_html__( 'URL', 'sumba-kit' ),
							    'param_name'    => 'url',
							    'admin_label' 	=> false,
							    "value" 		=> __( "https://", "sumba-kit" ),
								'description'	=> esc_html__( 'Enter the url', 'sumba-kit' )
							),
							
						)
					),
				),

	);
