<?php

return array(

	'name'			=> esc_html__( 'Entrepreneurs', 'sumba-kit' ),
	'base'			=> 'sumbawp-entrepreneurs',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show "We are entrepreneurs"', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
		),
		array(
		    'type'          => 'attach_image',
		    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
		    'param_name'    => 'image',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Choose the image to show', 'sumba-kit' )
		),
		array(
		    'type'          => 'checkbox',
		    'heading'       => esc_html__( 'Image Alignment', 'sumba-kit' ),
		    'param_name'    => 'img_pos',
			'admin_label' 	=> false,
			"value"       => array('Align Left'=>'align_left', 'Align Right'=>'align_right'), //value
			'description'	=> esc_html__( 'Select if you want to show image on left side or right side. (Check only one box)', 'sumba-kit' )
		),
		array(
		    'type'          => 'textarea_html',
		    'heading'       => esc_html__( 'Content', 'sumba-kit' ),
		    'param_name'    => 'content',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Enter graphy iframe', 'sumba-kit' )
		),
		array(
		    'type'          => 'checkbox',
		    'heading'       => esc_html__( 'Show Contact Button', 'sumba-kit' ),
		    'param_name'    => 'chk_btn',
			"value"       => array('Show'=>'shw'), //value
			'description'	=> esc_html__( 'Check it, If you want to show contact us button', 'sumba-kit' )
		),
		array(
		    'type'          => 'vc_link',
		    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
		    'param_name'    => 'btn',
			'description'	=> esc_html__( 'Enter button', 'sumba-kit' ),
			'dependency'	=> array( 'element' => 'chk_btn', 'value' => 'shw' )
		),
		array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Features', 'sumba-kit' ),
		    'param_name'    => 'features',
			'description'	=> esc_html__( 'Enter features', 'sumba-kit' ),
			'dependency'	=> array('element' => 'img_pos' ,'value' => 'align_right'),
			'params'		=> array(
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter feature title', 'sumba-kit' )
				),
				array(
				    'type'          => 'href',
				    'heading'       => esc_html__( 'URL', 'sumba-kit' ),
				    'param_name'    => 'url',
					'description'	=> esc_html__( 'Enter the url', 'sumba-kit' )
				),
				array(
				    'type'          => 'dropdown',
				    'heading'       => esc_html__( 'Icon type', 'sumba-kit' ),
				    'param_name'    => 'type',
				    'value'			=> array(
				    	esc_html__( 'Font Icon', 'sumba-kit' ) => 'icon',
				    	esc_html__( 'Image', 'sumba-kit' ) => 'image',
				    ),
					'description'	=> esc_html__( 'Choose icon type', 'sumba-kit' )
				),

				array(
				    'type'          => 'iconpicker',
				    'heading'       => esc_html__( 'Icon', 'sumba-kit' ),
				    'param_name'    => 'icon',
					'description'	=> esc_html__( 'Choose icon', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'icon' ),
				),
				array(
				    'type'          => 'attach_image',
				    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
				    'param_name'    => 'image',
					'description'	=> esc_html__( 'Choose image icon', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'image' ),
				),

			)
		),

	),

);