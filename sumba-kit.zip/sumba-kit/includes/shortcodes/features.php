<?php

return array(

	'name'			=> esc_html__( 'Sumba Features', 'sumba-kit' ),
	'base'			=> 'sumbawp-features',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show the business features', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Features', 'sumba-kit' ),
		    'param_name'    => 'features',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Enter the features', 'sumba-kit' ),
			'params'		=> array(
				array(
				    'type'          => 'dropdown',
				    'heading'       => esc_html__( 'Icon type', 'sumba-kit' ),
				    'param_name'    => 'type',
					'description'	=> esc_html__( 'Choose the icon type', 'sumba-kit' ),
					'value'			=> array(
						esc_html__( '--Select--', 'sumba-kit' ) => '',
						esc_html__( 'Font Icon', 'sumba-kit' ) => 'icon',
						esc_html__( 'Image', 'sumba-kit' ) => 'image',
					)
				),
				array(
				    'type'          => 'iconpicker',
				    'heading'       => esc_html__( 'Icon', 'sumba-kit' ),
				    'param_name'    => 'icon',
					'description'	=> esc_html__( 'Choose the icon', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'icon' )
				),
				array(
				    'type'          => 'attach_image',
				    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
				    'param_name'    => 'image',
					'description'	=> esc_html__( 'Choose the image to show', 'sumba-kit' ),
					'dependency'	=> array( 'element' => 'type', 'value' => 'image' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter the title', 'sumba-kit' ),
				),
				array(
				    'type'          => 'href',
				    'heading'       => esc_html__( 'URL', 'sumba-kit' ),
				    'param_name'    => 'url',
					'description'	=> esc_html__( 'Enter the URL (optional)', 'sumba-kit' ),
				),
				array(
				    'type'          => 'textarea',
				    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
				    'param_name'    => 'text',
					'description'	=> esc_html__( 'Enter the detailed description', 'sumba-kit' ),
				),

			)
		),
		
	),

);