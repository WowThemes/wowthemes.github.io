<?php
return array(

		'name'			=> esc_html__( 'Company Tabs With Progress Bar ', 'sumba-kit' ),
		'base'			=> 'sumbawp-about-company-tabs-alternative',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show company tabs with progress bar', 'sumba-kit' ),

		'params' => array(
				array(
					'type'			=> 'param_group',
					'heading'		=> esc_html__('Company Tabs', 'sumba-kit'),
					'param_name'	=> 'tabs',
					'description'	=> esc_html__('Create company tabs', 'sumba-kit'),
					'params'		=> array(
							array(
							    'type'          => 'attach_image',
							    'heading'       => esc_html__( 'Tab Image', 'sumba-kit' ),
							    'param_name'    => 'tab_image',
								'admin_label' 	=> false,
								'description'	=> esc_html__( 'Choose the image to show as tab', 'sumba-kit' )
							),
							array(
							    'type'          => 'textfield',
							    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
							    'param_name'    => 'title',
							    'admin_label' 	=> true,
								'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
							),
							array(
							    'type'          => 'textarea',
							    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
							    'param_name'    => 'content',
								'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
							),
							array(
							    'type'          => 'param_group',
							    'heading'       => esc_html__( 'Progress Bars', 'sumba-kit' ),
							    'param_name'    => 'pro_bars',
								'description'	=> esc_html__( 'Create progress bar', 'sumba-kit' ),
								'params'		=> array(
									array(
									    'type'          => 'textfield',
									    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
									    'param_name'    => 'pro_title',
										'description'	=> esc_html__( 'Enter the progress bar title', 'sumba-kit' )
									),
									array(
									    'type'          => 'textfield',
									    'heading'       => esc_html__( 'Value', 'sumba-kit' ),
									    'param_name'    => 'pro_value',
										'description'	=> esc_html__( 'Enter the progress bar value', 'sumba-kit' )
									)
								)
							)
						)
					),
				),

	);
