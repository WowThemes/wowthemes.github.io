<?php

return array(

		'name'			=> esc_html__( 'Planner Charts', 'sumba-kit' ),
		'base'			=> 'sumbawp-planner-charts',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show financial planner charts', 'sumba-kit' ),

		

		'params' => array(

			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
			    'param_name'    => 'title',
				'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Back Title', 'sumba-kit' ),
			    'param_name'    => 'back_title',
				'description'	=> esc_html__( 'Enter back title', 'sumba-kit' )
			),
			array(
			    'type'          => 'attach_image',
			    'heading'       => esc_html__( 'Video Image', 'sumba-kit' ),
			    'param_name'    => 'vid_img',
				'description'	=> esc_html__( 'Upload video image', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Video Link', 'sumba-kit' ),
			    'param_name'    => 'vid_link',
				'description'	=> esc_html__( 'Enter video link', 'sumba-kit' )
			),
			array(
			    'type'          => 'textarea_html',
			    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
			    'param_name'    => 'content',
				'description'	=> esc_html__( 'Enter description', 'sumba-kit' )
			),
			array(
			    'type'          => 'vc_link',
			    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
			    'param_name'    => 'btn',
				'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
			),
			
			array(
			    'type'          => 'dropdown',
			    'heading'       => esc_html__( 'Chart Type', 'sumba-kit' ),
			    'param_name'    => 'type',
			    'group'			=> esc_html__( 'Options', 'sumba-kit' ),
				'value'			=> array(
					esc_html__( '--Select--', 'sumba-kit' ) => '',
					esc_html__( 'Line', 'sumba-kit' ) => 'line',
					esc_html__( 'Bar', 'sumba-kit' ) => 'bar',
					esc_html__( 'Radar', 'sumba-kit' ) => 'radar',
					esc_html__( 'Pie', 'sumba-kit' ) => 'pie',
					esc_html__( 'Polar area', 'sumba-kit' ) => 'polar',
					esc_html__( 'Bubble', 'sumba-kit' ) => 'bubble',
					esc_html__( 'Scatter', 'sumba-kit' ) => 'scatter',
					esc_html__( 'Area', 'sumba-kit' ) => 'area',
					esc_html__( 'Mixed', 'sumba-kit' ) => 'mixed',

				),
				'default'		=> 'line',
				'description'	=> esc_html__( 'Choose chart type', 'sumba-kit' )
			),

			array(
				'type'		=> 'checkbox',
				'heading'	=> esc_html__( 'Responsive Chart', 'sumba-kit' ),
				'param_name'    => 'responsive',
				'group'			=> esc_html__( 'Options', 'sumba-kit' ),
				"value"       => array(
                                   'Responsive Chart'=>'responsive',
                                        ), //value
			),
			array(
			    'type'          => 'dropdown',
			    'heading'       => esc_html__( 'Tooltip Modes', 'sumba-kit' ),
			    'param_name'    => 'tooltip_mode',
			    'group'			=> esc_html__( 'Options', 'sumba-kit' ),
				'value'			=> array(
					esc_html__( '--Select--', 'sumba-kit' ) => '',
					esc_html__( 'Point', 'sumba-kit' ) => 'point',
					esc_html__( 'Nearest', 'sumba-kit' ) => 'nearest',
					esc_html__( 'Index', 'sumba-kit' ) => 'index',
					esc_html__( 'X', 'sumba-kit' ) => 'x',
					esc_html__( 'Y', 'sumba-kit' ) => 'y',
				),
				'default'		=> 'date',
				'description'	=> esc_html__( 'Choose tooltip mode', 'sumba-kit' )
			),
			array(
				'type'		=> 'checkbox',
				'heading'	=> esc_html__( 'Tool Tip intersect', 'sumba-kit' ),
				'group'			=> esc_html__( 'Options', 'sumba-kit' ),
				'param_name'    => 'tooltip_inter',
				"value"       => array(
                                   'Tool Tip intersect'=>'tooltip_inter',
                                        ), //value
			),
			array(
			    'type'          => 'dropdown',
			    'heading'       => esc_html__( 'Hover Modes', 'sumba-kit' ),
			    'group'			=> esc_html__( 'Options', 'sumba-kit' ),
			    'param_name'    => 'hover_mode',
				'value'			=> array(
					esc_html__( '--Select--', 'sumba-kit' ) => '',
					esc_html__( 'Point', 'sumba-kit' ) => 'point',
					esc_html__( 'Nearest', 'sumba-kit' ) => 'nearest',
					esc_html__( 'Index', 'sumba-kit' ) => 'index',
					esc_html__( 'X', 'sumba-kit' ) => 'x',
					esc_html__( 'Y', 'sumba-kit' ) => 'y',
				),
				'default'		=> 'point',
				'description'	=> esc_html__( 'Choose hover mode', 'sumba-kit' )
			),
			array(
				'type'		=> 'checkbox',
				'heading'	=> esc_html__( 'Hover intersect', 'sumba-kit' ),
				'group'			=> esc_html__( 'Options', 'sumba-kit' ),
				'param_name'    => 'hover_inter',
				"value"       => array(
                                   'Hover Intersect'=>'hover_intersect',
                                        ), //value
			),

			array(
				'type'          => 'textfield',
			    'heading'       => esc_html__( 'Labels', 'sumba-kit' ),
			    'param_name'    => 'labels',
				'description'	=> esc_html__( 'Enter the label', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 1', 'sumba-kit' )
				
			),
			array(
				'type'          => 'param_group',
			    'heading'       => esc_html__( 'Data Sets', 'sumba-kit' ),
			    'param_name'    => 'datasets',
				'description'	=> esc_html__( 'Enter data sets', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 1', 'sumba-kit' ),
				'params'		=> array(
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Label', 'sumba-kit' ),
					    'param_name'    => 'label',
						'description'	=> esc_html__( 'Enter the data set label', 'sumba-kit' )
					),
					array(
					    'type'          => 'checkbox',
					    'heading'       => esc_html__( 'Fill', 'sumba-kit' ),
					    'param_name'    => 'fill',
						'description'	=> esc_html__( 'Enable if you want to fill it with background color', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Background Color', 'sumba-kit' ),
					    'param_name'    => 'backgroundColor',
						'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Border Color', 'sumba-kit' ),
					    'param_name'    => 'borderColor',
						'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Data', 'sumba-kit' ),
					    'param_name'    => 'data',
						'description'	=> esc_html__( 'Enter the comma separated data values', 'sumba-kit' )
					),

				)

			),

			array(
				'type'          => 'textfield',
			    'heading'       => esc_html__( 'Labels', 'sumba-kit' ),
			    'param_name'    => 'labels_1',
				'description'	=> esc_html__( 'Enter the label', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 2', 'sumba-kit' )
				
			),
			array(
				'type'          => 'param_group',
			    'heading'       => esc_html__( 'Data Sets', 'sumba-kit' ),
			    'param_name'    => 'datasets_1',
				'description'	=> esc_html__( 'Enter data sets', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 2', 'sumba-kit' ),
				'params'		=> array(
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Label', 'sumba-kit' ),
					    'param_name'    => 'label',
						'description'	=> esc_html__( 'Enter the data set label', 'sumba-kit' )
					),
					array(
					    'type'          => 'checkbox',
					    'heading'       => esc_html__( 'Fill', 'sumba-kit' ),
					    'param_name'    => 'fill',
						'description'	=> esc_html__( 'Enable if you wnat to fill it with background color', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Background Color', 'sumba-kit' ),
					    'param_name'    => 'backgroundColor',
						'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Border Color', 'sumba-kit' ),
					    'param_name'    => 'borderColor',
						'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Data', 'sumba-kit' ),
					    'param_name'    => 'data',
						'description'	=> esc_html__( 'Enter the comma separated data values', 'sumba-kit' )
					),

				)

			),

			array(
				'type'          => 'textfield',
			    'heading'       => esc_html__( 'Labels', 'sumba-kit' ),
			    'param_name'    => 'labels_2',
				'description'	=> esc_html__( 'Enter the label', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 3', 'sumba-kit' )
				
			),
			array(
				'type'          => 'param_group',
			    'heading'       => esc_html__( 'Data Sets', 'sumba-kit' ),
			    'param_name'    => 'datasets_2',
				'description'	=> esc_html__( 'Enter data sets', 'sumba-kit' ),
				'group'			=> esc_html__( 'Tab 3', 'sumba-kit' ),
				'params'		=> array(
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Label', 'sumba-kit' ),
					    'param_name'    => 'label',
						'description'	=> esc_html__( 'Enter the data set label', 'sumba-kit' )
					),
					array(
					    'type'          => 'checkbox',
					    'heading'       => esc_html__( 'Fill', 'sumba-kit' ),
					    'param_name'    => 'fill',
						'description'	=> esc_html__( 'Enable if you wnat to fill it with background color', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Background Color', 'sumba-kit' ),
					    'param_name'    => 'backgroundColor',
						'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'colorpicker',
					    'heading'       => esc_html__( 'Border Color', 'sumba-kit' ),
					    'param_name'    => 'borderColor',
						'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Data', 'sumba-kit' ),
					    'param_name'    => 'data',
						'description'	=> esc_html__( 'Enter the comma separated data values', 'sumba-kit' )
					),

				)

			),

		),

);