<?php

return array(

	'name'			=> esc_html__( 'Public Survey / Stats', 'sumba-kit' ),
	'base'			=> 'sumbawp-stats',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show the statistics about the company', 'sumba-kit' ),

	'params' => array(
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
		    'param_name'    => 'title',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
		),
		array(
		    'type'          => 'textfield',
		    'heading'       => esc_html__( 'Tagline', 'sumba-kit' ),
		    'param_name'    => 'tagline',
			'admin_label' 	=> true,
			'description'	=> esc_html__( 'Enter the tagline', 'sumba-kit' )
		),
		array(
		    'type'          => 'textarea_html',
		    'heading'       => esc_html__( 'Content', 'sumba-kit' ),
		    'param_name'    => 'content',
			'admin_label' 	=> false,
			'description'	=> esc_html__( 'Enter graphy iframe', 'sumba-kit' )
		),
		array(
			'type'			=> 'checkbox',
			'heading'		=> esc_html__( 'Show View Button', 'sumba-kit' ),
			'param_name'	=>	'chck_btn',
			'value'			=> array('Show' => 'shw'),
			'description'	=> esc_html__( 'Check it, if you want to show view button', 'sumba-kit' )
		),
		array(
		    'type'          => 'vc_link',
		    'heading'       => esc_html__( 'Button', 'sumba-kit' ),
		    'param_name'    => 'btn',
			'description'	=> esc_html__( 'Set the button data', 'sumba-kit' ),
			'dependency'	=> array('element' => 'chck_btn', 'value' => 'shw')
		),
		array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Stats', 'sumba-kit' ),
		    'param_name'    => 'stats',
			'description'	=> esc_html__( 'Enter the stats', 'sumba-kit' ),
			'params'		=> array(
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Stat', 'sumba-kit' ),
				    'param_name'    => 'stat',
					'description'	=> esc_html__( 'Enter the stats', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Stat Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter the stat title', 'sumba-kit' )
				),	
			)
		),


	),

);