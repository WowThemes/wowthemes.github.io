<?php

return array(

		'name'			=> esc_html__( 'Company Stats Style Three', 'sumba-kit' ),
		'base'			=> 'sumbawp-stats-three',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show the statistics about the company', 'sumba-kit' ),

		'params' => array(
			array(
		    'type'          => 'param_group',
		    'heading'       => esc_html__( 'Stats', 'sumba-kit' ),
		    'param_name'    => 'stats',
			'description'	=> esc_html__( 'Enter the stats', 'sumba-kit' ),
			'params'		=> array(
				array(
				    'type'          => 'attach_image',
				    'heading'       => esc_html__( 'Image', 'sumba-kit' ),
				    'param_name'    => 'image',
					'admin_label' 	=> false,
					'description'	=> esc_html__( 'Choose image for stats', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Stat', 'sumba-kit' ),
				    'param_name'    => 'stat',
					'description'	=> esc_html__( 'Enter the stat value', 'sumba-kit' )
				),
				array(
				    'type'          => 'textfield',
				    'heading'       => esc_html__( 'Stat Title', 'sumba-kit' ),
				    'param_name'    => 'title',
					'description'	=> esc_html__( 'Enter the stat title', 'sumba-kit' )
				)	
			)
		)
		),



);