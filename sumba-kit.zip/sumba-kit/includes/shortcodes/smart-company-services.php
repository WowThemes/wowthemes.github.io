<?php
return array(

	'name'			=> esc_html__( 'Smart Company Services', 'sumba-kit' ),
	'base'			=> 'sumbawp-smart-company-services',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show smart company services', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> esc_html__( 'Side image', 'sumba-kit' ),
			'param_name'	=> 'img',
			'description'	=> esc_html__( 'Attach side image', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Tag Line', 'sumba-kit' ),
			'param_name'	=> 'tagline',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter tag line', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter title', 'sumba-kit' )
		),
		array(
			'type'			=> 'textarea_html',
			'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
			'param_name'	=> 'content',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter description', 'sumba-kit' )
		),
		array(
			'type'			=> 'param_group',
			'heading'		=> esc_html__( 'Smart Features', 'sumba-kit' ),
			'param_name'	=> 'features',
			'description'	=> esc_html__( 'Add smart features', 'sumba-kit' ),
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__( 'Feature Icon Image', 'sumba-kit' ),
					'param_name'	=> 'img',
					'description'	=> esc_html__( 'Attach feature icon image', 'sumba-kit' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
					'param_name'	=> 'title',
					'admin_label'	=> false,
					'description'	=> esc_html__( 'Enter title', 'sumba-kit' )
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
					'param_name'	=> 'content',
					'admin_label'	=> false,
					'description'	=> esc_html__( 'Enter description', 'sumba-kit' )
				)
			)
		)
	)
);
