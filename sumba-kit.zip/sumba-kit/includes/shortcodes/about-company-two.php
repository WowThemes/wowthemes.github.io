<?php

return array(

		'name'			=> esc_html__( 'About Company Style Two', 'sumba-kit' ),
		'base'			=> 'sumbawp-about-company-two',
		'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
		'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
		'description'	=> esc_html__( 'Show about company with promotional video', 'sumba-kit' ),

		'params' => array(
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Background Image', 'sumba-kit' ),
				'param_name'	=> 'bg_img',
				'description' 	=> esc_html__( 'Upload background image', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Title', 'sumba-kit' ),
			    'param_name'    => 'title',
				'admin_label' 	=> true,
				'description'	=> esc_html__( 'Enter the title of the section', 'sumba-kit' )
			),
			array(
			    'type'          => 'textarea_html',
			    'heading'       => esc_html__( 'Description', 'sumba-kit' ),
			    'param_name'    => 'content',
				'admin_label' 	=> false,
				'description'	=> esc_html__( 'Enter the description of the section', 'sumba-kit' )
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__( 'Company Stats', 'default' ),
				'param_name'	=> 'stats',
				'description'	=> esc_html__( 'Enter company stats', 'default' ),
				'params'		=> array(
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Stat Value', 'sumba-kit' ),
					    'param_name'    => 'stat_value',
						'admin_label' 	=> false,
						'description'	=> esc_html__( 'Enter the stat value', 'sumba-kit' )
					),
					array(
					    'type'          => 'textfield',
					    'heading'       => esc_html__( 'Stat Title', 'sumba-kit' ),
					    'param_name'    => 'stat_title',
						'admin_label' 	=> false,
						'description'	=> esc_html__( 'Enter the stat title of the section', 'sumba-kit' )
					),
				),
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> esc_html__('Button', 'sumba-kit'),
				'param_name'	=> 'btn',
				'description'	=> esc_html__( 'Enter button', 'sumba-kit' )
			),
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Video Image', 'sumba-kit' ),
				'param_name'	=> 'vid_img',
				'description' 	=> esc_html__( 'Upload video image', 'sumba-kit' )
			),
			array(
				'type'			=> 'vc_link',
				'heading'		=> esc_html__('Video Link', 'sumba-kit'),
				'param_name'	=> 'vid_btn',
				'description'	=> esc_html__( 'Enter video link', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Video Title', 'sumba-kit' ),
			    'param_name'    => 'vid_title',
				'admin_label' 	=> false,
				'description'	=> esc_html__( 'Enter video title', 'sumba-kit' )
			),
			array(
			    'type'          => 'textfield',
			    'heading'       => esc_html__( 'Video Tagline', 'sumba-kit' ),
			    'param_name'    => 'vid_tag',
				'admin_label' 	=> false,
				'description'	=> esc_html__( 'Enter video tagline', 'sumba-kit' )
			),

		)



);