<?php
return array(

	'name'			=> esc_html__( 'Development Stages', 'sumba-kit' ),
	'base'			=> 'sumbawp-development-stages',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show development stages for projects', 'sumba-kit' ),

	'params' => array(
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Background Image', 'sumba-kit' ),
				'param_name'	=> 'bg_img',
				'description'	=> esc_html__( 'Attach background image', 'sumba-kit' )
			),
			array(
				'type'			=> 'textfield',
				'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
				'param_name'	=> 'title',
				'admin_label'	=> true,
				'description'	=> esc_html__( 'Enter title of the section', 'sumba-kit' )
			),
			array(
				'type'			=> 'param_group',
				'heading'		=> esc_html__( 'Development Stages', 'sumba-kit' ),
				'param_name'	=> 'stages',
				'description'	=> esc_html__( 'Add development stages', 'sumba-kit' ),
				'params'		=> array(
						array(
							'type'			=> 'textfield',
							'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
							'param_name'	=> 'title',
							'admin_label'	=> true,
							'description'	=> esc_html__( 'Enter the title of stage', 'sumba-kit' )
						),
						array(
							'type'			=> 'textarea',
							'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
							'param_name'	=> 'content',
							'admin_label'	=> false,
							'description'	=> esc_html__( 'Enter the description of stage', 'sumba-kit' )
						)
					)
				),
			array(
				'type'			=> 'attach_image',
				'heading'		=> esc_html__( 'Mockup', 'sumba-kit' ),
				'param_name'	=> 'mockup',
				'description'	=> esc_html__( 'Attach mockup', 'sumba-kit' )
			)
		)
	);
