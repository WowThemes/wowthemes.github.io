<?php
return array(

	'name'			=> esc_html__( 'Amusing Inspirational Events', 'sumba-kit' ),
	'base'			=> 'sumbawp-amusing-inspirational-events',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show amusing inspirational events ', 'sumba-kit' ),

	'params' => array(
		array(
			'type'			=> 'attach_image',
			'heading'		=> esc_html__( 'Image', 'sumba-kit' ),
			'param_name'	=> 'img',
			'description'	=> esc_html__( 'Attach image', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
			'param_name'	=> 'title',
			'admin_label'	=> true,
			'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
		),
		array(
			'type'			=> 'textarea_html',
			'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
			'param_name'	=> 'content',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Address', 'sumba-kit' ),
			'param_name'	=> 'adress',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter the address', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Email', 'sumba-kit' ),
			'param_name'	=> 'email',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter the email', 'sumba-kit' )
		),
		array(
			'type'			=> 'textfield',
			'heading'		=> esc_html__( 'Phone No', 'sumba-kit' ),
			'param_name'	=> 'phone',
			'admin_label'	=> false,
			'description'	=> esc_html__( 'Enter the phone no', 'sumba-kit' )
		)
	)
);
