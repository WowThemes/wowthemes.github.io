<?php
return array(

	'name'			=> esc_html__( 'Team History ', 'sumba-kit' ),
	'base'			=> 'sumbawp-team-history',
	'category'		=> esc_html__( 'Sumbawp', 'sumba-kit' ),
	'icon'			=> trailingslashit( get_template_directory_uri() ) . 'img/vc.png',
	'description'	=> esc_html__( 'Show team history', 'sumba-kit' ),

	'params' => array(
		array(
			'type' 			=> 'param_group',
			'heading'		=> esc_html__( 'Team History', 'sumba-kit' ),
			'param_name'	=> 'team_history',
			'description' 	=> esc_html__( 'Add team history', 'sumba-kit' ),
			'params'		=> array(
				array(
					'type'			=> 'attach_image',
					'heading'		=> esc_html__( 'Image', 'default' ),
					'param_name'	=> 'img',
					'description'	=> esc_html__( 'Attach team image', 'sumba-kit' )
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Year', 'sumba-kit' ),
					'param_name'	=> 'year',
					'description'	=> esc_html__( 'Enter the year', 'sumba-kit' )
				),
				array(
					'type'			=> 'checkbox',
					'heading'		=> esc_html__( 'Show Background Title', 'sumba-kit' ),
					'param_name'    => 'title_show',
					//"value"       	=> array('Yes'=>'yes'), //value
				),
				array(
					'type'			=> 'textfield',
					'heading'		=> esc_html__( 'Backgound Title', 'sumba-kit' ),
					'param_name'	=> 'bg_title',
					'description'	=> esc_html__( 'Enter the background title', 'sumba-kit' ),
					'dependency'	=> array(
					        "element" => "title_show",
					        "value" => "true"
					    )
				),
				array(
					'type'			=> 'vc_link',
					'heading'		=> esc_html__( 'Title', 'sumba-kit' ),
					'param_name'	=> 'title',
					'description'	=> esc_html__( 'Enter the title', 'sumba-kit' )
				),
				array(
					'type'			=> 'textarea',
					'heading'		=> esc_html__( 'Description', 'sumba-kit' ),
					'param_name'	=> 'content',
					'description'	=> esc_html__( 'Enter the description', 'sumba-kit' )
				)
			)
		),
	)
);
