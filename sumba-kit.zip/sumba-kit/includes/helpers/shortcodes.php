<?php

/**
 * Shortcodes and VC Class
 */
class SumbaKit_Shortcodes
{
	/**
	 * Main init for vc map and shortcodes related hooks
	 *
	 * @return void
	 */
	static function init() {
			
		//self::register();
		add_action( 'vc_before_init', array( __CLASS__, 'register' ) );
		self::autocomplete_hooks();
	}

	/**
	 * VC map from an array of defined vc map files.
	 *
	 * @return void This method doesn't return anything.
	 */
	static function register() {

		self::custom_params();

		vc_set_shortcodes_templates_dir( get_template_directory() . '/templates/shortcodes' );

		vc_set_as_theme();

		$shortcodes = array( 'features', 'financial-plan', 'entrepreneurs', 'about-company', 'pricing-tables', 'latest-news', 'portfolio', 'stats', 'team', 'partners', 'contact-info', 'services', 'proficient-guidance', 'stats-two', 'financial-planning', 'core-services', 'request-callback', 'our-industries', 'get-quote', 'planner-charts', 'testimonials', 'latest-news-two', 'get-services', 'about-company-two', 'professional-team', 'request-callback-two', 'stats-three', 'latest-news-three', 'company-core-features', 'portfolio-two', 'about-company-tabs', 'contact-info-two', 'what-we-do', 'about-company-tabs-alternative', 'development-stages', 'pricing-tables-two', 'smart-company-services', 'company-core-features-style-two', 'testimonials-style-two', 'awards-company', 'blog-list-view', 'amusing-inspirational-events', 'team-history', 'experienced-specialist', 'benefits-rewards', 'company-benefits', 'job-positions','contact-us-google-maps', 'contact-info-with-form', 'company-team', 'team-contact-info', 'contact-us-form', 'blog-grid', 'sumba-social-media');

		foreach( $shortcodes as $shortcode ) {
			self::map($shortcode);
		}

	}

	/**
	 * Vc map or register shortcode
	 * @param  array $shortcode shortcodes array
	 * @return void            [description]
	 */
	static function map( $shortcode ) {

		$file = SUMBAKIT_PATH . 'includes/shortcodes/' . $shortcode . '.php';

		if ( file_exists( $file ) ) {
			$data = include $file;

			if( $data && function_exists('vc_map') ) {
				vc_map( $data );
				add_shortcode( $data['base'], array( __CLASS__, 'render' ) );
				
			} /*else {
			}*/
		}
	}

	static function render( $atts, $content = null, $tag ) {
		
		$file = SUMBAKIT_PATH . 'includes/shortcodes/' . $tag . '.php';

		if ( ! file_exists( $file ) ) {
			$file = SUMBAKIT_PATH . 'includes/shortcodes/' . str_replace( 'sumbawp-', '', $tag ) . '.php';
		}

		if ( file_exists( $file ) ) {
			
			$data = include $file;
			
			$file = locate_template( 'templates/shortcodes/' . $tag . '.php' );
			
			$data = self::parseData( $data, $atts );
			$data = shortcode_atts( $data, $atts, $tag );
			
			extract($data);

			unset($data);

			if( file_exists( $file ) ) {
				ob_start();
				include $file;
				return ob_get_clean();
			}
		}
	}

	static function parseData( $data, $atts ) {
		$newdata = array();

		if ( isset( $data['params'] ) ) {
			foreach( $data['params'] as $param ) {
				$name = $param['param_name'];
				if ( $name !== 'content' ) {
					$newdata[ $param['param_name'] ] = isset( $atts[ $name ] ) ? $atts[ $name ] : '';
				}
			}
		}

		return $newdata;
	}
	/**
	 * [autocomplete_hooks description]
	 *
	 * @return [type] [description]
	 */
	static function autocomplete_hooks() {

		// Our Professional team
		add_filter( 'vc_autocomplete_sumbawp-team_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-team_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// About company 
		add_filter( 'vc_autocomplete_sumbawp-about-company_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-about-company_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-about-company_include_callback', array( __CLASS__, 'post_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-about-company_include_render', array( __CLASS__, 'post_render' ), 10, 3);
		
		// Pricing Tables
		add_filter( 'vc_autocomplete_sumbawp-pricing-tables_include_callback', array( __CLASS__, 'post_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-pricing-tables_include_render', array( __CLASS__, 'post_render' ), 10, 3);
		
		// Portfolio
		add_filter( 'vc_autocomplete_sumbawp-portfolio_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio_tag_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio_tag_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);
		
		// Portfolio two
		add_filter( 'vc_autocomplete_sumbawp-portfolio-two_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio-two_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio-two_tag_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-portfolio-two_tag_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Latest News
		add_filter( 'vc_autocomplete_sumbawp-latest-news_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-latest-news_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Our Latest News Two
		add_filter( 'vc_autocomplete_sumbawp-latest-news-two_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-latest-news-two_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Blog List
		add_filter( 'vc_autocomplete_sumbawp-blog-list-view_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-blog-list-view_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Job positions
		add_filter( 'vc_autocomplete_sumbawp-job-positions_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-job-positions_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Company team
		add_filter( 'vc_autocomplete_sumbawp-company-team_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-company-team_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);

		// Blog Grid
		add_filter( 'vc_autocomplete_sumbawp-blog-grid_cat_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-blog-grid_cat_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);
	
		// Award Year
		add_filter( 'vc_autocomplete_sumbawp-awards-company_year_callback', array( __CLASS__, 'taxonomy_callback' ), 10, 3);
		add_filter( 'vc_autocomplete_sumbawp-awards-company_year_render', array( __CLASS__, 'taxonomy_render' ), 10, 3);


	}
	/**
	 * VC auto complete callback for taxonomy select.
	 *
	 * @param  string $query Search term
	 * @param  string $tag   Shortcode tag
	 * @param  string $param param name wich is called for.
	 * @return array         returns array of selected values.
	 */
	static function taxonomy_callback( $query, $tag, $param ) {
		global $wpdb;
	
		$vc_data = WPBMap::getParam($tag, $param);
		$dn = new Sumbawp_DotNotation( $vc_data );
		$post_type = ( $dn->get('query_args.taxonomy' ) ) ? $dn->get('query_args.taxonomy' ) : 'category';

		$post_meta_infos = get_terms( array( 'taxonomy' => $post_type, 'search' => $query, 'hide_empty' => false ) );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data['value'] = $value->term_id;
				$data['label'] = __( 'Id', 'sumba-kit' ) . ': ' . $value->term_id . ( ( strlen( $value->name ) > 0 ) ? ' - ' . __( 'Title', 'sumba-kit' ) . ': ' . $value->name : '' );
				$results[] = $data;
			}
		}

		return $results;
	}

	/**
	 * VC auto complete callback for taxonomy select.
	 *
	 * @param  string $query Search term
	 * @param  string $tag   Shortcode tag
	 * @param  string $param param name wich is called for.
	 * @return array         returns array of selected values.
	 */
	static function post_callback( $query, $tag, $param ) {
		global $wpdb;
	
		$vc_data = WPBMap::getParam($tag, $param);
		$dn = new Sumbawp_DotNotation( $vc_data );
		$post_type = ( $dn->get('query_args.post_type' ) ) ? $dn->get('query_args.post_type' ) : 'post';

		$post_meta_infos = get_posts( array( 'post_type' => $post_type, 's' => $query ) );

		$results = array();
		if ( is_array( $post_meta_infos ) && ! empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data['value'] = $value->ID;
				$data['label'] = __( 'Id', 'sumba-kit' ) . ': ' . $value->ID . ( ( strlen( $value->post_title ) > 0 ) ? ' - ' . __( 'Title', 'sumba-kit' ) . ': ' . $value->post_title : '' );
				$results[] = $data;
			}
		}

		return $results;
	}

	/**
	 * VC auto complete callback for taxonomy select.
	 *
	 * @param  string $query Search term
	 * @param  string $tag   Shortcode tag
	 * @param  string $param param name wich is called for.
	 * @return array         returns array of selected values.
	 */
	static function taxonomy_render( $value ) {
		$post = get_term( $value['value'] );

		return is_null( $post ) ? false : array(
			'label' => __( 'Id', 'sumba-kit' ) . ': ' . $post->term_id . ( ( strlen( $post->name ) > 0 ) ? ' - ' . __( 'Title', 'sumba-kit' ) . ': ' . $post->name : '' ),
			'value' => $post->term_id,
			'group' => $post->taxonomy,
		);
	}
	/**
	 * VC auto complete callback for taxonomy select.
	 *
	 * @param  string $query Search term
	 * @param  string $tag   Shortcode tag
	 * @param  string $param param name wich is called for.
	 * @return array         returns array of selected values.
	 */
	static function post_render( $value ) {
		$post = get_post( $value['value'] );

		return is_null( $post ) ? false : array(
			'label' => __( 'Id', 'sumba-kit' ) . ': ' . $post->ID . ( ( strlen( $post->post_title ) > 0 ) ? ' - ' . __( 'Title', 'sumba-kit' ) . ': ' . $post->post_title : '' ),
			'value' => $post->ID,
			'group' => $post->post_type,
		);
	}

	/**
	 * VC Custom params
	 */
	static function custom_params() {
		$attributes = array(
		    'type' => 'checkbox',
		    'heading' => esc_html__( 'Container', 'sumba-kit' ),
		    'param_name' => 'container',
		    'value' => array( esc_html__( 'Enable Container', 'sumba-kit' ) => 1 ),
		    'description' => esc_html__( "Enable the container at row level", "sumba-kit" )
		);
		vc_add_param( 'vc_row', $attributes ); // Note: 'vc_message' was used as a base for "Message box" element
	}

}