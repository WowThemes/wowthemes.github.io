<?php
namespace Sumbakit\Helpers;


class Autocomplete {

	static function init() {

		$method = sumbawp_set( $_REQUEST, 'subaction' );
		if ( method_exists( __CLASS__, $method ) ) {

			self::$method();
		}
		exit;
	}

	static function taxonomy() {

		$taxonomy = sumbawp_set( $_GET, 'taxonomy' );
		$search = sumbawp_set( $_GET, 'q' );

		$terms = get_terms( array(
		    'taxonomy' => $taxonomy,
		    'search'	=> $search,
		    'hide_empty'	=> false
		) );
		$return = [];

		if ( $terms ) {
			foreach ($terms as $term) {
				$return[] = array('id' => $term->term_id, 'text' => $term->name );
			}
		}

		return wp_send_json(['results' => $return]);
	}

	static function post() {

		$post_type = sumbawp_set( $_GET, 'post_Type' );
		$search = sumbawp_set( $_GET, 'q' );

		$terms = get_posts( array(
		    'post_type' => $post_type,
		    's'			=> $search,
		    'posts_per_page'	=> -1
		) );

		$return = [];

		if ( $terms ) {
			foreach ($terms as $term) {
				$return[] = array('id' => $term->ID, 'text' => $term->post_title );
			}
		}

		return wp_send_json(['results' => $return]);
	}
}