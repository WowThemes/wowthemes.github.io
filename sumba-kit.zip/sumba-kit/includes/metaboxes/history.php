<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_history_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'history_settings',
		'title'         => __( 'History Settings', 'sumba-kit' ),
		'object_types'  => array( 'history' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => esc_html__( 'Award Year', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the award year', 'sumba-kit' ),
				'id'         => $prefix . 'award_year',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),


		)
) );

	

	// Add other metaboxes as needed