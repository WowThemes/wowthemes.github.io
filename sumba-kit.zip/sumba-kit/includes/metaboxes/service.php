<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_service_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'service_settings',
		'title'         => __( 'Service Settings', 'sumba-kit' ),
		'object_types'  => array( 'service' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => esc_html__( 'Tagline', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the tagline', 'sumba-kit' ),
				'id'         => $prefix . 'tagline',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),

			array(
				'name' => esc_html__( 'Service Image', 'sumba-kit'),
				'desc' => esc_html__( 'Add service image', 'sumba-kit' ),
				'id'   => $prefix . 'img',
				'type' => 'file',
				// 'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
				// 'query_args' => array( 'type' => 'image' ), // Only images attachment
				// Optional, override default text strings
				'text' => array(
					'add_upload_files_text' => 'Add Image', // default: "Add or Upload Files"
					'remove_image_text' => 'Remove Image', // default: "Remove Image"
					'file_text' => 'Image', // default: "File:"
					'file_download_text' => 'Download', // default: "Download"
					'remove_text' => 'Remove', // default: "Remove"
				)
			),

			array(
				'name'       => __( 'Services List', 'sumba-kit' ),
				'desc'       => __( 'Enter list of services', 'sumba-kit' ),
				'id'         => $prefix . 'list',
				'type'       => 'group',
				'repeatable'      => true,
				'options'     => array(
					'group_title'   => __( 'Service {#}', 'sumba-kit' ), // since version 1.1.4, {#} gets replaced by row number
					'add_button'    => __( 'Add Another Service', 'sumba-kit' ),
					'remove_button' => __( 'Remove Service', 'sumba-kit' ),
					'sortable'      => true, // beta
					'closed'     => true, // true to have the groups closed by default
				),
				'fields'	 => array(
					array(
						'name'       => __( 'Service Title', 'sumba-kit' ),
						'desc'       => __( 'Enter the service title.', 'sumba-kit' ),
						'id'         => 'title',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
					array(
						'name'       => __( 'Service URL', 'sumba-kit' ),
						'desc'       => __( 'Enter the service url.', 'sumba-kit' ),
						'id'         => 'service_url',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
				)

			),


		)
) );

	

	// Add other metaboxes as needed