<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_layout_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'layout_settings',
		'title'         => __( 'Layout Settings', 'sumba-kit' ),
		'object_types'  => array( 'page', 'post', 'team', 'job', 'history', 'portfolio' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => __( 'Layout', 'sumba-kit' ),
				'desc'       => __( 'Choose the layout of the post', 'sumba-kit' ),
				'id'         => $prefix . 'layout',
				'type'       => 'radio_image',
				'default'	 => 'right',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,
				'options'          => array(
					'full'    	=> __('Full Width', 'cmb2'),
					'left'  	=> __('Left Sidebar', 'cmb2'),
					'right' 	=> __('Right Sidebar', 'cmb2'),
				),
				'images_path'      => SUMBAKIT_URL,
				'images'           => array(
					'full'    	=> 'assets/images/1col.png',
					'left'  	=> 'assets/images/2cl.png',
					'right' 	=> 'assets/images/2cr.png',
				)
			),
			array(
				'name' => __( 'Sidebars', 'sumba-kit' ),
				'desc' => __( 'Choose the sidebar', 'sumba-kit' ),
				'id'   => $prefix . 'sidebar',
				'type' => 'select',
				// 'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
				// 'repeatable' => true,
				'options'		=> array_merge( array('' => __('Select Sidebar', 'sumba-kit')), $sidebars ),
				'attributes' => array(
					'required'               => false, // Will be required only if visible.
					'data-conditional-id'    => $prefix . 'layout',
					'data-conditional-value' => wp_json_encode( array( 'left', 'right' ) ),
					'placeholder'			 => esc_html__( 'Select Sidebar', 'sumba-kit' )
				),
			),

		)
	) );

	

	// Add other metaboxes as needed