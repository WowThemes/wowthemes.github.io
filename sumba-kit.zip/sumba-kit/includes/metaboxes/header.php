<?php

// Start with an underscore to hide fields from custom fields list
$prefix = '_sumbakit_header_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'header_settings',
		'title'         => __( 'Header Settings', 'sumba-kit' ),
		'object_types'  => array( 'page', 'post', 'team', 'job', 'history', 'portfolio' ), // Post type
		'context'       => 'side',
		'priority'      => 'default',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => __( 'Select Header', 'sumba-kit' ),
				'desc'       => __( 'Select the header style for this page', 'sumba-kit' ),
				'id'         => $prefix . 'header',
				'type'       => 'select',
				'default'	 => '',
				'options'    => array(
					''      => __( 'Default Header', 'sumba-kit' ),
					'1'     => __( 'Header Style 1', 'sumba-kit' ),
					'2'     => __( 'Header Style 2', 'sumba-kit' ),
					'3'     => __( 'Header Style 3', 'sumba-kit' ),
				),				
				
			),
			array(
				'name'       => __( 'Select Footer Type', 'sumba-kit' ),
				'desc'       => __( 'Select the footer type for this page', 'sumba-kit' ),
				'id'         => $prefix . 'footer_type',
				'type'       => 'select',
				'default'	 => '',
				'options'    => array(
					''				=> __( 'Default Footer', 'sumba-kit' ),
					'elementor'     => __( 'Elementor', 'sumba-kit' ),

				),
			),

		)
	) );

	

	// Add other metaboxes as needed