<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_pricing_table_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'table_settings',
		'title'         => __( 'Table Settings', 'sumba-kit' ),
		'object_types'  => array( 'pricing_table' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => esc_html__( 'Tagline', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the tagline', 'sumba-kit' ),
				'id'         => $prefix . 'tagline',
				'type'       => 'text',
				'default'	 => 'Regular Services',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name' => esc_html__( 'Pricing Table Icon', 'sumba-kit'),
				'desc' => esc_html__( 'Add pricing table icon image', 'sumba-kit' ),
				'id'   => $prefix . 'img',
				'type' => 'file',
				// 'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
				// 'query_args' => array( 'type' => 'image' ), // Only images attachment
				// Optional, override default text strings
				'text' => array(
					'add_upload_files_text' => 'Add Image', // default: "Add or Upload Files"
					'remove_image_text' => 'Remove Image', // default: "Remove Image"
					'file_text' => 'Image', // default: "File:"
					'file_download_text' => 'Download', // default: "Download"
					'remove_text' => 'Remove', // default: "Remove"
				)
			),
			array(
				'name'       => esc_html__( 'Symbol', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the currency symbol', 'sumba-kit' ),
				'id'         => $prefix . 'symbol',
				'type'       => 'text_small',
				'default'	 => '$',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name' => esc_html__('Price', 'sumba-kit'),
				'desc' => esc_html__('Enter the package price', 'sumba-kit'),
				'id' => $prefix.'price',
				'type' => 'text_money',
				// 'before_field' => '£', // Replaces default '$'

			),
			array(
				'name'       => esc_html__( 'Duration', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the duration eg: month or year', 'sumba-kit' ),
				'id'         => $prefix . 'duration',
				'type'       => 'text_small',
				'default'	 => 'month',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name'       => esc_html__( 'Button Text', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the text to show on button', 'sumba-kit' ),
				'id'         => $prefix . 'btn',
				'type'       => 'text_small',
				'default'	 => 'Select Plan',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name'       => esc_html__( 'Button Link', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the link to the button', 'sumba-kit' ),
				'id'         => $prefix . 'link',
				'type'       => 'text_url',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),

			array(
				'name'       => __( 'Features', 'sumba-kit' ),
				'desc'       => __( 'Setup Table features', 'sumba-kit' ),
				'id'         => $prefix . 'features',
				'type'       => 'group',
				'repeatable'      => true,
				'options'     => array(
					'group_title'   => __( 'Feature {#}', 'sumba-kit' ), // since version 1.1.4, {#} gets replaced by row number
					'add_button'    => __( 'Add Another Feature', 'sumba-kit' ),
					'remove_button' => __( 'Remove Feature', 'sumba-kit' ),
					'sortable'      => true, // beta
					'closed'     => true, // true to have the groups closed by default
				),
				'fields'	 => array(
					array(
						'name'       => __( 'Feature', 'sumba-kit' ),
						'desc'       => __( 'Enter the feature. You can use html tags', 'sumba-kit' ),
						'id'         => 'feature',
						'type'       => 'textarea_small',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
				)

			),


		)
) );

	

	// Add other metaboxes as needed