<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_team_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'team_settings',
		'title'         => __( 'Team Settings', 'sumba-kit' ),
		'object_types'  => array( 'team' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => __( 'Designation', 'sumba-kit' ),
				'desc'       => __( 'Enter the designation of team member', 'sumba-kit' ),
				'id'         => $prefix . 'designation',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name'       => __( 'Social Icons', 'sumba-kit' ),
				'desc'       => __( 'Setup Social Icons', 'sumba-kit' ),
				'id'         => $prefix . 'icons',
				'type'       => 'group',
				'repeatable'      => true,
				'options'     => array(
					'group_title'   => __( 'Entry {#}', 'sumba-kit' ), // since version 1.1.4, {#} gets replaced by row number
					'add_button'    => __( 'Add Another Soical', 'sumba-kit' ),
					'remove_button' => __( 'Remove Social', 'sumba-kit' ),
					'sortable'      => true, // beta
					'closed'     => true, // true to have the groups closed by default
				),
				'fields'	 => array(
					array(
						'name'       => __( 'Title', 'sumba-kit' ),
						'desc'       => __( 'Enter the title for social network', 'sumba-kit' ),
						'id'         => 'title',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
					array(
						'name'       => __( 'Icon', 'sumba-kit' ),
						'desc'       => __( 'Choose the icon', 'sumba-kit' ),
						'id'         => 'icon',
						'type'       => 'faiconselect',
						'default'	 => '',
						'options' => array(
							'fa fa-facebook' 		=> 'fa fa-facebook',
							'fa fa-linkedin' 		=> 'fa fa-linkedin',
							'fa fa-twitter'	 		=> 'fa fa-twitter',
							'fa fa-pinterest' 		=> 'fa fa-pinterest',
							'fa fa-google-plus'	 	=> 'fa fa-google-plus'
						)
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
					array(
						'name'       => __( 'URL', 'sumba-kit' ),
						'desc'       => __( 'Enter social profile URL', 'sumba-kit' ),
						'id'         => 'url',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),

				)

			),


		)
) );

	

	// Add other metaboxes as needed