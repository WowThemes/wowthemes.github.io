<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_banner_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'banner_settings',
		'title'         => __( 'Banner Settings', 'sumba-kit' ),
		'object_types'  => array( 'page', 'post', 'team', 'job', 'history', 'portfolio' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => __( 'Heading', 'sumba-kit' ),
				'desc'       => __( 'Enter the heading of the banner', 'sumba-kit' ),
				'id'         => $prefix . 'heading',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name' => __( 'Background Image', 'sumba-kit' ),
				'desc' => __( 'Choose the background Image', 'sumba-kit' ),
				'id'   => $prefix . 'bg',
				'type' => 'file',
				// 'protocols' => array('http', 'https', 'ftp', 'ftps', 'mailto', 'news', 'irc', 'gopher', 'nntp', 'feed', 'telnet'), // Array of allowed protocols
				// 'repeatable' => true,
			),

		)
	) );

	

	// Add other metaboxes as needed