<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_job_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'job_settings',
		'title'         => __( 'Job Settings', 'sumba-kit' ),
		'object_types'  => array( 'job' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => esc_html__( 'Tag Line', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the tag line', 'sumba-kit' ),
				'id'         => $prefix . 'tagline',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name'       => esc_html__( 'Location', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the job location', 'sumba-kit' ),
				'id'         => $prefix . 'location',
				'type'       => 'text',
				'default'	 => '',
				//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
				// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
				// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
				// 'on_front'        => false, // Optionally designate a field to wp-admin only
				// 'repeatable'      => true,

			),
			array(
				'name'		=> esc_html__( 'End Date', 'sumba-kit' ),
				'desc'		=> esc_html__( 'Select the closing date of job position', 'sumba-kit' ),
				'id'		=> $prefix . 'end_date',
				'type'		=> 'text_date_timestamp',
				'default'	=> '',
			),
			array(
				'name'       => esc_html__( 'Button Link', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the link for apply now button ', 'sumba-kit' ),
				'id'         => $prefix . 'btn_link',
				'type'       => 'text',
				'default'	 => 'https://',
			),


		)
) );

	

	// Add other metaboxes as needed