<?php

// Start with an underscore to hide fields from custom fields list
	$prefix = '_sumbakit_portfolio_';

	/**
	 * Initiate the metabox
	 */
	$cmb = new_cmb2_box( array(
		'id'            => 'portfolio_settings',
		'title'         => __( 'Portfolio Settings', 'sumba-kit' ),
		'object_types'  => array( 'portfolio' ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
		// 'cmb_styles' => false, // false to disable the CMB stylesheet
		// 'closed'     => true, // Keep the metabox closed by default
		'fields'		=> array(
			array(
				'name'       => esc_html__( 'Gallery', 'sumba-kit' ),
				'desc'       => esc_html__( 'Upload portfolio gallery images', 'sumba-kit' ),
				'id'         => $prefix . 'gallery',
				'type'       => 'file_list',
				'text' => array(
							'add_upload_files_text' => 'Add or Upload', // default: "Add or Upload Files"
							'remove_image_text' => 'Remove Image', // default: "Remove Image"
							'file_text' => 'Replacement', // default: "File:"
							'file_download_text' => 'Replacement', // default: "Download"
							'remove_text' => 'Remove', // default: "Remove"
						),
			),
			array(
				'name'       => esc_html__( 'Client', 'sumba-kit' ),
				'desc'       => esc_html__( 'Enter the client name.', 'sumba-kit' ),
				'id'         => $prefix . 'client_name',
				'type'       => 'text',
				'default'	 => '',
			),
			array(
				'name'		=> esc_html__( 'Date', 'sumba-kit' ),
				'desc'		=> esc_html__( 'Select the date.', 'sumba-kit' ),
				'id'		=> $prefix . 'date',
				'type'		=> 'text_date_timestamp',
				'default'	=> '',
			),
			array(
				'name'		=> esc_html__( 'Team', 'sumba-kit' ),
				'desc'		=> esc_html__( 'Select the team members to show. Start typing their title.', 'sumba-kit' ),
				'id'		=> $prefix . 'team',
				'type'		=> 'post_search_ajax',
				'limit'      	=> 10, 		// Limit selection to X items only (default 1)
				'sortable' 	 	=> true, 	// Allow selected items to be sortable (default false)
				'query_args'	=> array(
					'post_type'			=> array( 'team' ),
					'post_status'		=> array( 'publish' ),
					'posts_per_page'	=> -1
				
				)
			
			),
			array(
				'name'		=> esc_html__( 'Services', 'sumba-kit' ),
				'desc'		=> esc_html__( 'Select the services to show. Start typing services title.', 'sumba-kit' ),
				'id'		=> $prefix . 'service',
				'type'		=> 'post_search_ajax',
				'limit'      	=> 10, 		// Limit selection to X items only (default 1)
				'sortable' 	 	=> true, 	// Allow selected items to be sortable (default false)
				'query_args'	=> array(
					'post_type'			=> array( 'service' ),
					'post_status'		=> array( 'publish' ),
					'posts_per_page'	=> -1
				
				)
			
			),
			array(
				'name'       => __( 'Social Icons', 'sumba-kit' ),
				'desc'       => __( 'Setup Social Icons', 'sumba-kit' ),
				'id'         => $prefix . 'icons',
				'type'       => 'group',
				'repeatable'      => true,
				'options'     => array(
					'group_title'   => __( 'Entry {#}', 'sumba-kit' ), // since version 1.1.4, {#} gets replaced by row number
					'add_button'    => __( 'Add Another Soical', 'sumba-kit' ),
					'remove_button' => __( 'Remove Social', 'sumba-kit' ),
					'sortable'      => true, // beta
					'closed'     => true, // true to have the groups closed by default
				),
				'fields'	 => array(
					array(
						'name'       => __( 'Title', 'sumba-kit' ),
						'desc'       => __( 'Enter the title for social network', 'sumba-kit' ),
						'id'         => 'title',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
					array(
						'name'       => __( 'Icon', 'sumba-kit' ),
						'desc'       => __( 'Choose the icon', 'sumba-kit' ),
						'id'         => 'icon',
						'type'       => 'faiconselect',
						'default'	 => '',
						'options' => array(
							'fa fa-facebook' 		=> 'fa fa-facebook',
							'fa fa-linkedin' 		=> 'fa fa-linkedin',
							'fa fa-twitter'	 		=> 'fa fa-twitter',
							'fa fa-pinterest' 		=> 'fa fa-pinterest',
							'fa fa-google-plus'	 	=> 'fa fa-google-plus',
							'fa fa-instagram'	 	=> 'fa fa-instagram',
							'fa fa-youtube'	 	    => 'fa fa-youtube',
						)
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),
					array(
						'name'       => __( 'URL', 'sumba-kit' ),
						'desc'       => __( 'Enter social profile URL', 'sumba-kit' ),
						'id'         => 'url',
						'type'       => 'text',
						'default'	 => '',
						//'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
						// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
						// 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
						// 'on_front'        => false, // Optionally designate a field to wp-admin only
						// 'repeatable'      => true,

					),

				)

			),


		)
) );

	

	// Add other metaboxes as needed