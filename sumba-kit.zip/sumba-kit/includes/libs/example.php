<?php
require_once ('coinapi.inc.php');
// define constants for testing
$api_key = "6C7DF913-710E-4075-91B1-2DE111245A94"; // insert here you api key
$asset_id_base = 'BTC';
$asset_id_quote = 'USD';
$symbol_id = 'BITSTAMP_SPOT_BTC_USD';
$period_id = '1HRS';
$time_start = (new DateTime())->modify('-7 days');
$time_end = (new DateTime())->modify('-5 days');
$limit = 200;
// allocate class
$capi = new CoinAPI($api_key);
// get list of exchanges
update_option('coin_list_of_exchanges', $capi->GetExchanges());
// get list of assets
update_option( 'coin_list_of_assets', $capi->GetAssets());
// get list of symbols
update_option('coin_list_of_symbols', $capi->GetSymbols());
// get current exchange rate
update_option( 'coin_current_exchange_rates', $capi->GetExchangeRate($asset_id_base, $asset_id_quote));
// get all current exchange rates for asset
update_option( 'coin_all_current_rates_for_assets', $capi->GetExchangeRates($asset_id_base));
// get ohlcv periods
update_option( 'get_ohlcv_periods', $capi->GetPeriods());

// get latest ohlcv data for specific symbol and period
update_option('latest_ohlcv_data_for_spec_symbol_period', $capi->GetOHLCVLatest($symbol_id, $period_id, $limit));
// get history ohlcv data for specific symbol, period and time range
update_option('coin_history_ohlcv_data_spec_symb_period',$capi->GetOHLCVHistory($symbol_id, $period_id, $time_start, $time_end, $limit));

// get latest trades across all symbols
update_option('coin_latest_trades_all_symb', $capi->GetTradesLatest(null, $limit));
// get latest trades from specific symbol
update_option('coin_latest_trades_spec_symb',$capi->GetTradesLatest($symbol_id, $limit));
// get history trades from specific symbol and time range
update_option('coin_history_trades_spec_cymb_time_range', $capi->GetTradesHistory($symbol_id, $time_start, $time_end, $limit));
// get current quotes across all symbols
update_option('coin_current_quotes', $capi->GetQuotesCurrent());
// get current quote for specific symbol
update_option('coin_current_quotes_spec_symb', $capi->GetQuotesCurrent($symbol_id));
// get latest quotes across all symbols
update_option('coin_latest_quotes', $capi->GetQuotesLatest(null, $limit));
// get latest quotes from specific symbol
update_option('coin_latest_quotes_spec_symb', $capi->GetQuotesLatest($symbol_id, $limit));
// get history quotes from specific symbol and time range
update_option('coin_history_quotes', $capi->GetQuotesHistory($symbol_id, $time_start, $time_end, $limit));
// get current Orderbooks across all symbols
update_option('coin_orderbooks',$capi->GetOrderbookCurrent());
// get current Orderbook from specific symbol
update_option('coin_orderbooks_spec_symb', $capi->GetOrderbookCurrent($symbol_id));
// get latest Orderbooks from spefific symbol
update_option('coin_orderbooks_spec_symb_latest', $capi->GetOrderbookLatest($symbol_id, $limit));
// get history Orderbooks from specific symbol and time range
update_option('coin_orderbooks_spec_symb_history', $capi->GetOrderbookHistory($symbol_id, $time_start, $time_end, $limit));
// get latest twitter data
update_option('coin_latest_twitter_data', $capi->GetTwitterLatest($limit));
// get history twitter data from specific time range
update_option('coin_history_twitter_data', $capi->GetTwitterHistory($time_start, $time_end, $limit));

exit;