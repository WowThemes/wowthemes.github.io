<?php

require_once SUMBAKIT_PATH . 'includes/helpers/autocomplete.php';

add_action('sumbawp/social_share', 'sumbakit_social_share');
add_action('sumbawp/single_post/after_content', 'sumbakit_single_post_related', 10);
add_action('sumbawp/single_post/after_content', 'sumbakit_single_post_author', 15);

add_filter( 'comment_form_fields', 'sumbakit_comment_form_fields', 100 );
add_filter( 'sumbawp_social_media_profiles', 'sumbakit_social_media_profiles' );
add_action( 'wp_ajax__submawp_elementor_control_autocomplete', array( 'Sumbakit\Helpers\Autocomplete', 'init' ) );

function sumbakit_social_share( $post_id ) {

	if( ! class_exists('Sumbawp_Base')) {
		return;
	}

	$options = Sumbawp_Base::option();

	//if( sumbawp_set($options, 'show_post_social_share') ) {
		echo '<div class="social-share"><ul class="unstyled">';
		sumbakit_social_share_output(array('facebook', 'twitter', 'pinterest', 'linkedin'));
		echo '</ul></div>';
	//}
}

/**
 * [sumbakit_single_post_author description]
 *
 * @param  [type] $post_id [description]
 * @return [type]          [description]
 */
function sumbakit_single_post_author($post_id) {
	$options = Sumbawp_Base::option();

	if( $options->get('single_post_show_author' ) ) {
		get_template_part('templates/single/author-box');
	}
}

/**
 * [sumbakit_single_post_related description]
 *
 * @param  [type] $post_id [description]
 * @return [type]          [description]
 */
function sumbakit_single_post_related($post_id) {

	$options = Sumbawp_Base::option();

	if( $options->get( 'single_post_show_related' ) ) {
		get_template_part('templates/single/related-posts');
	}
}


/**
 * [sumbakit_comment_form_fields description]
 *
 * @param  [type] $fields [description]
 * @return [type]         [description]
 */
function sumbakit_comment_form_fields( $fields ) {

	$comment = $fields['comment'];

	unset($fields['comment']);

	$fields['comment'] = $comment;

	return $fields;
}

/**
 * [builder_social_share_output description]
 *
 * @param  array   $shares [description].
 * @param  boolean $color  [description].
 * @return [type]          [description]
 */
function sumbakit_social_share_output( $shares = array(), $color = false ) {

	$permalink = get_permalink(get_the_ID());
	$titleget = get_the_title();
	if (in_array('facebook', $shares)) {
	    ?>
	    <li>
	    <a onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo esc_url( $permalink ); ?>', 'Facebook', 'width=600,height=300,left=' + (screen.availWidth / 2 - 300) + ',top=' + (screen.availHeight / 2 - 150) + '');
	                    return false;" href="http://www.facebook.com/sharer.php?u=<?php echo esc_url($permalink); ?>">
	        <i class="fa fa-facebook fa-fw"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('twitter', $shares)) {
	    ?>
	    <li>
	    <a onClick="window.open('http://twitter.com/share?url=<?php echo esc_url($permalink); ?>&amp;text=<?php echo str_replace(" ", "%20", $titleget); ?>', 'Twitter share', 'width=600,height=300,left=' + (screen.availWidth / 2 - 300) + ',top=' + (screen.availHeight / 2 - 150) + '');
	                    return false;" href="http://twitter.com/share?url=<?php echo esc_url($permalink); ?>&amp;text=<?php echo str_replace(" ", "%20", $titleget); ?>">
	        <i class="fa fa-twitter fa-fw"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('google-plus', $shares)) {
	    ?>
	    <li>
	    <a onClick="window.open('https://plus.google.com/share?url=<?php echo esc_url($permalink); ?>', 'Google plus', 'width=585,height=666,left=' + (screen.availWidth / 2 - 292) + ',top=' + (screen.availHeight / 2 - 333) + '');
	                    return false;" href="https://plus.google.com/share?url=<?php echo esc_url($permalink); ?>">
	        <i class="fa fa-google fa-fw"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('reddit', $shares)) {
	    ?>
	    <li>
	    <a onClick="window.open('http://reddit.com/submit?url=<?php echo esc_url($permalink); ?>&amp;title=<?php echo str_replace(" ", "%20", $titleget); ?>', 'Reddit', 'width=617,height=514,left=' + (screen.availWidth / 2 - 308) + ',top=' + (screen.availHeight / 2 - 257) + '');
	                    return false;" href="http://reddit.com/submit?url=<?php echo esc_url($permalink); ?>&amp;title=<?php echo str_replace(" ", "%20", $titleget); ?>">
	        <i class="fa fa-reddit"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('linkedin', $shares)) {
	    ?>
	    <li>
	    <a onClick="window.open('http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($permalink); ?>', 'Linkedin', 'width=863,height=500,left=' + (screen.availWidth / 2 - 431) + ',top=' + (screen.availHeight / 2 - 250) + '');
	                    return false;" href="http://www.linkedin.com/shareArticle?mini=true&amp;url=<?php echo esc_url($permalink); ?>">
	        <i class="fa fa-linkedin fa-fw"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('pinterest', $shares)) {
	    ?>
	    <li>
	    <a href='javascript:void((function()%7Bvar%20e=document.createElement(&apos;script&apos;);e.setAttribute(&apos;type&apos;,&apos;text/javascript&apos;);e.setAttribute(&apos;charset&apos;,&apos;UTF-8&apos;);e.setAttribute(&apos;src&apos;,&apos;http://assets.pinterest.com/js/pinmarklet.js?r=&apos;+Math.random()*99999999);document.body.appendChild(e)%7D)());'>
	        <i class="fa fa-pinterest fa-fw"></i></a></li>
	<?php } ?>



	<?php
	if (in_array('tumblr', $shares)) {
	    $str = $permalink;
	    $str = preg_replace('#^https?://#', '', $str);
	    ?>
	    <li>
	    <a onClick="window.open('http://www.tumblr.com/share/link?url=<?php echo esc_attr($str); ?>&amp;name=<?php echo str_replace(" ", "%20", $titleget); ?>', 'Tumblr', 'width=600,height=300,left=' + (screen.availWidth / 2 - 300) + ',top=' + (screen.availHeight / 2 - 150) + '');
	                    return false;" href="http://www.tumblr.com/share/link?url=<?php echo esc_attr( $str ); ?>&amp;name=<?php echo str_replace(" ", "%20", $titleget); ?>">
	        <i class="fa fa-tumblr fa-fw"></i></a></li>
	<?php } ?>

	<?php
	if (in_array('envelope-o', $shares)) {
	    ?>
	    <li>
	    <a href="mailto:?Subject=<?php echo str_replace(" ", "%20", $titleget); ?>&amp;Body=<?php echo esc_url($permalink); ?>"><i class="fa fa-envelope fa-fw"></i></a></li>
	    <?php
	}
}

if ( ! function_exists( 'sumbakit_social_media_profiles' ) ) {

	function sumbakit_social_media_profiles( $icons ) {

		$myicons = include SUMBAKIT_PATH . 'includes/resource/icons.php';
		$icons = array_merge( $icons, $myicons );
		return $icons;
	}
}
