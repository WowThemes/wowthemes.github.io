<?php
/**
 * Plugin Name:     Sumba Kit
 * Plugin URI:      https://wptech.co
 * Description:     Sumba Theme support plugin
 * Author:          Shahbaz Ahmed
 * Author URI:      https://wptech.co
 * Text Domain:     sumba-kit
 * Domain Path:     /languages
 * Version:         0.1.0
 *
 * @package         Sumbakit
 */

// Your code starts here.


defined('SUMBAKIT_PATH') || define('SUMBAKIT_PATH', plugin_dir_path( __FILE__ ) );
defined('SUMBAKIT_URL') || define('SUMBAKIT_URL', plugin_dir_url(  __FILE__ ) );


add_action('plugins_loaded', 'sumbakit_wp' );

function sumbakit_wp() {

	global $pagenow;
	require_once SUMBAKIT_PATH . 'includes/fileCrop.php';
	require_once SUMBAKIT_PATH . 'cmb/CMB2/init.php';
	require_once SUMBAKIT_PATH . 'cmb/CMB2-radio-image/cmb2-radio-image.php';
	require_once SUMBAKIT_PATH . 'cmb/cmb-field-select2/cmb-field-select2.php';
	require_once SUMBAKIT_PATH . 'cmb/cmb2-field-faiconselect/iconselect.php';
	require_once SUMBAKIT_PATH . 'cmb/cmb2-field-post-search-ajax-master/cmb-field-post-search-ajax.php';

	require_once SUMBAKIT_PATH . 'includes/elementor.php';
	require_once SUMBAKIT_PATH . 'elementor-controls/controls.php';
	require_once SUMBAKIT_PATH . 'includes/metaboxes.php';
	require_once SUMBAKIT_PATH . 'includes/hooks.php';
	require_once SUMBAKIT_PATH . 'includes/helpers/shortcodes.php';

	require_once SUMBAKIT_PATH . 'post-types/team.php';
	require_once SUMBAKIT_PATH . 'post-types/service.php';
	require_once SUMBAKIT_PATH . 'post-types/history.php';
	require_once SUMBAKIT_PATH . 'post-types/portfolio.php';
	require_once SUMBAKIT_PATH . 'post-types/pricing-table.php';
	require_once SUMBAKIT_PATH . 'post-types/job.php';
	require_once SUMBAKIT_PATH . 'functions.php';

	SumbaKit_Metaboxes::load();
	SumbaKit_Shortcodes::init();
}

//add_action('init', array('SumbaKit_Shortcodes', 'init'), 20 );

function sumbakit_register_widget() {

	require_once SUMBAKIT_PATH . 'includes/widgets/specialist.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/company-overview.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/related-advice.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/press-release.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/about.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/posts.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/tweets.php';
	require_once SUMBAKIT_PATH . 'includes/widgets/company-info.php';
}
add_action( 'widgets_init', 'sumbakit_register_widget' );

if( class_exists('Redux')) {
	Redux::setExtensions( 'sumbawp_options', SUMBAKIT_PATH . 'extensions' );
}

add_filter('user_contactmethods', 'sumbakit_user_contactmethods');

function sumbakit_user_contactmethods($fields) {

	$fields = array_merge($fields, array(
		'facebook'		=> esc_html__( 'Facebook', 'sumba-kit' ),
		'twitter'		=> esc_html__( 'Twitter', 'sumba-kit' ),
		'linkedin'		=> esc_html__( 'Linkedin', 'sumba-kit' ),
		'googleplugin'	=> esc_html__( 'Google Plus', 'sumba-kit' ),
		'pinterest'		=> esc_html__( 'Pinterest', 'sumba-kit' ),
	));

	return $fields;
}
if(!function_exists('sumbakit_output')){
	function sumbakit_output($data){

		echo $data;

	}
}

if(!function_exists('sumbakit_put_file_contents')){
	function sumbakit_put_file_contents($file,$data){

		file_put_contents($filename, $data);

	}
}

if (!function_exists('sumbakit_encrypt')) {

	function sumbakit_encrypt($param) {
		return base64_encode($param);
	}

}

if (!function_exists('sumbakit_decrypt')) {

	function sumbakit_decrypt($param) {
		return base64_decode($param);
	}

}

function sumbawp_register_form($post_data){

	$errors = '';

	$random_password = sumbawp_set( $post_data, 'password' );

	$confirm_password = sumbawp_set( $post_data, 'confirmpswd' );

	if(empty($random_password))
	{
		$errors .= '<div class="alert alert-danger">' . esc_html__('Please enter password', 'sumbawp' ) . '</div>';
	}
	elseif(empty($confirm_password))
	{
		$errors .= '<div class="alert alert-danger">' . esc_html__('Please enter confirm password', 'sumbawp' ) . '</div>';
	}
	elseif($confirm_password != $random_password )
	{
		$errors .= '<div class="alert alert-danger">' . esc_html__('Password and Confirm password are not same', 'sumbawp' ) . '</div>';
	}

	if( ! sumbawp_set( $post_data, 'username') ) {
		
		$errors .= '<div class="alert alert-danger">' . esc_html__('Username is required', 'sumbawp' ) . '</div>';
	}

	if ( username_exists( sumbawp_set( $post_data, 'username' ) ) ) {
		$errors .= '<div class="alert alert-danger">' . esc_html__('Username is already taken, please try another username', 'sumbawp' ) . '</div>';
	}

	$return_message = '';
	if($errors) {
		return array( 'status' => 'error', 'message' => $errors );
	}


	if ( is_email( sumbawp_set( $post_data, 'email' ) ) ) {

		$user_id = wp_create_user( sumbawp_set( $post_data, 'username' ), $random_password, sumbawp_set( $post_data, 'email' ) );
		if ( is_wp_error( $user_id ) && is_array( $user_id->get_error_messages() ) ) {
			foreach ( $user_id->get_error_messages() as $message ) {
				$return_message .= '<p>' . $message . '</p>';
			}
			
			return array( 'status' => 'error', 'message' => $return_message );

		} else {

			// Send the final registration notification
			wp_new_user_notification( $user_id, null, 'both' );
			
			$return_message .= '<div class="alert alert-success">' . esc_html__( 'Registration Successful - An email is sent', 'sumbawp' ) . '</div>';

			return array( 'status' => 'success', 'message' => $return_message );
		}

	} else {
		$return_message .= '<div class="alert alert-danger">' . esc_html__('Please enter valid email address', 'sumbawp' ) . '</div>';
		
		return array( 'status' => 'error', 'message' => $return_message );
	}



	return array( 'loggedin' => false, 'message' => $return_message );

}
