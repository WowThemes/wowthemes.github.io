<?php

class Sumbakit_Elementor_Controls 
{

	static function boot() {
		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			return;
		}

		$build_widgets_filename = [
			'autocomplete',
		];

		foreach ( $build_widgets_filename as $control_filename ) {

			$filename = SUMBAKIT_PATH . "elementor-controls/{$control_filename}/{$control_filename}.php";

			if ( file_exists( $filename ) ) {
				require( $filename );

				$class_name =  'Sumbakit_' . ucwords( str_replace( '-', '_', $control_filename ) ) . '_Control';

				add_action( 'elementor/controls/controls_registered', function($elemntor) use ($class_name, $control_filename ) {
				    $elemntor->register_control( $control_filename, new $class_name() );
				} );
			}


		}
	}
}

add_action('init', array( 'Sumbakit_Elementor_Controls', 'boot' ) );
