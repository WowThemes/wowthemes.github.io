<?php
/**
 * Elementor emoji one area control.
 *
 * A control for displaying a textarea with the ability to add emojis.
 *
 * @since 1.0.0
 */
class Sumbakit_Autocomplete_Control extends \Elementor\Base_Data_Control {

	/**
	 * Get emoji one area control type.
	 *
	 * Retrieve the control type, in this case `emojionearea`.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Control type.
	 */
	public function get_type() {
		return 'autocomplete';
	}

	/**
	 * Enqueue emoji one area control scripts and styles.
	 *
	 * Used to register and enqueue custom scripts and styles used by the emoji one
	 * area control.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function enqueue() {
		// Styles
		wp_register_style( 'autocomplete', SUMBAKIT_URL . 'elementor-controls/autocomplete/css/autocomplete.css', [], '1.0' );
		wp_enqueue_style( 'autocomplete' );

		// Scripts
		wp_register_script( 'autocomplete', SUMBAKIT_URL . 'elementor-controls/autocomplete/js/autocomplete.js', [], '1.0' );
		
		wp_enqueue_script( 'autocomplete' );
	}

	/**
	 * Get emoji one area control default settings.
	 *
	 * Retrieve the default settings of the emoji one area control. Used to return
	 * the default settings while initializing the emoji one area control.
	 *
	 * @since 1.0.0
	 * @access protected
	 *
	 * @return array Control default settings.
	 */
	protected function get_default_settings() {
		return [
			'label_block' => true,
			'rows' => 3,
			'autocomplete_options' => [
				'taxonomy'		=> 'category'
			],
			'subaction'		=> 'taxonomy',
		];
	}

	/**
	 * Render emoji one area control output in the editor.
	 *
	 * Used to generate the control HTML in the editor using Underscore JS
	 * template. The variables for the class are available using `data` JS
	 * object.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function content_template() {
		$control_uid = $this->get_control_uid();
		$settings = $this->get_settings('autocomplete_options');
		//printr($settings);
		?>
		<div class="elementor-control-field">
			<label for="<?php echo esc_attr( $control_uid ); ?>" class="elementor-control-title">{{{ data.label }}}</label>
			<div class="elementor-control-input-wrapper">
				<textarea id="<?php echo esc_attr( $control_uid ); ?>" class="elementor-control-tag-area" rows="{{ data.rows }}" data-setting="{{ data.name }}" placeholder="{{ data.placeholder }}" data-config='{{{ data.autocomplete_options }}}' data-subaction="{{ data.subaction }}"></textarea>

				<input type="text" class="elementor-control-tag-area" id="<?php echo esc_attr( $control_uid ); ?>-keypress" data-setting="{{ data.name }}">
				<input type="hidden" id="<?php echo esc_attr( $control_uid ); ?>" data-setting="{{ data.name }}">

				<div class="submawp-autocomplete">
					
				</div>
			</div>
		</div>
		<# if ( data.description ) { #>
		<div class="elementor-control-field-description">{{{ data.description }}}</div>
		<# } #>
		<?php
	}

}