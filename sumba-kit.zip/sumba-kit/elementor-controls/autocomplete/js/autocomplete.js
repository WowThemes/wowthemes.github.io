jQuery( window ).on( 'elementor:init', function() {
	var ControlEmojiOneAreaItemView = elementor.modules.controls.BaseData.extend( {

		onReady: function() {
			var self = this,
				options = _.extend( {
					emojiPlaceholder: ':smile_cat:',
					pickerPosition: 'bottom',
					filtersPosition: 'top',
					searchPosition: 'bottom',
					saveEmojisAs: 'unicode',
					inline: false,
				}, this.model.get( 'emojionearea_options' ) );

			this.onKeyUp();
		},
		onKeyUp: function() {
			console.log(this.ui);
			//this.ui.input.autocomplete(options);
			var textarea = this.ui.textarea,
			thisis = this;

			jQuery(textarea.context).on('keyup', '.elementor-control-tag-area', function(e) {
				var value = jQuery(this).val(),
				config = jQuery(this).data('config'),
				subaction = jQuery(this).data('subaction')

				jQuery.ajax({
					url: ElementorConfig.ajaxurl,
					type: 'POST',
					data: {action: '_submawp_elementor_control_autocomplete', value: value, subaction: subaction, config: config},
					complete: function(res) {
						if ( res.status == 200 ) {
							var dta = res.responseJSON;

							if ( dta ) {
								var html = '<ul>';
								jQuery(dta).each(function(index, el){
									html += '<li data-id="'+el.value+'">' + el.label + '</li>';
								});

								html += '</ul>';

								jQuery(textarea.context).find('.submawp-autocomplete').html(html);
							}
						} else {

						}
					}
				});
			});
		},

		saveValue: function() {
			this.setValue( this.ui.textarea.getText() );
		},

		onBeforeDestroy: function() {
			this.saveValue();
			this.ui.textarea.emojioneArea().destroy();
		}
	} );
	elementor.addControlView( 'autocomplete', ControlEmojiOneAreaItemView );
} );