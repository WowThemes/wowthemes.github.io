<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Contact_Info_Two extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'contact-info-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Contact information With Map', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'map_section',
			[
				'label' => esc_html__( 'Map Info', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'marker', [
				'label' => __( 'Map Marker', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => __( 'Choose map marker' , 'sumba-kit' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'latitude', [
				'label' => esc_html__( 'Latitude', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter latitude of google map' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'longitude', [
				'label' => esc_html__( 'Longitude', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter longitude of google map' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter location title of google map if you wants to show' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'address', [
				'label' => esc_html__( 'Address', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter location address if you wants to show' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'map_info',
			[
				'label' => __( 'Map Info', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'contact_section',
			[
				'label' => esc_html__( 'Contact Info', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'address', [
				'label' => esc_html__( 'Address', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter company address' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'email', [
				'label' => esc_html__( 'Email', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter email address' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'phone', [
				'label' => esc_html__( 'Phone No', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter Phone number' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'contact_btn',
			[
				'label' => __( 'Show Contact Us Button', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__('Check it, If you want to show contact us button',  'sumba-kit'),
				'label_block' => true,
				'label_on' => __( 'Show', 'sumba-kit' ),
				'label_off' => __( 'Hide', 'sumba-kit' ),
				'return_value' => 'show_btn',
				'default' => 'show_btn',
			]
		);

		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [
					'contact_btn' => 'show_btn',
				],
				'description' => esc_html__( 'Enter button label' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Buttton Link', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'condition' => [
					'contact_btn' => 'show_btn',
				],
				'placeholder' => esc_html__( 'https://', 'sumba-kit' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'description' => esc_html__( 'Enter btn link' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/contact-info-two.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
