<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Company_Core_Features_Style_two extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'company-core-features-style-two';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Company Core Features Style Two', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Company Features', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'bg_img', [
				'label' => esc_html__( 'Background Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => esc_html__( 'Upload background image' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'tagline', [
				'label' => esc_html__( 'Tag Line', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter tag line' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter title' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'images',
			[
				'label' => esc_html__( 'Feature Images', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::GALLERY,
				'default' => [],
				'description' => esc_html__( 'Attach feature images' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter description' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter button label' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'btn_link', [
				'label' => esc_html__( 'Button Link', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => esc_html__( 'https://', 'sumba-kit' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'description' => esc_html__( 'Enter button link' , 'sumba-kit' ),
			]
		);
		

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/company-core-features-style-two.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
