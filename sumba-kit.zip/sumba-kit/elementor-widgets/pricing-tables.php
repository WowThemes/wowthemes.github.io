<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Pricing_Tables extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'pricing-tables';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Sumba Pricing Tables', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'general_section',
			[
				'label' => esc_html__( 'General', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the title of the section' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'desc', [
				'label' => esc_html__( 'Content', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter content' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'play_icon_section',
			[
				'label' => esc_html__( 'Play Icon', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'icon_type',
			[
				'label' => esc_html__( 'Icon type', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'description'	=> esc_html__( 'Choose the icon type', 'sumba-kit' ),
				'default' => 'playicon',
				'options' => [
					'playicon'  => esc_html__( 'Font Icon', 'sumba-kit' ),
					'image' => esc_html__( 'Image', 'sumba-kit' ),
				],
			]
		);

		$this->add_control(
			'playicon',
			[
				'label' => esc_html__( 'Icon', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'options' => get_icons(),
				'condition' => [
					'icon_type' => 'playicon',
				],
				'description'	=> esc_html__( 'Choose the icon', 'sumba-kit' ),
			]
		);

		$this->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'condition' => [
					'icon_type' => 'image',
				],
				'description' => esc_html__( 'Choose the image to show' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'video', [
				'label' => esc_html__( 'Video URL', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => esc_html__( 'https://', 'sumba-kit' ),
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => false,
				],
				'description'	=> esc_html__( 'Enter the video URL to show in popup', 'sumba-kit' )
			]
		);

		$this->add_control(
			'comp_name', [
				'label' => esc_html__( 'Company Name', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the name of the company' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'comp_desg', [
				'label' => esc_html__( 'Designation', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the designated person of the company' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'table_section',
			[
				'label' => esc_html__( 'Pricing Table', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number', [
				'label' => esc_html__( 'Number of Tables', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the number of tables to show' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'include', [
				'label' => esc_html__( 'Include', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'description' => esc_html__( 'Choose specific tables to show' , 'sumba-kit' ),
				'multiple'	=> true,
				'select2options'	=> ['ajax' => ['url' => admin_url('admin-ajax.php?action=_submawp_elementor_control_autocomplete&subaction=post&post_Type=pricing_table'), 'dataType' => 'json']]
			]
		);

		$this->add_control(
			'order', [
				'label' => esc_html__( 'Order', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'desc',
				'options' => [
					'desc'  => esc_html__( 'Desc', 'sumba-kit' ),
					'asc' => esc_html__( 'Asc', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the order either Ascending or descending' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'orderby', [
				'label' => esc_html__( 'Order by', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'date',
				'options' => [
					'date'  => esc_html__( 'Date', 'sumba-kit' ),
					'author' => esc_html__( 'Author', 'sumba-kit' ),
					'title' => esc_html__( 'Title', 'sumba-kit' ),
					'name' => esc_html__( 'Name (Post Slug)', 'sumba-kit' ),
					'comment_count' => esc_html__( 'Comments', 'sumba-kit' ),
					'menu_order' => esc_html__( 'Menu Order', 'sumba-kit' ),
					'rand' => esc_html__( 'Random', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the orderby' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'carousel_section',
			[
				'label' => esc_html__( 'Carousel', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'items', [
				'label' => esc_html__( 'Items', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'		=> '2',
				'description' => esc_html__( 'The number of items you want to see on the screen.' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::SWITCHER,
				
				'label_block' => true,

				'label_on'    => __( 'True', 'sumba-kit' ),

				'label_off'    => __( 'False', 'sumba-kit' ),

				'return_value' => 'true',

				'default'      => 'true',
			]
		);


		$this->add_control(
			'autoplayTimeout', [
				'label' => esc_html__( 'Autoplay Timeout', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'		=> '50000',
				'description' => esc_html__( 'Enter the timeout for autoplay' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'smartSpeed', [
				'label' => esc_html__( 'Speed', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'		=> '250',
				'description' => esc_html__( 'Enter the speed in miliseconds' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/pricing-tables.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}

