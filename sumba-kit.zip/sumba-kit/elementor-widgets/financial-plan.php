<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Financial_Plan extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'financial-plan';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Financial Planning', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Financial Planning', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'tab_image', [
				'label' => esc_html__( 'Plan Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => esc_html__( 'Choose the image to show as tab' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'vid_link',
			[
				'label' => esc_html__( 'Video Link', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => false,
				],
				'description'	=> esc_html__( 'Enter the video link', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the title' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'year', [
				'label' => esc_html__( 'Experience Years', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the experience years' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'tagline', [
				'label' => esc_html__( 'Tag line', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the tag line to show under year' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter the description' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'chck_btn',
			[
				'label' => esc_html__( 'Show Contact Button', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'sumba-kit' ),
				'label_off' => esc_html__( 'Hide', 'sumba-kit' ),
				'return_value' => 'shw',
				'default' => 'shw',
			]
		);

		$repeater->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [
					'chck_btn' => 'shw',
				],
				'description' => esc_html__( 'Enter the button label' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'btn_url',
			[
				'label' => esc_html__( 'Button URL', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( '', 'sumba-kit' ),
				'show_external' => true,
				'condition' => [
					'chck_btn' => 'shw',
				],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => false,
				],
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => __( 'Plans', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
	
				],
				'title_field' => '{{{ title }}}',
			]
		);

	
		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/financial-plan.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
