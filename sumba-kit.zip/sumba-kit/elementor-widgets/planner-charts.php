<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Planner_Charts extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'planner-charts';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Planner Charts', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'general_section',
			[
				'label' => esc_html__( 'General', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the title' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'back_title', [
				'label' => esc_html__( 'Back Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter back title' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'vid_img', [
				'label' => esc_html__( 'Video Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => esc_html__( 'Upload video image' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'vid_link',
			[
				'label' => __( 'Video Link', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'plugin-domain' ),
				'description'	=> esc_html__( 'Enter video link', 'sumba-kit' ),
				'label_block' => true,
				'show_external' => false,
				'default' => [
					'url' => '',
					'is_external' => false,
					'nofollow' => false,
				],
			]
		);

		$this->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter description' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the button label' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'btn_url',
			[
				'label' => esc_html__( 'Button URL', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'sumba-kit' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'options_section',
			[
				'label' => esc_html__( 'Options', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'type',
			[
				'label' => esc_html__( 'Chart Type', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'line',
				'options' => [
					'line'  => esc_html__( 'Line', 'sumba-kit' ),
					'bar' => esc_html__( 'Bar', 'sumba-kit' ),
					'radar' => esc_html__( 'Radar', 'sumba-kit' ),
					'pie' => esc_html__( 'Pie', 'sumba-kit' ),
					'polar' => esc_html__( 'Polar area', 'sumba-kit' ),
					'bubble' => esc_html__( 'Bubble', 'sumba-kit' ),
					'scatter' => esc_html__( 'Scatter', 'sumba-kit' ),
					'area' => esc_html__( 'Area', 'sumba-kit' ),
					'mixed' => esc_html__( 'Mixed', 'sumba-kit' ),
				],
				'description'	=> esc_html__( 'Choose chart type', 'sumba-kit' )
			]
		);

		$this->add_control(
			'responsive',
			[
				'label' => __( 'Responsive Chart', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'your-plugin' ),
				'label_off' => __( 'No', 'your-plugin' ),
				'return_value' => 'responsive',
				'default' => 'responsive',
			]
		);

		$this->add_control(
			'tooltip_mode',
			[
				'label' => esc_html__( 'Tooltip Modes', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'point',
				'options' => [
					'point'  => esc_html__( 'Point', 'sumba-kit' ),
					'nearest' => esc_html__( 'Nearest', 'sumba-kit' ),
					'index' => esc_html__( 'Index', 'sumba-kit' ),
					'x' => esc_html__( 'X', 'sumba-kit' ),
					'y' => esc_html__( 'Y', 'sumba-kit' ),
				],
				'description'	=> esc_html__( 'Choose tooltip mode', 'sumba-kit' )
			]
		);

		$this->add_control(
			'tooltip_inter',
			[
				'label' => __( 'Tool Tip intersect', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'your-plugin' ),
				'label_off' => __( 'No', 'your-plugin' ),
				'return_value' => 'tooltip_inter',
				'default' => 'tooltip_inter',
			]
		);

		$this->add_control(
			'hover_mode',
			[
				'label' => esc_html__( 'Hover Modes', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'point',
				'options' => [
					'point'  => esc_html__( 'Point', 'sumba-kit' ),
					'nearest' => esc_html__( 'Nearest', 'sumba-kit' ),
					'index' => esc_html__( 'Index', 'sumba-kit' ),
					'x' => esc_html__( 'X', 'sumba-kit' ),
					'y' => esc_html__( 'Y', 'sumba-kit' ),
				],
				'description'	=> esc_html__( 'Choose hover mode', 'sumba-kit' )
			]
		);

		$this->add_control(
			'hover_inter',
			[
				'label' => __( 'Hover intersect', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Yes', 'your-plugin' ),
				'label_off' => __( 'No', 'your-plugin' ),
				'return_value' => 'hover_intersect',
				'default' => 'hover_intersect',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tab1_section',
			[
				'label' => esc_html__( 'Tab 1', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'labels', [
				'label' => esc_html__( 'Labels', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the label' , 'sumba-kit' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'label', [
				'label' => esc_html__( 'Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the data set label' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'fill',
			[
				'label' => __( 'Fill', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__( 'Enable if you want to fill it with background color', 'sumba-kit' ),
				'label_on' => __( 'Yes', 'sumba-kit' ),
				'label_off' => __( 'No', 'sumba-kit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'backgroundColor',
			[
				'label' => __( 'Background Color', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				/*'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'borderColor',
			[
				'label' => __( 'Border Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				/*'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'data', [
				'label' => esc_html__( 'Data', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the comma separated data values' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'datasets',
			[
				'label' => __( 'Data Sets', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
	
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tab2_section',
			[
				'label' => esc_html__( 'Tab 2', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'labels_1', [
				'label' => esc_html__( 'Labels', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the label' , 'sumba-kit' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'label', [
				'label' => esc_html__( 'Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the data set label' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'fill',
			[
				'label' => __( 'Fill', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__( 'Enable if you want to fill it with background color', 'sumba-kit' ),
				'label_on' => __( 'Yes', 'sumba-kit' ),
				'label_off' => __( 'No', 'sumba-kit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'backgroundColor',
			[
				'label' => __( 'Background Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				/*'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'borderColor',
			[
				'label' => __( 'Border Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				/*'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'data', [
				'label' => esc_html__( 'Data', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the comma separated data values' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'datasets_1',
			[
				'label' => __( 'Data Sets', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
	
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'tab3_section',
			[
				'label' => esc_html__( 'Tab 3', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'labels_2', [
				'label' => esc_html__( 'Labels', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the label' , 'sumba-kit' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'label', [
				'label' => esc_html__( 'Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the data set label' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'fill',
			[
				'label' => __( 'Fill', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__( 'Enable if you want to fill it with background color', 'sumba-kit' ),
				'label_on' => __( 'Yes', 'sumba-kit' ),
				'label_off' => __( 'No', 'sumba-kit' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$repeater->add_control(
			'backgroundColor',
			[
				'label' => __( 'Background Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				/*'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the background color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'borderColor',
			[
				'label' => __( 'Border Color', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				/*'scheme' => [
					'type' => \Elementor\Scheme_Color::get_type(),
					'value' => \Elementor\Scheme_Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],*/
				'description'	=> esc_html__( 'Choose the border color of data', 'sumba-kit' )
			]
		);

		$repeater->add_control(
			'data', [
				'label' => esc_html__( 'Data', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the comma separated data values' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'datasets_2',
			[
				'label' => __( 'Data Sets', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
	
				],
				'title_field' => '{{{ label }}}',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/planner-charts.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
