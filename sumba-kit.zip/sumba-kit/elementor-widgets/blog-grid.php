<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Blog_Grid extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'blog-grid';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return __( 'Blog Grid', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Blog Grid', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number', [
				'label' => esc_html__( 'Number', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Choose the number of posts to show' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'words', [
				'label' => esc_html__( 'Words Count', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 20,
				'description' => esc_html__( 'Enter the number of words to trim' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'cat', [
				'label' => esc_html__( 'Category', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'description' => esc_html__( 'Choose the category' , 'sumba-kit' ),
				/*'autocomplete_options'	=> wp_json_encode([
					'taxonomy'		=> 'post_tag'
				])*/
				//'options'	=> ['' => 'Type'],
				//'multiple'	=> true,
				'select2options'	=> ['ajax' => ['url' => admin_url('admin-ajax.php?action=_submawp_elementor_control_autocomplete&subaction=taxonomy&taxonomy=category'), 'dataType' => 'json']]
			]
		);

		$this->add_control(
			'columns', [
				'label' => esc_html__( 'Columns', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => '12',
				'options' => [
					'12'  => esc_html__( 'One Column', 'sumba-kit' ),
					'6' => esc_html__( 'Two Columns', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the column number' ),
			]
		);
		$this->add_control(
			'order', [
				'label' => esc_html__( 'Order', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'desc',
				'options' => [
					'desc'  => esc_html__( 'Desc', 'sumba-kit' ),
					'asc' => esc_html__( 'Asc', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the order either Ascending or descending' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'orderby', [
				'label' => esc_html__( 'Order by', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'date',
				'options' => [
					'date'  => esc_html__( 'Date', 'sumba-kit' ),
					'author' => esc_html__( 'Author', 'sumba-kit' ),
					'title' => esc_html__( 'Title', 'sumba-kit' ),
					'name' => esc_html__( 'Name (Post Slug)', 'sumba-kit' ),
					'comment_count' => esc_html__( 'Comments', 'sumba-kit' ),
					'menu_order' => esc_html__( 'Menu Order', 'sumba-kit' ),
					'rand' => esc_html__( 'Random', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the orderby' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'chk_btn',
			[
				'label' => __( 'Show Read More Button', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__('Check it, If you want to show read more button',  'sumba-kit'),
				'label_block' => true,
				'label_on' => __( 'Show', 'sumba-kit' ),
				'label_off' => __( 'Hide', 'sumba-kit' ),
				'return_value' => 'shw',
				'default' => 'shw',
			]
		);

		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Button Label', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'condition' => [
					'chk_btn' => 'shw',
				],
				'description' => esc_html__( 'Enter button label' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'pagi',
			[
				'label' => __( 'Show Pagination', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'description'	=> esc_html__('Check it, if you want to show pagination',  'sumba-kit'),
				'label_block' => true,
				'label_on' => __( 'Show', 'sumba-kit' ),
				'label_off' => __( 'Hide', 'sumba-kit' ),
				'return_value' => 'shw_pagi',
				'default' => 'shw_pagi',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/blog-grid.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
