<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Smart_Company_Services extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'smart-company-services';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return __( 'Smart Company Services', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Services', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'img', [
				'label' => esc_html__( 'Side image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => esc_html__( 'Attach side image' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'tagline', [
				'label' => esc_html__( 'Tag Line', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter tag line' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter title' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter description' , 'sumba-kit' ),
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'img', [
				'label' => esc_html__( 'Feature Icon Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'description' => esc_html__( 'Attach feature icon image' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter title' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter description' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'features',
			[
				'label' => __( 'Smart Features', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
				
				],
				'title_field' => '{{{ title }}}',
			]
		);


	

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/smart-company-services.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
