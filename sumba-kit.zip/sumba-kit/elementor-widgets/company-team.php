<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Company_Team extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'company-team';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Company Team ', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Company Team', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'number', [
				'label' => esc_html__( 'Number', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Choose the number of team members to show' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'cat', [
				'label' => esc_html__( 'Category', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT2,
				'label_block' => true,
				'description' => esc_html__( 'Choose the category' , 'sumba-kit' ),
				/*'autocomplete_options'	=> wp_json_encode([
					'taxonomy'		=> 'post_tag'
				])*/
				//'options'	=> ['' => 'Type'],
				//'multiple'	=> true,
				'select2options'	=> ['ajax' => ['url' => admin_url('admin-ajax.php?action=_submawp_elementor_control_autocomplete&subaction=taxonomy&taxonomy=team_cat'), 'dataType' => 'json']]
			]
		);

		$this->add_control(
			'order', [
				'label' => esc_html__( 'Order', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'desc',
				'options' => [
					'desc'  => esc_html__( 'Desc', 'sumba-kit' ),
					'asc' => esc_html__( 'Asc', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the order either Ascending or descending' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'orderby', [
				'label' => esc_html__( 'Order by', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'date',
				'options' => [
					'date'  => esc_html__( 'Date', 'sumba-kit' ),
					'author' => esc_html__( 'Author', 'sumba-kit' ),
					'title' => esc_html__( 'Title', 'sumba-kit' ),
					'name' => esc_html__( 'Name (Post Slug)', 'sumba-kit' ),
					'comment_count' => esc_html__( 'Comments', 'sumba-kit' ),
					'menu_order' => esc_html__( 'Menu Order', 'sumba-kit' ),
					'rand' => esc_html__( 'Random', 'sumba-kit' ),
				],
				'description' => esc_html__( 'Choose the orderby' , 'sumba-kit' ),
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/company-team.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
