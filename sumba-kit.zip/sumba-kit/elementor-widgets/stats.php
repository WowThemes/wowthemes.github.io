<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Stats extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'stats';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Public Survey / Stats', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Public Survey / Stats', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title', [

				'label'       => __( 'Title', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXT,

				'label_block' => true,

				'description' => __( 'Enter the title of the section' , 'sumba-kit' ),

			]
		);

		$this->add_control(
			'tagline', [

				'label'       => __( 'Tagline', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXT,

				'label_block' => true,

				'description' => __( 'Enter the tagline' , 'sumba-kit' ),

			]
		);

		$this->add_control(
			'desc', [

				'label'       => __( 'Description', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXTAREA,

				'label_block' => true,

				'description' => __( 'Enter the description' , 'sumba-kit' ),

			]
		);

		$this->add_control(
			'chck_btn',
			[
				'label'       => __( 'Show View Button', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::SWITCHER,
				
				'label_block' => true,

				'label_on'    => __( 'Show', 'sumba-kit' ),

				'label_off'    => __( 'Hide', 'sumba-kit' ),

				'return_value' => 'shw',

				'default'      => 'shw',
			]
		);

		$this->add_control(
			'url', [

				'label'         => __( 'Link Url', 'sumba-kit' ),

				'type'          => \Elementor\Controls_Manager::URL,

				'label_block'   => true,

				'description'   => __( 'Enter the link URL' , 'sumba-kit' ),

				'show_external' => true,

				'default'       => [
					'url'         => '',
					'is_external' => true,
					'nofollow'    => false,
				],

				'condition' => [
					'chck_btn' => 'shw',
				],


			]
		);

		$this->add_control(
			'link_title', [

				'label'       => __( 'Link Title', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXT,

				'label_block' => true,

				'description' => __( 'Enter the link title' , 'sumba-kit' ),

				'condition' => [
					'chck_btn' => 'shw',
				],


			]
		);

		


		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'stat', [

				'label'       => __( 'Stat', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXT,

				'label_block' => true,

				'description' => __( 'Enter the stats' , 'sumba-kit' ),

			]
		);

		$repeater->add_control(
			'title', [

				'label'       => __( 'Stat Title', 'sumba-kit' ),

				'type'        => \Elementor\Controls_Manager::TEXT,

				'label_block' => true,

				'description' => __( 'Enter the stat title' , 'sumba-kit' ),

			]
		);

		$this->add_control(
			'stats',
			[
				'label'   => esc_html__( 'Stats', 'sumba-kit' ),

				'type'    => \Elementor\Controls_Manager::REPEATER,

				'fields'  => $repeater->get_controls(),

				'default' => [

				],
				'title_field' => '{{{ title }}}',
			]
		);
		

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();

		extract($settings);

		$file = locate_template( 'templates/elementor/stats.php' );

		if ( file_exists( $file ) ) {

			include $file;
		}
	}

}
