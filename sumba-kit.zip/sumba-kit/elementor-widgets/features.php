<?php

/**
 * Elementor oEmbed Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Widget_Features extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve oEmbed widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'features';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve oEmbed widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {

		return esc_html__( 'Sumba Features', 'sumba-kit' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve oEmbed widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'fa fa-code';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the oEmbed widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'sumbawp' ];
	}

	/**
	 * Register oEmbed widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Features', 'sumba-kit' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new \Elementor\Repeater();

		$repeater->add_control(
			'type',
			[
				'label' => esc_html__( 'Icon type', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'description'	=> esc_html__( 'Choose the icon type', 'sumba-kit' ),
				'default' => 'icon',
				'options' => [
					'icon'  => esc_html__( 'Font Icon', 'plugin-domain' ),
					'image' => esc_html__( 'Image', 'plugin-domain' ),
				],
			]
		);

		$repeater->add_control(
			'icon',
			[
				'label' => esc_html__( 'Icon', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'options' => get_icons(),
				'condition' => [
					'type' => 'icon',
				],
				'description'	=> esc_html__( 'Choose the icon', 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'image', [
				'label' => esc_html__( 'Image', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,
				'condition' => [
					'type' => 'image',
				],
				'description' => esc_html__( 'Choose the image to show' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'title', [
				'label' => esc_html__( 'Title', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'Enter the title' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'link', [
				'label' => esc_html__( 'URL', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,
				'placeholder' => esc_html__( 'https://', 'sumba-kit' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'description' => esc_html__( 'Enter the URL (optional)' , 'sumba-kit' ),
			]
		);

		$repeater->add_control(
			'desc', [
				'label' => esc_html__( 'Description', 'sumba-kit' ),
				'type' => \Elementor\Controls_Manager::WYSIWYG,
				'label_block' => true,
				'description' => esc_html__( 'Enter the detailed description' , 'sumba-kit' ),
			]
		);

		$this->add_control(
			'features',
			[
				'label' => esc_html__( 'Features', 'plugin-domain' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'description' => esc_html__( 'Enter the features', 'sumba-kit' ),
				'fields' => $repeater->get_controls(),
				'default' => [
					
				],
				'title_field' => '{{{ title }}}',
			]
		);

		$this->end_controls_section();

	}

	/**
	 * Render oEmbed widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

		$settings = $this->get_settings_for_display();
		extract($settings);

		$file = locate_template( 'templates/elementor/features.php' );

		if ( file_exists( $file ) ) {
			include $file;
		}
	}

}
