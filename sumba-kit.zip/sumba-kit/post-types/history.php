<?php

/**
 * Registers the `history` post type.
 */
function sumbakit_history_init() {

	$history_permalink = Sumbawp_Base::option('histories_permalink');

	register_post_type( 'history', array(
		'labels'                => array(
			'name'                  => __( 'Histories', 'sumba-kit' ),
			'singular_name'         => __( 'History', 'sumba-kit' ),
			'all_items'             => __( 'All Histories', 'sumba-kit' ),
			'archives'              => __( 'History Archives', 'sumba-kit' ),
			'attributes'            => __( 'History Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into History', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this History', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'history', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'history', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'history', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'history', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Histories list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Histories list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Histories list', 'sumba-kit' ),
			'new_item'              => __( 'New History', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New History', 'sumba-kit' ),
			'edit_item'             => __( 'Edit History', 'sumba-kit' ),
			'view_item'             => __( 'View History', 'sumba-kit' ),
			'view_items'            => __( 'View Histories', 'sumba-kit' ),
			'search_items'          => __( 'Search Histories', 'sumba-kit' ),
			'not_found'             => __( 'No Histories found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Histories found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent History:', 'sumba-kit' ),
			'menu_name'             => __( 'Histories', 'sumba-kit' ),
		),
		'public'                => true,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'           => true,
		'rewrite'               => array('slug' => $history_permalink),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-networking',
		'show_in_rest'          => true,
		'rest_base'             => 'history',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_history_init' );

/**
 * Sets the post updated messages for the `history` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `history` post type.
 */
function history_updated_messages( $messages ) {
	global $post;

	$permalink = get_permalink( $post );

	$messages['history'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'History updated. <a target="_blank" href="%s">View History</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'sumba-kit' ),
		3  => __( 'Custom field deleted.', 'sumba-kit' ),
		4  => __( 'History updated.', 'sumba-kit' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'History restored to revision from %s', 'sumba-kit' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'History published. <a href="%s">View History</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		7  => __( 'History saved.', 'sumba-kit' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'History submitted. <a target="_blank" href="%s">Preview History</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'History scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview History</a>', 'sumba-kit' ),
		date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'History draft updated. <a target="_blank" href="%s">Preview History</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'history_updated_messages' );



/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function sumbawp_history_category_taxonomy() {

	$history_cat_permalink = Sumbawp_Base::option('histories_permalink');

	$labels = array(
		'name'                  => _x( 'Years', 'History Years', 'sumba-kit' ),
		'singular_name'         => _x( 'Year', 'History Year', 'sumba-kit' ),
		'search_items'          => __( 'Search Years', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Years', 'sumba-kit' ),
		'all_items'             => __( 'All Years', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Year', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Year', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Year', 'sumba-kit' ),
		'update_item'           => __( 'Update Year', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Year', 'sumba-kit' ),
		'new_item_name'         => __( 'New Year Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Years', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Years', 'sumba-kit' ),
		'menu_name'             => __( 'Years', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => false,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => $history_cat_permalink),
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'history_year', array( 'history' ), $args );
}

add_action( 'init', 'sumbawp_history_category_taxonomy' );