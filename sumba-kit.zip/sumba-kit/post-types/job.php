<?php

/**
 * Registers the `job` post type.
 */
function sumbakit_job_init() {

	$job_permalink = Sumbawp_Base::option('jobs_permalink');

	register_post_type( 'job', array(
		'labels'                => array(
			'name'                  => __( 'Jobs', 'sumba-kit' ),
			'singular_name'         => __( 'Job', 'sumba-kit' ),
			'all_items'             => __( 'All Jobs', 'sumba-kit' ),
			'archives'              => __( 'Job Archives', 'sumba-kit' ),
			'attributes'            => __( 'Job Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into Job', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Job', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'job', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'job', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'job', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'job', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Jobs list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Jobs list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Jobs list', 'sumba-kit' ),
			'new_item'              => __( 'New Job', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New Job', 'sumba-kit' ),
			'edit_item'             => __( 'Edit Job', 'sumba-kit' ),
			'view_item'             => __( 'View Job', 'sumba-kit' ),
			'view_items'            => __( 'View Jobs', 'sumba-kit' ),
			'search_items'          => __( 'Search Jobs', 'sumba-kit' ),
			'not_found'             => __( 'No Jobs found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Jobs found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent Job:', 'sumba-kit' ),
			'menu_name'             => __( 'Jobs', 'sumba-kit' ),
		),
		'public'                => true,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'           => true,
		'rewrite'               => array('slug' => $job_permalink ),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-businessman',
		'show_in_rest'          => true,
		'rest_base'             => 'job',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_job_init' );

/**
 * Sets the post updated messages for the `job` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `job` post type.
 */
function job_updated_messages( $messages ) {
	global $post;

	$permalink = get_permalink( $post );

	$messages['job'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'Job updated. <a target="_blank" href="%s">View Job</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'sumba-kit' ),
		3  => __( 'Custom field deleted.', 'sumba-kit' ),
		4  => __( 'Job updated.', 'sumba-kit' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Job restored to revision from %s', 'sumba-kit' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'Job published. <a href="%s">View Job</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		7  => __( 'Job saved.', 'sumba-kit' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'Job submitted. <a target="_blank" href="%s">Preview Job</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'Job scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Job</a>', 'sumba-kit' ),
		date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'Job draft updated. <a target="_blank" href="%s">Preview Job</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'job_updated_messages' );



/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function sumbawp_job_category_taxonomy() {

	$job_cat_permalink = Sumbawp_Base::option('jobs_category_permalink');

	$labels = array(
		'name'                  => _x( 'Categories', 'Job Categories', 'sumba-kit' ),
		'singular_name'         => _x( 'Category', 'Job Category', 'sumba-kit' ),
		'search_items'          => __( 'Search Categories', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Categories', 'sumba-kit' ),
		'all_items'             => __( 'All Categories', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Category', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Category', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Category', 'sumba-kit' ),
		'update_item'           => __( 'Update Category', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Category', 'sumba-kit' ),
		'new_item_name'         => __( 'New Category Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'sumba-kit' ),
		'menu_name'             => __( 'Categories', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => false,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => $job_cat_permalink),
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'job_cat', array( 'job' ), $args );
}

add_action( 'init', 'sumbawp_job_category_taxonomy' );