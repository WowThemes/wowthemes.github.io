<?php

/**
 * Registers the `service` post type.
 */
function sumbakit_service_init() {

	$service_permalink = Sumbawp_Base::option('services_permalink');

	register_post_type( 'service', array(
		'labels'                => array(
			'name'                  => __( 'Services', 'sumba-kit' ),
			'singular_name'         => __( 'Service', 'sumba-kit' ),
			'all_items'             => __( 'All Services', 'sumba-kit' ),
			'archives'              => __( 'Service Archives', 'sumba-kit' ),
			'attributes'            => __( 'Service Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into Service', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Service', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'service', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'service', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'service', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'service', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Services list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Services list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Services list', 'sumba-kit' ),
			'new_item'              => __( 'New Service', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New Service', 'sumba-kit' ),
			'edit_item'             => __( 'Edit Service', 'sumba-kit' ),
			'view_item'             => __( 'View Service', 'sumba-kit' ),
			'view_items'            => __( 'View Services', 'sumba-kit' ),
			'search_items'          => __( 'Search Services', 'sumba-kit' ),
			'not_found'             => __( 'No Services found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Services found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent Service:', 'sumba-kit' ),
			'menu_name'             => __( 'Services', 'sumba-kit' ),
		),
		'public'                => false,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'           => true,
		'rewrite'               => array('slug' => $service_permalink),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-clipboard',
		'show_in_rest'          => true,
		'rest_base'             => 'service',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_service_init' );

/**
 * Sets the post updated messages for the `service` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `service` post type.
 */
function service_updated_messages( $messages ) {
	global $post;

	$permalink = get_permalink( $post );

	$messages['service'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'Service updated. <a target="_blank" href="%s">View Service</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'sumba-kit' ),
		3  => __( 'Custom field deleted.', 'sumba-kit' ),
		4  => __( 'Service updated.', 'sumba-kit' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Service restored to revision from %s', 'sumba-kit' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'Service published. <a href="%s">View Service</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		7  => __( 'Service saved.', 'sumba-kit' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'Service submitted. <a target="_blank" href="%s">Preview Service</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'Service scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Service</a>', 'sumba-kit' ),
		date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'Service draft updated. <a target="_blank" href="%s">Preview Service</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'service_updated_messages' );



/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function sumbawp_service_category_taxonomy() {

	$service_cat_permalink = Sumbawp_Base::option('services_category_permalink');

	$labels = array(
		'name'                  => _x( 'Categories', 'Service Categories', 'sumba-kit' ),
		'singular_name'         => _x( 'Category', 'Service Category', 'sumba-kit' ),
		'search_items'          => __( 'Search Categories', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Categories', 'sumba-kit' ),
		'all_items'             => __( 'All Categories', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Category', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Category', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Category', 'sumba-kit' ),
		'update_item'           => __( 'Update Category', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Category', 'sumba-kit' ),
		'new_item_name'         => __( 'New Category Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'sumba-kit' ),
		'menu_name'             => __( 'Categories', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => $service_cat_permalink),
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'service_cat', array( 'service' ), $args );

}

add_action( 'init', 'sumbawp_service_category_taxonomy' );