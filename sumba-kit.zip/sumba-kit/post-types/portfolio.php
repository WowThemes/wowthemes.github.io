<?php

/**
 * Registers the `portfolio` post type.
 */
function sumbakit_portfolio_init() {

	$portfolio_permalink = Sumbawp_Base::option('portfolio_permalink');

	register_post_type( 'portfolio', array(
		'labels'                => array(
			'name'                  => __( 'Portfolios', 'sumba-kit' ),
			'singular_name'         => __( 'Portfolio', 'sumba-kit' ),
			'all_items'             => __( 'All Portfolios', 'sumba-kit' ),
			'archives'              => __( 'Portfolio Archives', 'sumba-kit' ),
			'attributes'            => __( 'Portfolio Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into Portfolio', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Portfolio', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'portfolio', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'portfolio', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'portfolio', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'portfolio', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Portfolios list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Portfolios list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Portfolios list', 'sumba-kit' ),
			'new_item'              => __( 'New Portfolio', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New Portfolio', 'sumba-kit' ),
			'edit_item'             => __( 'Edit Portfolio', 'sumba-kit' ),
			'view_item'             => __( 'View Portfolio', 'sumba-kit' ),
			'view_items'            => __( 'View Portfolios', 'sumba-kit' ),
			'search_items'          => __( 'Search Portfolios', 'sumba-kit' ),
			'not_found'             => __( 'No Portfolios found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Portfolios found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent Portfolio:', 'sumba-kit' ),
			'menu_name'             => __( 'Portfolios', 'sumba-kit' ),
		),
		'public'                => true,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'           => true,
		'rewrite'               => array('slug' => $portfolio_permalink),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-portfolio',
		'show_in_rest'          => true,
		'rest_base'             => 'portfolio',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_portfolio_init' );

/**
 * Sets the post updated messages for the `portfolio` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `portfolio` post type.
 */
function portfolio_updated_messages( $messages ) {
	global $post;

	$permalink = get_permalink( $post );

	$messages['portfolio'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'Portfolio updated. <a target="_blank" href="%s">View Portfolio</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'sumba-kit' ),
		3  => __( 'Custom field deleted.', 'sumba-kit' ),
		4  => __( 'Portfolio updated.', 'sumba-kit' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Portfolio restored to revision from %s', 'sumba-kit' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'Portfolio published. <a href="%s">View Portfolio</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		7  => __( 'Portfolio saved.', 'sumba-kit' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'Portfolio submitted. <a target="_blank" href="%s">Preview Portfolio</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'Portfolio scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Portfolio</a>', 'sumba-kit' ),
		date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'Portfolio draft updated. <a target="_blank" href="%s">Preview Portfolio</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'portfolio_updated_messages' );



/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function sumbawp_portfolio_category_taxonomy() {

	$portfolio_cat_permalink = Sumbawp_Base::option('portfolio_category_permalink');

	$labels = array(
		'name'                  => _x( 'Categories', 'Portfolio Categories', 'sumba-kit' ),
		'singular_name'         => _x( 'Category', 'Portfolio Category', 'sumba-kit' ),
		'search_items'          => __( 'Search Categories', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Categories', 'sumba-kit' ),
		'all_items'             => __( 'All Categories', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Category', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Category', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Category', 'sumba-kit' ),
		'update_item'           => __( 'Update Category', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Category', 'sumba-kit' ),
		'new_item_name'         => __( 'New Category Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'sumba-kit' ),
		'menu_name'             => __( 'Categories', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => $portfolio_cat_permalink),
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'portfolio_cat', array( 'portfolio' ), $args );


	$labels = array(
		'name'                  => _x( 'Tags', 'Portfolio Tags', 'sumba-kit' ),
		'singular_name'         => _x( 'Tag', 'Portfolio Tag', 'sumba-kit' ),
		'search_items'          => __( 'Search Tags', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Tags', 'sumba-kit' ),
		'all_items'             => __( 'All Tags', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Tag', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Tag', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Tag', 'sumba-kit' ),
		'update_item'           => __( 'Update Tag', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Tag', 'sumba-kit' ),
		'new_item_name'         => __( 'New Tag Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Tags', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Tags', 'sumba-kit' ),
		'menu_name'             => __( 'Tags', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => false,
		'hierarchical'      => false,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => true,
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'portfolio_tag', array( 'portfolio' ), $args );
}

add_action( 'init', 'sumbawp_portfolio_category_taxonomy' );