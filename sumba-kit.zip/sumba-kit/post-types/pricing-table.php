<?php

/**
 * Registers the `portfolio` post type.
 */
function sumbakit_pricing_table_init() {
	register_post_type( 'pricing_table', array(
		'labels'                => array(
			'name'                  => __( 'Pricing Tables', 'sumba-kit' ),
			'singular_name'         => __( 'Pricing Table', 'sumba-kit' ),
			'all_items'             => __( 'All Pricing Tables', 'sumba-kit' ),
			'archives'              => __( 'Pricing Table Archives', 'sumba-kit' ),
			'attributes'            => __( 'Pricing Table Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into Pricing Table', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Pricing Table', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'pricing table', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'pricing table', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'pricing table', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'pricing table', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Pricing Tables list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Pricing Tables list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Pricing Tables list', 'sumba-kit' ),
			'new_item'              => __( 'New Pricing Table', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New Pricing Table', 'sumba-kit' ),
			'edit_item'             => __( 'Edit Pricing Table', 'sumba-kit' ),
			'view_item'             => __( 'View Pricing Table', 'sumba-kit' ),
			'view_items'            => __( 'View Pricing Tables', 'sumba-kit' ),
			'search_items'          => __( 'Search Pricing Tables', 'sumba-kit' ),
			'not_found'             => __( 'No Pricing Tables found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Pricing Tables found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent Pricing Table:', 'sumba-kit' ),
			'menu_name'             => __( 'Pricing Tables', 'sumba-kit' ),
		),
		'public'                => false,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title' ),
		'has_archive'           => false,
		'rewrite'               => false,
		'query_var'             => false,
		'menu_icon'             => 'dashicons-feedback',
		'show_in_rest'          => true,
		'rest_base'             => 'pricing-table',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_pricing_table_init' );

