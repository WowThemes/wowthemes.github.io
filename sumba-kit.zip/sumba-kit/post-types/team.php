<?php

/**
 * Registers the `team` post type.
 */


function sumbakit_team_init() {

	$team_permalink = Sumbawp_Base::option('team_permalink');

	register_post_type( 'team', array(
		'labels'                => array(
			'name'                  => __( 'Teams', 'sumba-kit' ),
			'singular_name'         => __( 'Team', 'sumba-kit' ),
			'all_items'             => __( 'All Teams', 'sumba-kit' ),
			'archives'              => __( 'Team Archives', 'sumba-kit' ),
			'attributes'            => __( 'Team Attributes', 'sumba-kit' ),
			'insert_into_item'      => __( 'Insert into Team', 'sumba-kit' ),
			'uploaded_to_this_item' => __( 'Uploaded to this Team', 'sumba-kit' ),
			'featured_image'        => _x( 'Featured Image', 'team', 'sumba-kit' ),
			'set_featured_image'    => _x( 'Set featured image', 'team', 'sumba-kit' ),
			'remove_featured_image' => _x( 'Remove featured image', 'team', 'sumba-kit' ),
			'use_featured_image'    => _x( 'Use as featured image', 'team', 'sumba-kit' ),
			'filter_items_list'     => __( 'Filter Teams list', 'sumba-kit' ),
			'items_list_navigation' => __( 'Teams list navigation', 'sumba-kit' ),
			'items_list'            => __( 'Teams list', 'sumba-kit' ),
			'new_item'              => __( 'New Team', 'sumba-kit' ),
			'add_new'               => __( 'Add New', 'sumba-kit' ),
			'add_new_item'          => __( 'Add New Team', 'sumba-kit' ),
			'edit_item'             => __( 'Edit Team', 'sumba-kit' ),
			'view_item'             => __( 'View Team', 'sumba-kit' ),
			'view_items'            => __( 'View Teams', 'sumba-kit' ),
			'search_items'          => __( 'Search Teams', 'sumba-kit' ),
			'not_found'             => __( 'No Teams found', 'sumba-kit' ),
			'not_found_in_trash'    => __( 'No Teams found in trash', 'sumba-kit' ),
			'parent_item_colon'     => __( 'Parent Team:', 'sumba-kit' ),
			'menu_name'             => __( 'Teams', 'sumba-kit' ),
		),
		'public'                => true,
		'hierarchical'          => false,
		'show_ui'               => true,
		'show_in_nav_menus'     => true,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'has_archive'           => true,
		'rewrite'               => array('slug' => $team_permalink),
		'query_var'             => true,
		'menu_icon'             => 'dashicons-vault',
		'show_in_rest'          => true,
		'rest_base'             => 'team',
		'rest_controller_class' => 'WP_REST_Posts_Controller',
	) );

}
add_action( 'init', 'sumbakit_team_init' );

/**
 * Sets the post updated messages for the `team` post type.
 *
 * @param  array $messages Post updated messages.
 * @return array Messages for the `team` post type.
 */
function team_updated_messages( $messages ) {
	global $post;

	//$options = Sumbawp_Base::option();
	//$team_permalink = $options->get('team_permalink');
	//$permalink = ($team_permalink) ? $team_permalink : get_permalink( $post );
	$permalink = get_permalink( $post );

	$messages['team'] = array(
		0  => '', // Unused. Messages start at index 1.
		/* translators: %s: post permalink */
		1  => sprintf( __( 'Team updated. <a target="_blank" href="%s">View Team</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		2  => __( 'Custom field updated.', 'sumba-kit' ),
		3  => __( 'Custom field deleted.', 'sumba-kit' ),
		4  => __( 'Team updated.', 'sumba-kit' ),
		/* translators: %s: date and time of the revision */
		5  => isset( $_GET['revision'] ) ? sprintf( __( 'Team restored to revision from %s', 'sumba-kit' ), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
		/* translators: %s: post permalink */
		6  => sprintf( __( 'Team published. <a href="%s">View Team</a>', 'sumba-kit' ), esc_url( $permalink ) ),
		7  => __( 'Team saved.', 'sumba-kit' ),
		/* translators: %s: post permalink */
		8  => sprintf( __( 'Team submitted. <a target="_blank" href="%s">Preview Team</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
		/* translators: 1: Publish box date format, see https://secure.php.net/date 2: Post permalink */
		9  => sprintf( __( 'Team scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Team</a>', 'sumba-kit' ),
		date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( $permalink ) ),
		/* translators: %s: post permalink */
		10 => sprintf( __( 'Team draft updated. <a target="_blank" href="%s">Preview Team</a>', 'sumba-kit' ), esc_url( add_query_arg( 'preview', 'true', $permalink ) ) ),
	);

	return $messages;
}
add_filter( 'post_updated_messages', 'team_updated_messages' );



/**
 * Create a taxonomy
 *
 * @uses  Inserts new taxonomy object into the list
 * @uses  Adds query vars
 *
 * @param string  Name of taxonomy object
 * @param array|string  Name of the object type for the taxonomy object.
 * @param array|string  Taxonomy arguments
 * @return null|WP_Error WP_Error if errors, otherwise null.
 */
function sumbawp_team_category_taxonomy() {

	$team_cat_permalink = Sumbawp_Base::option('team_category_permalink');

	$labels = array(
		'name'                  => _x( 'Categories', 'Team Categories', 'sumba-kit' ),
		'singular_name'         => _x( 'Category', 'Team Category', 'sumba-kit' ),
		'search_items'          => __( 'Search Categories', 'sumba-kit' ),
		'popular_items'         => __( 'Popular Categories', 'sumba-kit' ),
		'all_items'             => __( 'All Categories', 'sumba-kit' ),
		'parent_item'           => __( 'Parent Category', 'sumba-kit' ),
		'parent_item_colon'     => __( 'Parent Category', 'sumba-kit' ),
		'edit_item'             => __( 'Edit Category', 'sumba-kit' ),
		'update_item'           => __( 'Update Category', 'sumba-kit' ),
		'add_new_item'          => __( 'Add New Category', 'sumba-kit' ),
		'new_item_name'         => __( 'New Category Name', 'sumba-kit' ),
		'add_or_remove_items'   => __( 'Add or remove Categories', 'sumba-kit' ),
		'choose_from_most_used' => __( 'Choose from most used Categories', 'sumba-kit' ),
		'menu_name'             => __( 'Category', 'sumba-kit' ),
	);

	$args = array(
		'labels'            => $labels,
		'public'            => true,
		'show_in_nav_menus' => true,
		'show_admin_column' => true,
		'hierarchical'      => true,
		'show_tagcloud'     => false,
		'show_ui'           => true,
		'query_var'         => true,
		'rewrite'           => array('slug' => $team_cat_permalink),
		'query_var'         => true,
		'capabilities'      => array(),
	);

	register_taxonomy( 'team_cat', array( 'team' ), $args );
}

add_action( 'init', 'sumbawp_team_category_taxonomy' );