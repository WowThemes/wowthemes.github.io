<?php

add_action( 'init', 'arkitekt_framework_init');

/**
 * Include Vafpress Framework
 */
require_once ARKITEKT_FR_PATH . 'includes/vafpress/bootstrap.php';

/**
 * Include Custom Data Sources
 */
require_once ARKITEKT_FR_PATH . 'includes/vafpress/admin/data_sources.php';


// shortocode generators
$tmpl_sg1  = ARKITEKT_FR_PATH . 'includes/vafpress/admin/shortcode_generator/shortcodes1.php';
$tmpl_sg2  = ARKITEKT_FR_PATH . 'includes/vafpress/admin/shortcode_generator/shortcodes2.php';

function arkitekt_framework_init()
{
	
	global $pagenow;
	/**
	 * Load options, metaboxes, and shortcode generator array templates.
	 */
	// metaboxes
	$tmpl_mb1  = include ARKITEKT_FR_PATH . 'includes/vafpress/admin/metabox/meta_boxes.php';
	// * Create instances of Metaboxes
	foreach( $tmpl_mb1 as $tmb )  new VP_Metabox($tmb);

	if( is_admin() ) {
		
		include_once ARKITEKT_FR_PATH . 'includes/helpers/backup_class.php';
		$backup = new SH_Backup_class;

		if( sh_set( $_GET, 'page' ) == SH_NAME.'_option' ) 
		{
			if( sh_set( $_GET, 'option_export' ) ){
				$backup->export();
			}
			
		}
	}	
	
	// options
	$tmpl_opt  = ARKITEKT_FR_PATH . 'includes/vafpress/admin/option/option.php';
	
	
	/**
	 * Create instance of Options
	 */
	$theme_options = new VP_Option(array(
		'is_dev_mode'           => false,                                  // dev mode, default to false
		'option_key'            => SH_NAME.'_theme_options',                      // options key in db, required
		'page_slug'             => SH_NAME.'_option',                      // options page slug, required
		'template'              => $tmpl_opt,                              // template file path or array, required
		'menu_page'             => 'themes.php',                           // parent menu slug or supply `array` (can contains 'icon_url' & 'position') for top level menu
		'use_auto_group_naming' => true,                                   // default to true
		'use_util_menu'         => true,                                   // default to true, shows utility menu
		'minimum_role'          => 'edit_theme_options',                   // default to 'edit_theme_options'
		'layout'                => 'fluid',                                // fluid or fixed, default to fixed
		'page_title'            => __( 'Theme Options', 'arkitekt' ), // page title
		'menu_label'            => __( 'Theme Options', 'arkitekt' ), // menu label
	));
	
	if ( function_exists( '_WHS' ) ) {
		_WSH()->user_extra( array('facebook'=>__('Facebook', 'arkitekt'), 'twitter'=>__('Twitter', 'arkitekt'), 'dribbble'=>__('Dribble', 'arkitekt'), 'github'=>__('Github', 'arkitekt'),
			'flickr'=>__('Flickr', 'arkitekt'), 'google-plus'=>__('Google+', 'arkitekt'), 'youtube'=>__('Youtube', 'arkitekt')) );
	}

	$sh_exlude_hooks = include_once ARKITEKT_FR_PATH . 'includes/resource/remove_action.php';

	foreach( $sh_exlude_hooks as $k => $v )
	{
		/*foreach( $v as $value )
		remove_action( $k, $value[0], $value[1] );*/
	}
	
	require_once ARKITEKT_FR_PATH . 'includes/thirdparty/lessc.inc.php';
}


include_once ARKITEKT_FR_PATH . 'includes/vp_new/loader.php';

require_once ARKITEKT_FR_PATH . 'includes/thirdparty/gallery.php';
require_once ARKITEKT_FR_PATH . 'includes/helpers/post_types.php';
require_once ARKITEKT_FR_PATH . 'includes/helpers/taxonomies.php';
require_once ARKITEKT_FR_PATH . 'includes/helpers/forms.php';

