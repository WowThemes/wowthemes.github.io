<?php
$options = array();
$options[] =  array(
	'id'          => 'sh_post_meta',
	'types'       => array('post'),
	'title'       => __('Post Settings', 'arkitekt'),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type'      => 'group',
						'repeating' => false,
						'length'    => 1,
						'name'      => 'sh_post_options',
						'title'     => __('General Post Settings', 'arkitekt'),
						'fields'    => 
						array(

							array(
								'type' => 'radioimage',
								'name' => 'layout',
								'label' => __('Page Layout', 'arkitekt'),
								'description' => __('Choose the layout for blog pages', 'arkitekt'),
								'items' => array(
									array(
										'value' => 'left',
										'label' => __('Left Sidebar', 'arkitekt'),
										'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
									),
									array(
										'value' => 'right',
										'label' => __('Right Sidebar', 'arkitekt'),
										'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
									),
									array(
										'value' => 'full',
										'label' => __('Full Width', 'arkitekt'),
										'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
									),
									
								),
							),
							
							array(
								'type' => 'select',
								'name' => 'sidebar',
								'label' => __('Sidebar', 'arkitekt'),
								'default' => '',
								'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()	
							),
							array(
								'type' => 'textbox',
								'name' => 'title',
								'label' => __('Banner Heading', 'arkitekt'),
								'default' => 'Single Post',
								'description'	=> esc_html__( 'Show the text in banner area', 'arkitekt' )
							),
							array(
								'type' => 'textarea',
								'name' => 'video',
								'label' => __('Video Embed Code', 'arkitekt'),
								'default' => '',
								'description' => __('If post format is video then this embed code will be used in content', 'arkitekt')
							),
							array(
								'type' => 'textarea',
								'name' => 'audio',
								'label' => __('Audio Embed Code', 'arkitekt'),
								'default' => '',
								'description' => __('If post format is AUDIO then this embed code will be used in content', 'arkitekt')
							),
							
						),
					),
				),
);

/* Page options */
$options[] =  array(
	'id'          => 'sh_page_meta',
	'types'       => array('page'),
	'title'       => __('Page Settings', 'arkitekt'),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type' => 'radioimage',
						'name' => 'layout',
						'label' => __('Page Layout', 'arkitekt'),
						'description' => __('Choose the layout for pages', 'arkitekt'),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Left Sidebar', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Right Sidebar', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					array(
								'type' => 'select',
								'name' => 'page_sidebar',
								'label' => __('Sidebar', 'arkitekt'),
								'default' => '',
								'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()	
							),
					array(
								'type' => 'toggle',
								'name' => 'show_bread_crums',
								'label' => __('Show Bread crums', 'arkitekt'),
								'default' => 1,
							),
				),
);
//downloads
$options[] =  array(
	'id'          => 'sh_download_meta',
	'types'       => array('download'),
	'title'       => __('Download Settings', 'arkitekt'),
	'priority'    => 'high',
	'template'    => 
			array(
					array(
						'type' => 'textbox',
						'name' => 'subtitle',
						'label' => __('Sub Title', 'arkitekt'),
						'default' => '',
					),
					array(
						'type' => 'upload',
						'name' => 'featured_image',
						'label' => __('Featured Image', 'arkitekt'),
						'default' => '',
						'description' => __('Featured image for detail download page', 'arkitekt'),
					),
					array(
						'type' => 'textbox',
						'name' => 'demo_link',
						'label' => __('Demo Link', 'arkitekt'),
						'default' => '',
					),
					array(
						'type' => 'textbox',
						'name' => 'version',
						'label' => __('Current Version', 'arkitekt'),
						'default' => '1.0',
					),
					array(
						'type' => 'date',
						'name' => 'release_date',
						'label' => __('Release Date', 'arkitekt'),
						'default' => '',
						'description' => __('Please choose the item release date', 'arkitekt')
					),
					array(
						'type' => 'date',
						'name' => 'update_date',
						'label' => __('Update Date', 'arkitekt'),
						'default' => '',
						'description' => __('Please choose the date when the item is updated', 'arkitekt')
					),
					array(
						'type' => 'textbox',
						'name' => 'author_name',
						'label' => __('Author', 'arkitekt'),
						'default' => '',
						'description' => __('Enter item\' Author Name', 'arkitekt')
					),
					array(
						'type' => 'textbox',
						'name' => 'requirements',
						'label' => __('Requirements', 'arkitekt'),
						'default' => '',
						'description' => __('Please enter the neccessory things required for this item', 'arkitekt')
					),
					array(
						'type' => 'toggle',
						'name' => 'show_features',
						'label' => __('Show Item Features', 'arkitekt'),
						'default' => 1,
					),
					array(
						'type' => 'textbox',
						'name' => 'feature_title',
						'label' => __('Feature Label', 'arkitekt'),
						'default' => __('Item Features', 'arkitekt'),
						'dependency' => array(
							'field' => 'show_features',
							'function' => 'vp_dep_boolean',
						),
					),
					array(
						'type' => 'textbox',
						'name' => 'feature_subtitle',
						'label' => __('Feature Sub Label', 'arkitekt'),
						'default' => __('Lets see all item features & updates below', 'arkitekt'),
						'dependency' => array(
							'field' => 'show_features',
							'function' => 'vp_dep_boolean',
						),
					),
					array(
						'type'      => 'group',
						'repeating' => true,
						'sortable'  => true,
						'length'    => 1,
						'name'      => 'item_features',
						'title'     => __('Item Features', 'arkitekt'),
						'dependency' => array(
							'field' => 'show_features',
							'function' => 'vp_dep_boolean',
						),
						'fields'    => 
						array(

							array(
								'type' => 'textbox',
								'name' => 'feature',
								'label' => __('Features', 'arkitekt'),
								'default' => '',
							),
							array(
								'type' => 'fontawesome',
								'name' => 'icon',
								'label' => __('Icon', 'arkitekt'),
								'default' => '',
								'description' => __('Choose icon that best represent the item feature', 'arkitekt')
							),
							array(
								'type' => 'textarea',
								'name' => 'desc',
								'label' => __('Feature Description', 'arkitekt'),
								'default' => '',
							),
							
						),
					),
				),
);

/** Portfolio Options */
$options[] =  array(
	'id'          => 'sh_portfolio_meta',
	'types'       => array('sh_portfolio'),
	'title'       => __('Portfolio Options', 'arkitekt'),
	'priority'    => 'high',
	'template'    => array(
		array(
			'type'      => 'group',
			'repeating' => false,
			'length'    => 1,
			'name'      => 'sh_portfolio_type',
			'title'     => __('Portfolio Type', 'arkitekt'),
			'fields'    => array(
				array(
					'type' => 'select',
					'name' => 'type',
					'label' => __('Type', 'arkitekt'),
					'default' => '',
					'items' => array(
						array('value' => 'image', 'label' => __('Image', 'arkitekt' ) ),
						array('value' => 'slider', 'label' => __('Slider', 'arkitekt' ) ),
						array('value' => 'video', 'label' => __('Video', 'arkitekt' ) ),
					),
					'description' => __('Choose the portfolio Type', 'arkitekt')
				),
				array(
					'type' => 'textarea',
					'name' => 'video',
					'label' => __('Video Embed Code', 'arkitekt'),
					'description' => __('Enter the video embed code', 'arkitekt'),
					'dependency' => array(
						'field'    => 'type',
						'function' => 'sh_dep_pb_dropdown',
					),
				),
				
			),
		),
		
		array(
			'type'      => 'group',
			'repeating' => false,
			'length'    => 1,
			'name'      => 'sh_page_options',
			'title'     => __('Portfolio Information', 'arkitekt'),
			'fields'    => array(
				array(
					'type' => 'select',
					'name' => 'sidebar',
					'label' => __('Sidebar', 'arkitekt'),
					'default' => '',
					'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
				),
				array(
					'type' => 'select',
					'name' => 'position',
					'label' => __('Content Position', 'arkitekt'),
					'items' => array(
						array('value' => 'left', 'label' => __('Left', 'arkitekt') ),
						array('value' => 'right', 'label' => __('Right', 'arkitekt') ),
					),
					'default' => 'left',
				),
				array(
					'type' => 'date',
					'name' => 'date',
					'label' => __('Release Date', 'arkitekt'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'client_name',
					'label' => __('Client Name', 'arkitekt'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'demo_link',
					'label' => __('Client URL', 'arkitekt'),
					'default' => 'http://example.com',
				),
				array(
					'type' => 'textbox',
					'name' => 'author',
					'label' => __('Author', 'arkitekt'),
					'default' => 'Derek Andorson',
				),
				array(
					'type' => 'textbox',
					'name' => 'website',
					'label' => __('Webstie URL', 'arkitekt'),
					'default' => 'http://example.com',
				),
				array(
					'type' => 'color',
					'name' => 'portfolio_color',
					'label' => __('Portfolio Color', 'arkitekt'),
					'default' => '',
				),
			),
		),
		array(
			'type'      => 'group',
			'repeating' => true,
			'sortable'  => true,
			'name'      => 'sh_skills',
			'title'     => __('Skills', 'arkitekt'),
			'fields'    => array(
				array(
					'type' => 'textbox',
					'name' => 'skill',
					'label' => __('Skill', 'arkitekt'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'link',
					'label' => __('URL', 'arkitekt'),
					'default' => 'http://example.com',
				),
			),
		),
	),
);


/** Team meta*/
$options[] =  array(
	'id'          => '_sh_team_meta',
	'types'       => array('sh_team'),
	'title'       => __('Team Settings', 'arkitekt'),
	'priority'    => 'high',
	'template'    => array(
			   array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', 'arkitekt'),
					'description' => __('Enter the designation of the member', 'arkitekt'),
					'default' => '',
				),
			   array(
					'type'      => 'group',
					'repeating' => true,
					'sortable'  => true,
					'length'    => 1,
					'name'      => 'social_icon_group',
					'title'     => __('Social icons', 'arkitekt'),
					
					'fields'    => 
					array(

						array(
							'type' => 'textbox',
							'name' => 'title',
							'label' => __('Title', 'arkitekt'),
							'default' => '',
						),
						array(
							'type' => 'textbox',
							'name' => 'social_url',
							'label' => __('URL', 'arkitekt'),
							'default' => '',
						),
						array(
								'type' => 'select',
								'name' => 'social_icon',
								'label' => __('Social icon', 'arkitekt'),
								'description' => __('Choose the social icon from the list', 'arkitekt'),
								'default' => '',
								'items' => array(
									'data' => array(
												array(
           												'source' => 'function',
           												'value' => 'vp_get_social_medias',
         											   ),
         											),
        										 ),
						),
						
					),
				),
				
				
	),
);



/** Testimonial Options*/
$options[] =  array(
	'id'          => 'sh_testimonial_options',
	'types'       => array('sh_testimonial'),
	'title'       => __('Testimonials Options', 'arkitekt'),
	'priority'    => 'high',
	'template'    => array(
				array(
					'type' => 'textbox',
					'name' => 'author',
					'label' => __('Author', 'arkitekt'),
					'default' => 'John Baba g',
				),
				
				array(
					'type' => 'textbox',
					'name' => 'designation',
					'label' => __('Designation', 'arkitekt'),
					'default' => '',
				),
				array(
					'type' => 'textbox',
					'name' => 'company',
					'label' => __('Company', 'arkitekt'),
					'default' => 'Artex',
				),
				
	),
);

/** Partner Options Options*/
$options[] =  array(
	'id'          => 'sh_partner_meta',
	'types'       => array('sh_partner'),
	'title'       => __('Partner Options', 'arkitekt'),
	'priority'    => 'high',
	'template'    => array(
						
			array(
				'type' => 'textbox',
				'name' => 'link',
				'label' => __('Partner URL', 'arkitekt'),
				'default' => '',
			),
	),
);

$options[] =  array(
	'id'          => 'sh_services_option',
	'types'       => array( 'sh_service' ),
	'title'       => __('Service Settings', 'arkitekt'),
	'priority'    => 'high',
	'template'    => 

			array(
				
				array(
					'type' => 'fontawesome',
					'name' => 'fontawesome',
					'label' => __('Service Icon', 'arkitekt'),
					'default' => '',
				),
					array(
					'type' => 'textbox',
					'name' => 'services_url',
					'label' => __('Enter Services URL', 'arkitekt'),
					'default' => '',
				),
				
				
	),
);

 
 return $options;
 
 
 
 
 
 
 
 