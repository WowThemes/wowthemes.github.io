<?php

return array(
	'title' => __('Arkitekt Theme Options', 'arkitekt'),
	'logo' => get_template_directory_uri().'/images/logo.png',
	'menus' => array(
		array(
			'title' => __('General Settings', 'arkitekt'),
			'name' => 'general_settings',
			'icon' => 'font-awesome:icon-cogs',
			'menus' => array(
				array(
					'title' => __('General Settings', 'arkitekt'),
					'name' => 'general_settings',
					'icon' => 'font-awesome:icon-cogs',
					'controls' => array(
						array(
                            'type' => 'toggle',
                            'name' => 'enable_rtl',
                            'label' => __( 'Enable RTL', 'arkitekt' ),
                            'description' => __( 'Click to enable RTL support on the website', 'arkitekt' ),
                            'default' => '',
                        ),						
						array(
							'type' => 'color',
							'name' => 'color_scheme',
							'label' => __('Color Scheme', 'arkitekt'),
							'description' => __('Choose the color scheme for website', 'arkitekt'),
							'default' => '#4eccb9',
						),
				    array(
							 'type' => 'section',
							 'title' => __('Boxed Version Settings', 'arkitekt'),
							 'name' => 'boxed_version_settings',
							 'description' => __('This section contain the information about boxed version settings', 'arkitekt'),
							 'fields' => array(
							array(
								'type' => 'toggle',
								'name' => 'boxed_version',
								'label' => __('Boxed Version for Whole Website', 'arkitekt'),
								'description' => __('Enable or disable boxed version for all pages', 'arkitekt'),
								'default' => '',
							),
							array(
	                           'type' => 'upload',
	                            'name' => 'body_bg_img',
	                            'label' => __( 'Background Image', 'arkitekt' ),
	                            'description' => __( 'Shown on box version', 'arkitekt' ),
	                            'default' => '' 
	                         ),
							array(
								'type' => 'toggle',
								'name' => 'boxed_background_repeat',
								'label' => __('Boxed background image Repeat', 'arkitekt'),
								'description' => __('Enable or disable boxed background Image', 'arkitekt'),
								'default' => '',
							),
							array(
								'type' => 'toggle',
								'name' => 'background_attached_img',
								'label' => __('Boxed background image Scroll', 'arkitekt'),
								'description' => __('Enable or disable Background Position', 'arkitekt'),
								'default' => '',
							),
							array(
								'type' => 'select',
								'name' => 'horizontal_position',
								'label' => __( 'horizontal Position', 'arkitekt' ),
								'description' => __( 'Select horizontal positiion', 'arkitekt' ),
								'default' => '',
								'items' => array(
									 array(
										'value' => 'left',
										'label' => __( 'Left', 'arkitekt' ),
									),
									array(
										'value' => 'center',
										'label' => __( 'Center', 'arkitekt' ),
									),
									array(
										'value' => 'right',
										'label' => __( 'Right', 'arkitekt' ),
									),
								),
							),
							array(
								'type' => 'select',
								'name' => 'vertical_position',
								'label' => __( 'Vertical Position', 'arkitekt' ),
								'description' => __( 'Select vertical positiion', 'arkitekt' ),
								'default' => '',
								'items' => array(
									 array(
										'value' => 'top',
										'label' => __( 'Top', 'arkitekt' ),
									),
									 array(
										'value' => 'center',
										'label' => __( 'Center', 'arkitekt' ),
									),
									array(
										'value' => 'bottom',
										'label' => __( 'Bottom', 'arkitekt' ),
									),
								),
							),
					),
                    ),
						array(
							'type' => 'toggle',
							'name' => 'dark_version',
							'label' => __('Dark Version for Whole Website', 'arkitekt'),
							'description' => __('Enable or disable darked version for all pages', 'arkitekt'),
							'default' => '',
						),
						array(
							 'type' => 'section',
							 'title' => __('Twitter Settings', 'arkitekt'),
							 'name' => 'twitter_settings',
							 'description' => __('This section contain the information about twitter api settings', 'arkitekt'),
							 'fields' => array(
							  		array(
							   			'type' => 'textbox',
							   			'name' => 'api',
							   			'label' => __('API Key', 'arkitekt'),
							   			'description' => __('Enter the twitter API key, You can get the api at http://developer.twitter.com', 'arkitekt'),
							   			'default' => '',
							  			),
							  		array(
							   			'type' => 'textbox',
							   			'name' => 'api_secret',
							   			'label' => __('API Secret', 'arkitekt'),
							   			'description' => __('Enter the API secret', 'arkitekt'),
							   			'default' => '',
							  			),
							  		array(
							   			'type' => 'textbox',
							   			'name' => 'token',
							   			'label' => __('Token', 'arkitekt'),
							   			'description' => __('Enter the twitter api token', 'arkitekt'),
							   			'default' => '',
							  			),
							  		array(
							   			'type' => 'textbox',
							   			'name' => 'token_secret',
							   			'label' => __('Token Secret', 'arkitekt'),
							   			'description' => __('Enter the API token secret', 'arkitekt'),
							   			'default' => '',
							  ),
							  
							 ),
							),
								array(
								 'type' => 'section',
								'repeating' => true,
								'sortable' => true,
								'title' => __( 'Purchase Information', 'arkitekt' ),
								'name' => 'purchase_information',
								'description' => __( 'To get the auto theme updates provide purchase information', 'arkitekt' ),
								'fields' => array(
								 
								array(
									'type' => 'textbox',
									'name' => 'sh_purchase_code',
									'label' => __( 'Purchase Code', 'arkitekt' ),
									'description' => __( 'To find the purchase code to TF downloads tab click on Download then choose "License and Purchase code"', 'arkitekt' ),
									'default' => '',
								),
								array(
									'type' => 'textbox',
									'name' => 'sh_purchase_user',
									'label' => __( 'Themeforest Username', 'arkitekt' ),
									'description' => __( 'Enter your themeforest username', 'arkitekt' ),
									'default' => '',
										),
										
									) 
								),
								
							array(
								'type' => 'section',
								'repeating' => true,
								'sortable' => true,
								'title' => __( 'Captcha Information', 'arkitekt' ),
								'name' => 'captcha_information',
								'description' => __( 'To enable captcha on contact form please provide the following information', 'arkitekt' ),
								'fields' => array(
								 
									   array(
											'type' => 'toggle',
											'name' => 'captcha_box',
											'label' => __('Enable Google Captcha', 'arkitekt'),
											'description' => __('enable or disable google capcha on contact form', 'arkitekt'),
											'default' => '',
										),
										array(
											'type' => 'textbox',
											'name' => 'private_key',
											'label' => __( 'Private Key', 'arkitekt' ),
											'description' => __( 'Kindly provide the private key of your site google recaptcha', 'arkitekt' ),
											'default' => '',
										),
										array(
											'type' => 'textbox',
											'name' => 'public_key',
											'label' => __( 'Public Key', 'arkitekt' ),
											'description' => __( 'Kindly provide the public key of your site google recaptcha', 'arkitekt' ),
											'default' => '',
										),
										
												
									) 
								),
				
						
					),
				),
				
				/** Submenu for heading settings */
				array(
					'title' => __('Header Settings', 'arkitekt'),
					'name' => 'header_settings',
					'icon' => 'font-awesome:icon-strikethrough',
					'controls' => array(
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Top bar settings', 'arkitekt'),
							'name' => 'top_bar',
							'description' => __('This section is used for top bar menues', 'arkitekt'),
							'fields' => array(
								array(
									'type' => 'select',
									'name' => 'policy_page',
									'label' => __('Policy Page', 'arkitekt'),
									'description' => __('choose policy page to show in header area, left it if you don\'t want to show poclicy link in header', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
												),
											),
										)
									),
								array(
									'type' => 'select',
									'name' => 'aboutus_page',
									'label' => __('About Us', 'arkitekt'),
									'description' => __('choose About us page to show in header area, left it if you don\'t want to show About us link in header', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
											),
										),
									)
								),
								array(
									'type' => 'select',
									'name' => 'login_page',
									'label' => __('login', 'arkitekt'),
									'description' => __('choose login page to show in header area, left it if you don\'t want to show login link in header', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
											),
										),
									)
								),
								array(
									'type' => 'select',
									'name' => 'contactus_page',
									'label' => __('contact us', 'arkitekt'),
									'description' => __('choose login page to show in header area, left it if you don\'t want to show login link in header', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_pages',
											),
										),
									)
								),
								
							),
						),
						
						
						array(
							'type' => 'select',
							'name' => 'logo_type',
							'label' => __('Logo Type', 'arkitekt'),
							'description' => __('Choose logo type', 'arkitekt'),
							'items' => array( array('value'=>'text', 'label'=>'Logo With Text'), array('value'=>'image', 'label'=>'Logo With Image'), ),
							'default' => 'logo'
						),
						
						array(
							'type' => 'section',
							'title' => __('Logo with Image', 'arkitekt'),
							'name' => 'logo_with_image',
							'dependency' => array(
								'field' => 'logo_type',
								'function' => 'vp_dep_is_logo',
							),
							'fields' => array(
								array(
									'type' => 'upload',
									'name' => 'logo_image',
									'label' => __('Logo Image', 'arkitekt'),
									'description' => __('Inser the logo image', 'arkitekt'),
									'default' => get_template_directory_uri().'/images/logo.png'
								),
								array(
									'type' => 'slider',
									'name' => 'logo_width',
									'label' => __('Logo Width', 'arkitekt'),
									'description' => __('choose the logo width', 'arkitekt'),
									'default' => '196',
									'mix' => 20,
									'max' => 400
								),
								array(
									'type' => 'slider',
									'name' => 'logo_height',
									'label' => __('Logo Height', 'arkitekt'),
									'description' => __('choose the logo height', 'arkitekt'),
									'default' => '43',
									'mix' => 20,
									'max' => 400
								),
								
							),
						),
						array(
							'type' => 'section',
							'title' => __('Custom Logo Text', 'arkitekt'),
							'name' => 'section_custom_logo_text',
							'dependency' => array(
								'field' => 'logo_type',
								'function' => 'vp_dep_is_text',
							),
							'fields' => array(
								array(
									'type' => 'textbox',
									'name' => 'logo_heading',
									'label' => __('Logo Heading', 'arkitekt'),
									'description' => __('Enter the website heading instead of logo', 'arkitekt'),
									'default' => 'Aplus'
								),
								array(
									'type' => 'slider',
									'name' => 'logo_font_size',
									'label' => __('Logo Font Size', 'arkitekt'),
									'description' => __('Choose the logo font size', 'arkitekt'),
									'default' => 40,
									'min' => 12,
									'max' => 45
								),
								array(
									'type' => 'select',
									'name' => 'logo_font_face',
									'label' => __('Logo Font Face', 'arkitekt'),
									'description' => __('Select Font', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_gwf_family',
											),
										),
									),
								),
								array(
									'type' => 'radiobutton',
									'name' => 'logo_font_style',
									'label' => __('Logo Font Style', 'arkitekt'),
									'description' => __('Select Font Style', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'binding',
												'field' => 'logo_font_face',
												'value' => 'vp_get_gwf_style',
											),
										),
									),
									'default' => array(
										'{{first}}',
									),
								),
								array(
									'type' => 'color',
									'name' => 'logo_color',
									'label' => __('Logo Color', 'arkitekt'),
									'description' => __('Choose the default color for logo.', 'arkitekt'),
									'default' => '#98ed28',
								),
								array(
									'type' => 'textbox',
									'name' => 'slogan_heading',
									'label' => __('Slogan Heading', 'arkitekt'),
									'description' => __('Enter the slogan', 'arkitekt'),
									'default' => 'Multipurpose Wordpress theme'
								),
								array(
									'type' => 'slider',
									'name' => 'slogan_font_size',
									'label' => __('Slogan Font Size', 'arkitekt'),
									'description' => __('Choose the slogan font size', 'arkitekt'),
									'default' => 40,
									'min' => 12,
									'max' => 45
								),
								array(
									'type' => 'select',
									'name' => 'slogan_font_face',
									'label' => __('Slogan Font Face', 'arkitekt'),
									'description' => __('Select Font', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'function',
												'value' => 'vp_get_gwf_family',
											),
										),
									),
								),
								array(
									'type' => 'radiobutton',
									'name' => 'slogan_font_style',
									'label' => __('Slogan Font Style', 'arkitekt'),
									'description' => __('Select Font Style', 'arkitekt'),
									'items' => array(
										'data' => array(
											array(
												'source' => 'binding',
												'field' => 'slogan_font_face',
												'value' => 'vp_get_gwf_style',
											),
										),
									),
									'default' => array(
										'{{first}}',
									),
								),
								array(
									'type' => 'color',
									'name' => 'slogan_color',
									'label' => __('Slogan Color', 'arkitekt'),
									'description' => __('Choose the default color for slogan.', 'arkitekt'),
									'default' => '#98ed28',
								),
							),
						),
						array(
							'type' => 'codeeditor',
							'name' => 'header_css',
							'label' => __('Header CSS', 'arkitekt'),
							'description' => __('Write your custom css to include in header.', 'arkitekt'),
							'theme' => 'github',
							'mode' => 'css',
						),
						array(
							'type' => 'codeeditor',
							'name' => 'header_js',
							'label' => __('Header JS', 'arkitekt'),
							'description' => __('Write your custom js to include in header.', 'arkitekt'),
							'theme' => 'twilight',
							'mode' => 'javascript',
						),
					),
				
				),
				
				/** Submenu for footer area */
				array(
					'title' => __('Footer Settings', 'arkitekt'),
					'name' => 'footer_settings',
					'icon' => 'font-awesome:icon-gear',
					'controls' => array(
						
						array(
							'type' => 'toggle',
							'name' => 'info_box',
							'label' => __('Info Box', 'arkitekt'),
							'description' => __('enable or disable info-box', 'arkitekt'),
							'default' => '',
						),
						array(
								'type' => 'builder',
								'repeating' => true,
								'sortable'  => true,
								'label' => __('Info Items', 'arkitekt'),
								'name' => 'info_items',
								'description' => __('This section is used for info items', 'arkitekt'),
								'fields' => array(
									array(
										'type' => 'fontawesome',
										'name' => 'info_box_icon',
										'label' => __('Choos info icon', 'arkitekt'),
										'description' => __('Choose an icon from the font icons list', 'arkitekt'),
										'default' => '',
									),
									array(
										'type' => 'textbox',
										'name' => 'info_text',
										'label' => __('Info Text', 'arkitekt'),
										
										'default' => '',
									),
									
								),
						),
						array(
							'type' => 'toggle',
							'name' => 'footer_widget_area',
							'label' => __('Widget Area', 'arkitekt'),
							'description' => __('Show or hide widget area in footer', 'arkitekt'),
							'default'	=> 0
						),
						array(
							'type' => 'textarea',
							'name' => 'copyright_text',
							'label' => __('Footer Copyright Text', 'arkitekt'),
							'description' => __('Enter the copyright text to show in footer area', 'arkitekt'),
						),
						
						array(
							'type' => 'codeeditor',
							'name' => 'footer_js',
							'label' => __('Footer JS', 'arkitekt'),
							'description' => __('Write your custom js to include in footer.', 'arkitekt'),
							'theme' => 'twilight',
							'mode' => 'javascript',
						),
					)
				), //End of submenu
				
				/** Contact Settings */
				array(
					'title' => __('Sidebar Creator', 'arkitekt'),
					'name' => 'sidebar-creator',
					'icon' => 'font-awesome:icon-columns',
					'controls' => array(
						array(
							'type' => 'builder',
							'repeating' => true,
							'sortable'  => true,
							'label' => __('Dynamic Sidebar', 'arkitekt'),
							'name' => 'dynamic_sidebar',
							'description' => __('This section is used for theme color settings', 'arkitekt'),
							'fields' => array(
								array(
									'type' => 'textbox',
									'name' => 'sidebar_name',
									'label' => __('Sidebar Name', 'arkitekt'),
									'description' => __('Choose the default color scheme for the theme.', 'arkitekt'),
									'default' => __('Dynamic Sidebar', 'arkitekt'),
								),
								
							),
						),
					)
				),
			),
			
		),
		
		/** Sidebar Settings*/
		array(
				'title' => __('Sidebar Settings', 'arkitekt'),
				'name' => 'sidebar_settings',
				'icon' => 'font-awesome:icon-gear',
				'controls' => array(
						
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Category Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section2',
							'description' => __('This section contains category sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'category_sidebar_layout',
								'label' => __('Category Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'category_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Archive Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section3',
							'description' => __('This section contains Archive Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'archive_sidebar_layout',
								'label' => __('Archive Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'archive_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Author Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section4',
							'description' => __('This section contains Author Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'author_sidebar_layout',
								'label' => __('Author Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'author_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Search Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section5',
							'description' => __('This section contains Search Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'search_sidebar_layout',
								'label' => __('Search Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'search_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Tag Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section6',
							'description' => __('This section contains Tag Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'tag_sidebar_layout',
								'label' => __('Tag Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'tag_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
												array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Single post page sidebar', 'arkitekt'),
							'name' => 'sidebar_setting_section7',
							'description' => __('This section contains Single post page Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'single_post_sidebar_layout',
								'label' => __('Product Category Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'single_post_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
						array(
							'type' => 'section',
							'repeating' => true,
							'sortable'  => true,
							'title' => __('Product Category Sidebar Settings', 'arkitekt'),
							'name' => 'sidebar_setting_section8',
							'description' => __('This section contains Product Category Sidebar settings', 'arkitekt'),
							'fields' => array(
								array(
								'type' => 'radioimage',
								'name' => 'product_category_sidebar_layout',
								'label' => __('Product Category Sidebar', 'arkitekt'),
								'description' => '',
								'items' => array(
											 array(
												'value' => 'full',
												'label' => __('Full Width', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
												),
	
											 array(
												'value' => 'left',
												'label' => __('Left Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
												),
											 array(
												'value' => 'right',
												'label' => __('Right Sidebar', 'arkitekt'),
												'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
												),
			 
											),
										),
										array(
											'type' => 'select',
											'name' => 'product_category_sidebar',
											'label' => __('Sidebar', 'arkitekt'),
											'description' => __('Choose an sidebar for this', 'arkitekt'),
											'default' => '',
											'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
										),

							),
						),
				)
			),
			
			
		/** Contact Settings */
		array(
				'title' => __('Contact Settings', 'arkitekt'),
				'name' => 'contact_settings',
				'icon' => 'font-awesome:icon-envelope',
				'controls' => array(
					array(
						'type'      => 'toggle',
						'name'      => 'contact_captcha_status',
						'label'     => __('Captcha Status', 'arkitekt'),
						'description' => '',
						'default'	=> '',
					),
					array(
						'type'      => 'textarea',
						'name'      => 'google_map',
						'label'     => __('Google Map Code', 'arkitekt'),
						'description' => '',
						'default'	=> '',
					),
					array(
						'type' => 'textbox',
						'name' => 'map_api',
						'label' => __( 'Google Map API', 'arkitekt' ),
						'description' => __( 'Enter Google Map API key Here.', 'arkitekt' ),
						'default' => '' 
					),
				)
			),
			
		/** Social Network Settings */
		array(
				'title' => __('Socializing Settings', 'arkitekt'),
				'name' => 'socializing_settings',
				'icon' => 'font-awesome:icon-share-sign',
				'controls' => array(
					
					array(
						'type' => 'builder',
						'repeating' => true,
						'sortable'  => true,
						'label' => __('Social Icons', 'arkitekt'),
						'name' => 'social_icons',
						'description' => __('This section is used for theme color settings', 'arkitekt'),
						'fields' => array(
							array(
								'type' => 'select',
								'name' => 'icon',
								'label' => __('Social Icon', 'arkitekt'),
								
								'default' => 'facebook',
								'items' => array(
									'data' => array(
										array(
											'source' => 'function',
											'value' => 'vp_get_social_medias',
										),
									),
								),
							),
							array(
								'type' => 'textbox',
								'name' => 'title',
								'label' => __('Title', 'arkitekt'),
								
								'default' => '',
							),
							array(
								'type' => 'textbox',
								'name' => 'link',
								'label' => __('URL', 'arkitekt'),
								
								'default' => '',

							),
							
						),
					),
					
					
				)
			),
		
		
		/** Font settings */	
		array(
				'title' => __('Font Settings', 'arkitekt'),
				'name' => 'font_settings',
				'icon' => 'font-awesome:icon-font',
				'menus' => array(
					
					/** heading font settings */
					array(
						'title' => __('Heading Font', 'arkitekt'),
						'name' => 'heading_font_settings',
						'icon' => 'font-awesome:icon-text-height',
						
						'controls' => array(
							
							array(
								'type' => 'toggle',
								'name' => 'use_custom_font',
								'label' => __('Use Custom Font', 'arkitekt'),
								'description' => __('Use custom font or not', 'arkitekt'),
							),
							array(
								'type'  => 'section',
								'title' => __('H1 Settings', 'arkitekt'),
								'name'  => 'h1_settings',
								'description' => __('heading 1 font settings', 'arkitekt'),
								'dependency' => array(
									'field' => 'use_custom_font',
									'function' => 'vp_dep_boolean',
								),
								'fields' => array(
									array(
										'type' => 'slider',
										'label' => __('Font Size', 'arkitekt'),
										'name' => 'h1_font_size',
										'description' => __('Choose the font size for h1', 'arkitekt'),
										'default'=>'38.5',
										'min' => 12,
										'max' => 50
									),
									array(
										'type' => 'select',
										'label' => __('Font Family', 'arkitekt'),
										'name' => 'h1_font_family',
										'description' => __('Select the font family to use for h1', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'function',
													'value' => 'vp_get_gwf_family',
												),
											),
										),
										
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h1_font_style',
										'label' => __('Font Style', 'arkitekt'),
										'description' => __('Select Font Style', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h1_font_family',
													'value' => 'vp_get_gwf_style',
												),
											),
										),
										'default' => array(
											'{{first}}',
										),
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h1_font_weight',
										'label' => __('Font Weight', 'arkitekt'),
										'description' => __('Select Font Weight', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h1_font_family',
													'value' => 'vp_get_gwf_weight',
												),
											),
										),
									),
									array(
										'type' => 'color',
										'name' => 'h1_font_color',
										'label' => __('Font Color', 'arkitekt'),
										'description' => __('Choose the font color for heading h1', 'arkitekt'),
										'default' => '#98ed28',
									),
								),
							),
							array(
								'type'  => 'section',
								'title' => __('H2 Settings', 'arkitekt'),
								'name'  => 'h2_settings',
								'description' => __('heading h2 font settings', 'arkitekt'),
								'dependency' => array(
									'field' => 'use_custom_font',
									'function' => 'vp_dep_boolean',
								),
								'fields' => array(
									array(
										'type' => 'slider',
										'label' => __('Font Size', 'arkitekt'),
										'name' => 'h2_font_size',
										'description' => __('Choose the font size for h2', 'arkitekt'),
										'default'=>'34.5',
										'min' => 12,
										'max' => 50
									),
									array(
										'type' => 'select',
										'label' => __('Font Family', 'arkitekt'),
										'name' => 'h2_font_family',
										'description' => __('Select the font family to use for h2', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'function',
													'value' => 'vp_get_gwf_family',
												),
											),
										),
										
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h2_font_style',
										'label' => __('Font Style', 'arkitekt'),
										'description' => __('Select Font Style', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h2_font_family',
													'value' => 'vp_get_gwf_style',
												),
											),
										),
										'default' => array(
											'{{first}}',
										),
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h2_font_weight',
										'label' => __('Font Weight', 'arkitekt'),
										'description' => __('Select Font Weight', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h2_font_family',
													'value' => 'vp_get_gwf_weight',
												),
											),
										),
									),
									array(
										'type' => 'color',
										'name' => 'h2_font_color',
										'label' => __('Font Color', 'arkitekt'),
										'description' => __('Choose the font color for heading h1', 'arkitekt'),
										'default' => '#98ed28',
									),
								),
							),
							array(
								'type'  => 'section',
								'title' => __('H3 Settings', 'arkitekt'),
								'name'  => 'h3_settings',
								'description' => __('heading h3 font settings', 'arkitekt'),
								'dependency' => array(
									'field' => 'use_custom_font',
									'function' => 'vp_dep_boolean',
								),
								'fields' => array(
									array(
										'type' => 'slider',
										'label' => __('Font Size', 'arkitekt'),
										'name' => 'h3_font_size',
										'description' => __('Choose the font size for h3', 'arkitekt'),
										'default'=>'30.5',
										'min' => 12,
										'max' => 50
									),
									array(
										'type' => 'select',
										'label' => __('Font Family', 'arkitekt'),
										'name' => 'h3_font_family',
										'description' => __('Select the font family to use for h3', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'function',
													'value' => 'vp_get_gwf_family',
												),
											),
										),
										
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h3_font_style',
										'label' => __('Font Style', 'arkitekt'),
										'description' => __('Select Font Style', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h3_font_family',
													'value' => 'vp_get_gwf_style',
												),
											),
										),
										'default' => array(
											'{{first}}',
										),
									),
									array(
										'type' => 'radiobutton',
										'name' => 'h3_font_weight',
										'label' => __('Font Weight', 'arkitekt'),
										'description' => __('Select Font Weight', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'h3_font_family',
													'value' => 'vp_get_gwf_weight',
												),
											),
										),
									),
									array(
										'type' => 'color',
										'name' => 'h3_font_color',
										'label' => __('Font Color', 'arkitekt'),
										'description' => __('Choose the font color for heading h3', 'arkitekt'),
										'default' => '#98ed28',
									),
								),
							),
						)
					),
					
					/** body font settings */
					array(
						'title' => __('Body Font', 'arkitekt'),
						'name' => 'body_font_settings',
						'icon' => 'font-awesome:icon-text-width',
						'controls' => array(
							array(
								'type' => 'toggle',
								'name' => 'body_custom_font',
								'label' => __('Use Custom Font', 'arkitekt'),
								'description' => __('Use custom font or not', 'arkitekt'),
							),
							array(
								'type'  => 'section',
								'title' => __('Body Font Settings', 'arkitekt'),
								'name'  => 'body_font_settings_1',
								'description' => __('body font settings', 'arkitekt'),
								'dependency' => array(
									'field' => 'body_custom_font',
									'function' => 'vp_dep_boolean',
								),
								'fields' => array(
									array(
										'type' => 'slider',
										'label' => __('Font Size', 'arkitekt'),
										'name' => 'body_font_size',
										'description' => __('Choose the font size for body area', 'arkitekt'),
										'default'=>'14',
										'min' => 12,
										'max' => 50
									),
									array(
										'type' => 'select',
										'label' => __('Font Family', 'arkitekt'),
										'name' => 'body_font_family',
										'description' => __('Select the font family to use for body', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'function',
													'value' => 'vp_get_gwf_family',
												),
											),
										),
										
									),
									array(
										'type' => 'radiobutton',
										'name' => 'body_font_style',
										'label' => __('Font Style', 'arkitekt'),
										'description' => __('Select Font Style', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'body_font_family',
													'value' => 'vp_get_gwf_style',
												),
											),
										),
										'default' => array(
											'{{first}}',
										),
									),
									array(
										'type' => 'radiobutton',
										'name' => 'body_font_weight',
										'label' => __('Font Weight', 'arkitekt'),
										'description' => __('Select Font Weight', 'arkitekt'),
										'items' => array(
											'data' => array(
												array(
													'source' => 'binding',
													'field' => 'body_font_family',
													'value' => 'vp_get_gwf_weight',
												),
											),
										),
									),
									array(
										'type' => 'color',
										'name' => 'body_font_color',
										'label' => __('Font Color', 'arkitekt'),
										'description' => __('Choose the font color for heading body', 'arkitekt'),
										'default' => '#98ed28',
									),
								),
							),
						)
					)
					
					
					
					
					
				)
		),
		
		/** Blog Listing Settings */
		array(
				'title' => __('Blog Settings', 'arkitekt'),
				'name' => 'blog_page_settings',
				'icon' => 'font-awesome:icon-rss',
				'controls' => array(
					
					array(
						'type' => 'radioimage',
						'name' => 'blog_layout',
						'label' => __('Blog Listing Layout', 'arkitekt'),
						'description' => __('Choose the layout for blog pages', 'arkitekt'),
						'items' => array(
							array(
								'value' => 'left',
								'label' => __('Blog with Left Sidebar', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cl.png',
							),
							array(
								'value' => 'right',
								'label' => __('Blog with Right Sidebar', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/2cr.png',
							),
							array(
								'value' => 'full',
								'label' => __('Full Width', 'arkitekt'),
								'img' => get_template_directory_uri().'/includes/vafpress/public/img/1col.png',
							),
							
						),
					),
					array(
						'type' => 'select',
						'name' => 'blog_sidebar',
						'label' => __('Sidebar', 'arkitekt'),
						
						'items' => (function_exists('arkitekt_get_sidebars')) ? arkitekt_get_sidebars(true) : array()
						
					),
				)
		),
	)
);



/**
 *EOF
 */