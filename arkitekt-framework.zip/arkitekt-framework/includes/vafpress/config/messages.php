<?php

return array(

	////////////////////////////////////////
	// Localized JS Message Configuration //
	////////////////////////////////////////

	/**
	 * Validation Messages
	 */
	'validation' => array(
		'alphabet'     => __('Value needs to be Alphabet', 'arkitekt'),
		'alphanumeric' => __('Value needs to be Alphanumeric', 'arkitekt'),
		'numeric'      => __('Value needs to be Numeric', 'arkitekt'),
		'email'        => __('Value needs to be Valid Email', 'arkitekt'),
		'url'          => __('Value needs to be Valid URL', 'arkitekt'),
		'maxlength'    => __('Length needs to be less than {0} characters', 'arkitekt'),
		'minlength'    => __('Length needs to be more than {0} characters', 'arkitekt'),
		'maxselected'  => __('Select no more than {0} items', 'arkitekt'),
		'minselected'  => __('Select at least {0} items', 'arkitekt'),
		'required'     => __('This is required', 'arkitekt'),
	),

	/**
	 * Import / Export Messages
	 */
	'util' => array(
		'import_success'    => __('Import succeed, option page will be refreshed..', 'arkitekt'),
		'import_failed'     => __('Import failed', 'arkitekt'),
		'export_success'    => __('Export succeed, copy the JSON formatted options', 'arkitekt'),
		'export_failed'     => __('Export failed', 'arkitekt'),
		'restore_success'   => __('Restoration succeed, option page will be refreshed..', 'arkitekt'),
		'restore_nochanges' => __('Options identical to default', 'arkitekt'),
		'restore_failed'    => __('Restoration failed', 'arkitekt'),
	),

	/**
	 * Control Fields String
	 */
	'control' => array(
		// select2 select box
		'select2_placeholder' => __('Select option(s)', 'arkitekt'),
		// fontawesome chooser
		'fac_placeholder'     => __('Select an Icon', 'arkitekt'),
	),

);

/**
 * EOF
 */