<?php

class Arkitekt_Post_types
{
	
	function __construct()
	{
		// Hook into the 'init' action
		add_action( 'init', array( $this, 'bistro_slider' ), 0 );
		
	}
	
	function labels( $names = '', $labels = array() )
	{
		$default =  array(
			'name'                => _x( 'Slides', 'Slides', 'arkitekt' ),
			'singular_name'       => _x( 'Slide', 'Slide', 'arkitekt' ),
			'menu_name'           => __( 'Slidr', 'arkitekt' ),
			'parent_item_colon'   => __( 'Parent Slide:', 'arkitekt' ),
			'all_items'           => __( 'All Slides', 'arkitekt' ),
			'view_item'           => __( 'View Slide', 'arkitekt' ),
			'add_new_item'        => __( 'Add New Slide', 'arkitekt' ),
			'add_new'             => __( 'New Slide', 'arkitekt' ),
			'edit_item'           => __( 'Edit Slide', 'arkitekt' ),
			'update_item'         => __( 'Update Slide', 'arkitekt' ),
			'search_items'        => __( 'Search Slides', 'arkitekt' ),
			'not_found'           => __( 'No Slides found', 'arkitekt' ),
			'not_found_in_trash'  => __( 'No Slides found in Trash', 'arkitekt' ),
		);
		
		foreach( $default as $k => $v ){
			$default[$k] = str_replace( array('Slide', 'Slides'), $names, $v);
		}
		$labels = wp_parse_args( $labels, $default );
		
		return $labels;
	}
	
	function args( $args = array() )
	{
		$default = array(
			'label'               => __( 'bistro_slider', 'arkitekt' ),
			'labels'              => array(),
			'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields'),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => false,
			'show_in_admin_bar'   => false,
			'menu_position'       => 5,
			'menu_icon'           => '',
			'can_export'          => true,
			'has_archive'         => false,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'rewrite'             => array(),
			'capability_type'     => 'post',
		);
		$args = wp_parse_args( $args, $default );
		return $args;
	}
	
	// Register Custom Post Type
	function bistro_slider() {

		
		$settings = include( get_template_directory().'/includes/resource/post_types.php');
		
		foreach( $options as $k => $v )
		{
			$labels = $this->labels(sh_set( $v, 'labels'), sh_set( $v, 'label_args' ) );	
	
			$rewrite = array(
				'slug'                => sh_set( $v, 'slug' ),
				'with_front'          => true,
				'pages'               => true,
				'feeds'               => false,
			);
		
			$args = $this->args( array('labels'=>$labels, 'supports'=>sh_set( $v, 'supports'), 'rewrite'=>$rewrite) );
			$args = wp_parse_args( sh_set( $v, 'args' ), $args );
			register_post_type( $k, $args );
		}

	}

}

new Arkitekt_Post_types;
