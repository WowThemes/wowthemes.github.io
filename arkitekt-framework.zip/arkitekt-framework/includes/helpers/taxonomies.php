<?php

class Arkitekt_Taxonomies
{
	function __construct()
	{
		// Hook into the 'init' action
		add_action( 'init', array($this, 'taxonomies'), 0 );
	}
	
	// Register Custom Taxonomy
	function taxonomies()  {
		$labels = array(
			'name'                       => _x( 'Category', 'Portfolio Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'portfolio_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'portfolio_category', 'sh_portfolio', $args );





		$labels = array(
			'name'                       => _x( 'Category', 'Portfolio Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'portfolio_gallery_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'portfolio_gallery_category', 'sh_portfolio_gallery', $args );



		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Testimonial Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'testimonial_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'testimonial_category', 'sh_testimonial', $args );
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Team Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'team_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'team_category', 'sh_team', $args );
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Partner Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'partner_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'partner_category', 'sh_partner', $args );
		
		
		$labels = array(
			'name'                       => _x( 'Category', 'Service Category', 'arkitekt' ),
			'singular_name'              => _x( 'Category', 'Category', 'arkitekt' ),
			'menu_name'                  => __( 'Category', 'arkitekt' ),
			'all_items'                  => __( 'All Categories', 'arkitekt' ),
			'parent_item'                => __( 'Parent Category', 'arkitekt' ),
			'parent_item_colon'          => __( 'Parent Category:', 'arkitekt' ),
			'new_item_name'              => __( 'New Category Name', 'arkitekt' ),
			'add_new_item'               => __( 'Add New Category', 'arkitekt' ),
			'edit_item'                  => __( 'Edit Category', 'arkitekt' ),
			'update_item'                => __( 'Update Category', 'arkitekt' ),
			'separate_items_with_commas' => __( 'Separate Categories with commas', 'arkitekt' ),
			'search_items'               => __( 'Search Categories', 'arkitekt' ),
			'add_or_remove_items'        => __( 'Add or remove Categories', 'arkitekt' ),
			'choose_from_most_used'      => __( 'Choose from the most used Categories', 'arkitekt' ),
		);
	
		$rewrite = array(
			'slug'                       => 'service_category',
			'with_front'                 => true,
			'hierarchical'               => true,
		);
	
		$args = array(
			'labels'                     => $labels,
			'hierarchical'               => true,
			'public'                     => true,
			'show_ui'                    => true,
			'show_admin_column'          => true,
			'show_in_nav_menus'          => true,
			'show_tagcloud'              => true,
			'rewrite'                    => $rewrite,
		);
	
		register_taxonomy( 'service_category', 'sh_service', $args );
	}
}

new Arkitekt_Taxonomies;
