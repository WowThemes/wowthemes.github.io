<?php
/**
 * @package Arkitekt Framework
 */
/*
Plugin Name: Arkitekt Framwork
Plugin URI: https://wptech.co/
Description: This plugin only supports the Arkitekt WordPress theme.
Version: 1.0.0
Author: Wptech
Author URI: https://themeforest.net/item/arkitekt-architecture-wordpress-theme/8682181
License: GPLv2 or later
Text Domain: arkitekt-framework
*/


defined('ARKITEKT_FR_PATH') || define('ARKITEKT_FR_PATH', plugin_dir_path( __FILE__ ) );
defined('ARKITEKT_FR_URL') || define('ARKITEKT_FR_URL', plugin_dir_url( __FILE__ ) );

defined('SH_NAME') || define('SH_NAME', 'wp_arkitekt');

require_once ARKITEKT_FR_PATH . 'includes/loader.php';

add_action( 'plugins_loaded', 'arkitekt_framework_textdomain' );


function arkitekt_framework_textdomain() {

	load_plugin_textdomain( 'arkitekt_framework', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' ); 
}

function arkitekt_add_shrtcode( $tag, $callback ) {
	add_shortcode( $tag, $callback );
}

add_action('arkitekt_include_codebird', 'arkitekt_include_codebird' );

function arkitekt_include_codebird() {
	require_once ARKITEKT_FR_PATH . 'includes/helpers/codebird.php';
}

function arkitekt_server($key) {

	return $_SERVER[$key];
}

function get_file_contents( $url, $args = array() ) {
	return file_get_contents($url, $args);
}

add_filter('arkitekt_mail', 'arkitekt_email' );

function arkitekt_email( $args ) {

	$default = array( 'to' => '', 'subject', '', 'message' => '', 'headers' => '', 'attachments' => array() );
	extract( wp_parse_args( $args, $default ));

	return wp_mail( $to, $subject, $message, $headers, $attachments );

}

function arkitekt_encode( $data){
	return base64_encode($url, $args);
}

function arkitekt_decode( $data){
	return base64_decode($url, $args);
}


